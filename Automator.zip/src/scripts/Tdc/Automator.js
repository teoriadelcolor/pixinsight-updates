/*
 ****************************************************************************
 * Automator Script
 *
 * Automator.js
 * Copyright (C) 2024 Jesús M. García Flores
 *
 * This script will help you automate the most common processes in Pixinisight.
 * Upgrade your license to activate Advanced processes.
 *
 *
 * If you wish to contact us you can do so by email at info@teoriadelcolor.es
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * Version history
 * 1.0     2024-10-28 first release v1
 *
 *
 ****************************************************************************
 */



#feature-id    Automator : Utilities > Automator

#feature-info  This script will help you automate the most common processes in Pixinisight. \
Upgrade your license to activate Advanced processes. \
<br/>\
Copyright &copy; 2024 Jesús M. García Flores.

#define TITLE "Automator"
#define VERSION "1.0.0"

#include <pjsr/Sizer.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/SectionBar.jsh>
#include <pjsr/Color.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdDialogCode.jsh>
#include "lib/process06.js"
#include "lib/process05.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process02.js"
#include "lib/process01.js"



// Variables globales para compartir con process01.js
var ProjecTypevar = "SHO";  // Valor inicial
var AlignmenTypevar = "Ha"; // Valor inicial
var OptionLinkRGB = "false";  // Deshabilitado por defecto
var PimageSii = "EMPTY";        // Valor inicial
var PimageHa = "EMPTY";         // Valor inicial
var PimageOiii = "EMPTY";       // Valor inicial
var PimageRed = "EMPTY";        // Valor inicial
var PimageGreen = "EMPTY";      // Valor inicial
var PimageBlue = "EMPTY";       // Valor inicial
var PimageLuminance = "EMPTY";  // Valor inicial
var Option1var = "OFF";         // Valor inicial para StarsRGB
var VarProcesStar = "OFF";  // Inicializamos la variable para saber cuando se está creando la capa de estrellas.
var Option2var = "ON";          // Valor inicial para 300pppResolution
var OptionGraXNoise = "OFF";    // Valor inicial para GraXNoise
var OptionStarXterminator = "ON";    // Valor inicial para StarX
var OptionBlurXterminator = "ON";    // Valor inicial para BlurX
var OptionGradient ="ON"; // Valor inicial para el Gradient
var OptionDBE = "OFF";          // Valor inicial para DBE
var OptionEnh = "OFF";            // Valor inicial para Enhanced
var MiraIconosvar = "SHO_Align";  // Valor inicial
var VarPGlobal = "EMPTY";  // Inicializamos la variable de proceso general.
var VarPGlobal2 ="EMPTY";
var VarPGlobal3 ="EMPTY";
var NewGreenValue = 0.0;  // Inicializamos NewGreenValue con 0.0
var NewMagentaValue = 1;  // Inicializamos NewMAgenta con 1
var NewStarsValue = 1;  // Inicializamos NewStarsValue
var NewProOptionValue = 100;  // Inicializamos NewStarsValue
var isStarProcess = false; //Valor de paso por MiraGreen2()
var OptionHSOvar = "ON";
var OptionProOne = "Dark Optimizer Areas";
var OptionMaskvar = "None";        // Inicialización por defecto
var OptionBlurMaskvar = "None";    // Inicialización por defecto
var OptionColorMaskvar = "Red channel"; // Inicialización por defecto
var OptionColorMaskHuevar = 10;     // Inicialización por defecto
var OptionColorMaskSatvar = 10;     // Inicialización por defecto
var OptionColorMaskLumvar = 10;     // Inicialización por defecto
var OptionSigmavar = 5.00;
var OptionSharpenNonstellar = 0.40;
var OptionMergePro0  = "<Select an Image>";
var OptionMergePro1  = "<Select an Image>";
var OptionMergePro2  = "<Select an Image>";
var OptionAdjvalue = 1;
var OptionshowMaskvar = "OFF";
var OptionTypeMaskvar = "None";
var OptionBlurMaskvar = "None";
var OptionRGBMaskvar = "None";
var OptionshowConsolRadio = "ON";
let previousMaskType = null;
let previousBlurOption = null;
var OptionNombVar = null;
var originalFilePath ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var startTime = Date.now();  // Inicializar startTime al inicio del script


console.clear();
//console.hide();



var totalTime = Date.now()

// Function to Apply Saturation Reduction in the Viewer
function MiraReduceSaturationInViewer(imageViewerControl, imageWindow) {
    if (!imageWindow || !imageWindow.mainView || imageWindow.mainView.isNull) {
        console.criticalln("Error: Invalid image window for saturation reduction.");
        return;
    }

    // Create a copy of the image to apply saturation reduction
    let imageToProcess = new Image(imageWindow.mainView.image);
    if (imageToProcess.isNull) {
        console.criticalln("Error: Could not create a copy of the image for processing.");
        return;
    }

    // Call MiraBajaSat to reduce the saturation and get the processed image
    let processedImage = MiraBajaSat(imageToProcess);
    if (!processedImage) {
        console.criticalln("Error: Saturation reduction failed.");
        return;
    }

    // Update the viewer control with the processed image
    fitImageToWindow(imageViewerControl, processedImage, false);
    imageViewerControl.show();
}


// Creación del diálogo principal
function IntegratorDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "Automator";
     // Set both minimum and maximum size to control window dimensions appropriately
    this.minWidth = 650;  // Set your desired minimum width here
    this.minHeight = 860; // Set your desired minimum height here

    this.maxHeight = 900; // Set your desired maximum height here
    this.maxWidth = 1200; // (Optional) Set your desired maximum width if needed

     this.setFixedSize();  // Makes the dialog fixed in size if you want no resizing at all.


    // Creación del contenedor de pestañas
    this.tabBox = new TabBox(this);

    // --- Tab 1: Integration ---
    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;

    // --- Tab 2: Horizoantal ---
    // Crear un HorizontalSizer para mantener los dos GroupBoxes en horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Espacio entre los elementos


    // --- GroupBox: Project Type ---
    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "Select Project type:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    // RadioButtons para Project Type
    this.projectLRGBRadioButton = new RadioButton(this);
    this.projectLRGBRadioButton.text = "LRGB";
    this.projectLRGBRadioButton.onClick = function () {
       ProjecTypevar = "LRGB";
       this.dialog.update();
    };

    this.projectRGBRadioButton = new RadioButton(this);
    this.projectRGBRadioButton.text = "RGB";
    this.projectRGBRadioButton.onClick = function () {
       ProjecTypevar = "RGB";
       this.dialog.update();
    };

    this.projectSHORadioButton = new RadioButton(this);
    this.projectSHORadioButton.text = "SHO";
    this.projectSHORadioButton.checked = true;
    this.projectSHORadioButton.onClick = function () {
       ProjecTypevar = "SHO";
       this.dialog.update();
    };

    this.projectHOORadioButton = new RadioButton(this);
    this.projectHOORadioButton.text = "HOO";
    this.projectHOORadioButton.onClick = function () {
       ProjecTypevar = "HOO";
       this.dialog.update();
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;

    this.projectTypeGroupBox.sizer.add(this.projectLRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectSHORadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectHOORadioButton);

    // --- GroupBox: Alignment Type ---
    this.alignmentGroupBox = new GroupBox(this.integrationPage);
    this.alignmentGroupBox.title = "Select Alignment:";
    this.alignmentGroupBox.sizer = new VerticalSizer;

    this.alignmentHaRadioButton = new RadioButton(this);
    this.alignmentHaRadioButton.text = "Project images (default)";
    this.alignmentHaRadioButton.checked = true;
    this.alignmentHaRadioButton.onClick = function () { AlignmenTypevar = "Ha"; };

    this.alignmentAllRadioButton = new RadioButton(this);
    this.alignmentAllRadioButton.text = "All images by Ha";
    this.alignmentAllRadioButton.onClick = function () { AlignmenTypevar = "All by Ha"; };

    this.alignmentGroupBox.sizer.margin = 6;
    this.alignmentGroupBox.sizer.spacing = 6;

    this.alignmentGroupBox.sizer.add(this.alignmentHaRadioButton);
    this.alignmentGroupBox.sizer.add(this.alignmentAllRadioButton);

    // Añadir los dos GroupBoxes al HorizontalSizer para que estén en la misma fila
    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.alignmentGroupBox);


    // --- GroupBox: Tagging ---
    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    function addTaggingControl(parentSizer, labelText, variableKey) {
        let label = new Label(this);
        label.text = labelText;
        label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
        parentSizer.add(label);

        let comboBox = new ComboBox(this);
        comboBox.editEnabled = false;
        comboBox.addItem("<Select an Image>");

        let windowList = ImageWindow.windows;

        for (let i = 0; i < windowList.length; i++) {
            let windowId = String(windowList[i].mainView.id);
            comboBox.addItem(windowId);
        }

        comboBox.onItemSelected = function (index) {
            let selectedText = comboBox.itemText(index);
            if (variableKey === "PimageSii") PimageSii = selectedText;
            if (variableKey === "PimageHa") PimageHa = selectedText;
            if (variableKey === "PimageOiii") PimageOiii = selectedText;
            if (variableKey === "PimageRed") PimageRed = selectedText;
            if (variableKey === "PimageGreen") PimageGreen = selectedText;
            if (variableKey === "PimageBlue") PimageBlue = selectedText;
            if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
        };

        parentSizer.add(comboBox);
    }

    this.taggingGroupBox.sizer.margin = 6;
    this.taggingGroupBox.sizer.spacing = 6;

    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Sii Image:", "PimageSii");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Ha Image:", "PimageHa");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Oiii Image:", "PimageOiii");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Red Image:", "PimageRed");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Green Image:", "PimageGreen");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Blue Image:", "PimageBlue");
    addTaggingControl.call(this, this.taggingGroupBox.sizer, "Select Luminance Image:", "PimageLuminance");



      // Agregar las pestañas al TabBox debajo de los 2 grupos
      this.tabBox.addPage(this.integrationPage, "Integration");


    // --- GroupBox: Project Options ---
    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "Select Project final options:";
    this.optionsGroupBox.sizer = new HorizontalSizer;

    // Crear un `VerticalSizer` para la primera columna
    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;

    // Checkboxes para la primera columna
      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;  // Predeterminado deshabilitado
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "ON";
          } else {
          OptionLinkRGB = "OFF";
         }
      };



     this.graXNoiseCheckBox = new CheckBox(this);
    this.graXNoiseCheckBox.text = "Run GraXNoise (need Internet connection)";
    this.graXNoiseCheckBox.checked = false;
    this.graXNoiseCheckBox.onClick = function () {
        OptionGraXNoise = this.checked ? "ON" : "OFF";
    };

    this.gradientCheckBox = new CheckBox(this);
    this.gradientCheckBox.text = "Run Gradient Reduction";
    this.gradientCheckBox.checked = true;
    this.gradientCheckBox.onClick = function () {
        OptionGradient = this.checked ? "ON" : "OFF";
    };



   // Creación del campo numérico GreenValor
   this.greenValueEdit = new NumericControl(this);
   this.greenValueEdit.label.text = "Green Reduction:";
   this.greenValueEdit.setRange(0.0, 1.0);  // Rango entre 0 y 1
   this.greenValueEdit.setPrecision(2);     // Dos decimales
   this.greenValueEdit.setValue(0.0);       // Valor inicial por defecto es 0.0

   // Evento para manejar la validación del valor y actualizar NewGreenValue
   this.greenValueEdit.onValueUpdated = function (value) {
    if (value < 0.0 || value > 1) {
        console.criticalln("Error: Green Valor must be between 0 and 1.");
    } else {
        NewGreenValue = value;  // Actualizamos NewGreenValue con el nuevo valor
    }
   };


    this.EnhCheckBox = new CheckBox(this);
    this.EnhCheckBox.text = "Final Image Enhanced";
    this.EnhCheckBox.checked = false;
    this.EnhCheckBox.onClick = function () {
        OptionEnh = this.checked ? "ON" : "OFF";
    };

    this.resolutionCheckBox = new CheckBox(this);
    this.resolutionCheckBox.text = "300ppi Resolution (Final Image)";
    this.resolutionCheckBox.checked = true;
    this.resolutionCheckBox.onClick = function () {
        Option2var = this.checked ? "ON" : "OFF";
    };

    // Añadir checkboxes a la primera columna
    column1Sizer.add(this.linkRGBChannels);
    column1Sizer.add(this.gradientCheckBox);
    column1Sizer.add(this.graXNoiseCheckBox);
    column1Sizer.add(this.greenValueEdit);
    column1Sizer.add(this.EnhCheckBox);
    column1Sizer.add(this.resolutionCheckBox);

    // Crear un `VerticalSizer` para la segunda columna
    let column2Sizer = new VerticalSizer;
    column2Sizer.spacing = 6;
    column2Sizer.margin = 6;

   // stars
    this.starsHSOCheckBox = new CheckBox(this);
    this.starsHSOCheckBox.text = "Create Star layer (Project)";
    this.starsHSOCheckBox.checked = true;
    let self = this; // Guardar referencia al contexto actual
   this.starsHSOCheckBox.onClick = function () {
    // Cambiar el valor de OptionHSOvar dependiendo de si la opción está activada o desactivada
    OptionHSOvar = this.checked ? "ON" : "OFF";

    // Si la opción HSO está activada (ON)
    if (OptionHSOvar === "ON") {
        Option1var = "OFF";  // Apagar la opción RGB
        self.starsRGBCheckBox.checked = false;  // Desmarcar la opción RGB
    }
    // Si la opción HSO está desactivada (OFF)
    else {
        //Option1var = "ON";  // Encender la opción RGB
        //self.starsRGBCheckBox.checked = true;  // Marcar la opción RGB
    }
};

    // Checkboxes para la segunda columna
    this.starsRGBCheckBox = new CheckBox(this);
    this.starsRGBCheckBox.text = "Create RGB Stars layer (only SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    let self = this; // Guardar referencia al contexto actual

   this.starsRGBCheckBox.onClick = function () {
    Option1var = this.checked ? "ON" : "OFF";
    self.starsHSOCheckBox.checked = false;
    var OptionHSOvar = "OFF";
    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("RGB Images are selected?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
        if (MiraVacioRGB()) {
            // Continuar con el proceso si las imágenes RGB están correctamente seleccionadas
            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {
            // Si alguna imagen está vacía, no continúa
            self.starsRGBCheckBox.checked = false;
            Option1var = "OFF";
            self.update();
        }
    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
}; // Fin del checkbox



 // Creación del campo numérico StarsValor
   this.starsValueEdit = new NumericControl(this);
   this.starsValueEdit.setValue(NewStarsValue);  // Valor inicial con 8 decimales
   this.starsValueEdit.label.text = "Star Reduce Presence:";
   this.starsValueEdit.setRange(0.0, 9.0);  // Rango entre 0 y 1
   this.starsValueEdit.setPrecision(2);     // Dos decimales


   // Evento para manejar la validación del valor y actualizar NewGreenValue
   this.starsValueEdit.onValueUpdated = function (starsvalue) {
    if (starsvalue < 0.00 || starsvalue > 9.0) {
        console.criticalln("Error: Star Valor must be between 0 and 9.");
    } else {
        NewStarsValue = starsvalue;  // Actualizamos NewGreenValue con el nuevo valor
    }
   };

 // Añadir el nuevo Checkbox para StarXterminator
    this.starXterminatorCheckBox = new CheckBox(this);
    this.starXterminatorCheckBox.text = "Star Removal by StarXterminator";
    this.starXterminatorCheckBox.checked = true;  // Predeterminado activado

    // Variable para almacenar la opción seleccionada
      let starRemovalMethodLabel = this.starXterminatorCheckBox.text;

      // Evento onClick para gestionar el cambio entre StarXterminator y StarNet2
      this.starXterminatorCheckBox.onClick = function () {
    // Actualizar la opción según si el checkbox está marcado o no
    OptionStarXterminator = this.checked ? "ON" : "OFF";

    if (OptionStarXterminator === "OFF") {
        // Si StarXterminator está apagado, cambiar el texto para usar StarNet2
        this.text = "Star Removal by StarNet2";
        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");
        console.writeln("Slow Process !!!");
    } else {
        // Si StarXterminator está encendido, usar StarXterminator
        this.text = "Star Removal by StarXterminator";
        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");
        console.writeln("Fast Process !!!");
    }

    //console.writeln(starRemovalMethodLabel + " method selected.\nVery slow Process !!!");
    };


   // Añadir el nuevo Checkbox para BlurXterminator
    this.blurXterminatorCheckBox = new CheckBox(this);
    this.blurXterminatorCheckBox.text = "Star Sharpening by BlurXterminator";
    this.blurXterminatorCheckBox.checked = true;  // Predeterminado activado
    this.blurXterminatorCheckBox.onClick = function () {
        OptionBlurXterminator = this.checked ? "ON" : "OFF";
    };


   // Añadir checkboxes a la segunda columna

    column2Sizer.add(this.starsHSOCheckBox);
    column2Sizer.add(this.starsRGBCheckBox);
    column2Sizer.add(this.starsValueEdit);
    column2Sizer.add(this.starXterminatorCheckBox);
    column2Sizer.add(this.blurXterminatorCheckBox);


    // Añadir las dos columnas al `HorizontalSizer` del `optionsGroupBox`
    this.optionsGroupBox.sizer.add(column1Sizer);
    this.optionsGroupBox.sizer.addSpacing(20);
    this.optionsGroupBox.sizer.add(column2Sizer);

    //this.integrationPage.sizer.add(this.projectTypeGroupBox);
    //this.integrationPage.sizer.addSpacing(10);
    //this.integrationPage.sizer.add(this.alignmentGroupBox);
    //this.integrationPage.sizer.addSpacing(10);
    //this.integrationPage.sizer.add(this.taggingGroupBox);
    //this.integrationPage.sizer.addSpacing(10);
    //this.integrationPage.sizer.add(this.optionsGroupBox);




    // --- Tab 2: Options ---
    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


////////// ////////// ////////// ////////// ////////// ////////// //////////

      // Crear ScrollControl para visualizar la imagen
      function ScrollControl(parent) {
      this.__base__ = ScrollBox;
      this.__base__(parent);

      this.displayImage = null;
      this.viewport.cursor = new Cursor(StdCursor_OpenHand);

          // Función para actualizar la imagen mostrada
         this.doUpdateImage = function(image) {
         this.displayImage = image;
         this.viewport.update();
    };

        this.viewport.onPaint = function(x0, y0, x1, y1) {
           var g = new Graphics(this);
           var image = this.parent.displayImage;
           if (image) {
               g.drawBitmap(x0, y0, image.render());
           } else {
               g.fillRect(x0, y0, x1, y1, new Brush(0xff000000)); // Fondo negro si no hay imagen
          }
          g.end();
          };
      }

   ScrollControl.prototype = new ScrollBox;



   // Creamos un espacio para visualizar la imagen usando ScrollControl
   let imageViewerControl = new ScrollControl(this.optionsPage);
   imageViewerControl.setFixedHeight(400);  // Espacio reservado para la visualización de la imagen
   imageViewerControl.setScaledMinWidth(400);  // Tamaño mínimo escalado

   this.optionsPage.sizer.add(imageViewerControl);  // Añadir el control de imagen al sizer de la página



////////// ////////// ////////// ////////// ////////// ////////// //////////


      // Crear el GroupBox para "Pro Options"
      let ColorGroupBox = new GroupBox(this.optionsPage);
      //ColorGroupBox.title = "Advanced Options II:";
      ColorGroupBox.sizer = new VerticalSizer;
      ColorGroupBox.sizer.margin = 6;
      ColorGroupBox.sizer.spacing = 4;

      // Crear el Label para seleccionar una imagen
      let ColorLabel = new Label(ColorGroupBox);
      ColorLabel.text = "Select a Non Linear image to Refresh and Apply adjustment.\nImage A:";
      ColorLabel.textAlignment = TextAlign_Left;
      ColorGroupBox.sizer.add(ColorLabel);

      // Visor de textura
      let imageSelector = new ComboBox(ColorGroupBox);
      imageSelector.editEnabled = false;  // Desactivar la edición manual
      ColorGroupBox.sizer.add(imageSelector);

      // Función para cargar las ventanas activas en el ComboBox
      function updateImageSelector() {
          imageSelector.clear();  // Limpiar el ComboBox

          imageSelector.addItem("<Select an Image>");  // Añadir la opción predeterminada

          let windows = ImageWindow.windows;
          for (let i = 0; i < windows.length; i++) {
              imageSelector.addItem(windows[i].mainView.id);  // Añadir las ventanas activas
          }
      }

      // Asignar la función para que se ejecute al hacer clic en el ComboBox
      imageSelector.onMousePress = function() {
          updateImageSelector();  // Actualizar las ventanas activas al hacer clic
      };

      // Función para actualizar OptionMergePro1 cuando se selecciona una ventana
      imageSelector.onItemSelected = function(index) {
          if (index === 0) {
              // Si se selecciona "<Select an Image>", no hacer nada
              console.warningln("Please select a valid image.");
              return;
          }

          if (index > 0) {
              OptionMergePro1 = imageSelector.itemText(index);  // Asignar el nombre de la ventana seleccionada a OptionMergePro1
              console.writeln("Image A: set to: " + OptionMergePro1);  // Mostrar en consola
              dialog.spaceLabel2.textColor = 0xFF0000; // Set label text color to red
              dialog.spaceLabel2.text = "Loading...";

              // Mostrar la imagen seleccionada en el visor
                MiraPreview(imageViewerControl, imageSelector);

                // Obtener el ID de la ventana seleccionada y buscar la ventana
                let selectedImageId = imageSelector.itemText(index);
                let previewWindow = ImageWindow.windowById(selectedImageId);

                // Aplicar reducción de saturación a la imagen en el visor
                MiraReduceSaturationInViewer(imageViewerControl, previewWindow);

               dialog.spaceLabel2.textColor = 0x000000; // Set label text color to red
               dialog.spaceLabel2.text = "Image Loaded.";



              //
               if  (VarPGlobal2 !== "EMPTY" && VarPGlobal3 === "EMPTY"){
              ColorPreviewButton.enabled = true;
               }
              //
          }
      };

      // Ejecutar la función para cargar las ventanas activas la primera vez
      updateImageSelector();



      // Añadir el GroupBox a la pestaña
      this.optionsPage.sizer.add(ColorGroupBox);


      // Añadir el GroupBox con RadioButtons para las opciones de capa
      let layerSelectionGroupBox = new GroupBox(ColorGroupBox);
      layerSelectionGroupBox.title = "Select a New Adjustment:";
      layerSelectionGroupBox.sizer = new VerticalSizer;
      layerSelectionGroupBox.sizer.margin = 6;
      layerSelectionGroupBox.sizer.spacing = 4;

      let BlackLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      BlackLayerRadioButton.text = "Dark Optimizer Areas";
      BlackLayerRadioButton.checked = true;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(BlackLayerRadioButton);

      let textureLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      textureLayerRadioButton.text = "Detail Enhanced image";
      textureLayerRadioButton.checked = false;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(textureLayerRadioButton);

      let backgroundLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      backgroundLayerRadioButton.text = "Background Enhanced image";
      backgroundLayerRadioButton.checked = false;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(backgroundLayerRadioButton);

      let GlowLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      GlowLayerRadioButton.text = "Add Glow effect";
      GlowLayerRadioButton.checked = false;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(GlowLayerRadioButton);

      let VignetedLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      VignetedLayerRadioButton.text = "Add Vignette";
      VignetedLayerRadioButton.checked = false;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(VignetedLayerRadioButton);

      let MergeLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      MergeLayerRadioButton.text = "Merge Image A with below Image (screen mode): ";
      MergeLayerRadioButton.checked = false;  // No seleccionado por defecto
      layerSelectionGroupBox.sizer.add(MergeLayerRadioButton);



    // Function to detect which RadioButton is selected and update OptionProOne
    function selectedLayer() {
    if (textureLayerRadioButton.checked) {
        OptionProOne = "Detail";  // Update the global variable
          console.writeln("Adjustment Process set to : " + OptionProOne);
          spaceLabel3.text = OptionProOne;
          dialog.ProOptionEdit.setValue(0.30);       // Valor inicial
          OptionSharpenNonstellar = 0.30;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

    } else if (backgroundLayerRadioButton.checked) {
        OptionProOne = "Background";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
        spaceLabel3.text = OptionProOne;
          dialog.ProOptionEdit.setValue(0.40);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

    } else if (MergeLayerRadioButton.checked) {
        OptionProOne = "Merge";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
        spaceLabel3.text = OptionProOne + " Image B:";
          dialog.ProOptionEdit.setValue(1.00);       // Valor inicial
          OptionSharpenNonstellar = 1.00;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);
          imageSelector2.enabled = true;

   } else if (VignetedLayerRadioButton.checked) {
        OptionProOne = "Vignette";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
        spaceLabel3.text = OptionProOne;
          dialog.ProOptionEdit.setValue(0.40);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (GlowLayerRadioButton.checked) {
        OptionProOne = "Glow Effect";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
        spaceLabel3.text = OptionProOne;
          dialog.ProOptionEdit.setValue(0.30);       // Valor inicial
          OptionSharpenNonstellar = 0.30;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (BlackLayerRadioButton.checked) {
        OptionProOne = "Dark Optimizer Areas";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
        spaceLabel3.text = OptionProOne;
          dialog.ProOptionEdit.setValue(0.40);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);


    }
    }

      // Bind radio buttons to update OptionProOne on click
      textureLayerRadioButton.onClick = function() { selectedLayer(); };
      backgroundLayerRadioButton.onClick = function() { selectedLayer(); };
      MergeLayerRadioButton.onClick = function() { selectedLayer(); };
      VignetedLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      GlowLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      BlackLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick



//
      // Crear un ComboBox con las ventanas activas
      let imageSelector2 = new ComboBox(ColorGroupBox);
      imageSelector2.editEnabled = false;  // Desactivar la edición manual
      imageSelector2.enabled = false;
      layerSelectionGroupBox.sizer.add(imageSelector2);

      // Función para cargar las ventanas activas en el ComboBox
      function updateImageSelector2() {
          imageSelector2.clear();  // Limpiar el ComboBox

          imageSelector2.addItem("<Select an Image>");  // Añadir la opción predeterminada

          let windows = ImageWindow.windows;
          for (let i = 0; i < windows.length; i++) {
              imageSelector2.addItem(windows[i].mainView.id);  // Añadir las ventanas activas
          }
             imageSelector2.maxVisibleItemCount = 13;
      }

      // Asignar la función para que se ejecute al hacer clic en el ComboBox
      imageSelector2.onMousePress = function() {
          updateImageSelector2();  // Actualizar las ventanas activas al hacer clic
      };

      // Función para actualizar OptionMergePro2 cuando se selecciona una ventana
      imageSelector2.onItemSelected = function(index) {
          if (index === 0) {
              // Si se selecciona "<Select an Image>", no hacer nada
              console.warningln("Please select a valid image.");
              return;
          }

          if (index > 0) {
              OptionMergePro2 = imageSelector2.itemText(index);  // Asignar el nombre de la ventana seleccionada a OptionMergePro2
              console.writeln("Image B: set to: " + OptionMergePro2);  // Mostrar en consola
          }
      };

      // Ejecutar la función para cargar las ventanas activas la primera vez
      updateImageSelector2();

//

      // Añadir el GroupBox de RadioButtons al GroupBox principal (ColorGroupBox)
      ColorGroupBox.sizer.add(layerSelectionGroupBox);


      // Crear el Label para espacio
      //let spaceLabel = new Label(ColorGroupBox);
      //spaceLabel.text = "";
      //spaceLabel.textAlignment = TextAlign_Left;
      //ColorGroupBox.sizer.add(spaceLabel);

         // Crear text del ajuste
      let spaceLabel3 = new Label(ColorGroupBox);
      spaceLabel3.text = OptionProOne;
      spaceLabel3.textAlignment = TextAlign_Left;
      ColorGroupBox.sizer.add(spaceLabel3);

      // Crear el campo numérico StarsValor debajo de los RadioButtons
      let dialog = this;  // Store reference to `this`
      this.ProOptionEdit = new NumericControl(this);
      this.ProOptionEdit.setValue(NewProOptionValue);  // Valor inicial
      this.ProOptionEdit.label.text = "Adjustment Presence:";
      this.ProOptionEdit.setRange(0, 1);  // Rango
      this.ProOptionEdit.setPrecision(2);  // Unidades
      this.ProOptionEdit.setValue(OptionSharpenNonstellar);       // Valor inicial



      // Evento para manejar la validación del valor y actualizar NewGreenValue
      let OptionAdjvalue = OptionSharpenNonstellar;

      this.ProOptionEdit.onValueUpdated = function (OptionAdjvalue) {
          if (OptionAdjvalue < 0 || OptionAdjvalue > 1) {
              console.criticalln("Error: Adjustment Value must be between 0.0 and 1.0");
          } else {
              OptionSharpenNonstellar = OptionAdjvalue;  // Actualizar la variable global con el nuevo valor
              //console.writeln("Adjustment value set to : " + OptionSharpenNonstellar);
          }
      };

      // Añadir el campo numérico al GroupBox
      ColorGroupBox.sizer.add(this.ProOptionEdit);

      // Crear el Label para espacio
      // Asegurarse de que `dialog` esté definido correctamente
      let dialog = this; // Si `this` es tu objeto de diálogo
      //Label para working process...
      dialog.spaceLabel2 = new Label(ColorGroupBox);
      dialog.spaceLabel2.text = "Activate your license to enable Advanced options.";
      dialog.spaceLabel2.textAlignment = TextAlign_Left;
      ColorGroupBox.sizer.add(dialog.spaceLabel2);

      // Crear un HorizontalSizer para alinear los botones en una misma línea
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones

      // Crear el botón "APPLY" de Texture
      let ColorPreviewButton = new PushButton(ColorGroupBox);
      ColorPreviewButton.text = "APPLY";
      ColorPreviewButton.icon = this.scaledResource( ":/icons/play.png" );
      ColorPreviewButton.setFixedWidth(150);
      ColorPreviewButton.enabled = false;
      ColorPreviewButton.toolTip ="Select adjustments and clic Apply";
      ColorPreviewButton.onClick = function() {

        // Verificar si la opción seleccionada es "<Select an Image>" o si MergeLayerRadioButton.checked es true
      if (OptionMergePro1 === "<Select an Image>" || (MergeLayerRadioButton.checked && OptionMergePro1 === "<Select an Image>")) {
      let errorMsgBox = new MessageBox("Please select a valid image in Image A or Merge.", "Error", StdIcon_Error, StdButton_Ok);
      errorMsgBox.execute();
      return;  // Salir de la función si no se ha seleccionado una imagen válida o si la condición de MergeLayerRadioButton es true
       }

            // Preguntar al usuario si desea aplicar el proceso
         let msgBox = new MessageBox("Do you want to continue with process??", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
         let response = msgBox.execute();

         if (response === StdButton_Yes) {


                ColorPreviewButton.enabled = false;


                 MiraProcesosPro(imageViewerControl, imageSelector, OptionSharpenNonstellar, OptionProOne, OptionMergePro1, OptionMergePro2);


                  dialog.spaceLabel2.textColor = 0x0000FF; // Cambiar el color del texto de la etiqueta a negro
                   dialog.spaceLabel2.text = "Apply Done !!!";
                     // resetar comboBox
                      // Resetear ComboBox a la opción predeterminada "<Select an Image>"
                   imageSelector.currentItem = 0;
                   updateImageSelector();
                   imageSelector2.currentItem = 0;
                   updateImageSelector2();



             } else {
        // Si el usuario selecciona "No", cancelar el proceso
        console.noteln("Process canceled by user.");
         }

   };//fin botón Apply

      // Alinear el botón "PREVIEW" a la izquierda
     //buttonSizer.addStretch();  // Espaciador flexible para empujar el botón a la izquierda
      buttonSizer.add(ColorPreviewButton);


      // Alinear el botón "RUN" a la derecha
      buttonSizer.addStretch();  // Espaciador flexible para empujar el botón a la derecha


    let workingLabel = new Label(ColorGroupBox);
    workingLabel.text = "";
    workingLabel.textAlignment = TextAlign_Right;
    buttonSizer.add(workingLabel);
    // Crear un sizer horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Añadir algo de espacio entre el botón y la etiqueta


      // Añadir el HorizontalSizer con los botones al GroupBox
      //ColorGroupBox.sizer.add(buttonSizer);



    horizontalSizer.add(buttonSizer);
    horizontalSizer.addStretch();
    ColorGroupBox.sizer.add(horizontalSizer);

    this.optionsPage.sizer.add(ColorGroupBox);



    // --- Tab 3: License ---
    this.licensePage = new Control(this);
    this.licensePage.sizer = new VerticalSizer;
    this.licensePage.sizer.margin = 10;
    this.licensePage.sizer.spacing = 6;

    //////////////////////////////////////////////////////


// --- NEW Tab Page 2
    this.optionsPage2 = new Control(this);
    this.optionsPage2.sizer = new VerticalSizer;
    this.optionsPage2.sizer.margin = 6;
    this.optionsPage2.sizer.spacing = 9;

// Actualiza el listado de ventanas
//      this.optionsPage2.onShow = function() {
//        MiraBorrarPrev();
//       };


////////// ////////// ////////// ////////// ////////// ////////// //////////


   ScrollControl.prototype = new ScrollBox;

   // Creamos un espacio para visualizar la imagen usando ScrollControl
   let imageViewerControl2 = new ScrollControl(this.optionsPage2);
   imageViewerControl2.setFixedHeight(400);  // Espacio reservado para la visualización de la imagen
   imageViewerControl2.setScaledMinWidth(400);  // Tamaño mínimo escalado

   this.optionsPage2.sizer.add(imageViewerControl2);  // Añadir el control de imagen al sizer de la página


////////// ////////// ////////// ////////// ////////// ////////// //////////

    let ColorGroupBox2 = new GroupBox(this.optionsPage2);
    //ColorGroupBox2.title = "Advanced Options I:";
    ColorGroupBox2.sizer = new VerticalSizer;
    ColorGroupBox2.sizer.margin = 6;
    ColorGroupBox2.sizer.spacing = 4;

    let ColorLabel2 = new Label(ColorGroupBox2);
    ColorLabel2.text = "Select a Non Linear image to Refresh and Apply adjustment.\n";
    ColorLabel2.textAlignment = TextAlign_Left;
    ColorGroupBox2.sizer.add(ColorLabel2);

   //------------------------------------------------------------Visor de HSL
   let imageSelector22 = new ComboBox(ColorGroupBox2);
   imageSelector22.editEnabled = false;
   imageSelector22.visibleItemCount = 10;  // Set the number of visible items to 10
   ColorGroupBox2.sizer.add(imageSelector22);

   function updateImageSelector22() {
    imageSelector22.clear();  // Limpiar el ComboBox

    imageSelector22.addItem("<Select an Image>");  // Añadir la opción predeterminada

    let windows = ImageWindow.windows;
    for (let i = 0; i < windows.length; i++) {
        imageSelector22.addItem(windows[i].mainView.id);  // Añadir las ventanas activas
    }
    imageSelector22.visibleItemCount = 10;  // Set the number of visible items to 10
   }

   // Ejecutar la función para cargar las ventanas activas la primera vez
   updateImageSelector22();


   // Asignar la función para que se ejecute al hacer clic en el ComboBox
      imageSelector22.onMousePress = function() {
          updateImageSelector22();  // Actualizar las ventanas activas al hacer clic
      };

   // Actualizar OptionMergePro0 con el valor seleccionado
   imageSelector22.onItemSelected = function (index) {
    let selectedOption = imageSelector22.itemText(index);

    // Si selecciona "<Select an Image>", OptionMergePro0 debe quedar sin asignar o mostrar un mensaje.
    if (selectedOption === "<Select an Image>") {
        OptionMergePro0 = "<Select an Image>";
        console.warningln("Please select a valid image.");
    } else {
        // Actualizar OptionMergePro0 con la opción seleccionada
        OptionMergePro0 = selectedOption;

        // ejecuta Borra Start_preview

     spaceLabel22.textColor = 0xFF0000; // Set label text color to red
     spaceLabel22.text = "Loading...";

    MiraBorrarPrev0();


    //pasa variables

    MiraDevelop(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar);

   // Bajar Saturación en el visor
   // Obtener la ventana activa por su nombre
      let previewWindow = ImageWindow.windowById("Start_preview");

      MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);

    // Bajar Saturación en el visor

     spaceLabel22.textColor = 0x000000; // Set label text color to red
     spaceLabel22.text = "Image Loaded.";



    console.writeln("");
    console.noteln("Refresh done !!!");

    //activa opciones

    maskOptionsComboBox.enabled = true;
    blurOptionsComboBox.enabled = true;
    RGBOptionsComboBox.enabled = true;


        if  (VarPGlobal2 !== "EMPTY"){
    ColorRunButton2.enabled = true;
    ColorRunButton222.enabled = true;
    ColorRunButtonGreen222.enabled = true;
        }
         //

    }
};

  // Ejecutar la función para cargar las ventanas nuevas
   updateImageSelector22();

  //////////////////////////////////////////////

    let buttonSizer2 = new HorizontalSizer;
    buttonSizer2.spacing = 6;

    // Declare maskOptionsComboBox globally if it's part of the UI
    let maskOptionsComboBox;

      // Initialize the ComboBox with values
      maskOptionsComboBox = new ComboBox(this);
      maskOptionsComboBox.addItem("None");
      maskOptionsComboBox.addItem("Light Mask");
      maskOptionsComboBox.addItem("Shadow Mask");
      maskOptionsComboBox.addItem("Red Mask");
      maskOptionsComboBox.addItem("Yellow Mask");
      maskOptionsComboBox.addItem("Green Mask");
      maskOptionsComboBox.addItem("Cyan Mask");
      maskOptionsComboBox.addItem("Blue Mask");
      maskOptionsComboBox.addItem("Magenta Mask");


      // Event handler when a new option is selected
      maskOptionsComboBox.onItemSelected = function (index) {
          let selectedMaskOption = maskOptionsComboBox.itemText(index);

          // If no valid option is selected, assume "None"
          if (selectedMaskOption === "None") {
              OptionTypeMaskvar = selectedMaskOption;
              console.writeln("No mask selected: " + OptionTypeMaskvar);
          } else {
        // Update the selected mask option
        OptionTypeMaskvar = selectedMaskOption;
        console.writeln("Selected mask option: " + OptionTypeMaskvar);

        // Restablecer el valor predeterminado de OptionColorMaskLumvar
        OptionColorMaskLumvar = 0;
        OptionColorMaskSatvar = 0;
        OptionColorMaskHuevar = 0;
        lumSlider.value = 10;  // Colocar el slider en el centro (10 es el valor neutro)
        satSlider.value = 10;
        hueSlider.value = 10;
        }
          };

      let blurOptionsComboBox;

      // Initialize the ComboBox with values
      blurOptionsComboBox = new ComboBox(this);
      blurOptionsComboBox.addItem("None");
      blurOptionsComboBox.addItem("Soft Blur");
      blurOptionsComboBox.addItem("Hard Blur");


      // Event handler when a new option is selected
          blurOptionsComboBox.onItemSelected = function (index) {
          let selectedblurOption = blurOptionsComboBox.itemText(index);

          // If no valid option is selected, assume "None"
          if (selectedblurOption === "None") {
             OptionBlurMaskvar = selectedblurOption;
              console.writeln("No Blurring selected: " + OptionBlurMaskvar);
          } else {
              OptionBlurMaskvar = selectedblurOption;
              console.writeln("Selected Blurring option: " + OptionBlurMaskvar);
              checkLuminosityMask()
              //hacer el check de None en Mask
          }
      };

     // Function to check and enforce the mask option when blur is "Soft" or "Hard"
      function checkLuminosityMask() {
          let selectedMaskOption = maskOptionsComboBox.itemText(maskOptionsComboBox.currentItem);
          if (selectedMaskOption == "None") {
              console.warningln("Error: Luminosity mask cannot be 'None' when blur is 'Soft' or 'Hard'");
          // Automatically select the first mask option (assuming it's index 1)
        maskOptionsComboBox.currentItem = 1;  // Use currentItem instead of setCurrentItem
        OptionTypeMaskvar = maskOptionsComboBox.itemText(1);  // Update the variable
        console.writeln("Selected mask option: " + OptionTypeMaskvar );
          }
         }


      let RGBOptionsComboBox;

      // Initialize the ComboBox with values
      RGBOptionsComboBox = new ComboBox(this);
      RGBOptionsComboBox.addItem("None");
      RGBOptionsComboBox.addItem("Red Channel");
      RGBOptionsComboBox.addItem("Green Channel");
      RGBOptionsComboBox.addItem("Blue Channel");


// Event handler when a new option is selected
RGBOptionsComboBox.onItemSelected = function (index) {
    let selectedRGBOption = RGBOptionsComboBox.itemText(index);

    // If no valid option is selected, assume "None"
    if (selectedRGBOption === "None") {
        OptionRGBMaskvar = selectedRGBOption;
        console.writeln("Selected: " + OptionRGBMaskvar);
        hueSliderLabel.text = "Channel: None";
        hueSliderLabel.textColor = 0x000000; // Set label text color to black (default)
        hueSlider.enabled = false;
    } else {
        OptionRGBMaskvar = selectedRGBOption;
        console.writeln("Selected RGB option: " + OptionRGBMaskvar);
        hueSliderLabel.text = "Channel: " + OptionRGBMaskvar;

        // Set the label color based on the selected channel
        switch (OptionRGBMaskvar) {
            case "Red Channel":
                hueSliderLabel.textColor = 0xFF0000; // Set label text color to red
                hueSlider.enabled = true;
                break;
            case "Green Channel":
                hueSliderLabel.textColor = 0x008000; // Set label text color to green
                hueSlider.enabled = true;
                break;
            case "Blue Channel":
                hueSliderLabel.textColor = 0x0000FF; // Set label text color to blue
                hueSlider.enabled = true;
                break;
            default:
                hueSliderLabel.textColor = 0x000000; // Set to black as fallback
                break;
        }

        // Optional: You can add logic here to interact with the Mask ComboBox if needed
        // For example, automatically setting "None" on the mask comboBox:
        // maskOptionsComboBox.setCurrentItem(0);  // Select "None" in the mask options
    }
};


         // Crear el tercer HorizontalSizer (horizontal3Bar)
         let horizontal8Bar = new HorizontalSizer;
         ColorGroupBox2.sizer.margin = 6;
         ColorGroupBox2.sizer.spacing = 4;


      let spaceLabel = new Label(ColorGroupBox);
      spaceLabel.text = "";
      spaceLabel.textAlignment = TextAlign_Left;

      ColorGroupBox2.sizer.add(spaceLabel);


     // Añadir Label1
     let MaskLabel = new Label;
     MaskLabel.text = "Select Masking options:   ";

     // Añadir Label2
     let blurLabel = new Label;
     blurLabel.text = "Select Blurring options:   ";

     // Añadir Label3
     let rgbLabel = new Label;
     rgbLabel.text = "Select RGB Channel:   ";


      // Crear los RadioButtons para Showmask
      let showMaskRadio = new RadioButton;
      showMaskRadio.text = "Show Mask";
      showMaskRadio.checked = false; // Opción por defecto
      showMaskRadio.enabled = false;
      // Handle the onClick event to set the mask visibility option
         showMaskRadio.onClick = function () {

         //

      let windows = ImageWindow.windows;
      let duplicateImageWindow = null;

       // Buscar la ventana duplicada que termina en "_preview"
       for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.endsWith("_preview")) {
            duplicateImageWindow = windows[i];
            break;
        }
      }

    if (!duplicateImageWindow) {
        console.criticalln("Error: No '_preview' window found to apply mask.");
        return;  // Detener si no se encuentra la ventana
    }

    duplicateImageWindow.bringToFront();  // Llevar la ventana al frente

         //


         if (this.checked) {
             OptionshowMaskvar = "ON";
             console.writeln("Show mask: " + OptionshowMaskvar + " " + OptionTypeMaskvar);
             //
             if (OptionTypeMaskvar !== "None") { //Mirar variable de Showmask
             MiraMaskBYN(duplicateImageWindow, imageViewerControl2);  // Llamar a la nueva función
             } else {
               console.warningln("No Mask Selected to show");
               OptionshowMaskvar = "OFF";
            }
         } else {
             OptionshowMaskvar = "OFF";
             console.writeln("Show mask: " + " " + OptionshowMaskvar);
             //
  // Mostrar la ventana Start_preview
        let startPreviewWindow = ImageWindow.windowById("Start_preview");

        if (startPreviewWindow && !startPreviewWindow.mainView.isNull) {
            // Llevar la ventana al frente
            startPreviewWindow.bringToFront();

            // **Limpiar el visor actual antes de actualizar**
            imageViewerControl2.doUpdateImage(null); // Limpia el visor de imágenes

            // Actualizar el visor de imágenes con la imagen seleccionada
            let imageViewerControl = imageViewerControl2;
            fitImageToWindow(imageViewerControl, startPreviewWindow.mainView.image);

            // Mostrar la ventana en el visor de imágenes
            imageViewerControl2.show();
        } else {
            console.criticalln("Error: No 'Start_preview' window found.");
        }
             //
         }
         };


      // Añadir el Label y el RadioButton al leftSizer (a la izquierda)
      horizontal8Bar.add(MaskLabel);
      horizontal8Bar.add(showMaskRadio);

      // Añadir el ComboBox a la derecha
      maskOptionsComboBox.minWidth = 300;
      maskOptionsComboBox.enabled =false;
      horizontal8Bar.add(maskOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal8Bar);

      // añade aquí el código de None, SoftBlur y hard blue
      let horizontal7Bar = new HorizontalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;

      horizontal7Bar.add(blurLabel);

      // Añadir el ComboBox a la derecha
       blurOptionsComboBox.minWidth = 300;
       blurOptionsComboBox.enabled =false;
      horizontal7Bar.add(blurOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal7Bar);

     // añade aquí el código de RGB
      let horizontal6Bar = new HorizontalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;

      horizontal6Bar.add(rgbLabel);

      // Añadir el ComboBox a la derecha
       RGBOptionsComboBox.minWidth = 300;
       RGBOptionsComboBox.enabled =false;
       horizontal6Bar.add(RGBOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal6Bar);




      ///////////////////////////////////
      // Crear el Label para espacio
      let spaceLabel = new Label(ColorGroupBox);
      spaceLabel.text = "";
      spaceLabel.textAlignment = TextAlign_Left;
      ColorGroupBox2.sizer.add(spaceLabel);

      //sliders
      // Crear el tercer HorizontalSizer (horizontal3Bar) para los sliders de Hue, Saturation, Luminance
      let horizontal9Bar = new VerticalSizer;

      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;

      // Añadir los sliders de Hue, Saturation, Luminance

      // Hue slider / Channel slide

      // Crear el sizer horizontal
      let horizontal9Bar = new HorizontalSizer;
      horizontal9Bar.spacing = 4; // Espaciado entre elementos


      let hueSliderLabel = new Label;
      hueSliderLabel.text = "Channel: None";
      horizontal9Bar.add(hueSliderLabel);

      let ceroSliderLabel = new Label;
      ceroSliderLabel.text = "0";
      ceroSliderLabel.textAlignment = TextAlign_Left;
      horizontal9Bar.add(ceroSliderLabel);



     // Crear el sizer horizontal
      let horizontal98Bar = new HorizontalSizer;
      horizontal98Bar.spacing = 4; // Espaciado entre elementos

      // Añadir el símbolo de menos (-)
      let minusLabel = new Label;
      minusLabel.text = "-     ";
      minusLabel.textAlignment = TextAlign_Center;
      horizontal98Bar.add(minusLabel);

      let hueSlider = new Slider;
      hueSlider.setRange(0, 20);
      hueSlider.value = OptionColorMaskHuevar;
      hueSlider.onValueUpdated = function(value) {
          OptionColorMaskHuevar = value - 10;
      };
      hueSlider.enabled = false;
      hueSlider.toolTip ="Select one RGB Channel";
      horizontal98Bar.add(hueSlider);

     // Añadir el símbolo de más (+)
      let plusLabel = new Label;
      plusLabel.text = "+";
      plusLabel.textAlignment = TextAlign_Center;
      horizontal98Bar.add(plusLabel);

       ColorGroupBox2.sizer.add(horizontal9Bar);
       ColorGroupBox2.sizer.add(horizontal98Bar);


      // Saturation slider
    // Crear el sizer horizontal
      let horizontal9Bar = new HorizontalSizer;
      horizontal9Bar.spacing = 4; // Espaciado entre elementos


      let satSliderLabel = new Label;
      satSliderLabel.text = "Saturation:";
      horizontal9Bar.add(satSliderLabel);

      // Crear el sizer horizontal
      let horizontal97Bar = new HorizontalSizer;
      horizontal97Bar.spacing = 4; // Espaciado entre elementos

      // Añadir el símbolo de menos (-)
      let minusLabel = new Label;
      minusLabel.text = "-     ";
      minusLabel.textAlignment = TextAlign_Center;
      horizontal97Bar.add(minusLabel);

      let satSlider = new Slider;
      satSlider.setRange(0, 20);
      satSlider.value = OptionColorMaskSatvar;
      satSlider.onValueUpdated = function(value) {
          OptionColorMaskSatvar = value - 10;
      };

      horizontal97Bar.add(satSlider);

      // Añadir el símbolo de más (+)
      let plusLabel = new Label;
      plusLabel.text = "+";
      plusLabel.textAlignment = TextAlign_Center;
      horizontal97Bar.add(plusLabel);

       ColorGroupBox2.sizer.add(horizontal9Bar);
        ColorGroupBox2.sizer.add(horizontal97Bar);

      // Luminance slider

      // Crear el sizer horizontal
      let horizontal9Bar = new HorizontalSizer;
      horizontal9Bar.spacing = 4; // Espaciado entre elementos

      let lumSliderLabel = new Label;
      lumSliderLabel.text = "Luminance:";
      horizontal9Bar.add(lumSliderLabel);

       // Crear el sizer horizontal
      let horizontal96Bar = new HorizontalSizer;
      horizontal96Bar.spacing = 4; // Espaciado entre elementos

       // Añadir el símbolo de menos (-)
      let minusLabel = new Label;
      minusLabel.text = "-     ";
      minusLabel.textAlignment = TextAlign_Center;
      horizontal96Bar.add(minusLabel);

      let lumSlider = new Slider;
      lumSlider.setRange(0, 20);
      lumSlider.value = OptionColorMaskLumvar;
      lumSlider.onValueUpdated = function(value) {
          OptionColorMaskLumvar = value - 10;
      };
      horizontal96Bar.add(lumSlider);

      // Añadir el símbolo de más (+)
      let plusLabel = new Label;
      plusLabel.text = "+";
      plusLabel.textAlignment = TextAlign_Center;
      horizontal96Bar.add(plusLabel);

      ColorGroupBox2.sizer.add(horizontal9Bar);
       ColorGroupBox2.sizer.add(horizontal96Bar);

      // Crear el Label para espacio
      let spaceLabel22 = new Label(ColorGroupBox);
      spaceLabel22.text = "Activate your license to enable Advanced options.";
      spaceLabel22.textAlignment = TextAlign_Left;
      ColorGroupBox2.sizer.add(spaceLabel22);

      // Crear los RadioButtons para Showconsole
      let showConsolCheckBox = new RadioButton;
      showConsolCheckBox.text = "Show console";
      showConsolCheckBox.checked = true; // Opción por defecto

      // Crear el CheckBox para Show console
      let showConsoleCheckBox = new CheckBox;
      showConsoleCheckBox.text = "Show console";
      showConsoleCheckBox.checked = true; // Opción por defecto



    let ColorRunButton2 = new PushButton(ColorGroupBox2);
    ColorRunButton2.text = "REFRESH";
    ColorRunButton2.icon = this.scaledResource( ":/icons/refresh.png" );
    ColorRunButton2.setFixedWidth(100);

    let ColorRunButton222 = new PushButton(ColorGroupBox2);
    ColorRunButton222.text = "Reset";
    ColorRunButton222.icon = this.scaledResource( ":/icons/debug-restart.png" );
    ColorRunButton222.setFixedWidth(100);



       ColorRunButton222.onClick = function() {

       //Resetear Valores Combox y textos
       blurOptionsComboBox.currentItem = 0;
       RGBOptionsComboBox.currentItem = 0;
       maskOptionsComboBox.currentItem = 0;

       selectedblurOption = "None";
       selectedRGBOption = "None";
       selectedMaskOption = "None";

         console.writeln("Selected: " + OptionRGBMaskvar);
        hueSliderLabel.text = "Channel: None";
        hueSliderLabel.textColor = 0x000000; // Set label text color to black (default)
        hueSlider.enabled = false;

        console.noteln("Reseted slider values...");
        OptionColorMaskLumvar = 0;
        OptionColorMaskSatvar = 0;
        OptionColorMaskHuevar = 0;
        lumSlider.value = 10;  // Colocar el slider en el centro (10 es el valor neutro)
        satSlider.value = 10;
        hueSlider.value = 10;

    }

    let ColorRunButtonGreen222 = new PushButton(ColorGroupBox2);
    ColorRunButtonGreen222.text = "Green";
    ColorRunButtonGreen222.icon = this.scaledResource( ":/icons/delete.png" );
    ColorRunButtonGreen222.setFixedWidth(100);

      ColorRunButtonGreen222.onClick = function() {

     spaceLabel22.textColor = 0xFF0000; // Set label text color to red
     spaceLabel22.text = "Loading...";

      NewGreenValue = 1;
      MiraGreen2(NewGreenValue); //si cambiamos el nombre de la función hay que mirar todas las llamadas...

        // Actualizar la imagen en el visor
        let previewWindow = ImageWindow.windowById("Start_preview");
        if (!previewWindow || !previewWindow.mainView || previewWindow.mainView.isNull) {
          console.criticalln("Error: 'Start_preview' window not found or invalid.");
          return;
        }
        //fitImageToWindow(imageViewerControl2, previewWindow.mainView.image, false);
        //imageViewerControl2.show();

         let previewWindow = ImageWindow.windowById("Start_preview"); //Se actualiza NO saturado
         MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);


      console.writeln("");
      console.noteln("Refresh done !!!");

      spaceLabel22.textColor = 0x0000FF; // Set label text color to blue
      spaceLabel22.text = "Refresh done. Clic OK to save image.";
      ColorRunButton3.enabled= true;
      }

    ColorRunButton2.onClick = function() {


     spaceLabel22.foregroundColor = 0xFF0000;
     spaceLabel22.text = "Loading...";
     OptionshowMaskvar = "OFF";
     showMaskRadio.checked = false;

    // Comprobar si las selecciones de máscara o desenfoque han cambiado
    if (previousMaskType !== OptionTypeMaskvar || previousBlurOption !== OptionBlurMaskvar) {
        console.writeln("New selection detected. Clearing intermediate windows...");
        MiraBorrarPrev();  // Solo borrar ventanas si las selecciones han cambiado
    } else {
        console.writeln("No new selection. Skipping window clearing.");
    }

    ColorRunButton2.enabled= false;
    ColorRunButton222.enabled= false;
    ColorRunButtonGreen222.enabled= false;


    let windows = ImageWindow.windows;
    let duplicateImageWindow = null;

    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.endsWith("_preview")) {
            duplicateImageWindow = windows[i];
            break;  // Detener el bucle cuando encontramos la ventana
        }
    }

   if (!duplicateImageWindow) {
    console.criticalln("Error: No '_preview' window found to apply mask.");
    return;  // Detener el proceso si no hay una ventana duplicada
   }

    duplicateImageWindow.bringToFront(); // Llevarla al frente


      if (duplicateImageWindow) {
    console.writeln("Passing duplicateImageWindow to MiraDevelop2 with id: " + duplicateImageWindow.mainView.id);

    MiraDevelop2(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar, duplicateImageWindow); // Aplicar máscara
      } else {
    console.criticalln("Error: No '_preview' window found to apply mask.");
    return;
     }

    duplicateImageWindow.bringToFront(); // Llevarla al frente


         let previewWindow = ImageWindow.windowById("Start_preview"); //Se actualiza NO saturado
         MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);



    showMaskRadio.enabled = true;

    console.writeln("");
    console.noteln("Refresh done !!!");

    spaceLabel22.textColor = 0x0000FF; // Set label text color to blue
    spaceLabel22.text = "Refresh done. Clic OK to save image.";

    ColorRunButton2.enabled= true;

    ColorRunButton222.enabled= true;
    ColorRunButtonGreen222.enabled= true;
    ColorRunButton3.enabled= true;

   }

    let ColorRunButton3 = new PushButton(ColorGroupBox2);
    ColorRunButton3.text = "OK";
    ColorRunButton3.icon = this.scaledResource( ":/icons/ok.png" );
    ColorRunButton3.setFixedWidth(100);

    // Acción del botón OK
    ColorRunButton3.onClick = function () {
    // Preguntar si desea aplicar los cambios en una nueva imagen
    let msgBox = new MessageBox("Do you want to apply changes in a new image?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
    let response = msgBox.execute();

    // Si la respuesta es "Sí", ejecutar MiraOk
    if (response === StdButton_Yes) {

        MiraOk(); //Grabar nombre

        console.writeln("");
        console.noteln("APPLY done !!!");
        ColorRunButton2.enabled= false;
        ColorRunButton222.enabled= false;
        ColorRunButtonGreen222.enabled= false;
        ColorRunButton3.enabled= false;
        spaceLabel22.textColor = 0x0000; // Set label text color to blue
        imageSelector22.currentItem = 0;
        spaceLabel22.text = "Image saved !!!";


    } else {
        console.noteln("Process canceled by user.");
        return;  // Salir si la respuesta es "No"
    }
   };


    ColorRunButton2.toolTip = "Select an image and clic Load image.";
    ColorRunButton2.enabled = false; // activa con licencia
    ColorRunButton222.enabled= false;
    ColorRunButtonGreen222.enabled= false;
    ColorRunButton3.enabled = false; // activa con licencia
    buttonSizer2.add(ColorRunButton2);
    buttonSizer2.add(ColorRunButton222);
    buttonSizer2.add(ColorRunButtonGreen222);

    buttonSizer2.add(ColorRunButton3);
    buttonSizer2.addStretch();


    ColorGroupBox2.sizer.add(buttonSizer2);

    this.optionsPage2.sizer.add(ColorGroupBox2);





    //////////////////////////////////////////////////////

    // --- Tab 4: License ---

      let licenseGroupBox = new GroupBox(this.licensePage);
      licenseGroupBox.title = "License Information";
      licenseGroupBox.sizer = new VerticalSizer;
      licenseGroupBox.sizer.margin = 6;
      licenseGroupBox.sizer.spacing = 4;


      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(emailLabel);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";  // Inicializar con una cadena vacía o algún valor por defecto
      this.emailEdit.enabled = false;
      licenseGroupBox.sizer.add(this.emailEdit);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(codeLabel);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";  // Inicializar con una cadena vacía
      this.codeEdit.enabled = false;
      licenseGroupBox.sizer.add(this.codeEdit);


         // Función para rellenar los campos con los datos de licencia
         function FillLicenseFields(context, email, code) {
          // Validar que el email y el code sean cadenas y que los campos existan
          if (!context.emailEdit || !context.codeEdit) {
              console.criticalln("Error: email or code are not defined.");
              return;
             }

          if (typeof email !== 'string' || typeof code !== 'string') {
           console.criticalln("Error: Expected a text string for email and code.");
           return;
          }

         // Asignar los valores correctamente a los campos de texto
         context.emailEdit.text = email.trim();  // Asegurarse de eliminar espacios innecesarios
         context.codeEdit.text = code.trim();    // Asegurarse de eliminar espacios innecesarios
         }

         // Función para leer el archivo de licencia
         function ReadLicenseFile(filePath, context) {
         try {
        let outputDir = File.extractDrive(filePath) + File.extractDirectory(filePath);

        if (!outputDir.endsWith('/')) {
            outputDir += '/';
        }

        let newPath = outputDir + "license.js";

        if (!File.exists(newPath)) {
            throw "The license file does not exist at the specified path: " + newPath;
        }

        let file = new File;
        file.openForReading(newPath);
        let content = file.read(DataType_Uint8Array, file.size);  // Leer el archivo completo
        file.close();

        let contentString = String.fromCharCode.apply(null, content);

        // Usamos expresiones regulares para extraer email y código
        let emailMatch = contentString.match(/email:\s*"([^"]+)"/);
        let codeMatch = contentString.match(/code:\s*"([^"]+)"/);

        if (emailMatch && codeMatch) {
            let email = emailMatch[1];
            let code = codeMatch[1];

            console.writeln("");
            console.noteln("Automator script...");


            // Llamar a la función FillLicenseFields con el contexto correcto
            FillLicenseFields(context, email, code);

            MiraFgCo(email, code);


        } else {
            console.criticalln("License file does not contain a valid email or code.");
        }

    } catch (e) {
        console.criticalln("The license file does not contain a valid email or code: " + (e.message || e));
    }
    }//Fin ReadLicense

      // Ejemplo de llamada a ReadLicenseFile después de que los campos se han creado
      let self = this;
      let filePath = originalFilePath
      ReadLicenseFile(filePath, self);  // Usamos 'self' para pasar el contexto

      let EspacioLabel = new Label(this);
      EspacioLabel.text = "";
      EspacioLabel.textAlignment = TextAlign_Left ;
      licenseGroupBox.sizer.add(EspacioLabel);

      // Crear una sizer horizontal para los botones "Edit" y "Validate"
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones


      let EditvalidateButton = new PushButton(this);
      EditvalidateButton.text = "Edit";
      EditvalidateButton.icon = this.scaledResource( ":/icons/folder.png" );
      EditvalidateButton.setFixedWidth(150);
      buttonSizer.add(EditvalidateButton);
      EditvalidateButton.onClick = function () {


            let msgBox = new MessageBox(
            "Editing License Process\nDo you want to continue?",  // Message text
            "Confirmation",  // Title
            StdIcon_Question,  // Question icon
            StdButton_Yes, StdButton_No  // Yes/No buttons
             );

             let result = msgBox.execute();  // Show the MessageBox and capture the result

             // If the user clicks 'Yes', proceed with writing the license file
             if (result === StdButton_Yes) {
               console.writeln("Editing License...");
                self.emailEdit.enabled = true;
                self.codeEdit.enabled = true;
                validateButton.enabled = true;

      } else {
                self.emailEdit.enabled = false;
                self.codeEdit.enabled = false;
      }
      };

      let validateButton = new PushButton(this);
      validateButton.text = "Validate";
      validateButton.icon = this.scaledResource( ":/icons/ok.png" );
      validateButton.setFixedWidth(150);
      validateButton.enabled = false;
      buttonSizer.add(validateButton);
      validateButton.onClick = function () {

               // Llamada a la función para leer la licencia
             // Usamos 'self' para capturar correctamente los valores de los campos de texto
              let email = self.emailEdit.text ? self.emailEdit.text.trim() : "";
              let code = self.codeEdit.text ? self.codeEdit.text.trim() : "";

               // Asegurarse de que los campos no estén vacíos
                if (email === "" || code === "") {
               console.criticalln("Error: Both Email and Code fields must be filled.");
               return;
                  }


               // Ruta al archivo original o donde se debe generar license.js
               //let originalFilePath = "/Users/teoriadelcolorm3pro/Desktop/Astrofotografía/Pixin-Java/beta_v6/license.js";


              // Llamada a la función para escribir el archivo de licencia
              WriteLicenseFile(originalFilePath, email, code);

           };

      // Añadimos el sizer de los botones al grupo de licencia

     licenseGroupBox.sizer.add(buttonSizer);
     licenseGroupBox.adjustToContents();  // Ajustamos el grupo al contenido
      this.licensePage.sizer.add(licenseGroupBox);


      // **Nuevo GroupBox llamado "Information" debajo del "License Information"**

      let informationGroupBox = new GroupBox(this.licensePage);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;  // Espaciado vertical reducido

      // Añadir etiquetas y campos adicionales si es necesario
      let infoLabel = new Label(this);
      infoLabel.text = "\nPrograms or plugis you need to be installed:\n\nRemove Star:\n -StarXterminator (www.rc-astro.com) or Starnet (free - www.starnetastro.com)\n\nRemove Noise:\n- GraXnoise (free - https://graxpert.com)\n\nSharpening:\n- BlurXterminator (www.rc-astro.com)\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nwww.teoriadelcolor.es\n";
      infoLabel.textAlignment = TextAlign_Left ;
      informationGroupBox.sizer.add(infoLabel);



      // Añadir el nuevo GroupBox "Information" a la página, debajo del de "License"
      this.licensePage.sizer.add(informationGroupBox);

      // Ajustes finales para que el contenido se ajuste
      licenseGroupBox.adjustToContents();
      informationGroupBox.adjustToContents();
      this.licensePage.adjustToContents();


      // Agregar la pestaña License al TabBox
      this.tabBox.addPage(this.licensePage, "License");

    // Agregar las pestañas al TabBox
    this.tabBox.addPage(this.integrationPage, "Integration");
    this.tabBox.addPage(this.optionsPage2, "Develop");
    this.tabBox.addPage(this.optionsPage, "Tools");
    this.tabBox.addPage(this.licensePage, "License");


      // Dibuja todo el menú

      // --- Horizontal Sizer to hold Project Type and Alignment GroupBoxes ---
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.spacing = 10; // Espacio entre los dos grupos horizontales

      // Create VerticalSizer for each group to tightly manage layout
      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      projectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;  // Remove any margin to reduce extra spacing
      alignmentSizer.spacing = 10;  // Set appropriate spacing between elements
      alignmentSizer.add(this.alignmentGroupBox);

      // Create HorizontalSizer to put both projectTypeSizer and alignmentSizer side by side
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;  // Ensure no extra margin is added around the group boxes
      projectAndAlignmentSizer.spacing = 10;  // Space between the two group boxes

      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);


      // Agregar el HorizontalSizer al sizer de la integración
      this.integrationPage.sizer.add(projectAndAlignmentSizer);

      // --- Añadir el Tagging GroupBox directamente después del Horizontal Sizer ---
      this.integrationPage.sizer.add(this.taggingGroupBox);



       // Añadir el sizer horizontal a la página de integración
        this.integrationPage.sizer.add(this.optionsGroupBox);


      //
  // --- RUN Button ---
    this.runButton = new PushButton(this.integrationPage);
    this.runButton.text = "RUN";
    this.runButton.icon = this.scaledResource( ":/icons/play.png" );
    this.runButton.toolTip ="Select a Project type\nSelect an Aligment\nSelect images\nSelect Final options\nand clic RUN";
    this.runButton.setFixedWidth(100);
    this.runButton.onClick = function () {
            console.noteln("Incializating Script...");

            if (!MiraCheckWindowsABE()) {
               console.criticalln("Cancel script...");

                // Detener la ejecución si MiraCheckWindowsABE() falla
                return;
            }

         let msgBox = new MessageBox("Do you want to Run the Script?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
            if (msgBox.execute() === StdButton_Yes) {


            let startTime = Date.now();

            console.noteln("Running Script...");
            // Cambiar el color del texto a rojo
            dialog.workingLabel.foregroundColor = 0xFF0000;  // Color rojo (en formato RGB hexadecimal)
            // Actualizar el label para que el cambio sea visible
            dialog.workingLabel.update();

            dialog.workingLabel.text = "Running Process: [1 to 4]/14. Please wait... ";

            MiraProyecto();

            dialog.workingLabel.text = "Running Process: [1 to 4]/14. Please wait... ";

            if (MiraVentana()) {
            dialog.workingLabel.text = "Running Process: [1 to 4]/14. Please wait... ";
                MiraRenombre();
            dialog.workingLabel.text = "Running Process: [1 to 4]/14. Please wait... ";

                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
            dialog.workingLabel.text = "Step 5/14. Main process, Please wait... ";

                    MiraProcesoGeneral01();

            dialog.workingLabel.text = "Step 6/14. Please wait... ";
                    MiraChannelCom();
            dialog.workingLabel.text = "Step 7/14. Please wait... ";

            dialog.workingLabel.text = "Step 8/14. Please wait... ";
                    MiraGreen() // Elimina el verde la imagen activa

            dialog.workingLabel.text = "Step 9/14. Please wait... ";

                    if (OptionHSOvar === "ON") { // Creamos Capa de estrellas RGB o SHO/HOO?

                        if (Option1var === "ON") {
                        MiraRGBStars();
                        } else {
                        MiraSHOStars();
                        }

                    } //fin de OPtionHSOvar

             dialog.workingLabel.text = "Step 10/14. Please wait... ";
                    MiraEnh();  // Ejecuta el proceso Enhanced
            dialog.workingLabel.text = "Step 11/14. Please wait... ";
                    MiraResolFinal(); // Ejecuta la resolución final
            dialog.workingLabel.text = "Step 12/14. Please wait... ";
                    MiraBorraVentanas()
            dialog.workingLabel.text = "Step 13/14. Please wait... ";
                    iconizeAndArrangeWindows() //Iconiza las ventanas y deja Base_Non_Linear activa
            dialog.workingLabel.text = "Step 14/14. Please wait... ";
                     MirashowTotalTime(startTime);


                   console.warningln("");
                   console.warningln("End Script...");

                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                }
            } else {
                console.criticalln("Exiting script due to missing images...");
            }
        } else {
            console.warningln("");
            console.warningln("Exit script...");
            console.hide();
        }
    };

    this.integrationPage.sizer.addSpacing(10);

    this.workingLabel = new Label(this.integrationPage);
    this.workingLabel.text = "";
    //this.workingLabel.textAlignment = TextAlign_Right;

    // Crear un sizer horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
    horizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes


    // Añadir el botón y la etiqueta al sizer horizontal
    horizontalSizer.add(this.workingLabel);


    //horizontalSizer.addStretch(); // Esto empuja el label hacia la derecha

     // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(horizontalSizer);

        // Crear un sizer horizontal
    let vhorizontalSizer = new VerticalSizer;
    vhorizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
    vhorizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes
    vhorizontalSizer.add(this.runButton);

     // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(vhorizontalSizer);

  // Create VerticalSizer for each group to tightly manage layout
      let xprojectTypeSizer = new VerticalSizer;
      xprojectTypeSizer.margin = 30;  // Remove any margin to reduce extra spacing
      xprojectTypeSizer.spacing = 30;  // Set appropriate spacing between elements
      this.integrationPage.sizer.add(xprojectTypeSizer);


    // --- Help Button ---
    this.HelpButton = new PushButton(this);
    this.HelpButton.text = "HELP";
    this.HelpButton.icon = this.scaledResource( ":/icons/help.png" );
    this.HelpButton.onClick = function () {


        this.dialog.cancel();
    };
    this.HelpButton.setFixedWidth(200);

    // --- EXIT Button ---
    this.exitButton = new PushButton(this);
    this.exitButton.text = "EXIT";
    this.exitButton.icon = this.scaledResource( ":/icons/cancel.png" );
    this.exitButton.onClick = function () {

       // Llamar a la función para eliminar cualquier máscara activa

        MiraBorrarPrev()

        ExitWithLuminosityMaskCheck();

        this.dialog.cancel();
    };


 // Crear los RadioButtons para Showconsole
      let showConsolCheckBox = new RadioButton;
      showConsolCheckBox.text = "Show console";
      showConsolCheckBox.checked = true; // Opción por defecto

      // Crear el CheckBox para Show console
      let showConsoleCheckBox = new CheckBox;
      showConsoleCheckBox.text = "Show console";
      showConsoleCheckBox.checked = true; // Opción por defecto

      // Manejar el evento onCheck para mostrar u ocultar la consola
      showConsoleCheckBox.onCheck = function (checked) {
          if (checked) {
              OptionshowConsolRadio = "ON";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.show(); // Mostrar la consola
          } else {
              OptionshowConsolRadio = "OFF";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.hide(); // Ocultar la consola
          }
      };


   this.exitButton.setFixedWidth(200);

    // Sizer para HELP y EXIT en la misma línea
    this.helpExitSizer = new HorizontalSizer;
    this.helpExitSizer.spacing = 10;
    this.helpExitSizer.add(this.HelpButton);
    this.helpExitSizer.addStretch();
    this.helpExitSizer.add(showConsoleCheckBox);
     this.helpExitSizer.addStretch();
    this.helpExitSizer.add(this.exitButton);


    // Sizer principal
    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;
    this.sizer.spacing = 10;

    this.sizer.add(this.tabBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.helpExitSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = "Automator Script";

}



IntegratorDialog.prototype = new Dialog;

let dialog = new IntegratorDialog();
dialog.execute();
