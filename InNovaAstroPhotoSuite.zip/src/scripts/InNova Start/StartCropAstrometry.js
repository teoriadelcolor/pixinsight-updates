
function StartCropAstrometryScale(window)
{
   if (!window || window.isNull) return null;
   try {


      let metadata = new AstrometricMetadata("ImageSolver");
      metadata.focal = null;
      metadata.xpixsz = null;
      metadata.resolution = null;
      metadata.ExtractMetadata(window);
      let scale = metadata.resolution;
      if (MiraIsFiniteNumber(scale) && scale > 0) return scale;

      function number(name) {
         let entry = MiraWindowKeywordEntry(window, [name]);
         if (!entry) return null;
         let value = Number(entry.value.replace(/[dD]/g, "e"));
         return isFinite(value) ? value : null;
      }
      let unit1 = MiraWindowKeywordEntry(window, ["CUNIT1"]);
      let unit2 = MiraWindowKeywordEntry(window, ["CUNIT2"]);
      if ((!unit1 || /^deg(rees)?$/i.test(unit1.value)) &&
          (!unit2 || /^deg(rees)?$/i.test(unit2.value))) {
         let a = number("CD1_1"), b = number("CD1_2");
         let c = number("CD2_1"), d = number("CD2_2");
         if (a !== null && d !== null) {
            scale = (Math.sqrt(a*a + (b || 0)*(b || 0)) +
               Math.sqrt((c || 0)*(c || 0) + d*d))/2;
            if (scale > 0) return scale;
         }
         let x = number("CDELT1"), y = number("CDELT2");
         if (x && y) return (Math.abs(x) + Math.abs(y))/2;
      }
   } catch (e) {
      console.warningln("⚠️ Cannot read original image scale for " + window.mainView.id + ": " + e);
   }
   return null;
}

var StartCropAstrometryRunProcessor = "__RUN_INNOVA_ASTRO_PROCESSOR__";

function StartCropAstrometryFailureAction(text, allowProcessorLaunch)
{
   let prompt = new Dialog;
   prompt.windowTitle = "🔭 InNova Bridge — Astrometric Solution";
   prompt.sizer = new VerticalSizer;
   prompt.sizer.margin = 16;
   prompt.sizer.spacing = 12;

   let header = StartLauncherPanel(prompt, true);
   header.setScaledFixedHeight(92);
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   header.sizer.add(StartLauncherIcon(header, "bridge", 68));
   let headerText = new VerticalSizer;
   headerText.spacing = 5;
   headerText.addStretch();
   headerText.add(StartLauncherLabel(header,
      "<b>Astrometric Solution</b>", 20, "#102b50", false));
   headerText.add(StartLauncherLabel(header,
      "Restore the astrometric solution after cropping.",
      12, "#243f5b", false));
   headerText.addStretch();
   header.sizer.add(headerText, 100);
   prompt.sizer.add(header);

   let message = new Label(prompt);
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_Center;
   message.text =
      "<p align=\"center\"><b>Automatic astrometry could not be completed.</b></p>";
   message.setScaledMinWidth(620);
   prompt.sizer.add(message);
   let action = "cancel";
   let buttons = new HorizontalSizer;
   buttons.spacing = 8;
   buttons.addStretch();
   let retry = new PushButton(prompt);
   retry.text = "Retry";
   retry.icon = prompt.scaledResource( ":/icons/reload.png" );
   retry.setScaledFixedHeight(28);
   retry.onClick = function() { action = "retry"; prompt.ok(); };
   buttons.add(retry);
   if ( allowProcessorLaunch === true ) {
      let run = new PushButton(prompt);
      run.text = "🚀  Run InNova Astro Processor";
      run.setScaledFixedHeight(28);
      run.onClick = function() { action = "processor"; prompt.ok(); };
      buttons.add(run);
   }
   let cancel = new PushButton(prompt);
   cancel.text = "Cancel";
   cancel.icon = prompt.scaledResource( ":/icons/cancel.png" );
   cancel.setScaledFixedHeight(28);
   cancel.onClick = function() { action = "cancel"; prompt.cancel(); };
   buttons.add(cancel);
   buttons.addStretch();
   prompt.sizer.add(buttons);
   prompt.adjustToContents();
   prompt.execute();
   return action;
}

function StartRestoreCropAstrometry(series, consoleVisibilityChanged,
   showApplyMultiNightPrompt, allowProcessorLaunch)
{
   function setProcessConsoleVisible(visible)
   {
      if (visible) console.show();
      else console.hide();
      if (typeof consoleVisibilityChanged == "function")
         consoleVisibilityChanged(visible);
      CoreApplication.processEvents();
   }

   let previousTarget = "";
   while (true) {
   let pending = series.filter(function(item) {
      return !MiraHasAstrometricSolution(item.window);
   });
   if (pending.length == 0) {
      setProcessConsoleVisible(false);
      return "Astrometric solutions are available.";
   }
   try {
      let prompt = new Dialog;
      prompt.windowTitle = "🔭 InNova Bridge — Astrometric Solution";
      prompt.sizer = new VerticalSizer;
      prompt.sizer.margin = 16;
      prompt.sizer.spacing = 12;

      let header = StartLauncherPanel(prompt, true);
      header.setScaledFixedHeight(92);
      header.sizer = new HorizontalSizer;
      header.sizer.margin = 12;
      header.sizer.spacing = 16;
      header.sizer.add(StartLauncherIcon(header, "bridge", 68));
      let headerText = new VerticalSizer;
      headerText.spacing = 5;
      headerText.addStretch();
      headerText.add(StartLauncherLabel(header,
         "<b>Astrometric Solution</b>", 20, "#102b50", false));
      headerText.add(StartLauncherLabel(header,
         "Restore the astrometric solution after cropping.",
         12, "#243f5b", false));
      headerText.addStretch();
      header.sizer.add(headerText, 100);
      prompt.sizer.add(header);

      let message = new Label(prompt);
      message.useRichText = true;
      message.textAlignment = TextAlign_Center;
      message.text = "<b>Enter the object name and click Solve.</b>";
      message.margin = 6;
      prompt.sizer.add(message);
      let target = new Edit(prompt);
      target.text = previousTarget;
      target.toolTip =
         "Enter a catalog name, such as M 31 or NGC 7000.";
      target.setScaledMinWidth(620);
      prompt.sizer.add(target);
      let buttons = new HorizontalSizer;
      buttons.spacing = 8;
      buttons.addStretch();
      let solve = new PushButton(prompt);
      solve.text = "Solve";
      solve.icon = StartImageSolverIcon();
      solve.setScaledFixedHeight(28);
      solve.enabled = false;
      let cancel = new PushButton(prompt);
      cancel.text = "Cancel";
      cancel.icon = prompt.scaledResource( ":/icons/cancel.png" );
      cancel.setScaledFixedHeight(28);
      let examples = new Label(prompt);
      examples.useRichText = true;
      examples.textAlignment = TextAlign_Center;
      examples.text =
         "<span style=\"color:#506070\">Examples: M 42, NGC 6888, " +
         "IC 1848</span>";
      prompt.sizer.add(examples);
      buttons.add(solve);
      buttons.add(cancel);
      buttons.addStretch();
      prompt.sizer.add(buttons);
      function validate() {
         solve.enabled = target.text.trim().length > 0;
      }
      target.onTextUpdated = validate;
      validate();
      solve.onClick = function() { prompt.ok(); };
      cancel.onClick = function() { prompt.cancel(); };
      prompt.adjustToContents();
      if (prompt.execute() != StdDialogCode_Ok)
         return "Cropped images kept without astrometric solutions.";

      previousTarget = target.text.trim();


      setProcessConsoleVisible(true);
      let seed = MiraResolveSesameObject(previousTarget);
      if (!seed) throw new Error("The object name could not be resolved. Check the catalog name and Internet connection.");
      let failed = [];
      let solved = 0;
      for (let i = 0; i < pending.length; ++i) {
         let item = pending[i];
         try {
            console.noteln("🔭 Solving cropped image " + (i + 1) + "/" + pending.length + ": " + item.window.mainView.id);
            let solveWindow = item.astrometrySolveWindow != null &&
               !item.astrometrySolveWindow.isNull ?
               item.astrometrySolveWindow : item.window;
            if (solveWindow !== item.window)
               console.noteln("🔭 Using an identically cropped linear proxy for ImageSolver.");
            let solver = MiraPrepareAutomaticSolver(solveWindow, false, seed, 0);
            let resolution = item.astrometryScale;
            if (!MiraIsFiniteNumber(resolution) || resolution <= 0) {


               resolution = solver.metadata.resolution;
               if (solver.metadata.useFocal && solver.metadata.focal > 0 && solver.metadata.xpixsz > 0)
                  resolution = solver.metadata.ResolutionFromFocal(solver.metadata.focal);
               console.noteln("🔭 Original image scale unavailable; using ImageSolver configuration: " +
                  (resolution * 3600) + " arcsec/pixel.");
            }
            if (!MiraIsFiniteNumber(resolution) || resolution <= 0)
               throw new Error("Neither the image nor the ImageSolver configuration provides a usable scale.");
            solver.metadata.resolution = resolution;
            solver.metadata.useFocal = false;

            solver.solverCfg.generateDistortModel = false;
            solver.solverCfg.showStars = false;
            solver.solverCfg.showStarMatches = false;
            solver.solverCfg.showDistortion = false;
            solver.solverCfg.showSimplifiedSurfaces = false;


            solver.solverCfg.distortionCorrection = false;
            if (!MiraHasAstrometricSolution(solveWindow))
               solver.solveImage(solveWindow);
            if (solveWindow !== item.window &&
                !StartCopyAstrometricSolution(solveWindow, item.window))
               throw new Error("The linear proxy solution could not be transferred to the cropped image.");
            if (!MiraHasAstrometricSolution(item.window))
               throw new Error("ImageSolver did not produce a valid solution.");
            ++solved;
         } catch (e) {
            failed.push(item.window.mainView.id);
            console.warningln("⚠️ Astrometry failed for " + item.window.mainView.id + ": " + e);
         }
      }

      setProcessConsoleVisible(false);
      if (failed.length) {
         let failureAction = StartCropAstrometryFailureAction(
            "ImageSolver failed for " + failed.length +
            (failed.length == 1 ? " image." : " images.") +
            "\nSee the Process Console for details.", allowProcessorLaunch);
         if (failureAction == "retry")
            continue;
         if (failureAction == "processor")
            return StartCropAstrometryRunProcessor;
      }
      else if (solved > 0) {
         let completedText = showApplyMultiNightPrompt === true ?
            "<p align=\"center\"><b>Process completed successfully.</b></p>" +
            "<p align=\"center\">Now click the <b>Apply Multi-night</b> button.</p>" :
            "<p align=\"center\">Astrometric solution completed successfully.</p>" +
            "<p align=\"center\">" + solved +
            (solved == 1 ? " cropped image has" : " cropped images have") +
            " a valid astrometric solution.</p>";
         new MessageBox(completedText,
            "InNova Bridge — Astrometry", StdIcon_Information, StdButton_Ok).execute();
      }
      return "Astrometry restored for " + solved + " of " + pending.length + " cropped images.";
   } catch (e) {
      setProcessConsoleVisible(false);
      console.warningln("⚠️ Crop astrometry: " + e);
      let failureAction = StartCropAstrometryFailureAction(
         String(e), allowProcessorLaunch);
      if (failureAction == "retry") continue;
      if (failureAction == "processor")
         return StartCropAstrometryRunProcessor;
      return "Cropped images kept; automatic astrometry could not be completed.";
   }
}
}
