InNova Start — startup window (build 0290)

The menu command is InNova START. The release launcher includes InNova Subframe Review & Integration,
Multi-Night, Astro Processor, Adaptive Stretch and Photo Editor. Guided Workflow
begins with a simplified visual journey: Load files, Process a single-night or
multi-night, and Edit & Export.
Guided Workflow retains image selection and handoff to Astro Processor. Astro
Processor (current Integrator), Adaptive Stretch and Photo Editor (current
Editor) each open independently from the module selector. Their internal renaming
will follow separately. Exit closes Start.

Astro Processor includes the same dedicated blue masters folder used by
Multi-Night beside its standard image folder. It opens the image selector
directly in Documents/InNova/Sub master files.

INNOVA GET STARTED
============

Current version: v.1.0.build.0290

The Start launcher presents the standalone modules in one compact icon row.
Pointing at an icon enlarges it inside a fixed slot and updates the shared
information panel below. A single click on the highlighted icon or Open
launches the selected module. Larger selector icons improve recognition while
the five columns retain the existing launcher width. Milky Way and Eclipses
remain outside this release while their applications are under development.

Clicking Start step by step first opens a branded Guided Workflow choice over
the InNova galaxy background. Its three compact cards fit inside the original
fixed-size window. Open subframes for integration starts Subframe Review; Open
one stacked image opens Astro Processor for a Seestar, Vespera or other
integrated source; Open
multi-night masters starts the combination route.
The button reverses to a white background with blue text and border while the
pointer is over it, making its interactive state explicit.
After Guided Subframe completes its save step, every generated master is
opened in PixInsight and assigned directly to Astro Processor, whether Yes or
No is selected in the save dialog. The intermediate three-choice selector is
not shown. Astro Processor opens directly with the transferred images and
channels. Its Run button always opens one shared Basic/Advanced selector
immediately before processing starts, regardless of whether Astro Processor
was opened directly, from Guided Workflow, Subframe Review or Multi-Night.
Basic runs Photo Editor; Advanced provides the full process checklist. Astro
Processor returns to InNova START when its workflow ends.

Subframe Review & Integration
-----------------------------

Multi-Night includes a dedicated blue folder beside the standard yellow folder.
It always opens Documents/InNova/Sub master files, where Subframe Review saves
the master images selected by the user.
Clicking the orange Combine star marks the current source and automatically
advances the preview to the next image. The final image remains selected, and
removing a mark does not move away from the image being corrected.
Multi-Night inspects the RGB channel medians before its first Quick
Stretch preview. A severe linear-background colour imbalance automatically
uses independent channel stretches, while balanced and nonlinear images keep
their linked-channel relationship. The toolbar control remains available for
manual selection and displays the current linked or unlinked state.

InNova Subframe Review & Integration runs before Multi-Night. Load FITS, XISF or TIFF subframes,
inspect them with the fitted quick-stretch preview, move backward or forward,
or use Blink for automatic playback. The Blink control changes from Play to
Pause while playback is running and returns to Play when it stops. Every row has a Use checkbox and the Keep
selected, Reject selected and Keep all actions. Files rejected during review
are excluded from integration; original files are never changed or deleted.
After the user zooms or pans a subframe, consecutive previews retain the same
zoom level and relative centre. Fit mode continues fitting each new image until
the user selects a manual zoom.
The preview and Multi-Night share the same viewport core for fit, bilinear zoom,
scrolling and pan behaviour, while retaining workflow-specific controls.

The Integrate selected subs with selector offers FBPP first and WBPP second.
The calibration-folder action and the pre-run question accept optional Bias,
Darks and Flats folders independently. FBPP/WBPP receives each selected folder
through its official recursive directory automation argument and identifies the
calibration type from image metadata and smart folder/file naming. Only accepted
light subframes are passed as light inputs from the review list.
Run launches the selected official PixInsight preprocessing script immediately
in automation mode with only the accepted files. Work files are written to a
unique run folder under Documents/InNova/Subframe temporary. InNova
displays the current elapsed time and offers STOP. While the auxiliary
PixInsight instance starts, this compact progress dialog recovers the foreground
briefly so STOP remains accessible on a single-display system. It stops forcing
the foreground after startup, allowing either instance to be inspected normally.
After processing finishes,
InNova offers to retain the generated masters under
Documents/InNova/Sub master files. The save dialog creates a named subfolder
for each set of masters. Its editable Folder name field starts with the current
date in YYYY-MM-DD format.
When the user declines, the masters are loaded into Multi-Night first and the
temporary run folder is then deleted. Guided
Workflow also offers Skip to Multi-Night when the subs have already been integrated.
The untitled lower status box reports the configured DR3 folder and accessible XPSD
files. These paths are transferred to the separate PixInsight instance used by
FBPP/WBPP before automatic preprocessing starts.

InNova Start is the preparation module for multi-night and multi-exposure
deep-sky HDR projects. This first development build implements the safe front
half of the proposed workflow:

1. Load FITS, XISF, TIFF and camera RAW images or discover images already open
   in PixInsight. The RAW selector covers the major Canon, Nikon, Sony,
   Fujifilm, Olympus/OM System, Panasonic, Pentax, Leica, Hasselblad, Phase One,
   Sigma, Kodak and other manufacturer extensions supported by PixInsight.
   Loading reports a live stopwatch and preserves the final elapsed time.
   The initial Multi-Night screen shows only a Quick Stretch preview of the selected
   table row before Run. Selection and exclusion continue through the existing
   Input images table and lower toolbar.
2. Read exposure, filter, camera, dimensions and channel metadata.
3. Diagnose whether the selection is a single image, a single-night set, a
   multi-night integration set, a multi-channel project or an HDR exposure
   series.
4. Estimate image quality and automatically select a reference.
   The reference is chosen from the dominant image geometry, preventing an
   isolated mask or unrelated frame from becoming the reference merely because
   it has high contrast.
5. Preflight the reference star field. References with fewer than three
   detected stars switch directly to Sun/Moon preparation as a normal workflow
   adjustment, avoiding an alarming StarAlignment error for bright targets.
6. Register non-reference images with StarAlignment when a stellar field is
   available.
7. Create a registered copy of the reference so every source follows the same
   non-destructive workflow.
8. Detect the largest rectangular region with common data in every registered
   image, with a configurable safety margin.
9. Draw the retained crop rectangle directly over the image when a custom crop
   is preferred.
10. Apply exactly the same crop to newly generated copies.
    A visual crop made from the main Multi-Night preview is accepted for the
    complete registered sequence and the pending integration resumes once,
    without requesting the same crop again.
11. Inspect registered and cropped copies in the built-in quick-stretch image
    viewer without modifying their linear pixel data.

Analyze and registration are executed by one Run button. Its English tooltip
describes every operation performed by the button.

Multi-night and HDR groups are configured visually in the registered/cropped
image viewer. The orange star toggles the currently visible image in or out of
the Multi-exposure group. On the first selection, a centred dialog chooses the
acquisition type and shows the target treatment. The first Next generates and
displays the combined result; a second Next continues to an InNova module.
Generated combinations use a bold blue `NEW INTEGRATED` or `NEW HDR` viewer
label. The compact destination step lists every individual and generated image
with a checkbox, so only explicitly selected images are sent to InNova
Integrator. It automatically fills the Sii, Ha, Oiii, R, G, B, L and OSC image
selectors with the best selected prepared result, prioritising a new HDR or
multi-night integration, then a crop, then a registered copy.
After Multi-Night creates a combined master, Run is disabled and the same
dated, editable-folder save dialog used by Subframe Review is displayed. On
leaving Multi-Night, all temporary InNovaStartRegistered and InNovaStartCrop
windows are closed while original images and the combined result are retained.

With one source image, Run skips StarAlignment, creates one non-destructive
review copy and opens the same quick-stretch viewer directly. Visual Crop,
Restore, zoom, Fit and Pan remain available, including for Vespera images.

Object treatment is automatic. Every new project first uses the normal Nebula
or Galaxy stellar workflow. If StarAlignment cannot register any target because
there is no usable star field, InNova Start automatically switches to Sun or
Moon treatment, cleans the failed review output and retries without requiring a
second Run. Bright-target treatment creates a safe review copy for every
exposure and opens the same viewer for inspection, removal, synchronized crop
and HDR selection.

The main header has no manual Project or Object boxes. It presents the guided
Single night, Multi-night and HDR workflow, while project/object metadata remain
internal for automatic processing and handoff. The compact resizable table is
initially sized through Camera; remaining columns stay available with the Input
images horizontal scroll bar.

HDR and Multi-night generation report a live stopwatch in both the main status
and the review information box, and retain the final elapsed time.

The review window ends with Back and Next navigation buttons. Back returns to
the initial InNova Start window for project changes. Next opens the Processing
Destination step with InNova Astro Processor, InNova Adaptive Stretch and InNova
Editor choices, followed by Exit.

Before the image table, three selectors define the processing context:

- Project: the same LRGB, RGB, SHO, HOO, OSC, SEESTAR and VAONIS VESPERA
  choices used by InNova Astro Processor.
- Acquisition: One single night, Multi-night or HDR (High Dynamic Range).
- Object type: Nebula or Galaxy, or Sun or Moon.

The selections are stored in shared PixInsight Settings keys named
InNovaHandoffProjectType, InNovaHandoffAcquisitionMode and
InNovaHandoffObjectType. They are ready for the future direct Integrator
launch/handoff. Sun or Moon skips stellar StarAlignment.

Image viewer
------------

InNova Multi-Night is dedicated to combining masters captured over multiple
nights. Its table places a
Combine selector immediately after Use, and its toolbar places Combine, Crop
and Reset immediately after the linked-channel control. Run requires at least
two marked images, registers them, performs the former Bridge multi-night
validation and creates the SNR-weighted combined result. The result is added
as a green row and selected in this same window. Magnifier buttons zoom in and
out and the hand enables drag-to-pan.
The chain control immediately before Adaptive Stretch shows the next RGB
Quick Stretch action. A chain with an X unlinks the channels and recalculates
the preview with independent R, G and B transforms; a plain chain links them
again and uses one shared RGB transform. Multi-Night inspects the first Quick
Stretch before displaying the opposite action, and remembers the setting for
each image while navigating.
There is no separate Crop box. The classic Crop icon activates direct visual
crop selection and asks whether to apply it to the complete sequence.

While crop selection or editing is active, every viewer toolbar control except
Crop is disabled. Clicking Crop again asks whether the selection is correct and
should be synchronized with the complete image sequence. Yes applies the crop;
No leaves the images unchanged and restores all viewer controls.

The Restore icon beside Crop asks for confirmation before discarding every
crop adjustment. It removes generated crop copies and reloads the original
registered sequence; source images and registered copies remain unchanged.

After the rectangle is drawn, it remains editable. Drag inside it to move the
complete frame, or drag any of its four corner and four edge handles to enlarge
or contract it. Click Crop a second time to confirm and apply the crop.

The viewer trash icon asks for confirmation before excluding the current exposure
from the project, table and registered/cropped sequences. It never closes,
deletes or modifies the corresponding PixInsight image. After Crop is applied,
the viewer automatically reloads the newly cropped copies for inspection.

Cropping is visual. Click Crop and drag a rectangle directly over the preview:
the area inside the blue rectangle is retained and the shaded area outside is
removed. The same rectangle is applied to the complete current sequence. The
manual X/Y/Width/Height fields are intentionally omitted. A further visual crop
can be drawn on the already cropped sequence if another adjustment is needed.

In the main window, Trash closes every image in the current project, including
the originals, and clears Input images. The adjacent recycle icon closes only
generated registration/crop results; original inputs remain open and loaded so
Run can be repeated from a clean state.

Project protection
------------------

Generated masks, previews, registered images, crops, rejection maps, weight
maps, starless/stars layers and background-model images are detected when the
image list is refreshed. They remain visible for diagnosis but are unchecked
automatically and a project warning identifies them.

Before registration, InNova Start also warns about conflicting OBJECT or WCS
coordinates, substantially different geometry and frame scales. If
StarAlignment succeeds only partially, successful copies remain usable while
failed images are explicitly identified and excluded from common-crop
calculation.

No source image is modified. Generated views use the suffixes
_InNovaStartRegistered and _InNovaStartCrop.

License and trial
-----------------

InNova Start is always free. It displays the locally available Suite trial or
license status and remaining days, but expiry, missing licenses, validation
failures and status-read errors never block Start. Paid modules retain their
own license checks. The shared trial clock is never reset by Start.

Planned next stages
-------------------

- Interactive crop overlay and coverage map.
- Registration quality report and limiting-image warnings.
- Per-exposure/per-filter integration for multi-night projects.
- HDR fusion of the resulting exposure masters.
- Final astrometric verification and hand-off to Adaptive Stretch/Editor.

Installation
------------

Add the InNova Start folder to PixInsight's script directories and use
Script > Feature Scripts to rescan. The command will appear under:

InNova Astro Photo Suite > InNova START
