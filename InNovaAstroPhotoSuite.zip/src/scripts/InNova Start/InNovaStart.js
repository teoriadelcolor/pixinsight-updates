#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaStart : InNova Astro Photo Suite > InNova START
#feature-icon  InNovaStartIcon.svg
#feature-info  Guided workflow, image preparation and direct access to InNova modules.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

new MessageBox( "InNova START requiere PixInsight 1.9.4 o posterior.",
   "InNova START", StdIcon_Error, StdButton_Ok ).execute();

#else

#engine v8


#define TITLE "InNova Start"

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>
#include <pjsr/ImageOp.jsh>

var InNovaStartVersion = "v.1.0.build.0290";

var OptionSeestar = "OFF";
var OptionSmartTelescopeModel = "SEESTAR_AUTO";
var InNovaStartRegisteredSuffix = "_InNovaStartRegistered";
var InNovaStartBrightTargetSuffix = "_InNovaStartBrightTarget";
var InNovaStartCropSuffix = "_InNovaStartCrop";
var InNovaStartHDRSuffix = "_InNovaStartHDR";
var InNovaStartIntegrationSuffix = "_InNovaStartIntegration";
var InNovaStartCombinedSuffix = "_combined";
var InNovaHandoffProjectSetting = "InNovaHandoffProjectType";
var InNovaHandoffAcquisitionSetting = "InNovaHandoffAcquisitionMode";
var InNovaHandoffObjectSetting = "InNovaHandoffObjectType";
var InNovaIntegratorHandoffPendingSetting =
   "InNovaGetStartedIntegratorHandoffPending";
var InNovaIntegratorHandoffProjectSetting =
   "InNovaGetStartedIntegratorProject";
var InNovaIntegratorHandoffImagePrefix =
   "InNovaGetStartedIntegratorImage_";
var InNovaIntegratorHandoffRgbStarsSetting =
   "InNovaGetStartedIntegratorRgbStars";
var InNovaIntegratorHandoffHaBlendSetting =
   "InNovaGetStartedIntegratorHaBlend";
var InNovaIntegratorHandoffNoticeShownSetting =
   "InNovaGetStartedIntegratorNoticeShown";
var InNovaIntegratorProcessSettingPrefix =
   "InNovaGetStartedIntegratorProcess_";
var ProjecTname = "✦ InNova Start";
var ProjecTver = InNovaStartVersion;


var _0x6d1f63ff9b = String.fromCharCode(49,56,97,100,48,57,120,106,114);
var _0xd70ef7a89b =
   String.fromCharCode(101,102,48,50,56,100,50,54,101,100,55,52,54,50,99,52,54,53,102,52,48,57,49,101,57,54,53,98,52,97,102,57,102,99,100,54,102,97,49,50,53,98,50,53,57,55,48,101,56,51,51,51,98,98,55,49,97,52,102,53,50,100,49,52);
var _0x9627d349e7 = "";
var _0xf30298b9b9 = "EMPTY";
var _0xb1b3782c92 = false;
var InNovaStartPreviewSerial = 0;
var InNovaStartBugLogActive = false;
var InNovaStartExistingConsoleText = "";

function StartBeginBugReportCapture()
{


   try {
      InNovaStartExistingConsoleText = String( console.logText() );
   } catch ( error ) {
      InNovaStartExistingConsoleText = "";
   }
   try {
      console.beginLog();
      InNovaStartBugLogActive = true;
   } catch ( error ) {
      InNovaStartBugLogActive = false;
   }
}

function StartBugReportBuildInformation()
{
   return [
      "InNova Start: " + InNovaStartVersion,
      "InNova Astro Processor: v.1.0.build.0462",
      "InNova Photo Editor: v.1.0.build.0218",
      "InNova Photo Editor engine: build 0176",
      "InNova Adaptive Stretch: v.1.0.build.0094",
      "PixInsight: " + CoreApplication.versionMajor + "." +
         CoreApplication.versionMinor + "." +
         CoreApplication.versionRelease + " build " +
         CoreApplication.versionBuild,
      "Platform: " + CoreApplication.platform
   ].join( "\n" );
}

function StartBugReportText()
{
   let currentConsoleText = "";
   try {
      currentConsoleText = String( console.logText() );
   } catch ( error ) {
      currentConsoleText = "";
   }
   let consoleText = currentConsoleText;
   if ( InNovaStartExistingConsoleText.length > 0 ) {
      if ( currentConsoleText.indexOf( InNovaStartExistingConsoleText ) < 0 )
         consoleText = InNovaStartExistingConsoleText +
            (currentConsoleText.length > 0 ? "\n" + currentConsoleText : "");
   }
   if ( consoleText.length == 0 )
      consoleText = "No console output was available for this session.";
   return "InNova Astro Photo Suite - Bug report\n" +
      "Generated: " + new Date().toISOString() + "\n\n" +
      "BUILDS\n------\n" + StartBugReportBuildInformation() +
      "\n\nPIXINSIGHT PROCESS CONSOLE\n--------------------------\n" +
      consoleText + "\n";
}

function StartOpenBugReportEmail( reportPath )
{
   let recipient = "soporte@teoriadelcolor.net";
   let subject = "InNova Astro Photo Suit - Bug report";
   let body = "Hello,\n\nThe InNova bug report is attached.\n\n" +
      StartBugReportBuildInformation();
   let platform = String( CoreApplication.platform ).toLowerCase();
   if ( platform.indexOf( "mac" ) >= 0 ) {


      let mailAutomation =
         "function run(argv) {\n" +
         "if (argv.length < 4) return false;\n" +
         "var mail = Application('Mail');\n" +
         "var message = mail.OutgoingMessage({subject:argv[2], " +
            "content:argv[3] + '\\n\\n', visible:true});\n" +
         "mail.outgoingMessages.push(message);\n" +
         "message.toRecipients.push(mail.ToRecipient({address:argv[1]}));\n" +
         "message.content.attachments.push(mail.Attachment(" +
            "{fileName:Path(argv[0])}));\n" +
         "mail.activate();\n" +
         "return true;\n" +
         "}";
      try {
         let mailProcess = new ExternalProcess;
         mailProcess.start( "/usr/bin/osascript",
            [ "-l", "JavaScript", "-e", mailAutomation, "--",
              reportPath, recipient, subject, body ] );
         if ( mailProcess.waitForStarted( 3000 ) )
            return true;
      } catch ( error ) {}
   }
   let mailUrl = "mailto:" + recipient + "?subject=" +
      encodeURIComponent( subject ) + "&body=" + encodeURIComponent(
         body + "\n\nThe report was saved as:\n" + reportPath );
   try {
      let command = platform.indexOf( "win" ) >= 0 ?
         [ "cmd.exe", [ "/c", "start", "", mailUrl ] ] :
         [ "xdg-open", [ mailUrl ] ];
      if ( platform.indexOf( "mac" ) >= 0 )
         command = [ "/usr/bin/open", [ mailUrl ] ];
      let process = new ExternalProcess;
      process.start( command[0], command[1] );
      if ( process.waitForStarted( 3000 ) ) return true;
   } catch ( error ) {}
   try {
      Dialog.openBrowser( mailUrl, "InNova Bug Report" );
      return true;
   } catch ( error ) {
      return false;
   }
}

#include "../InNova/lib/lite01.js"

#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaBridgeImageSolver"
#include "../InNova/lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Start"
#include "../InNova/lib/process12.js"
#include "StartCropAstrometry.js"
#include "lib/ImageReviewViewport.js"


var InNovaStartSuiteStatus = "Suite status unavailable";

function _0x88bfe5ab4a()
{
   return "FREE · " + InNovaStartSuiteStatus.replace( / · \d+ day\(s\)/g, "" );
}

function _0x195e32f0d7()
{
   _0x9627d349e7 = "";
   _0xf30298b9b9 = "EMPTY";
   try {
      let _0x15139f4b5f = _0x7eee2bd14f();
      if ( _0xd86c035f60( _0x15139f4b5f ) ) {
         if ( _0x3f51e778c9( _0x15139f4b5f ) ) {
            let days = _0x5bac6fd5ce( _0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)] );
            let _0xa95094b41d = _0xbbbb498022( _0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)] );
            _0xf30298b9b9 = _0xa95094b41d ? String.fromCharCode(69,88,80,73,82,69,68) : "FULL";
            InNovaStartSuiteStatus = String.fromCharCode(76,73,67,69,78,83,69,32,183,32) + days + " day(s)" +
               (_0xa95094b41d ? String.fromCharCode(32,183,32,69,120,112,105,114,101,100) : "");
         } else {
            InNovaStartSuiteStatus = String.fromCharCode(76,73,67,69,78,83,69,32,183,32,86,101,114,105,102,105,99,97,116,105,111,110,32,114,101,113,117,105,114,101,100);
         }
      } else if ( _0xb4b48f6b83() ) {
         InNovaStartSuiteStatus = String.fromCharCode(76,73,67,69,78,83,69,32,183,32,78,111,116,32,97,118,97,105,108,97,98,108,101,32,108,111,99,97,108,108,121);
      } else {
         let days = _0x584b867740();
         _0xf30298b9b9 = days > 0 ? "PROJECT" : String.fromCharCode(69,88,80,73,82,69,68);
         InNovaStartSuiteStatus = String.fromCharCode(84,82,73,65,76,32,183,32) + days + " day(s)" +
            (days == 0 ? String.fromCharCode(32,183,32,69,120,112,105,114,101,100) : "");
      }
   } catch ( error ) {
      InNovaStartSuiteStatus = "Suite status unavailable";
      console.warningln( "⚠️ Suite status could not be read. InNova Start remains available." );
   }
   return true;
}

function StartKeywordValue( window, names )
{
   if ( window == null || window.isNull )
      return "";
   let keywords = window.keywords;
   for ( let i = 0; i < keywords.length; ++i ) {
      let name = String( keywords[i].name ).toUpperCase();
      for ( let j = 0; j < names.length; ++j )
         if ( name == names[j] )
            return String( keywords[i].strippedValue ).trim();
   }
   return "";
}

function StartExposureSeconds( window )
{
   let value = StartKeywordValue( window,
      [ "EXPTIME", "EXPOSURE", "EXPOSURETIME" ] );
   if ( value.length == 0 )
      return NaN;
   let slash = value.indexOf( "/" );
   if ( slash > 0 ) {
      let a = parseFloat( value.substring( 0, slash ) );
      let b = parseFloat( value.substring( slash + 1 ) );
      return b != 0 ? a/b : NaN;
   }
   return parseFloat( value );
}

function StartExposureText( seconds )
{
   if ( !isFinite( seconds ) || seconds <= 0 )
      return "—";
   if ( seconds < 1 ) {
      let denominator = Math.round( 1/seconds );
      if ( denominator > 1 )
         return "1/" + denominator + " s";
   }
   return format( "%.6g s", seconds );
}

function StartElapsedRichText( elapsed )
{
   return "<b style=\"color:#d02020\">⏱ Elapsed: " + elapsed + "</b>";
}

function StartSafeId( text )
{
   let id = String( text ).replace( /[^A-Za-z0-9_]/g, "_" );
   if ( id.length == 0 || !/[A-Za-z]/.test( id.charAt( 0 ) ) )
      id = "InNovaStart_" + id;
   return id;
}

function StartAuxiliaryReason( id )
{
   let value = String( id ).toLowerCase();


   if ( StartIsReusableBridgeOutput( id ) )
      return "";
   if ( value.indexOf( "registered" ) >= 0 ||
        value.indexOf( "innovastartcrop" ) >= 0 )
      return "InNova Multi-Night or registration output";
   let generatedTokens =
      /(^|_)(mask|preview|registered|crop|rejection|weight|background|starless|stars|abe|dbe)(_|[0-9]|$)/;
   if ( generatedTokens.test( value ) )
      return "Auxiliary/generated image";
   return "";
}

function StartIsReusableBridgeOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "innovastartregistered" ) >= 0 ||
      value.indexOf( "innovastartbrighttarget" ) >= 0 ||
      value.indexOf( "innovastartcrop" ) >= 0 ||
      value.indexOf( "innovastarthdr" ) >= 0 ||
      value.indexOf( "innovastartintegration" ) >= 0;
}

function StartIsTransientBridgeOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "innovastartpreview" ) >= 0 ||
      value.indexOf( "innovastartstarpreflight" ) >= 0 ||
      value.indexOf( "innovastarthdrfileinput" ) >= 0;
}

function StartIsGeneratedOutput( id )
{
   let value = String( id ).toLowerCase();
   return value.indexOf( "registered" ) >= 0 ||
      value.indexOf( "innovastartbrighttarget" ) >= 0 ||
      value.indexOf( "innovastartcrop" ) >= 0 ||
      value.indexOf( "innovastarthdr" ) >= 0 ||
      value.indexOf( "innovastartintegration" ) >= 0 ||
      value.indexOf( "innovastartpreview" ) >= 0;
}

function StartHandIcon()
{
   let bitmap = new Bitmap( 24, 24 );
   bitmap.fill( 0x00000000 );
   let g = new Graphics( bitmap );
   g.antialiasing = true;
   g.pen = new Pen( 0xff30343a, 2 );
   g.drawLine( 8, 4, 8, 14 );
   g.drawLine( 11, 2, 11, 14 );
   g.drawLine( 14, 3, 14, 14 );
   g.drawLine( 17, 5, 17, 15 );
   g.drawLine( 8, 12, 5, 9 );
   g.drawLine( 5, 9, 3, 11 );
   g.drawLine( 3, 11, 9, 21 );
   g.drawLine( 9, 21, 17, 21 );
   g.drawLine( 17, 21, 20, 15 );
   g.end();
   return bitmap.scaled( 2, 2, BitmapInterpolation_Bilinear );
}

function StartCropIcon()
{
   let bitmap = new Bitmap( 24, 24 );
   bitmap.fill( 0x00000000 );
   let g = new Graphics( bitmap );
   g.antialiasing = true;
   let scissorsFont = new Font;
   scissorsFont.pixelSize = 18;
   g.font = scissorsFont;
   g.pen = new Pen( 0xff101010 );
   let scissors = "✂";
   let scissorsX = Math.round( (24 - g.font.width( scissors ))/2 );
   let scissorsY = Math.round(
      (24 + g.font.ascent - g.font.descent)/2 );
   g.drawText( scissorsX, scissorsY, scissors );
   g.end();
   return bitmap.scaled( 2, 2, BitmapInterpolation_Bilinear );
}

function StartTrashIcon()
{
   let bitmap = new Bitmap( 24, 24 );
   bitmap.fill( 0x00000000 );
   let g = new Graphics( bitmap );
   g.antialiasing = true;
   g.pen = new Pen( 0xff30343a, 2 );
   g.drawLine( 5, 7, 19, 7 );
   g.drawLine( 8, 4, 16, 4 );
   g.drawLine( 6, 9, 7, 21 );
   g.drawLine( 18, 9, 17, 21 );
   g.drawLine( 7, 21, 17, 21 );
   g.drawLine( 10, 10, 10, 18 );
   g.drawLine( 14, 10, 14, 18 );
   g.end();
   return bitmap.scaled( 2, 2, BitmapInterpolation_Bilinear );
}

function StartEditorAdjustmentsIcon()
{
   let bitmap = new Bitmap(48, 48);
   bitmap.fill(0x00000000);
   let graphics = new Graphics(bitmap);
   graphics.antialiasing = true;
   graphics.pen = new Pen(0xff4a5057, 3);
   graphics.drawLine(6, 10, 42, 10);
   graphics.drawLine(6, 24, 42, 24);
   graphics.drawLine(6, 38, 42, 38);
   let blue = new Brush(0xff087bc9);
   graphics.fillCircle(16, 10, 5, blue);
   graphics.fillCircle(33, 24, 5, blue);
   graphics.fillCircle(21, 38, 5, blue);
   graphics.end();
   return bitmap;
}

function StartAdaptiveIcon()
{
   let bitmap = new Bitmap( 48, 48 );
   bitmap.fill( 0x00000000 );
   let graphics = new Graphics( bitmap );
   graphics.antialiasing = true;
   let dark = new Brush( 0xff666666 );
   let yellow = new Brush( 0xffffbf55 );
   graphics.fillCircle( 24, 24, 21, dark );
   for ( let sector = 0; sector < 3; ++sector ) {
      let points = [ new Point( 24, 24 ) ];
      for ( let angle = -120 + sector*120;
            angle <= -60 + sector*120; angle += 3 ) {
         let radians = angle*Math.PI/180;
         points.push( new Point( 24 + 21*Math.cos( radians ),
                                 24 + 21*Math.sin( radians ) ) );
      }
      graphics.fillPolygon( points, yellow );
   }
   graphics.fillCircle( 24, 24, 4, dark );
   graphics.end();
   return bitmap;
}

function StartSubframeMastersFolderIcon()
{
   return new Bitmap(":/icons/documents-import.png");
}

function StartQuickStretchLinkIcon( unlinkAction )
{
   let bitmap = new Bitmap( 48, 48 );
   bitmap.fill( 0x00000000 );
   let graphics = new Graphics( bitmap );
   graphics.antialiasing = true;
   graphics.pen = new Pen( unlinkAction ? 0xff4f565c : 0xff087bc9, 4 );


   let links = [
      [ [ 5, 30 ], [ 16, 19 ], [ 23, 19 ], [ 29, 25 ],
        [ 29, 31 ], [ 18, 42 ], [ 11, 42 ], [ 5, 36 ] ],
      [ [ 19, 17 ], [ 30, 6 ], [ 37, 6 ], [ 43, 12 ],
        [ 43, 18 ], [ 32, 29 ], [ 25, 29 ], [ 19, 23 ] ]
   ];
   for ( let link = 0; link < links.length; ++link )
      for ( let i = 0; i < links[link].length; ++i ) {
         let a = links[link][i];
         let b = links[link][(i + 1)%links[link].length];
         graphics.drawLine( a[0], a[1], b[0], b[1] );
      }
   if ( unlinkAction ) {
      graphics.pen = new Pen( 0xffd7191c, 4 );
      graphics.drawLine( 33, 4, 45, 16 );
      graphics.drawLine( 45, 4, 33, 16 );
   }
   graphics.end();
   return bitmap;
}

function StartColorCalibrationIcon()
{
   let bitmap = new Bitmap( 48, 48 );
   bitmap.fill( 0x00000000 );
   let graphics = new Graphics( bitmap );
   graphics.antialiasing = true;
   graphics.pen = new Pen( 0xff4a5057, 2 );
   graphics.fillCircle( 18, 19, 11, new Brush( 0xcce53935 ) );
   graphics.fillCircle( 30, 19, 11, new Brush( 0xcc168de2 ) );
   graphics.fillCircle( 24, 30, 11, new Brush( 0xcc22a35a ) );
   graphics.drawCircle( 18, 19, 11 );
   graphics.drawCircle( 30, 19, 11 );
   graphics.drawCircle( 24, 30, 11 );
   graphics.fillCircle( 24, 23, 4, new Brush( 0xffffffff ) );
   graphics.end();
   return bitmap;
}

function StartImageSolverIcon()
{
   let bitmap = new Bitmap( 48, 48 );
   bitmap.fill( 0x00000000 );
   let graphics = new Graphics( bitmap );
   graphics.antialiasing = true;
   graphics.pen = new Pen( 0xff4a5057, 3 );
   graphics.drawLine( 24, 5, 24, 43 );
   graphics.drawLine( 5, 24, 43, 24 );
   graphics.drawCircle( 24, 24, 15 );
   graphics.drawCircle( 24, 24, 7 );
   graphics.fillCircle( 24, 24, 3, new Brush( 0xff168de2 ) );
   graphics.pen = new Pen( 0xffffbf55, 2 );
   graphics.drawLine( 35, 7, 35, 17 );
   graphics.drawLine( 30, 12, 40, 12 );
   graphics.end();
   return bitmap;
}

function StartProcessorRocketIcon()
{
   let bitmap = new Bitmap( 48, 48 );
   bitmap.fill( 0x00000000 );
   let graphics = new Graphics( bitmap );
   graphics.antialiasing = true;

   let outline = new Pen( 0xff4a5057, 2 );
   let body = new Brush( 0xfff2f4f6 );
   let blue = new Brush( 0xff087bc9 );
   let orange = new Brush( 0xffff7a1a );
   graphics.pen = outline;

   graphics.fillPolygon( [
      new Point( 17, 31 ), new Point( 20, 17 ),
      new Point( 24, 8 ), new Point( 28, 17 ),
      new Point( 31, 31 ), new Point( 24, 36 )
   ], body );
   graphics.drawLine( 17, 31, 20, 17 );
   graphics.drawLine( 20, 17, 24, 8 );
   graphics.drawLine( 24, 8, 28, 17 );
   graphics.drawLine( 28, 17, 31, 31 );
   graphics.drawLine( 31, 31, 24, 36 );
   graphics.drawLine( 24, 36, 17, 31 );

   graphics.fillCircle( 24, 21, 4, blue );
   graphics.fillPolygon( [
      new Point( 18, 27 ), new Point( 11, 35 ), new Point( 19, 33 )
   ], blue );
   graphics.fillPolygon( [
      new Point( 30, 27 ), new Point( 37, 35 ), new Point( 29, 33 )
   ], blue );
   graphics.fillPolygon( [
      new Point( 21, 36 ), new Point( 24, 45 ), new Point( 27, 36 )
   ], orange );
   graphics.end();
   return bitmap;
}

function StartMultiExposureIcon()
{
   let bitmap = new Bitmap( 24, 24 );
   bitmap.fill( 0x00000000 );
   let g = new Graphics( bitmap );
   g.antialiasing = true;
   g.pen = new Pen( 0xffd97800, 2 );
   let points = [ [12,2], [14.7,8.1], [21.3,8.8], [16.3,13.2],
      [17.8,20], [12,16.5], [6.2,20], [7.7,13.2], [2.7,8.8],
      [9.3,8.1], [12,2] ];
   for ( let i = 0; i + 1 < points.length; ++i )
      g.drawLine( points[i][0], points[i][1],
         points[i + 1][0], points[i + 1][1] );
   g.end();
   return bitmap.scaled( 2, 2, BitmapInterpolation_Bilinear );
}

class StartCropInstructionDialog extends Dialog
{
constructor()
{
   super();
   let dialog = this;
   this.windowTitle = "🔭 InNova Multi-Night — Crop selection";

   this.textLabel = new Label( this );
   this.textLabel.useRichText = true;
   this.textLabel.wordWrapping = true;
   this.textLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.textLabel.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">Draw a rectangle around the part of the image " +
      "you want to keep.</p>" +
      "<p align=\"center\">Everything outside the rectangle will be " +
      "cropped.</p>" +
      "<p align=\"center\"><b>Click the Crop icon again to confirm the " +
      "crop.</b></p>";
   this.textLabel.minWidth = 520;
   this.textLabel.margin = 8;

   this.okButton = new PushButton( this );
   this.okButton.text = "OK";
   this.okButton.defaultButton = true;
   this.okButton.onClick = function() { dialog.ok(); };

   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.onClick = function() { dialog.cancel(); };

   let buttonRow = new HorizontalSizer;
   buttonRow.spacing = 8;
   buttonRow.addStretch();
   buttonRow.add( this.okButton );
   buttonRow.add( this.cancelButton );
   buttonRow.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 14;
   this.sizer.spacing = 10;
   this.sizer.add( this.textLabel );
   this.sizer.add( buttonRow );
   this.adjustToContents();
}
}

function StartHTMLText( value )
{
   return String( value ).replace( /&/g, "&amp;" ).replace( /</g, "&lt;" )
      .replace( />/g, "&gt;" ).replace( /\"/g, "&quot;" );
}

class StartUnrelatedImagesDialog extends Dialog
{
constructor( referenceId, issues )
{
   super();
   let dialog = this;
   this.windowTitle = "🔭 InNova Multi-Night — Possible unrelated images";

   this.message = new Label( this );
   this.message.useRichText = true;
   this.message.wordWrapping = true;
   this.message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let issueText = "";
   for ( let i = 0; i < issues.length && i < 8; ++i )
      issueText += "<p align=\"center\">• <b>" +
         StartHTMLText( issues[i].entry.id ) + "</b> — " +
         StartHTMLText( issues[i].reason ) + "</p>";
   if ( issues.length > 8 ) issueText += "<p align=\"center\">• …</p>";
   this.message.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">Some selected images may not belong to the " +
      "same project as the reference <b>" + StartHTMLText( referenceId ) +
      "</b>:</p>" + issueText +
      "<p align=\"center\">Review the selection before continuing.</p>" +
      "<p align=\"center\"><b>Register them anyway?</b></p>";
   this.message.minWidth = 650;
   this.message.margin = 10;

   this.yesButton = new PushButton( this );
   this.yesButton.text = "Yes";
   this.yesButton.defaultButton = true;
   this.yesButton.onClick = function() { dialog.ok(); };
   this.noButton = new PushButton( this );
   this.noButton.text = "No";
   this.noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( this.yesButton );
   buttons.add( this.noButton );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 16;
   this.sizer.spacing = 10;
   this.sizer.add( this.message );
   this.sizer.add( buttons );
   this.adjustToContents();
}
}

class StartAuxiliaryImagesDialog extends Dialog
{
constructor( entries )
{
   super();
   let dialog = this;
   this.windowTitle = "🔭 InNova Multi-Night — Project warning";

   this.message = new Label( this );
   this.message.useRichText = true;
   this.message.wordWrapping = true;
   this.message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let names = "";
   for ( let i = 0; i < entries.length; ++i )
      names += "<p align=\"center\">• <b>" +
         StartHTMLText( entries[i].id ) + "</b></p>";
   this.message.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\">These loaded images look auxiliary and were " +
      "left unchecked:</p>" + names +
      "<p align=\"center\"><b>Do you want to delete them?</b></p>" +
      "<p align=\"center\">If you select Yes, they will not be added to " +
      "Input images and will be closed in PixInsight.</p>" +
      "<p align=\"center\"><b>The original files on disk will not be " +
      "deleted.</b></p>";
   this.message.minWidth = 650;
   this.message.margin = 10;

   this.yesButton = new PushButton( this );
   this.yesButton.text = "Yes";
   this.yesButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.yesButton.defaultButton = true;
   this.yesButton.onClick = function() { dialog.ok(); };
   this.noButton = new PushButton( this );
   this.noButton.text = "No";
   this.noButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( this.yesButton );
   buttons.add( this.noButton );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 16;
   this.sizer.spacing = 10;
   this.sizer.add( this.message );
   this.sizer.add( buttons );
   this.adjustToContents();
}
}

function StartAskCenteredQuestion(
   title, text, showInformationIcon, boldText, brandIconName )
{
   let dialog = new Dialog;
   dialog.windowTitle = title;

   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   let paragraphs = String( text ).split( "\n\n" );
   let html = showInformationIcon && !brandIconName ?
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" : "";
   for ( let i = 0; i < paragraphs.length; ++i )
      html += "<p align=\"center\">" +
         StartHTMLText( paragraphs[i] ).replace( /\n/g, "<br/>" ) +
         "</p>";
   if ( boldText ) {
      let escapedBoldText = StartHTMLText( boldText );
      html = html.split( escapedBoldText ).join( "<b>" + escapedBoldText + "</b>" );
   }
   message.text = html;
   message.minWidth = 590;
   message.margin = 10;

   let yesButton = new PushButton( dialog );
   yesButton.text = "Yes";
   yesButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   yesButton.defaultButton = true;
   yesButton.onClick = function() { dialog.ok(); };
   let noButton = new PushButton( dialog );
   noButton.text = "No";
   noButton.icon = dialog.scaledResource( ":/icons/cancel.png" );
   noButton.onClick = function() { dialog.cancel(); };

   let buttons = new HorizontalSizer;
   buttons.spacing = 14;
   buttons.addStretch();
   buttons.add( yesButton );
   buttons.add( noButton );
   buttons.addStretch();
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 10;
   if ( brandIconName ) {
      let iconRow = new HorizontalSizer;
      iconRow.addStretch();
      iconRow.add( StartLauncherIcon( dialog, brandIconName, 72 ) );
      iconRow.addStretch();
      dialog.sizer.add( iconRow );
   }
   dialog.sizer.add( message );
   dialog.sizer.add( buttons );
   dialog.adjustToContents();
   let accepted = dialog.execute() == StdDialogCode_Ok;


   dialog.hide();
   CoreApplication.processEvents();
   return accepted ? StdButton_Yes : StdButton_No;
}

function StartShowMultiNightRegistrationWarning( referenceId, failed )
{
   let dialog = new Dialog;
   dialog.windowTitle = "🔭 InNova Multi-Night — Registration warning";

   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.minWidth = 520;
   message.margin = 10;
   let failedHTML = [];
   for ( let i = 0; i < failed.length; ++i )
      failedHTML.push( "<span style=\"color:#c62828\"><b>" +
         StartHTMLText( failed[i] ) + "</b></span>" );
   message.text =
      "<p align=\"center\"><span style=\"font-size:38pt;color:#e6a23c\">⚠</span></p>" +
      "<p align=\"center\">These images could not be registered to <b>" +
      StartHTMLText( referenceId ) + "</b><br/>and may not belong to the project:</p>" +
      "<p align=\"center\">" + failedHTML.join( "<br/>" ) + "</p>" +
      "<p align=\"center\">They have been excluded from common-crop " +
      "calculation.<br/>Successful registered copies are preserved.</p>";

   let okButton = new PushButton( dialog );
   okButton.text = "OK";
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 110, 28 );
   okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add( okButton );
   buttons.addStretch();

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 8;
   dialog.sizer.add( message );
   dialog.sizer.add( buttons );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

function StartShowMultiNightCropRequired( heading, detailsHTML, instruction )
{
   let dialog = new Dialog;
   dialog.windowTitle = "🔭 InNova Multi-Night — Common crop required";

   let background = StartLauncherPanel( dialog, true );
   background.setScaledFixedSize( 720, 330 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   let titleRow = new HorizontalSizer;
   titleRow.spacing = 16;
   titleRow.add( StartLauncherIcon( background, "bridge", 76 ) );
   let titleText = new VerticalSizer;
   titleText.addStretch();
   titleText.add( StartLauncherLabel( background,
      "<b>Common crop required</b>", 20, "#102b50", false ) );
   titleText.add( StartLauncherLabel( background,
      "Create one common frame for the complete multi-night sequence.",
      12, "#174675", false ) );
   titleText.addStretch();
   titleRow.add( titleText, 100 );
   background.sizer.add( titleRow );

   let information = StartLauncherPanel( background, false );
   information.sizer = new VerticalSizer;
   information.sizer.margin = 12;
   let message = new Label( information );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.text = "<p align=\"center\"><b>" + heading +
      "</b></p>" + detailsHTML +
      "<p align=\"center\"><span style=\"font-size:24pt\">✂️</span>" +
      "</p><p align=\"center\">" + instruction + "</p>";
   information.sizer.add( message, 100 );
   background.sizer.add( information, 100 );

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   let okButton = new PushButton( background );
   okButton.text = "OK";
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 120, 30 );
   okButton.onClick = function() { dialog.ok(); };
   buttons.add( okButton );
   buttons.addStretch();
   background.sizer.add( buttons );

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

class StartMultiExposureDialog extends Dialog
{
constructor( acquisitionIndex, imageIds, finalSelection )
{
   super();
   let dialog = this;
   this.finalSelection = finalSelection === true;
   imageIds = imageIds instanceof Array ? imageIds : [ String( imageIds ) ];
   this.windowTitle = "🔭 InNova Multi-Night — Multi-Night Combination";

   this.header = StartLauncherPanel( this, true );
   this.header.setScaledFixedHeight( 92 );
   this.header.sizer = new HorizontalSizer;
   this.header.sizer.margin = 12;
   this.header.sizer.spacing = 16;
   this.header.sizer.add( StartLauncherIcon( this.header, "bridge", 68 ) );
   let headerText = new VerticalSizer;
   headerText.spacing = 4;
   headerText.addStretch();
   headerText.add( StartLauncherLabel( this.header,
      "<b>Multi-Night Combination</b>", 20, "#102b50", false ) );
   headerText.add( StartLauncherLabel( this.header,
      "Combine registered images from different nights or exposure levels.",
      12, "#243f5b", false ) );
   headerText.addStretch();
   this.header.sizer.add( headerText, 100 );

   this.imagesGroup = new GroupBox( this );
   this.imagesGroup.title = "Images";
   this.imagesLabel = new Label( this.imagesGroup );
   this.imagesLabel.useRichText = true;
   this.imagesLabel.wordWrapping = true;
   this.imagesLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   let imageList = "";
   for ( let i = 0; i < imageIds.length; ++i )
      imageList += (i > 0 ? "<br/>" : "") + "<b>" +
         StartHTMLText( imageIds[i] ) + "</b>";
   for ( let i = imageIds.length; i < 4; ++i ) imageList += "<br/>&nbsp;";
   this.imagesLabel.text =
      (this.finalSelection ?
         "The following images have been selected:" :
         "The current image will be added to the combination:") +
      "<br/><br/>" + imageList;
   this.imagesLabel.minWidth = 700;
   this.imagesGroup.sizer = new VerticalSizer;
   this.imagesGroup.sizer.margin = 10;
   this.imagesGroup.sizer.add( this.imagesLabel );

   this.combinationLabel = new Label( this );
   this.combinationLabel.text = "Combination type:";
   this.acquisitionCombo = new ComboBox( this );
   this.acquisitionCombo.addItem( "Multi-night integration" );
   this.acquisitionCombo.addItem( "HDR (High Dynamic Range)" );
   this.acquisitionCombo.currentItem = acquisitionIndex == 2 ? 1 : 0;


   this.combinationLabel.visible = this.finalSelection;
   this.acquisitionCombo.visible = this.finalSelection;
   let combinationRow = new HorizontalSizer;
   combinationRow.spacing = 8;
   combinationRow.addStretch();
   combinationRow.add( this.combinationLabel );
   combinationRow.add( this.acquisitionCombo );
   combinationRow.addStretch();

   this.informationGroup = new GroupBox( this );
   this.informationGroup.title = "Information";
   this.informationLabel = new Label( this.informationGroup );
   this.informationLabel.useRichText = true;
   this.informationLabel.wordWrapping = true;
   this.informationLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.informationLabel.text =
      "<p align=\"center\"><b>Select the images you want to combine.</b></p>" +
      "<p align=\"center\">Multi-night requires <b>at least 2 images</b>.<br/>" +
      "HDR requires <b>at least 3 images</b> with distinct exposure levels.</p>" +
      "<p align=\"center\">Images must have compatible geometry after " +
      "registration.<br/>Bracketed HDR images must provide consecutive " +
      "exposure values." +
      (this.finalSelection ?
         "<br/><br/><span style=\"color:#d7191c\"><b>" +
         "Make sure the dimensions of the images to be combined are identical. " +
         "If they are not, crop the corners slightly before continuing." +
         "</b></span>" : "") + "</p>";
   this.informationGroup.sizer = new VerticalSizer;
   this.informationGroup.sizer.margin = 10;
   this.informationGroup.sizer.add( this.informationLabel );

   this.okButton = new PushButton( this );
   this.okButton.text = "OK";
   this.okButton.icon = this.scaledResource( ":/icons/ok.png" );
   this.okButton.defaultButton = true;
   this.cancelButton = new PushButton( this );
   this.cancelButton.text = "Cancel";
   this.cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancelButton.onClick = function() { dialog.cancel(); };
   this.okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.spacing = 12;
   buttons.addStretch();
   buttons.add( this.okButton );
   buttons.add( this.cancelButton );
   buttons.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.margin = 14;
   this.sizer.spacing = 10;
   this.sizer.add( this.header );
   this.sizer.add( this.imagesGroup );
   if ( this.finalSelection ) this.sizer.add( combinationRow );
   this.sizer.add( this.informationGroup );
   this.sizer.add( buttons );
   this.adjustToContents();
}
}

function StartNumericKeyword( window, names )
{
   let text = StartKeywordValue( window, names );
   let value = parseFloat( text );
   return isFinite( value ) ? value : NaN;
}

function StartWindowIdSet()
{
   let result = {};
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
      if ( windows[i] != null && !windows[i].isNull &&
           !windows[i].mainView.isNull )
         result[windows[i].mainView.id] = true;
   return result;
}

function StartFindNewRegisteredWindow( sourceId, idsBefore )
{
   let sourcePrefix = StartSafeId( sourceId ) + "_";
   let windows = ImageWindow.windows;
   for ( let i = windows.length - 1; i >= 0; --i ) {
      if ( windows[i] == null || windows[i].isNull ||
           windows[i].mainView.isNull )
         continue;
      let id = windows[i].mainView.id;
      let lower = id.toLowerCase();
      if ( !idsBefore[id] && id.indexOf( sourcePrefix ) == 0 &&
           lower.indexOf( "registered" ) >= 0 )
         return windows[i];
   }


   let candidates = [
      StartSafeId( sourceId + InNovaStartRegisteredSuffix ),
      StartSafeId( sourceId + "_registered" )
   ];
   for ( let i = 0; i < candidates.length; ++i ) {
      let window = ImageWindow.windowById( candidates[i] );
      if ( window != null && !window.isNull && !idsBefore[candidates[i]] )
         return window;
   }
   return null;
}

function StartRenameRegisteredWindow( window, sourceId )
{
   if ( window == null || window.isNull || window.mainView.isNull )
      return window;
   let preferred = StartSafeId( sourceId + InNovaStartRegisteredSuffix );
   if ( window.mainView.id == preferred ) return window;
   let candidate = preferred;
   let serial = 2;
   while ( !ImageWindow.windowById( candidate ).isNull )
      candidate = preferred + "_" + serial++;
   window.mainView.id = candidate;
   return window;
}

function StartProjectIssues( entries, reference )
{
   let issues = [];
   let referenceAspect = reference.width/reference.height;
   let referenceObject = String( reference.objectName ).toUpperCase();
   for ( let i = 0; i < entries.length; ++i ) {
      let entry = entries[i];
      if ( entry.id == reference.id ) continue;
      let reasons = [];
      let aspect = entry.width/entry.height;
      if ( Math.abs( aspect/referenceAspect - 1 ) > 0.03 )
         reasons.push( "different frame proportions" );
      let scaleX = entry.width/reference.width;
      let scaleY = entry.height/reference.height;
      if ( Math.max( Math.abs( scaleX - 1 ), Math.abs( scaleY - 1 ) ) > 0.25 )
         reasons.push( "frame size differs by more than 25%" );
      let objectName = String( entry.objectName ).toUpperCase();
      if ( referenceObject.length > 0 && objectName.length > 0 &&
           referenceObject != objectName )
         reasons.push( "OBJECT metadata differs (" + entry.objectName + ")" );
      if ( isFinite( reference.ra ) && isFinite( reference.dec ) &&
           isFinite( entry.ra ) && isFinite( entry.dec ) ) {
         let dra = Math.abs( entry.ra - reference.ra );
         dra = Math.min( dra, 360 - dra );
         let meanDec = Math.PI*(entry.dec + reference.dec)/360;
         let distance = Math.sqrt( Math.pow( dra*Math.cos( meanDec ), 2 ) +
            Math.pow( entry.dec - reference.dec, 2 ) );
         if ( distance > 2 )
            reasons.push( "astrometric centre is " +
               format( "%.1f°", distance ) + " away" );
      }
      if ( reasons.length > 0 )
         issues.push( { entry: entry, reason: reasons.join( ", " ) } );
   }
   return issues;
}

function StartAstronomicalNight( dateText )
{
   let match = String( dateText ).match(
      /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):?(\d{2})?)/ );
   if ( match == null ) return "";
   let year = parseInt( match[1], 10 );
   let month = parseInt( match[2], 10 ) - 1;
   let day = parseInt( match[3], 10 );
   let hour = match[4] ? parseInt( match[4], 10 ) : 12;


   let date = new Date( Date.UTC( year, month, day - (hour < 12 ? 1 : 0) ) );
   function two( value ) { return value < 10 ? "0" + value : String( value ); }
   return date.getUTCFullYear() + "-" + two( date.getUTCMonth() + 1 ) +
      "-" + two( date.getUTCDate() );
}

function StartClassifyProject( entries, declaredMode )
{
   if ( entries.length == 0 )
      return { title: "Empty project", insufficientHDRFilters: [],
         detail: "No source image is selected." };
   if ( entries.length == 1 )
      return { title: "Single image", insufficientHDRFilters: [], detail:
         "One source image is selected; registration and HDR composition are not required." };

   let nights = {};
   let nightCount = 0;
   let datedCount = 0;
   let filters = {};
   let filterCount = 0;
   let exposureLevels = {};
   let measuredExposureCount = 0;
   let masterCount = 0;
   for ( let i = 0; i < entries.length; ++i ) {
      let entry = entries[i];
      let night = StartAstronomicalNight( entry.dateObs );
      if ( night.length > 0 ) {
         ++datedCount;
         if ( !nights[night] ) { nights[night] = true; ++nightCount; }
      }
      let filter = entry.filter == "—" ? "UNKNOWN" :
         String( entry.filter ).toUpperCase();
      if ( !filters[filter] ) { filters[filter] = true; ++filterCount; }
      if ( exposureLevels[filter] == null ) exposureLevels[filter] = {};
      if ( isFinite( entry.exposure ) && entry.exposure > 0 ) {
         ++measuredExposureCount;


         exposureLevels[filter][Math.round( 1000*entry.exposure )] = true;
      }
      if ( entry.isMaster ) ++masterCount;
   }

   let hdrFilters = [];
   let incompleteHDRFilters = [];
   for ( let filter in exposureLevels ) {
      let levelCount = 0;
      for ( let level in exposureLevels[filter] ) ++levelCount;
      if ( levelCount >= 3 ) hdrFilters.push( filter );
      else if ( levelCount == 2 ) incompleteHDRFilters.push( filter );
   }

   let title;
   if ( hdrFilters.length > 0 && filterCount > 1 )
      title = "Multi-channel HDR project";
   else if ( hdrFilters.length > 0 )
      title = "HDR exposure series";
   else if ( filterCount > 1 && nightCount > 1 )
      title = "Multi-night, multi-channel project";
   else if ( filterCount > 1 )
      title = "Multi-channel image set — not HDR by exposure";
   else if ( nightCount > 1 )
      title = "Multi-night integration project";
   else if ( nightCount == 1 && datedCount == entries.length )
      title = "Single-night image set";
   else
      title = "Image set — acquisition night is uncertain";

   let details = [];
   if ( nightCount > 0 ) details.push( nightCount + " observing night(s)" );
   else details.push( "DATE-OBS unavailable" );
   details.push( filterCount + " filter/channel group(s)" );
   if ( hdrFilters.length > 0 )
      details.push( "at least three exposure levels in " + hdrFilters.join( ", " ) );
   else if ( incompleteHDRFilters.length > 0 )
      details.push( "only two exposure levels in " +
         incompleteHDRFilters.join( ", " ) +
         "; InNova Multi-Night requires at least three for HDR" );
   else if ( measuredExposureCount == entries.length )
      details.push( "no filter has multiple exposure levels" );
   else
      details.push( "some exposure metadata is unavailable" );
   if ( masterCount > 0 )
      details.push( masterCount + " probable integrated master(s)" );
   let declaredTitles = {
      SINGLE_NIGHT: "One single night",
      MULTI_NIGHT: "Multi-night",
      HDR: "HDR (High Dynamic Range)"
   };
   let declaredTitle = declaredTitles[declaredMode] || title;
   let mismatch = "";
   if ( declaredMode == "HDR" && hdrFilters.length == 0 )
      mismatch = incompleteHDRFilters.length > 0 ?
         " Warning: HDR requires at least three compatible exposure levels; only two were detected." :
         " Warning: metadata does not show at least three exposure levels within the same filter.";
   else if ( declaredMode == "SINGLE_NIGHT" && nightCount > 1 )
      mismatch = " Warning: DATE-OBS indicates more than one observing night.";
   else if ( declaredMode == "MULTI_NIGHT" && nightCount == 1 &&
             datedCount == entries.length )
      mismatch = " Warning: DATE-OBS currently indicates only one observing night.";
   return { title: declaredTitle, detectedTitle: title,
      insufficientHDRFilters: incompleteHDRFilters,
      detail: "Selected treatment: " + declaredTitle + ". Detected data: " +
         title + "; " + details.join( "; ") + "." + mismatch };
}


function StartDetectHDRGroups( entries )
{
   let groups = {};
   for ( let i = 0; i < entries.length; ++i ) {
      entries[i].hdrCompatible = false;
      entries[i].hdrGroup = "";
      if ( !isFinite( entries[i].exposure ) || entries[i].exposure <= 0 )
         continue;
      let filter = entries[i].filter == "—" ?
         (entries[i].channels >= 3 ? "OSC/COLOR" : "UNFILTERED") :
         String( entries[i].filter ).toUpperCase();
      let key = filter;
      if ( groups[key] == null )
         groups[key] = { label: filter, entries: [], levels: {} };
      groups[key].entries.push( entries[i] );
      groups[key].levels[Math.round( 1000*entries[i].exposure )] = true;
   }

   let result = [];
   for ( let key in groups ) {
      let levelCount = 0;
      for ( let level in groups[key].levels ) ++levelCount;
      if ( levelCount < 3 ) continue;
      let group = groups[key];
      for ( let i = 0; i < group.entries.length; ++i ) {
         group.entries[i].hdrCompatible = true;
         group.entries[i].hdrGroup = group.label;
      }
      result.push( group );
   }
   return result;
}

function StartSeriesSourceEntry( item )
{
   let source = item;
   while ( source != null && source.source != null )
      source = source.source;
   return source;
}

function StartCombinationImageDetails( selectedSources, workingSeries )
{
   let details = [];
   for ( let i = 0; i < selectedSources.length; ++i ) {
      let source = selectedSources[i];
      let workingWindow = null;
      for ( let j = 0; j < workingSeries.length; ++j )
         if ( StartSeriesSourceEntry( workingSeries[j] ) === source ) {
            workingWindow = workingSeries[j].window || workingSeries[j];
            break;
         }
      let width = source.width;
      let height = source.height;
      let channels = source.channels;
      if ( workingWindow != null && !workingWindow.isNull &&
           workingWindow.mainView != null && !workingWindow.mainView.isNull ) {
         let image = workingWindow.mainView.image;
         width = image.width;
         height = image.height;
         channels = image.numberOfChannels;
      }
      details.push(
         "<b>" + StartHTMLText( source.id ) + "</b><br/>" +
         "Exposure: " + StartHTMLText( StartExposureText( source.exposure ) ) +
         " &nbsp;·&nbsp; Filter: " + StartHTMLText( source.filter ) +
         " &nbsp;·&nbsp; Camera: " + StartHTMLText( source.camera ) +
         "<br/>Registered geometry: " + width + " × " + height +
         " × " + channels + " channel(s)" );
   }
   return details.join( "<br/><br/>" );
}

function StartCombinationCompatibility( selectedSources, workingSeries )
{
   let geometries = {};
   let cameras = {};
   let exposures = {};
   let geometryValues = [];
   let cameraValues = [];
   let exposureValues = [];
   let matchedCount = 0;
   for ( let i = 0; i < selectedSources.length; ++i ) {
      let source = selectedSources[i];
      let workingWindow = null;
      for ( let j = 0; j < workingSeries.length; ++j )
         if ( StartSeriesSourceEntry( workingSeries[j] ) === source ) {
            workingWindow = workingSeries[j].window || workingSeries[j];
            break;
         }
      if ( workingWindow != null && !workingWindow.isNull &&
           workingWindow.mainView != null && !workingWindow.mainView.isNull ) {
         let image = workingWindow.mainView.image;
         let geometry = image.width + " × " + image.height + " × " +
            image.numberOfChannels + " channel(s)";
         if ( geometries[geometry] == null ) {
            geometries[geometry] = true;
            geometryValues.push( geometry );
         }
         ++matchedCount;
      }
      let camera = source.camera == null || source.camera == "" ?
         "—" : String( source.camera );
      if ( cameras[camera] == null ) {
         cameras[camera] = true;
         cameraValues.push( camera );
      }
      let exposure = StartExposureText( source.exposure );
      if ( exposures[exposure] == null ) {
         exposures[exposure] = true;
         exposureValues.push( exposure );
      }
   }
   return {
      sameGeometry: matchedCount == selectedSources.length &&
         geometryValues.length == 1,
      differentCamera: cameraValues.length > 1,
      differentExposure: exposureValues.length > 1,
      geometries: geometryValues,
      cameras: cameraValues,
      exposures: exposureValues
   };
}

function StartPreparedOscProject( item )
{
   let identity = StartPreparedSourceIdentity( item );
   if ( /VAONIS_VESPERA_III|VESPERA[^A-Z0-9]*(III|3)([^A-Z0-9]|$)/i.test(
      identity ) )
      return "VAONIS_VESPERA_III";
   if ( /VAONIS|VESPERA/i.test( identity ) )
      return "VAONIS_VESPERA";
   if ( /SEESTAR[^\n]*S50\s*PRO|S50\s*PRO(?![A-Z0-9])/i.test( identity ) )
      return "SEESTAR_S50_PRO";
   if ( /SEESTAR[^\n]*S50(?![^\n]*PRO)|S50(?!\s*PRO)(?![A-Z0-9])/i.test(
      identity ) )
      return "SEESTAR_S50";
   if ( /SEESTAR[^\n]*S30|S30\s*PRO(?![A-Z0-9])/i.test( identity ) )
      return "SEESTAR_S30_PRO";
   if ( /SEESTAR/i.test( identity ) )
      return "SEESTAR";
   return "OSC";
}

function StartPreparedSourceIdentity( item )
{
   let names = [ "CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION",
      "INNVDEV" ];
   let parts = [];
   let visitedItems = [];
   let visitedWindows = [];
   function collectWindow( window ) {
      if ( window == null || window.isNull ||
           visitedWindows.indexOf( window ) >= 0 ) return;
      visitedWindows.push( window );
      let keywords = window.keywords || [];
      for ( let i = 0; i < keywords.length; ++i ) {
         let keywordName = String( keywords[i].name ).toUpperCase();
         if ( names.indexOf( keywordName ) >= 0 )
            parts.push( String( keywords[i].strippedValue ) );
      }
      if ( window.filePath ) parts.push( String( window.filePath ) );
      if ( window.mainView != null && !window.mainView.isNull )
         parts.push( String( window.mainView.id ) );
   }
   function visit( candidate ) {
      if ( candidate == null || visitedItems.indexOf( candidate ) >= 0 ) return;
      visitedItems.push( candidate );
      if ( candidate.item != null ) visit( candidate.item );
      collectWindow( candidate.window != null ? candidate.window : candidate );
      if ( candidate.source != null ) visit( candidate.source );
      if ( candidate.sourceItems != null )
         for ( let i = 0; i < candidate.sourceItems.length; ++i )
            visit( candidate.sourceItems[i] );
   }
   visit( item );
   return parts.join( " " );
}

function StartCombinationSourceLabel( items )
{
   let detected = "OSC";
   for ( let i = 0; i < items.length; ++i ) {
      let project = StartPreparedOscProject( items[i] );
      if ( project == "VAONIS_VESPERA_III" ) return "VAONIS Vespera III";
      if ( project == "VAONIS_VESPERA" ) detected = "VAONIS Vespera";
      else if ( project == "SEESTAR_S50_PRO" ) detected = "Seestar S50 Pro";
      else if ( project == "SEESTAR_S50" ) detected = "Seestar S50";
      else if ( project == "SEESTAR_S30_PRO" ) detected = "Seestar S30 Pro";
      else if ( project == "SEESTAR" && detected == "OSC" )
         detected = "Seestar";
   }
   return detected;
}

function StartWriteCombinationSource( window, items )
{
   let label = StartCombinationSourceLabel( items );
   if ( label == "OSC" || window == null || window.isNull ) return;
   let keywords = window.keywords || [];
   let updated = [];
   for ( let i = 0; i < keywords.length; ++i )
      if ( String( keywords[i].name ).toUpperCase() != "INNVDEV" )
         updated.push( keywords[i] );
   updated.push( new FITSKeyword( "INNVDEV", "'" + label + "'",
      "InNova combined image source" ) );
   window.keywords = updated;
}

function StartSpccMessage( text, icon, title )
{
   let html = String( text )
      .replace( /&/g, "&amp;" )
      .replace( /</g, "&lt;" )
      .replace( />/g, "&gt;" )
      .replace( /\n/g, "<br/>" );
   new MessageBox( "<p align=\"center\">" + html + "</p>",
      title || "InNova Multi-Night — SPCC",
      icon === undefined ? StdIcon_Warning : icon,
      StdButton_Ok ).execute();
}

function StartRunImageSolver( window, item, progress )
{
   if ( window == null || window.isNull || window.mainView.isNull ) {
      StartSpccMessage( "ImageSolver cannot run because no valid image is selected.",
         StdIcon_Warning, "InNova Multi-Night — ImageSolver" );
      return false;
   }
   if ( window.mainView.image.isComplex ) {
      StartSpccMessage( "ImageSolver cannot run on an image with complex samples.",
         StdIcon_Warning, "InNova Multi-Night — ImageSolver" );
      return false;
   }
   if ( MiraHasAstrometricSolution( window ) ) {
      StartSpccMessage( "The selected image already has a valid astrometric solution.",
         StdIcon_Information, "InNova Multi-Night — ImageSolver" );
      return true;
   }

   let solver = new ImageSolver;
   let solverDialog = null;
   let accepted = false;
   try {
      window.show();
      window.bringToFront();
      for ( ;; ) {
         solver.initialize( window, false );
         let preparedProject = StartPreparedOscProject( item );
         let seestarProject = preparedProject.indexOf( "SEESTAR" ) == 0;
         let vaonisProject = preparedProject.indexOf( "VAONIS" ) == 0;
         OptionSeestar = seestarProject ? "ON" : "OFF";
         OptionSmartTelescopeModel = seestarProject || vaonisProject ?
            (preparedProject == "SEESTAR" ? "SEESTAR_AUTO" :
             (preparedProject == "VAONIS_VESPERA" ? "VAONIS_AUTO" :
              preparedProject)) : "NONE";
         if ( seestarProject || vaonisProject )
            MiraApplySmartTelescopeOpticalProfile( solver, window );
         solver.solverCfg.useActive = true;
         solverDialog = new ImageSolverDialog(
            solver.solverCfg, solver.metadata, true );
         if ( solverDialog.execute() ) {
            accepted = true;
            break;
         }
         if ( !solverDialog.resetRequest ) return false;
         solver = new ImageSolver;
      }

      if ( !accepted ) return false;
      solver.solverCfg = solverDialog.solverCfg;
      solver.solverCfg.useActive = true;
      solver.metadata = solverDialog.metadata;
      let preparedProject = StartPreparedOscProject( item );
      let seestarProject = preparedProject.indexOf( "SEESTAR" ) == 0;
      let vaonisProject = preparedProject.indexOf( "VAONIS" ) == 0;
      OptionSeestar = seestarProject ? "ON" : "OFF";
      OptionSmartTelescopeModel = seestarProject || vaonisProject ?
         (preparedProject == "SEESTAR" ? "SEESTAR_AUTO" :
          (preparedProject == "VAONIS_VESPERA" ? "VAONIS_AUTO" :
           preparedProject)) : "NONE";
      if ( seestarProject || vaonisProject )
         MiraApplySmartTelescopeOpticalProfile( solver, window );
      solver.solverCfg.SaveSettings();
      solver.metadata.SaveSettings();
      if ( typeof progress == "function" )
         progress( "Running ImageSolver…" );
      console.show();
      console.noteln( "🔭 InNova Multi-Night: solving " + window.mainView.id );
      solver.solveImage( window );
      if ( !MiraHasAstrometricSolution( window ) )
         throw new Error( "ImageSolver finished without a valid astrometric solution." );
      console.noteln( "✅ Astrometric solution detected: " + window.mainView.id );
      return true;
   } catch ( error ) {
      StartSpccMessage( "ImageSolver could not solve the selected image.\n\n" +
         (error.message || error), StdIcon_Error,
         "InNova Multi-Night — ImageSolver" );
      return false;
   }
}

function StartSpccSourceText( item )
{
   let window = item != null && item.window != null ? item.window : item;
   let source = StartSeriesSourceEntry( item );
   let sourceWindow = source != null && source.window != null ?
      source.window : source;
   let names = [ "CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION",
      "FILTER", "FILTERID", "INNVDEV" ];
   function collect( candidate ) {
      if ( candidate == null || candidate.isNull ) return "";
      let values = [];
      let keywords = candidate.keywords;
      for ( let i = 0; i < keywords.length; ++i ) {
         let keywordName = String( keywords[i].name ).toUpperCase();
         for ( let j = 0; j < names.length; ++j )
            if ( keywordName == names[j] ) {
               values.push( String( keywords[i].strippedValue ) );
               break;
            }
      }
      return values.join( " " );
   }
   return collect( window ) + " " + collect( sourceWindow ) + " " +
      (window != null && window.filePath ? String( window.filePath ) : "") + " " +
      (sourceWindow != null && sourceWindow.filePath ?
         String( sourceWindow.filePath ) : "");
}

function StartSpccProfileNames( item )
{
   let identity = StartSpccSourceText( item );
   let project = /VAONIS|VESPERA/i.test( identity ) ? "VAONIS_VESPERA" :
      (/SEESTAR|S30\s*PRO(?![A-Z0-9])|S50(?:\s*PRO)?(?![A-Z0-9])/i.test( identity ) ? "SEESTAR" : "OSC");
   let dualBand = /DUAL[ _-]*BAND|DUALBAND|DUO[ _-]*BAND|(^|[^A-Z])DB([^A-Z]|$)/i.test( identity );
   let lightPollution = /(^|[^A-Z])LP([^A-Z]|$)|LIGHT[ _-]*POLLUTION/i.test( identity );

   if ( project == "SEESTAR" ) {
      let root = lightPollution || dualBand ?
         "Seestar-LP-" : "Sony IMX 462-662-585-UVIRCut ";
      return { red: root + "R", green: root + "G", blue: root + "B",
         label: lightPollution || dualBand ? "Seestar LP" :
            "Seestar S50 (Sony IMX462 with UV/IR cut)",
         narrowband: dualBand };
   }

   if ( project == "VAONIS_VESPERA" ) {
      let model;
      if ( /VESPERA[^A-Z0-9]*PRO/i.test( identity ) )
         model = "Vaonis VESPERA Pro 2-";
      else if ( /VESPERA[^A-Z0-9]*(II|III|2|3)([^A-Z0-9]|$)/i.test( identity ) )
         model = "Vaonis VESPERA II, 3-";
      else
         return null;
      let filter = dualBand ? "Dual Band " : "CLS ";
      return { red: model + filter + "R", green: model + filter + "G",
         blue: model + filter + "B",
         label: model.replace( /-$/, "" ) + " " + filter.trim(),
         narrowband: dualBand };
   }
   return null;
}

function StartSpccDatabasePath( fileName )
{
   let root = CoreApplication.binDirPath.replace( /[\\\/]+bin[\\\/]?$/, "" );
   let candidates = [
      root + "/library/" + fileName,
      CoreApplication.binDirPath + "/../library/" + fileName
   ];
   for ( let i = 0; i < candidates.length; ++i )
      if ( File.exists( candidates[i] ) ) return candidates[i];
   return "";
}

function StartSpccXmlAttributeData( xml, tag, name )
{
   let escaped = String( name ).replace( /[.*+?^${}()|[\]\\]/g, "\\$&" );
   let expression = new RegExp( "<" + tag +
      "\\s+name=\"" + escaped + "\"[^>]*\\sdata=\"([^\"]+)\"" );
   let match = expression.exec( xml );
   return match != null ? match[1] : "";
}

function StartSpccLoadCurves( profile )
{
   let filterPath = StartSpccDatabasePath( "filters.xspd" );
   let whitePath = StartSpccDatabasePath( "white-references.xspd" );
   if ( filterPath.length == 0 || whitePath.length == 0 )
      return { error: "SPCC cannot run because the PixInsight spectral databases could not be found." };
   try {
      let filters = File.readTextFile( filterPath );
      let whites = File.readTextFile( whitePath );
      let red = StartSpccXmlAttributeData( filters, "Filter", profile.red );
      let green = StartSpccXmlAttributeData( filters, "Filter", profile.green );
      let blue = StartSpccXmlAttributeData( filters, "Filter", profile.blue );
      let white = StartSpccXmlAttributeData( whites, "WhiteRef", "Average Spiral Galaxy" );
      if ( red.length == 0 || green.length == 0 || blue.length == 0 )
         return { error: "SPCC cannot run because the required RGB response curves are missing from the PixInsight filter database.\n\nProfile: " + profile.label };
      if ( white.length == 0 )
         return { error: "SPCC cannot run because the Average Spiral Galaxy white reference is missing from the PixInsight spectral database." };
      return { red: red, green: green, blue: blue, white: white };
   } catch ( error ) {
      return { error: "SPCC cannot read the PixInsight spectral databases.\n\n" +
         (error.message || error) };
   }
}

function StartSpccLooksLinear( window, item )
{
   if ( item != null && item.alreadyStretched === true ) return false;
   let keywords = window.keywords;
   for ( let i = 0; i < keywords.length; ++i )
      if ( String( keywords[i].name ).toUpperCase() == "HISTORY" &&
           /HISTOGRAMTRANSFORMATION|MASKEDSTRETCH|GENERALIZEDHYPERBOLICSTRETCH|INNOVA[ _]?ADAPTIVE|INNOVA[ _]?PHOTO[ _]?EDITOR/i.test(
              String( keywords[i].strippedValue ) ) ) return false;
   try {
      let median = window.mainView.computeOrFetchProperty( "Median" );
      let channels = Math.min( 3, window.mainView.image.numberOfChannels );
      for ( let c = 0; c < channels; ++c )
         if ( median.at( c ) >= 0.25 ) return false;
   } catch ( ignored ) {}
   return true;
}

function StartCopyAstrometricSolution( source, target )
{
   if ( !MiraHasAstrometricSolution( source ) ) return false;
   let processing = false;
   try {
      let metadata = new AstrometricMetadata( "InNovaBridgeImageSolver" );
      metadata.ExtractMetadata( source );
      target.mainView.beginProcess(
         UndoFlag_Keywords | UndoFlag_AstrometricSolution );
      processing = true;
      metadata.SaveKeywords( target, false );
      metadata.SaveProperties( target, "InNova Multi-Night SPCC", "Gaia DR3/SP" );
      target.regenerateAstrometricSolution();
      target.mainView.endProcess();
      processing = false;
      return MiraHasAstrometricSolution( target );
   } catch ( error ) {
      if ( processing )
         try { target.mainView.endProcess(); } catch ( ignored ) {}
      console.warningln( "⚠️ Could not transfer the astrometric solution: " +
         (error.message || error) );
      return false;
   }
}

function StartConfigureSpccProcess( profile, curves, applyCalibration,
   generateGraphs )
{
   let process = new SpectrophotometricColorCalibration;
   process.applyCalibration = applyCalibration;
   process.generateGraphs = generateGraphs;


   process.narrowbandMode = false;
   process.whiteReferenceSpectrum = curves.white;
   process.whiteReferenceName = "Average Spiral Galaxy";
   process.redFilterTrCurve = curves.red;
   process.redFilterName = profile.red;
   process.greenFilterTrCurve = curves.green;
   process.greenFilterName = profile.green;
   process.blueFilterTrCurve = curves.blue;
   process.blueFilterName = profile.blue;
   process.deviceQECurve = "300,1,400,1,500,1,600,1,700,1,800,1,900,1,1000,1,1100,1";
   process.deviceQECurveName = "Ideal detector QE";
   process.catalogId = "GaiaDR3SP";
   return process;
}

function StartShowDeferredSpccReport( request )
{
   if ( request == null || request.window == null || request.window.isNull ||
        request.window.mainView.isNull )
      return false;
   let process = StartConfigureSpccProcess( request.profile, request.curves,
      false, true );
   if ( !process.canExecuteOn( request.window.mainView ) ) {
      StartSpccMessage(
         "The SPCC White Balance Functions report could not be generated because its source image is no longer available." );
      return false;
   }
   try {
      console.show();
      console.noteln(
         "🌈 InNova Multi-Night: generating the SPCC White Balance Functions report…" );
      CoreApplication.processEvents();
      if ( !process.executeOn( request.window.mainView ) )
         throw new Error( "SpectrophotometricColorCalibration did not complete." );
      console.hide();
      return true;
   } catch ( error ) {
      console.hide();
      StartSpccMessage( "The SPCC White Balance Functions report could not be generated.\n\n" +
         (error.message || error), StdIcon_Error );
      return false;
   }
}

function StartRunSpccCopy( window, item, progress, deferredReport )
{
   if ( window == null || window.isNull || window.mainView.isNull ) {
      StartSpccMessage( "SPCC cannot run because no valid image is selected." );
      return null;
   }
   let image = window.mainView.image;
   if ( !image.isColor || image.numberOfChannels < 3 ) {
      StartSpccMessage( "SPCC cannot run because the selected image is not an RGB color image." );
      return null;
   }
   if ( image.isComplex ) {
      StartSpccMessage( "SPCC cannot run on an image with complex samples." );
      return null;
   }
   if ( !StartSpccLooksLinear( window, item ) ) {
      StartSpccMessage( "SPCC cannot run because the selected image appears to be nonlinear or has already been stretched.\n\nSelect a linear image before applying any stretch." );
      return null;
   }
   if ( !MiraHasAstrometricSolution( window ) ) {
      let answer = StartAskCenteredQuestion(
         "InNova Multi-Night — SPCC",
         "SPCC requires a valid astrometric solution.\n\nWould you like to run ImageSolver now?",
         true,
         "ImageSolver" );
      if ( answer != StdButton_Yes )
         return null;
      if ( !StartRunImageSolver( window, item, progress ) ||
           !MiraHasAstrometricSolution( window ) )
         return null;
   }
   if ( typeof SpectrophotometricColorCalibration == "undefined" ) {
      StartSpccMessage( "SPCC cannot run because SpectrophotometricColorCalibration is not installed in this PixInsight installation." );
      return null;
   }
   let gaia = MiraGaiaDr3SpStatus();
   if ( !gaia.processInstalled || !gaia.supported || !gaia.ready ) {
      StartSpccMessage( "SPCC cannot run because the Gaia DR3/SP local database is not available or is not configured.\n\n" +
         (gaia.error || "Configure valid Gaia DR3/SP XPSD files in the Gaia process." ) );
      return null;
   }
   let profile = StartSpccProfileNames( item );
   if ( profile == null ) {
      StartSpccMessage( "SPCC cannot run because InNova could not identify a supported RGB sensor and filter profile for this image.\n\nAutomatic profiles are available for Seestar S30 Pro, S50 and Vaonis Vespera II, III and Pro images." );
      return null;
   }
   let curves = StartSpccLoadCurves( profile );
   if ( curves.error != null ) {
      StartSpccMessage( curves.error );
      return null;
   }


   let process = StartConfigureSpccProcess( profile, curves, true, false );
   if ( !process.canExecuteOn( window.mainView ) ) {
      StartSpccMessage( "SPCC cannot execute on the selected image. Check that it is a linear RGB main view with a valid astrometric solution." );
      return null;
   }

   let copy = StartCloneWindow( window,
      window.mainView.id + "_InNovaSPCC" );
   if ( !StartCopyAstrometricSolution( window, copy ) ) {
      copy.forceClose();
      StartSpccMessage(
         "SPCC cannot run because the astrometric solution could not be transferred to the image copy." );
      return null;
   }
   if ( !process.canExecuteOn( copy.mainView ) ) {
      copy.forceClose();
      StartSpccMessage(
         "SPCC cannot execute on the image copy after transferring its astrometric solution." );
      return null;
   }
   try {
      if ( typeof progress == "function" )
         progress( "Running SPCC color calibration…" );
      console.show();
      console.noteln( "🌈 InNova Multi-Night: applying SPCC to copy " +
         copy.mainView.id );
      console.writeln( "⚙️ RGB response profile: " + profile.label );
      CoreApplication.processEvents();
      if ( !process.executeOn( copy.mainView ) )
         throw new Error( "SpectrophotometricColorCalibration did not complete." );
      if ( deferredReport != null ) {
         deferredReport.window = window;
         deferredReport.profile = profile;
         deferredReport.curves = curves;
      }
      copy.bringToFront();
      return copy;
   } catch ( error ) {
      if ( copy != null && !copy.isNull ) copy.forceClose();
      StartSpccMessage( "SPCC could not calibrate the image.\n\n" +
         (error.message || error), StdIcon_Error );
      return null;
   }
}

function StartPreparedChannelKey( item )
{
   let window = item.window || item;
   let source = item;
   if ( item.sourceItems != null && item.sourceItems.length > 0 ) {
      source = item.sourceItems[0];
      if ( source.item != null ) source = source.item;
   }
   source = StartSeriesSourceEntry( source );
   let filter = source != null && source.filter != null ?
      String( source.filter ) : "";
   let id = window != null && !window.isNull && !window.mainView.isNull ?
      String( window.mainView.id ) : "";
   let sourceWindow = source != null && source.window != null ?
      source.window : source;
   let bayerPattern = StartKeywordValue( window,
      [ "BAYERPAT", "BAYERPATTERN", "CFAPATTERN" ] );
   if ( bayerPattern.length == 0 )
      bayerPattern = StartKeywordValue( sourceWindow,
         [ "BAYERPAT", "BAYERPATTERN", "CFAPATTERN" ] );
   let probe = (filter + " " + id).toUpperCase().replace(
      /[^A-Z0-9]+/g, " " );
   let filterProbe = filter.toUpperCase().replace(
      /[^A-Z0-9]+/g, " " ).trim();
   let idProbe = id.toUpperCase().replace(
      /[^A-Z0-9]+/g, " " ).trim();
   if ( /(^| )SII( |$)|(^| )S2( |$)/.test( probe ) ||
        filterProbe == "S" || /^S( |$)/.test( idProbe ) )
      return "PimageSii";
   if ( /(^| )OIII( |$)|(^| )O3( |$)/.test( probe ) ||
        filterProbe == "O" || /^O( |$)/.test( idProbe ) )
      return "PimageOiii";
   if ( /(^| )HA( |$)|(^| )HALPHA( |$)/.test( probe ) ||
        filterProbe == "H" || /^H( |$)/.test( idProbe ) )
      return "PimageHa";
   if ( /(^| )RED( |$)|(^| )R( |$)/.test( probe ) ) return "PimageRed";
   if ( /(^| )GREEN( |$)|(^| )G( |$)/.test( probe ) ) return "PimageGreen";
   if ( /(^| )BLUE( |$)|(^| )B( |$)/.test( probe ) ) return "PimageBlue";
   if ( /(^| )LUMINANCE( |$)|(^| )LUM( |$)|(^| )L( |$)/.test( probe ) )
      return "PimageLuminance";
   if ( /^(RGGB|BGGR|GRBG|GBRG)$/i.test( bayerPattern ) ||
        /(^| )OSC( |$)|(^| )COLOR( |$)/.test( probe ) ||
        source != null && source.channels >= 3 ||
        window != null && !window.isNull && window.mainView != null &&
        window.mainView.image != null && window.mainView.image.numberOfChannels >= 3 )
      return "PimageOsc";
   return "";
}

function StartPreparedImagePriority( item )
{
   if ( item.kind == "HDR" ) return 50;
   if ( item.kind == "INTEGRATION" ) return 45;
   let window = item.window || item;
   let id = window != null && !window.isNull && !window.mainView.isNull ?
      String( window.mainView.id ).toLowerCase() : "";
   if ( id.indexOf( "innovastartcrop" ) >= 0 ) return 35;
   if ( id.indexOf( "registered" ) >= 0 ) return 25;
   return 10;
}

function StartProcessorSelectionSupportsMonochrome( selected )
{
   let channels = {};
   for ( let i = 0; i < selected.length; ++i ) {
      let item = selected[i];
      let window = item.window || item;
      if ( window == null || window.isNull || window.mainView == null ||
           window.mainView.isNull || window.mainView.image == null )
         continue;
      if ( window.mainView.image.numberOfChannels >= 3 ||
           window.mainView.image.isColor )
         return true;
      let source = StartSeriesSourceEntry( item );
      let sourceWindow = source != null && source.window != null ?
         source.window : source;
      let bayerPattern = StartKeywordValue( window,
         [ "BAYERPAT", "BAYERPATTERN", "CFAPATTERN" ] );
      if ( bayerPattern.length == 0 )
         bayerPattern = StartKeywordValue( sourceWindow,
            [ "BAYERPAT", "BAYERPATTERN", "CFAPATTERN" ] );
      if ( /^(RGGB|BGGR|GRBG|GBRG)$/i.test( bayerPattern ) )
         return true;
      let key = StartPreparedChannelKey( item );
      if ( key.length > 0 ) channels[key] = true;
   }
   let rgb = channels.PimageRed && channels.PimageGreen &&
      channels.PimageBlue;
   let sho = channels.PimageSii && channels.PimageHa &&
      channels.PimageOiii;
   let hoo = channels.PimageHa && channels.PimageOiii;
   return rgb || sho || hoo;
}

function StartShowMonochromeProcessorInformation()
{
   let dialog = new Dialog;
   dialog.windowTitle = "🔭 InNova Multi-Night — Monochrome images";
   let message = new Label( dialog );
   message.useRichText = true;
   message.wordWrapping = true;
   message.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   message.minWidth = 620;
   message.margin = 10;
   message.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span></p>" +
      "<p align=\"center\"><b>InNova Astro Processor cannot process a " +
      "single monochrome image by itself.</b></p>" +
      "<p align=\"center\">To process monochrome data, select a complete " +
      "set of separate channel images, such as <b>Red, Green and Blue</b>." +
      "</p><p align=\"center\">Complete SHO or HOO narrowband channel " +
      "sets are also supported.</p>" +
      "<p align=\"center\">If you only have one file, select an integrated " +
      "RGB/OSC image.</p>";
   let okButton = new PushButton( dialog );
   okButton.text = "OK";
   okButton.icon = dialog.scaledResource( ":/icons/ok.png" );
   okButton.defaultButton = true;
   okButton.setScaledFixedSize( 92, 24 );
   okButton.onClick = function() { dialog.ok(); };
   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add( okButton );
   buttons.addStretch();
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 16;
   dialog.sizer.spacing = 10;
   dialog.sizer.add( message );
   dialog.sizer.add( buttons );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   dialog.execute();
}

function StartPrepareSubframeMastersForProcessor( windows )
{
   let items = [];
   for ( let i = 0; i < windows.length; ++i )
      items.push( StartImageEntry( windows[i] ) );
   if ( !StartProcessorSelectionSupportsMonochrome( items ) ) {
      StartShowMonochromeProcessorInformation();
      return false;
   }

   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   let assignments = {};
   for ( let i = 0; i < items.length; ++i ) {
      let key = StartPreparedChannelKey( items[i] );
      if ( key.length > 0 && assignments[key] == null )
         assignments[key] = windows[i].mainView.id;
   }
   let assigned = 0;
   for ( let i = 0; i < keys.length; ++i ) {
      let value = assignments[keys[i]] || "";
      Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
         DataType_String, value );
      if ( value.length > 0 ) ++assigned;
   }
   if ( assigned == 0 ) return false;

   let project = "OSC";
   if ( assignments.PimageSii && assignments.PimageHa &&
        assignments.PimageOiii )
      project = "SHO";
   else if ( assignments.PimageHa && assignments.PimageOiii )
      project = "HOO";
   else if ( assignments.PimageRed && assignments.PimageGreen &&
             assignments.PimageBlue && assignments.PimageLuminance )
      project = "LRGB";
   else if ( assignments.PimageRed && assignments.PimageGreen &&
             assignments.PimageBlue )
      project = "RGB";
   else if ( assignments.PimageOsc ) {
      for ( let i = 0; i < items.length; ++i )
         if ( windows[i].mainView.id == assignments.PimageOsc ) {
            project = StartPreparedOscProject( items[i] );
            break;
         }
   }

   Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffHaBlendSetting,
      DataType_String, "0" );
   Settings.write( InNovaHandoffProjectSetting, DataType_String, project );
   Settings.write( InNovaHandoffAcquisitionSetting,
      DataType_String, "SINGLE_NIGHT" );
   Settings.write( InNovaHandoffObjectSetting, DataType_String, "STARS" );
   Settings.write( InNovaIntegratorHandoffProjectSetting,
      DataType_String, project );
   Settings.write( InNovaIntegratorHandoffPendingSetting,
      DataType_String, "1" );
   console.noteln( "🚀 Guided Subframe handoff: " + assigned +
      " master image(s) assigned to InNova Astro Processor." );
   return true;
}

function StartPrepareProcessorLaunchWithoutImages()
{
   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   for ( let i = 0; i < keys.length; ++i )
      Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
         DataType_String, "" );
   let project = Settings.read( InNovaHandoffProjectSetting,
      DataType_String );
   if ( !Settings.lastReadOK || typeof project != "string" ||
        project.length == 0 )
      project = "OSC";
   Settings.write( InNovaIntegratorHandoffProjectSetting,
      DataType_String, project );
   Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffHaBlendSetting,
      DataType_String, "0" );
   Settings.write( InNovaIntegratorHandoffPendingSetting,
      DataType_String, "1" );
}

function StartShowProcessorHandoffInformation( mastersAssigned )
{
   let dialog = new Dialog;
   dialog.windowTitle = "🔭 InNova Guided Workflow — Astro Processor";
   let background = new Control( dialog );
   background.setScaledFixedWidth( 650 );
   background.setScaledMinHeight( 510 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 18;
   background.sizer.spacing = 12;

   let headerPanel = StartLauncherPanel( background, true );
   headerPanel.setScaledFixedHeight( 92 );
   headerPanel.sizer = new VerticalSizer;
   headerPanel.sizer.margin = 12;
   let heading = new HorizontalSizer;
   heading.spacing = 16;
   heading.add( StartLauncherIcon( headerPanel, "astro-processor", 68 ) );
   let headingText = new VerticalSizer;
   headingText.spacing = 5;
   headingText.addStretch();
   headingText.add( StartLauncherLabel( headerPanel,
      "<b>InNova Astro Processor</b>", 20, "#102b50", false ) );
   headingText.add( StartLauncherLabel( headerPanel,
      "Choose the modules you want to run.", 12, "#174675", false ) );
   headingText.addStretch();
   heading.add( headingText, 100 );
   headerPanel.sizer.add( heading );
   background.sizer.add( headerPanel );

   let information = new Label( background );
   information.useRichText = true;
   information.wordWrapping = true;
   information.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   information.text =
      "<p align=\"center\"><span style=\"font-size:30pt;color:#2784b9\">" +
      "ⓘ</span></p>" +
      (mastersAssigned === true ?
         "<p align=\"center\"><b>The master images have been assigned to " +
         "InNova Astro Processor.</b></p>" +
         "<p align=\"center\"><b>Check that the assigned images and channels " +
         "are correct, then choose the modules to execute.</b></p><br/><br/>" :
         "<p align=\"center\"><b>Choose Basic or Advanced mode before " +
         "opening InNova Astro Processor.</b></p>" +
         "<p align=\"center\">Select your stacked image in Astro Processor, " +
         "then <b>check that the project and image assignment are correct.</b>" +
         "</p><br/><br/>");
   background.sizer.add( information );

   background.sizer.add( StartLauncherLabel( background,
      "<b>Select the Astro Processor processing mode</b>",
      13, "#0869d6", true ) );

   let basicGroup = new GroupBox( background );
   basicGroup.title = "Basic";
   basicGroup.sizer = new VerticalSizer;
   basicGroup.sizer.margin = 10;
   let basic = new RadioButton( basicGroup );
   basic.text = "Basic Mode:  Photo Editor";
   basic.checked = true;
   let basicRow = new HorizontalSizer;
   basicRow.addStretch();
   basicRow.add( basic );
   basicRow.addStretch();
   basicGroup.sizer.add( basicRow );

   let advancedGroup = new GroupBox( background );
   advancedGroup.title = "Advanced";
   advancedGroup.sizer = new VerticalSizer;
   advancedGroup.sizer.margin = 10;
   advancedGroup.sizer.spacing = 5;
   let advanced = new RadioButton( advancedGroup );
   advanced.text = "Advanced Mode:";
   let advancedRow = new HorizontalSizer;
   advancedRow.addStretch();
   advancedRow.add( advanced );
   advancedRow.addStretch();
   advancedGroup.sizer.add( advancedRow );
   advancedGroup.sizer.addSpacing( 8 );
   let definitions = [
      { key: "BackgroundCorrection", label: "Background Correction" },
      { key: "Denoise", label: "Denoise" },
      { key: "Sharpen", label: "Sharpen" },
      { key: "DarkStructureEnhance", label: "Dark Structure Enhance" },
      { key: "StarRefinement", label: "Star Refinement" },
      { key: "PhotoEditor", label: "Photo Editor" }
   ];
   let checks = {};
   let remembered = {};
   let columns = new HorizontalSizer;
   columns.spacing = 36;
   columns.addStretch();
   let left = new VerticalSizer;
   left.spacing = 10;
   let right = new VerticalSizer;
   right.spacing = 10;
   for ( let i = 0; i < definitions.length; ++i ) {
      let definition = definitions[i];
      let check = new CheckBox( advancedGroup );
      check.text = definition.label;
      check.setScaledMinHeight( 24 );
      check.checked = false;
      check.enabled = false;
      check.toolTip = "Run " + definition.label +
         " in InNova Astro Processor";
      checks[definition.key] = check;
      remembered[definition.key] = true;
      let row = new HorizontalSizer;
      row.add( check );
      row.addStretch();
      (i < 3 ? left : right).add( row );
   }
   columns.add( left, 50 );
   columns.add( right, 50 );
   columns.addStretch();
   advancedGroup.sizer.add( columns );
   function setAdvancedMode( enabled )
   {
      for ( let i = 0; i < definitions.length; ++i ) {
         let definition = definitions[i];
         let check = checks[definition.key];
         if ( enabled ) {
            check.checked = remembered[definition.key] !== false;
            check.enabled = true;
         } else {
            remembered[definition.key] = check.checked;
            check.checked = false;
            check.enabled = false;
         }
      }
   }
   basic.onCheck = function( checked )
   {
      if ( checked ) {
         advanced.checked = false;
         setAdvancedMode( false );
      }
   };
   advanced.onCheck = function( checked )
   {
      if ( checked ) {
         basic.checked = false;
         setAdvancedMode( true );
      }
   };
   background.sizer.add( basicGroup );
   background.sizer.add( advancedGroup );

   let run = new PushButton( background );
   run.text = "Run";
   run.icon = dialog.scaledResource( ":/icons/play.png" );
   run.defaultButton = true;
   run.setScaledFixedSize( 100, 30 );
   run.onClick = function()
   {
      for ( let i = 0; i < definitions.length; ++i ) {
         let definition = definitions[i];
         let enabled = basic.checked ? definition.key == "PhotoEditor" :
            checks[definition.key].checked;
         Settings.write( InNovaIntegratorProcessSettingPrefix +
            definition.key, DataType_String, enabled ? "1" : "0" );
      }
      Settings.remove( InNovaIntegratorProcessSettingPrefix +
         "HAlphaBlend" );
      Settings.write( InNovaIntegratorHandoffNoticeShownSetting,
         DataType_String, "1" );
      dialog.ok();
   };
   let cancel = new PushButton( background );
   cancel.text = "Cancel";
   cancel.icon = dialog.scaledResource( ":/icons/close.png" );
   cancel.setScaledFixedSize( 100, 30 );
   cancel.onClick = function() { dialog.cancel(); };
   let buttons = new HorizontalSizer;
   buttons.spacing = 10;
   buttons.addStretch();
   buttons.add( run );
   buttons.add( cancel );
   background.sizer.add( buttons );
   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   let accepted = dialog.execute() == StdDialogCode_Ok;
   if ( !accepted ) {
      Settings.remove( InNovaIntegratorHandoffPendingSetting );
      Settings.remove( InNovaIntegratorHandoffNoticeShownSetting );
   }
   return accepted;
}

function StartLaunchInNovaIntegrator( bridgeReturnSourceId )
{
   let scriptPath = File.extractDrive(#__FILE__) +
      File.extractDirectory(#__FILE__) + "/../InNova/InNova01.js";
   let key = "InNova/ProcessorReturnToStart";
   let baselineIds = [];
   let windows = ImageWindow.windows;
   for ( let i = 0; i < windows.length; ++i )
      if ( windows[i] != null && !windows[i].isNull &&
           !windows[i].mainView.isNull )
         baselineIds.push( windows[i].mainView.id );
   Settings.write(key, DataType_String, JSON.stringify({
      path: File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/InNovaStart.js",
      created: Date.now(),
      returnMode: bridgeReturnSourceId ? "bridge" : "start",
      sourceId: bridgeReturnSourceId || "",
      baselineIds: baselineIds
   }));
   try {


      return StartLaunchModule( scriptPath,
         bridgeReturnSourceId ? 1.25 : 0.20 );
   }
   catch (error) {
      Settings.write(key, DataType_String, "");
      Settings.remove( InNovaIntegratorHandoffNoticeShownSetting );
      throw error;
   }
}

function StartLaunchModule( scriptPath, launchDelaySeconds )
{
   console.noteln( "🚀 Opening InNova module: " + scriptPath );


   return MiraLaunchSuiteScript( scriptPath,
      launchDelaySeconds == null ? 0.20 : launchDelaySeconds );
}

function StartCloseSeriesWindows( series )
{
   for ( let i = 0; i < series.length; ++i ) {
      let window = series[i].window || series[i];
      if ( window != null && !window.isNull ) window.forceClose();
   }
}

function StartCloseMultiNightTemporaryWindows()
{
   let windows = ImageWindow.windows.slice();
   let closed = 0;
   for ( let i = 0; i < windows.length; ++i ) {
      let window = windows[i];
      if ( window == null || window.isNull || window.mainView.isNull )
         continue;
      let id = String( window.mainView.id ).toLowerCase();
      if ( id.indexOf( "innovastartregistered" ) < 0 &&
           id.indexOf( "innovastartcrop" ) < 0 )
         continue;
      try {
         window.forceClose();
         ++closed;
      } catch ( error ) {
         console.warningln( "⚠️ Could not close temporary Multi-Night " +
            "window " + window.mainView.id + ": " + error );
      }
   }
   if ( closed > 0 )
      console.noteln( "🧹 Closed " + closed +
         " temporary registered/cropped Multi-Night window(s)." );
   return closed;
}

function StartIntegrationWeightMetrics( window )
{
   let image = window.mainView.image;


   let maximumSamples = 80000;
   let step = Math.max( 1, Math.ceil( Math.sqrt(
      image.width*image.height/maximumSamples ) ) );
   let values = [];
   let differences = [];
   for ( let y = Math.floor( step/2 ); y + 1 < image.height; y += step )
      for ( let x = Math.floor( step/2 ); x + 1 < image.width; x += step ) {
         let value = StartLuminance( image, x, y );
         let right = StartLuminance( image, x + 1, y );
         let below = StartLuminance( image, x, y + 1 );
         if ( !isFinite( value ) || !isFinite( right ) || !isFinite( below ) )
            continue;


         if ( Math.abs( value ) < 1.0e-12 &&
              Math.abs( right ) < 1.0e-12 && Math.abs( below ) < 1.0e-12 )
            continue;
         if ( value >= 0.985 || right >= 0.985 || below >= 0.985 )
            continue;
         values.push( value );
         differences.push( Math.abs( value - right ) );
         differences.push( Math.abs( value - below ) );
      }
   if ( values.length < 32 || differences.length < 64 )
      return { signal: 0, noise: 0, snr: 0, rawWeight: 1,
         fallback: true };
   values.sort( function( a, b ) { return a - b; } );
   differences.sort( function( a, b ) { return a - b; } );
   let background = values[Math.floor( 0.50*(values.length - 1) )];
   let upper = values[Math.floor( 0.995*(values.length - 1) )];
   let signal = Math.max( 1.0e-8, upper - background );


   let noise = differences[Math.floor( 0.50*(differences.length - 1) )]/
      0.953872;
   if ( !isFinite( noise ) || noise <= 1.0e-10 )
      return { signal: signal, noise: 0, snr: 0, rawWeight: 1,
         fallback: true };
   let snr = signal/noise;
   let rawWeight = Math.max( 1.0e-8, snr*snr );
   return { signal: signal, noise: noise, snr: snr,
      rawWeight: rawWeight, fallback: false };
}


function StartCreateIntegrationSeries( series, combineDifferentFilters )
{
   let groups = {};
   for ( let i = 0; i < series.length; ++i ) {
      let source = StartSeriesSourceEntry( series[i] );
      let window = series[i].window || series[i];
      if ( source == null || window == null || window.isNull ||
           source.projectCompatible === false ||
           source.multiExposureSelected !== true ) continue;
      let image = window.mainView.image;
      let filter = source.filter == "—" ?
         (source.channels >= 3 ? "OSC_COLOR" : "UNFILTERED") :
         String( source.filter ).toUpperCase();
      let exposureKey = isFinite( source.exposure ) && source.exposure > 0 ?
         Math.round( 1000*source.exposure ) + "ms" : "UNKNOWN_EXPOSURE";
      let groupingFilter = combineDifferentFilters === true ?
         "MIXED_FILTERS" : filter;
      let key = groupingFilter + " | " + image.width + "x" + image.height + "x" +
         image.numberOfChannels;
      if ( groups[key] == null )
         groups[key] = { label: filter, filters: {}, filterNames: [],
            exposure: source.exposure, exposureKey: exposureKey, items: [] };
      else if ( groups[key].exposureKey != exposureKey )
         groups[key].exposureKey = "MIXED_EXPOSURE";
      if ( groups[key].filters[filter] == null ) {
         groups[key].filters[filter] = true;
         groups[key].filterNames.push( filter );
         if ( combineDifferentFilters === true )
            groups[key].label = groups[key].filterNames.join( " + " );
      }
      groups[key].items.push( series[i] );
   }

   let results = [];
   for ( let key in groups ) {
      let group = groups[key];
      if ( group.items.length < 2 ) continue;
      console.noteln( "⚙️ Integrating " + group.items.length + " images: " + group.label );
      try {
         let metrics = [];
         let weightSum = 0;
         for ( let i = 0; i < group.items.length; ++i ) {
            let metricWindow = group.items[i].window || group.items[i];
            let metric = StartIntegrationWeightMetrics( metricWindow );
            metrics.push( metric );
            weightSum += metric.rawWeight;
         }
         if ( !isFinite( weightSum ) || weightSum <= 0 ) weightSum = 0;
         for ( let i = 0; i < metrics.length; ++i ) {
            metrics[i].weight = weightSum > 0 ?
               metrics[i].rawWeight/weightSum : 1/metrics.length;
            let metricWindow = group.items[i].window || group.items[i];
            console.writeln( "📊 " + metricWindow.mainView.id +
               ": SNR " + format( "%.2f", metrics[i].snr ) +
               " · noise " + format( "%.6g", metrics[i].noise ) +
               " · weight " + format( "%.1f%%", 100*metrics[i].weight ) +
               (metrics[i].fallback ? " · fallback estimate" : "") );
         }
         let first = group.items[0].window || group.items[0];
         let output = StartCloneWindow( first,
            "InNovaStart_" + group.label + "_" +
            group.exposureKey +
            InNovaStartIntegrationSuffix + InNovaStartCombinedSuffix );
         output.mainView.beginProcess( UndoFlag_NoSwapFile );
         output.mainView.image.apply( metrics[0].weight, ImageOp.Mul );
         for ( let i = 1; i < group.items.length; ++i ) {
            let other = group.items[i].window || group.items[i];
            let weighted = new Image( other.mainView.image );
            weighted.apply( metrics[i].weight, ImageOp.Mul );
            output.mainView.image.apply( weighted, ImageOp.Add );
            weighted.free();
         }
         output.mainView.endProcess();
         StartWriteCombinationSource( output, group.items );
         results.push( { window: output, kind: "INTEGRATION",
            integrationLabel: "INTEGRATED — " + group.label,
            sourceItems: group.items, weightMetrics: metrics } );
      } catch ( error ) {
         console.warningln( "⚠️ InNova Multi-Night multi-night integration failed for " +
            group.label + ": " + error );
      }
   }
   return results;
}


function StartCreateHDRSeries( series )
{
   let groups = {};
   for ( let i = 0; i < series.length; ++i ) {
      let source = StartSeriesSourceEntry( series[i] );
      if ( source == null || !source.hdrCompatible ||
           source.multiExposureSelected !== true ) continue;
      let window = series[i].window || series[i];
      let image = window.mainView.image;
      let key = source.hdrGroup + " | " + image.width + "x" +
         image.height + "x" + image.numberOfChannels;
      if ( groups[key] == null )
         groups[key] = { label: source.hdrGroup, items: [], levels: {} };
      let level = Math.round( 1000*source.exposure );
      let candidate = { item: series[i], exposure: source.exposure };
      groups[key].items.push( candidate );
      if ( groups[key].levels[level] == null ) groups[key].levels[level] = [];
      groups[key].levels[level].push( candidate );
   }

   let results = [];
   for ( let key in groups ) {
      let group = groups[key];
      let levelCount = 0;
      for ( let level in group.levels ) ++levelCount;
      if ( levelCount < 3 ) continue;
      let hdrInputs = [];
      let temporaryIntegrations = [];
      let temporaryFiles = [];
      try {


         for ( let level in group.levels ) {
            let candidates = group.levels[level];
            if ( candidates.length == 1 ) {
               hdrInputs.push( candidates[0] );
               continue;
            }
            let first = candidates[0].item.window || candidates[0].item;
            let average = StartCloneWindow( first,
               "InNovaStart_" + group.label + "_" + level + "ms_Master" );
            average.mainView.beginProcess( UndoFlag_NoSwapFile );
            for ( let i = 1; i < candidates.length; ++i ) {
               let other = candidates[i].item.window || candidates[i].item;
               average.mainView.image.apply( other.mainView.image, ImageOp.Add );
            }
            average.mainView.image.apply( candidates.length, ImageOp.Div );
            average.mainView.endProcess();
            temporaryIntegrations.push( { window: average } );
            hdrInputs.push( { item: { window: average },
               exposure: candidates[0].exposure } );
         }
         hdrInputs.sort( function( a, b ) { return b.exposure - a.exposure; } );
         let idsBefore = StartWindowIdSet();
         let process = new HDRComposition;
         let processImages = [];
         for ( let i = 0; i < hdrInputs.length; ++i ) {
            let window = hdrInputs[i].item.window || hdrInputs[i].item;
            let temporaryPath = File.systemTempDirectory + "/" +
               StartSafeId( "InNovaStartHDR_" + group.label + "_" +
                  (new Date()).getTime() + "_" + i ) + ".xisf";
            let fileCopy = StartCloneWindow( window,
               "InNovaStartHDRFileInput_" + i );
            let saved = fileCopy.saveAs(
               temporaryPath, false, false, false, false );
            fileCopy.forceClose();
            if ( !saved )
               throw new Error( "Could not create a temporary HDR input." );
            temporaryFiles.push( temporaryPath );
            processImages.push( [ true, temporaryPath ] );
         }
         process.images = processImages;
         process.outputMasks = false;
         console.noteln( "🌗 Running HDRComposition…" );
         if ( !process.executeGlobal() )
            throw new Error( "HDRComposition did not generate an image." );
         let generated = null;
         let windows = ImageWindow.windows;
         for ( let i = 0; i < windows.length; ++i )
            if ( windows[i] != null && !windows[i].isNull &&
                 !windows[i].mainView.isNull &&
                 !idsBefore[windows[i].mainView.id] ) {
               generated = windows[i];
               break;
            }
         if ( generated == null )
            throw new Error( "The HDRComposition result could not be located." );
         let output = StartCloneWindow( generated,
            "InNovaStart_" + group.label + InNovaStartHDRSuffix +
            InNovaStartCombinedSuffix );
         generated.forceClose();
         StartWriteCombinationSource( output, group.items );
         StartCloseSeriesWindows( temporaryIntegrations );
         for ( let i = 0; i < temporaryFiles.length; ++i )
            if ( File.exists( temporaryFiles[i] ) ) File.remove( temporaryFiles[i] );
         results.push( { window: output, kind: "HDR",
            hdrLabel: "HDR — " + group.label,
            sourceItems: group.items } );
      } catch ( error ) {
         StartCloseSeriesWindows( temporaryIntegrations );
         for ( let i = 0; i < temporaryFiles.length; ++i )
            if ( File.exists( temporaryFiles[i] ) ) File.remove( temporaryFiles[i] );
         console.warningln( "⚠️ InNova Multi-Night HDR composition failed for " +
            group.label + ": " + error );
      }
   }
   return results;
}

function StartLuminance( image, x, y )
{
   let value = image.sample( x, y, 0 );
   if ( image.numberOfChannels >= 3 )
      value = 0.2126*value + 0.7152*image.sample( x, y, 1 ) +
         0.0722*image.sample( x, y, 2 );
   return value;
}

function StartImageQuality( window )
{
   let image = window.mainView.image;
   let maximumSamples = 30000;
   let step = Math.max( 1, Math.ceil( Math.sqrt(
      image.width*image.height/maximumSamples ) ) );
   let values = [];
   let saturated = 0;
   for ( let y = Math.floor( step/2 ); y < image.height; y += step )
      for ( let x = Math.floor( step/2 ); x < image.width; x += step ) {
         let value = StartLuminance( image, x, y );
         values.push( value );
         if ( value >= 0.985 )
            ++saturated;
      }
   if ( values.length < 16 )
      return { score: 0, background: 0, signal: 0, saturation: 0 };
   values.sort( function( a, b ) { return a - b; } );
   let background = values[Math.floor( 0.50*(values.length - 1) )];
   let upper = values[Math.floor( 0.995*(values.length - 1) )];
   let signal = Math.max( 0, upper - background );
   let saturation = saturated/values.length;
   let score = signal/Math.sqrt( Math.max( background, 1.0e-6 ) );
   score *= Math.max( 0.05, 1 - 8*saturation );
   return { score: score, background: background, signal: signal,
      saturation: saturation };
}

function StartPreflightStarCount( window )
{
   if ( window == null || window.isNull || window.mainView.isNull ) return -1;
   let auxiliary = null;
   try {
      let source = window.mainView.image;
      let workingImage = source;
      if ( source.isColor ) {
         auxiliary = new ImageWindow( source.width, source.height,
            source.numberOfChannels, 32, true, true,
            StartSafeId( "InNovaStartStarPreflight" ) );
         auxiliary.mainView.beginProcess( UndoFlag_NoSwapFile );
         auxiliary.mainView.image.assign( source );
         auxiliary.mainView.endProcess();
         let grayscale = new ConvertToGrayscale;
         grayscale.executeOn( auxiliary.mainView );
         workingImage = auxiliary.mainView.image;
      }
      let detector = new StarDetector;
      detector.structureLayers = 5;
      detector.noiseReductionFilterRadius = 1;
      detector.sensitivity = 0.5;
      detector.peakResponse = 0.5;
      detector.allowClusteredSources = false;
      detector.maxDistortion = 0.6;
      detector.minStructureSize = 3;
      detector.fitPSF = false;
      let stars = detector.stars( workingImage );
      if ( auxiliary != null && !auxiliary.isNull ) auxiliary.forceClose();
      return stars.length;
   } catch ( error ) {
      if ( auxiliary != null && !auxiliary.isNull ) auxiliary.forceClose();
      console.writeln( "🔎 Star-field preflight was inconclusive: " + error );
      return -1;
   }
}

function StartImageEntry( window )
{
   let image = window.mainView.image;
   let auxiliaryReason = StartAuxiliaryReason( window.mainView.id );
   return {
      window: window,
      astrometryScale: StartCropAstrometryScale(window),
      id: window.mainView.id,
      width: image.width,
      height: image.height,
      channels: image.numberOfChannels,
      exposure: StartExposureSeconds( window ),
      filter: StartKeywordValue( window, [ "FILTER", "FILTERID" ] ) || "—",
      camera: StartKeywordValue( window,
         [ "INSTRUME", "CAMERA", "DETECTOR" ] ) || "—",
      objectName: StartKeywordValue( window,
         [ "OBJECT", "OBJNAME", "TARGET" ] ),
      dateObs: StartKeywordValue( window,
         [ "DATE-OBS", "DATE-BEG", "DATE" ] ),
      ra: StartNumericKeyword( window, [ "CRVAL1" ] ),
      dec: StartNumericKeyword( window, [ "CRVAL2" ] ),
      isMaster: /master|integrat|stack/i.test( window.mainView.id ) ||
         StartNumericKeyword( window, [ "NCOMBINE", "STACKCNT" ] ) > 1,
      quality: null,
      projectStatus: auxiliaryReason.length > 0 ? auxiliaryReason : "Pending",
      projectCompatible: auxiliaryReason.length == 0,
      hdrCompatible: false,
      hdrGroup: "",
      multiExposureSelected: false,
      auxiliaryReason: auxiliaryReason,
      enabled: auxiliaryReason.length == 0
   };
}

function StartCloneWindow( source, id, showOutput )
{
   let image = source.mainView.image;
   let output = new ImageWindow( image.width, image.height,
      image.numberOfChannels, 32, true, image.colorSpace != ColorSpace_Gray,
      StartSafeId( id ) );
   output.mainView.beginProcess( UndoFlag_NoSwapFile );
   output.mainView.image.assign( image );
   output.mainView.endProcess();
   try { output.keywords = source.keywords; } catch ( error ) {}
   if ( showOutput !== false ) output.show();
   return output;
}

function StartQuickStretchRow( median, mad, channelIndexes )
{
   let inverted = 0;
   for ( let i = 0; i < channelIndexes.length; ++i )
      if ( median.at( channelIndexes[i] ) > 0.5 ) ++inverted;

   if ( inverted < channelIndexes.length ) {
      let shadows = 0;
      let center = 0;
      for ( let i = 0; i < channelIndexes.length; ++i ) {
         let c = channelIndexes[i];
         shadows += median.at( c ) - 2.8*mad.at( c );
         center += median.at( c );
      }
      shadows = Math.range( shadows/channelIndexes.length, 0, 1 );
      center = Math.mtf(
         0.25, center/channelIndexes.length - shadows );
      return [ shadows, center, 1, 0, 1 ];
   }

   let highlights = 0;
   let center = 0;
   for ( let i = 0; i < channelIndexes.length; ++i ) {
      let c = channelIndexes[i];
      highlights += median.at( c ) + 2.8*mad.at( c );
      center += median.at( c );
   }
   highlights = Math.range(
      highlights/channelIndexes.length, 0, 1 );
   center = Math.mtf(
      highlights - center/channelIndexes.length, 0.25 );
   return [ 0, center, highlights, 0, 1 ];
}

function StartQuickStretchRowsLinked( rows )
{
   if ( rows == null || rows.length < 3 ) return true;
   for ( let c = 1; c < 3; ++c )
      for ( let i = 0; i < rows[0].length; ++i )
         if ( Math.abs( rows[c][i] - rows[0][i] ) > 1.0e-12 )
            return false;
   return true;
}

function StartQuickStretchAutomaticLinkedMode( median, mad )
{


   let minimum = 1;
   let maximum = 0;
   let noise = 0;
   for ( let c = 0; c < 3; ++c ) {
      let value = median.at( c );
      minimum = Math.min( minimum, value );
      maximum = Math.max( maximum, value );
      noise += mad.at( c );
   }
   noise /= 3;


   if ( maximum >= 0.25 ) return true;
   let spread = maximum - minimum;
   let relativeSpread = spread/Math.max( maximum, 1.0e-6 );
   let significantSpread = spread > 2.5*Math.max( noise, 1.0e-6 );
   return !(relativeSpread > 0.15 && significantSpread);
}

function StartQuickStretchBitmap( source, alreadyStretched,
   linkedChannels, stretchState )
{
   if ( stretchState != null ) {
      stretchState.linked = null;
      stretchState.adjustable = false;
      stretchState.automatic = false;
   }
   if ( source == null || source.isNull || source.mainView.isNull )
      return null;
   let previewWindow = null;
   try {
      let image = new Image( source.mainView.image );
      let maximumDimension = 1800;
      let scale = Math.min( 1,
         maximumDimension/Math.max( image.width, image.height ) );
      if ( scale < 1 )
         image.resample( scale, scale, 0, 0 );
      if ( alreadyStretched ) {
         let bitmap = image.render();
         image.free();
         if ( stretchState != null ) {
            stretchState.linked = null;
            stretchState.adjustable = false;
         }
         return bitmap;
      }

      previewWindow = new ImageWindow( image.width, image.height,
         image.numberOfChannels, 32, true, image.isColor,
         StartSafeId( "InNovaStartPreview_" + (++InNovaStartPreviewSerial) ) );
      previewWindow.mainView.beginProcess( UndoFlag_NoSwapFile );
      previewWindow.mainView.image.assign( image );
      previewWindow.mainView.endProcess();
      image.free();

      let view = previewWindow.mainView;
      let median = view.computeOrFetchProperty( "Median" );
      let mad = view.computeOrFetchProperty( "MAD" );
      mad.mul( 1.4826 );
      let histogram = new HistogramTransformation;
      let identity = [ 0, 0.5, 1, 0, 1 ];
      let rows;
      let automaticMode = false;
      let useLinkedChannels = linkedChannels !== false;
      if ( view.image.isColor ) {
         automaticMode = typeof linkedChannels != "boolean";
         useLinkedChannels = automaticMode ?
            StartQuickStretchAutomaticLinkedMode( median, mad ) :
            linkedChannels;
         if ( useLinkedChannels ) {
            let linkedRow = StartQuickStretchRow(
               median, mad, [ 0, 1, 2 ] );
            rows = [ linkedRow, linkedRow, linkedRow, identity ];
         } else {
            rows = [
               StartQuickStretchRow( median, mad, [ 0 ] ),
               StartQuickStretchRow( median, mad, [ 1 ] ),
               StartQuickStretchRow( median, mad, [ 2 ] ),
               identity
            ];
         }
      } else {
         let grayRow = StartQuickStretchRow( median, mad, [ 0 ] );
         rows = [ identity, identity, identity, grayRow ];
      }
      histogram.H = rows;
      if ( stretchState != null ) {


         stretchState.linked = view.image.isColor ?
            (useLinkedChannels &&
             StartQuickStretchRowsLinked( rows )) : null;
         stretchState.adjustable = view.image.isColor;
         stretchState.automatic = view.image.isColor && automaticMode;
      }
      histogram.executeOn( view );
      let bitmap = view.image.render();
      previewWindow.forceClose();
      return bitmap;
   } catch ( error ) {
      if ( previewWindow != null && !previewWindow.isNull )
         previewWindow.forceClose();
      console.warningln( "⚠️ Quick-stretch preview failed: " + error );
      try { return source.mainView.image.render(); } catch ( ignored ) {}
      return null;
   }
}

class InNovaStartImageViewer extends Control
{
constructor( parent, informationParent, navigationParent )
{
   super( parent );
   let viewer = this;
   this.series = [];
   this.index = -1;
   this.bitmap = null;
   this.scaledBitmap = null;
   this.scale = 1;
   this.fitMode = true;
   this.panEnabled = true;
   this.scrolling = null;
   this.seriesLabel = "";
   this.onRemoveRequested = null;
   this.onMultiExposureRequested = null;
   this.onCropRequested = null;
   this.onRestoreCropRequested = null;
   this.onCropSelected = null;
   this.cropMode = false;
   this.cropEditMode = false;
   this.cropStart = null;
   this.cropDrag = null;
   this.cropSelection = null;
   this.cropInteractionActive = false;
   this.quickStretchLinked = null;
   this.quickStretchToggleAvailable = false;
   this.onImageSolverRequested = null;
   this.onColorCalibrationRequested = null;
   this.onConsoleRequested = null;

   this.scrollBox = new StartImageReviewViewport( this, 820, 440 );
   this.scrollBox.viewport.cursor = new Cursor( StdCursor_OpenHand );

   this.previousButton = new ToolButton( this );
   this.previousButton.icon = this.scaledResource( ":/icons/previous.png" );
   this.previousButton.setScaledFixedSize( 40, 34 );
   this.previousButton.toolTip = "Previous image";

   this.consoleButton = new ToolButton( this );
   this.consoleButton.icon =
      this.scaledResource( ":/toolbar/view-process-console.png" );
   this.consoleButton.setScaledFixedSize( 28, 28 );
   this.consoleButton.toolTip = "Show the PixInsight Process Console";
   this.consoleButton.onClick = function()
   {
      if ( typeof viewer.onConsoleRequested == "function" )
         viewer.onConsoleRequested();
   };

   this.zoomInButton = new ToolButton( this );
   this.zoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.zoomInButton.setScaledFixedSize( 28, 28 );
   this.zoomInButton.toolTip = "Zoom in";

   this.fitButton = new ToolButton( this );
   this.fitButton.icon =
      this.scaledResource( ":/toolbar/view-zoom-fit.png" );
   this.fitButton.setScaledFixedSize( 28, 28 );
   this.fitButton.toolTip = "Fit image to viewer";

   this.zoomOutButton = new ToolButton( this );
   this.zoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.zoomOutButton.setScaledFixedSize( 28, 28 );
   this.zoomOutButton.toolTip = "Zoom out";

   this.panButton = new ToolButton( this );
   this.panButton.text = "✋";
   this.panButton.setScaledFixedSize( 32, 32 );
   this.panButton.checkable = true;
   this.panButton.checked = true;
   this.panButton.toolTip = "Pan the zoomed image by dragging";

   this.cropToolButton = new ToolButton( this );
   this.cropToolButton.icon = StartCropIcon();
   this.cropToolButton.setScaledFixedSize( 32, 32 );
   this.cropToolButton.toolTip =
      "Crop: draw or edit the retained rectangle; click again to apply it";

   this.adaptiveAccessEnabled = false;
   this.adaptiveButton = new ToolButton( this );
   this.adaptiveButton.icon = StartAdaptiveIcon();
   this.adaptiveButton.setScaledFixedSize( 32, 32 );
   this.adaptiveButton.toolTip = "Open the current image in InNova Adaptive Stretch";
   this.adaptiveButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onAdaptiveRequested == "function" )
         viewer.onAdaptiveRequested( window );
   };

   this.quickStretchLinkButton = new ToolButton( this );
   this.quickStretchLinkButton.icon = StartQuickStretchLinkIcon( true );
   this.quickStretchLinkButton.setScaledFixedSize( 32, 32 );
   this.quickStretchLinkButton.toolTip =
      "Unlink RGB channels and recalculate Quick Stretch";
   this.updateQuickStretchLinkButton = function()
   {
      this.quickStretchLinkButton.icon =
         StartQuickStretchLinkIcon( this.quickStretchLinked !== true );
      this.quickStretchLinkButton.toolTip =
         this.quickStretchLinked === true ?
         "RGB channels: Linked · Click to unlink and recalculate Quick Stretch" :
         "RGB channels: Unlinked · Click to link and recalculate Quick Stretch";
   };
   this.quickStretchLinkButton.onClick = function()
   {
      if ( !viewer.quickStretchToggleAvailable ||
           viewer.cropInteractionActive || viewer.index < 0 ) return;
      let item = viewer.series[viewer.index];
      let window = item.window || item;
      if ( window == null || window.isNull ) return;
      let targetLinked = viewer.quickStretchLinked !== true;
      let state = {};
      viewer.footer.text = targetLinked ?
         "Recalculating linked RGB Quick Stretch…" :
         "Recalculating unlinked RGB Quick Stretch…";
      CoreApplication.processEvents();
      let bitmap = StartQuickStretchBitmap(
         window, false, targetLinked, state );
      if ( bitmap == null ) return;
      viewer.bitmap = bitmap;
      viewer.quickStretchLinked = state.linked;
      viewer.quickStretchToggleAvailable = state.adjustable === true;
      item.quickStretchLinked = state.linked;
      item.quickStretchAutomatic = false;
      viewer.rebuildScaledBitmap();
      viewer.updateQuickStretchLinkButton();
      viewer.updateInformation();
      viewer.updateButtons();
   };

   this.imageSolverButton = new ToolButton( this );
   this.imageSolverButton.icon = StartImageSolverIcon();
   this.imageSolverButton.setScaledFixedSize( 32, 32 );
   this.imageSolverButton.toolTip =
      "Solve the current image with ImageSolver";
   this.imageSolverButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onImageSolverRequested == "function" )
         viewer.onImageSolverRequested( window,
            viewer.index >= 0 ? viewer.series[viewer.index] : window );
   };

   this.colorCalibrationButton = new ToolButton( this );
   this.colorCalibrationButton.icon = StartColorCalibrationIcon();
   this.colorCalibrationButton.setScaledFixedSize( 32, 32 );
   this.colorCalibrationButton.toolTip =
      "Create a copy and apply SPCC color calibration";
   this.colorCalibrationButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onColorCalibrationRequested == "function" )
         viewer.onColorCalibrationRequested( window,
            viewer.index >= 0 ? viewer.series[viewer.index] : window );
   };

   this.processorButton = new ToolButton( this );
   this.processorButton.icon = StartProcessorRocketIcon();
   this.processorButton.setScaledFixedSize( 32, 32 );
   this.processorButton.toolTip = "Open InNova Astro Processor";
   this.processorButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onProcessorRequested == "function" )
         viewer.onProcessorRequested( window );
   };

   this.editorButton = new ToolButton( this );
   this.editorButton.icon = StartEditorAdjustmentsIcon();
   this.editorButton.setScaledFixedSize( 32, 32 );
   this.editorButton.toolTip = "Open the current image in InNova Photo Editor";
   this.editorButton.onClick = function()
   {
      if ( !viewer.adaptiveAccessEnabled || viewer.cropInteractionActive ) return;
      let window = viewer.currentWindow();
      if ( window == null || window.isNull ) return;
      if ( typeof viewer.onEditorRequested == "function" )
         viewer.onEditorRequested( window );
   };

   this.restoreCropButton = new ToolButton( this );
   this.restoreCropButton.icon = this.scaledResource( ":/icons/reload.png" );
   this.restoreCropButton.setScaledFixedSize( 28, 28 );
   this.restoreCropButton.toolTip =
      "Restore the image sequence and discard all crop adjustments";

   this.removeButton = new ToolButton( this );
   this.removeButton.icon = this.scaledResource( ":/icons/trash.png" );
   this.removeButton.setScaledFixedSize( 28, 28 );
   this.removeButton.toolTip =
      "Remove this image from the project without closing or deleting it in PixInsight";

   this.multiExposureButton = new ToolButton( this );
   this.multiExposureButton.icon = StartMultiExposureIcon();
   this.multiExposureButton.setScaledFixedSize( 32, 32 );
   this.multiExposureButton.checkable = true;
   this.multiExposureButton.toolTip =
      "Add or remove the current image from the Multi-exposure selection";

   this.nextButton = new ToolButton( this );
   this.nextButton.icon = this.scaledResource( ":/icons/next.png" );
   this.nextButton.setScaledFixedSize( 40, 34 );
   this.nextButton.toolTip = "Next image";

   let labelParent = informationParent || this;
   this.fileLabel = new Label( labelParent );
   this.fileLabel.useRichText = true;
   this.fileLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
   this.fileLabel.setScaledFixedHeight( 22 );
   this.fileLabel.text = "No image selected";


   if ( labelParent != null && labelParent.title !== undefined )
      labelParent.title = "Image: 0 / 0";

   this.footer = new Label( navigationParent || labelParent );
   this.footer.useRichText = true;
   this.footer.wordWrapping = true;
   this.footer.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;


   this.footer.setScaledFixedHeight( 44 );
   this.footer.text =
      "<b>Use the ← and → arrows to move through the images.</b><br>" +
      "In this process, you can zoom in on the images, crop them, or create " +
      "a multi-night integration.";

   this.exifLabel = new Label( labelParent );
   this.exifLabel.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.exifLabel.setScaledFixedHeight( 22 );
   this.exifLabel.text =
      "Exposure: — · Filter: — · Camera: — · Geometry: —";

   this.updateInformation = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) {
         this.fileLabel.text =
            "<span style=\"color:#168de2\">No image selected</span>";
         this.multiExposureButton.checked = false;
         if ( labelParent != null && labelParent.title !== undefined )
            labelParent.title = "Image: 0 / 0";
         this.footer.text =
            "Run the project to preview registered images.";
         this.exifLabel.text =
            "Exposure: — · Filter: — · Camera: — · Geometry: —";
         return;
      }
      let item = this.series[this.index];
      let window = item.window || item;
      let typeText = item.kind == "HDR" ? " - ✅ NEW HDR" :
         (item.kind == "INTEGRATION" ?
            " - ✅ NEW MULTI-EXPOSURE IMAGE" : "");
      let source = item;
      while ( source != null && source.source != null ) source = source.source;
      let selected = source != null &&
         source.multiExposureSelected === true && typeText.length == 0;
      this.fileLabel.text = item.kind == "HDR" ||
         item.kind == "INTEGRATION" ?
         "<b style=\"color:#168de2\">" +
         StartHTMLText( window.mainView.id + typeText ) + "</b>" : selected ?
         "<b style=\"color:#d97800\">★ " +
         StartHTMLText( window.mainView.id ) +
         " — ADDED TO MULTI-EXPOSURE</b>" :
         "<span style=\"color:#168de2\">" +
         StartHTMLText( window.mainView.id + typeText ) + "</span>";
      this.multiExposureButton.checked = selected;
      if ( labelParent != null && labelParent.title !== undefined )
         labelParent.title = "Image: " + (this.index + 1) + " / " +
            this.series.length;
      this.footer.text =
         "<b>Use the ← and → arrows to move through the images.</b> · " +
         (item.alreadyStretched ? "Processed image" :
            ((item.quickStretchAutomatic === true ? "Automatic " : "") +
             (this.quickStretchLinked === false ? "unlinked" : "linked") +
             " RGB Quick Stretch")) +
         "<br>In this process, you can zoom in on the images, crop them, " +
         "or create a multi-night integration.";
      let metadataSource = item;
      if ( item.sourceItems != null && item.sourceItems.length > 0 ) {
         metadataSource = item.sourceItems[0];
         if ( metadataSource.item != null )
            metadataSource = metadataSource.item;
      }
      metadataSource = StartSeriesSourceEntry( metadataSource );
      let exposureText = item.kind == "HDR" ? "Multiple exposures" :
         (metadataSource != null ?
            StartExposureText( metadataSource.exposure ) : "—");
      let filterText = metadataSource != null &&
         metadataSource.filter != null ? metadataSource.filter : "—";
      let cameraText = metadataSource != null &&
         metadataSource.camera != null ? metadataSource.camera : "—";
      let image = window.mainView.image;
      this.exifLabel.text = "Exposure: " + exposureText +
         " · Filter: " + filterText +
         " · Camera: " + cameraText +
         " · Geometry: " + image.width + " × " + image.height;
   };

   this.updateButtons = function()
   {
      let available = this.series.length > 0;
      let currentIsDerived = available && this.index >= 0 &&
         (this.series[this.index].kind == "HDR" ||
          this.series[this.index].kind == "INTEGRATION");
      if ( this.cropInteractionActive ) {
         this.previousButton.enabled = false;
         this.nextButton.enabled = false;
         this.zoomInButton.enabled = false;
         this.fitButton.enabled = false;
         this.zoomOutButton.enabled = false;
         this.panButton.enabled = false;
         this.cropToolButton.enabled = available;
         this.quickStretchLinkButton.enabled = false;
         this.adaptiveButton.enabled = false;
         this.imageSolverButton.enabled = false;
         this.colorCalibrationButton.enabled = false;
         this.editorButton.enabled = false;
         this.processorButton.enabled = false;
         this.restoreCropButton.enabled = false;
         this.removeButton.enabled = false;
         this.multiExposureButton.enabled = false;
         return;
      }
      this.previousButton.enabled = available && this.index > 0;
      this.nextButton.enabled = available && this.index + 1 < this.series.length;
      this.zoomInButton.enabled = available;
      this.fitButton.enabled = available;
      this.zoomOutButton.enabled = available;
      this.panButton.enabled = available;
      this.cropToolButton.enabled = available;
      this.quickStretchLinkButton.enabled = available &&
         this.quickStretchToggleAvailable;
      this.adaptiveButton.enabled = available && this.adaptiveAccessEnabled;
      this.imageSolverButton.enabled = available && this.adaptiveAccessEnabled;
      this.colorCalibrationButton.enabled = available && this.adaptiveAccessEnabled;
      this.editorButton.enabled = available && this.adaptiveAccessEnabled;
      this.processorButton.enabled = available && this.adaptiveAccessEnabled;
      this.restoreCropButton.enabled = available;
      this.removeButton.enabled = available && !currentIsDerived;
      this.multiExposureButton.enabled = available && !currentIsDerived;
   };

   this.setCropInteractionActive = function( active )
   {
      this.cropInteractionActive = active === true;
      this.updateButtons();
   };

   this.currentWindow = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) return null;
      let item = this.series[this.index];
      let window = item.window || item;
      if ( window == null || window.isNull || window.mainView == null ||
           window.mainView.isNull ) return null;
      return window;
   };

   this.bitmapOffset = function()
   {
      return this.scrollBox.bitmapOffsetFor( this );
   };

   this.viewportToSource = function( x, y, clampToImage )
   {
      let window = this.currentWindow();
      if ( window == null || this.bitmap == null ||
           this.scaledBitmap == null ) return null;
      let offset = this.bitmapOffset();
      let bx = (x - offset.x)/this.scale;
      let by = (y - offset.y)/this.scale;
      if ( clampToImage ) {
         bx = Math.range( bx, 0, this.bitmap.width - 1 );
         by = Math.range( by, 0, this.bitmap.height - 1 );
      } else if ( bx < 0 || by < 0 || bx >= this.bitmap.width ||
                  by >= this.bitmap.height ) return null;
      let image = window.mainView.image;
      return {
         x: Math.range( Math.round( bx*image.width/this.bitmap.width ),
            0, image.width - 1 ),
         y: Math.range( Math.round( by*image.height/this.bitmap.height ),
            0, image.height - 1 )
      };
   };

   this.setCropMode = function( active )
   {
      this.cropMode = active === true && this.bitmap != null;
      this.cropEditMode = false;
      this.cropStart = null;
      this.cropDrag = null;
      this.scrolling = null;
      if ( this.cropMode ) {
         this.panEnabled = false;
         this.panButton.checked = false;
      }
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropMode ? StdCursor_Cross :
         (this.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow) );
      this.scrollBox.viewport.update();
   };

   this.setCropEditMode = function( active )
   {
      this.cropMode = false;
      this.cropStart = null;
      this.cropDrag = null;
      this.scrolling = null;
      this.cropEditMode = active === true && this.cropSelection != null;
      if ( this.cropEditMode ) {
         this.panEnabled = false;
         this.panButton.checked = false;
      }
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropEditMode ? StdCursor_Cross :
         (this.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow) );
      this.scrollBox.viewport.update();
   };

   this.setCropSelection = function( rectangle )
   {
      this.cropSelection = rectangle;
      this.scrollBox.viewport.update();
   };

   this.cropHitAction = function( point )
   {
      if ( this.cropSelection == null || this.scaledBitmap == null ) return "new";
      let window = this.currentWindow();
      if ( window == null ) return "new";
      let image = window.mainView.image;
      let r = this.cropSelection;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      let tx = Math.max( 4, 10*image.width/this.scaledBitmap.width );
      let ty = Math.max( 4, 10*image.height/this.scaledBitmap.height );
      let nearLeft = Math.abs( point.x - r.x ) <= tx;
      let nearRight = Math.abs( point.x - right ) <= tx;
      let nearTop = Math.abs( point.y - r.y ) <= ty;
      let nearBottom = Math.abs( point.y - bottom ) <= ty;
      let verticalRange = point.y >= r.y - ty && point.y <= bottom + ty;
      let horizontalRange = point.x >= r.x - tx && point.x <= right + tx;
      if ( nearLeft && nearTop ) return "lt";
      if ( nearRight && nearTop ) return "rt";
      if ( nearLeft && nearBottom ) return "lb";
      if ( nearRight && nearBottom ) return "rb";
      if ( nearLeft && verticalRange ) return "l";
      if ( nearRight && verticalRange ) return "r";
      if ( nearTop && horizontalRange ) return "t";
      if ( nearBottom && horizontalRange ) return "b";
      if ( point.x >= r.x && point.x <= right &&
           point.y >= r.y && point.y <= bottom ) return "move";
      return "new";
   };

   this.updateCropDrag = function( point )
   {
      if ( this.cropDrag == null ) return;
      let d = this.cropDrag;
      let r = d.original;
      let window = this.currentWindow();
      if ( window == null ) {
         this.cropDrag = null;
         return;
      }
      let image = window.mainView.image;
      if ( d.action == "move" ) {
         let x = Math.range( r.x + point.x - d.start.x,
            0, image.width - r.width );
         let y = Math.range( r.y + point.y - d.start.y,
            0, image.height - r.height );
         this.cropSelection = { x: x, y: y,
            width: r.width, height: r.height };
         return;
      }
      let left = r.x;
      let top = r.y;
      let right = r.x + r.width - 1;
      let bottom = r.y + r.height - 1;
      if ( d.action.indexOf( "l" ) >= 0 )
         left = Math.range( point.x, 0, right - 63 );
      if ( d.action.indexOf( "r" ) >= 0 )
         right = Math.range( point.x, left + 63, image.width - 1 );
      if ( d.action.indexOf( "t" ) >= 0 )
         top = Math.range( point.y, 0, bottom - 63 );
      if ( d.action.indexOf( "b" ) >= 0 )
         bottom = Math.range( point.y, top + 63, image.height - 1 );
      this.cropSelection = { x: left, y: top,
         width: right - left + 1, height: bottom - top + 1 };
   };

   this.rebuildScaledBitmap = function()
   {
      this.scrollBox.rebuildFor( this );
   };

   this.showCurrent = function()
   {
      if ( this.index < 0 || this.index >= this.series.length ) return;
      let item = this.series[this.index];
      let window = item.window || item;
      this.footer.text = "<b>Preparing quick-stretch preview…</b>";
      CoreApplication.processEvents();
      let stretchState = {};
      this.bitmap = StartQuickStretchBitmap( window,
         item.alreadyStretched === true,
         typeof item.quickStretchLinked == "boolean" &&
         item.quickStretchAutomatic !== true ?
            item.quickStretchLinked : undefined,
         stretchState );
      this.quickStretchLinked = stretchState.linked;
      this.quickStretchToggleAvailable =
         stretchState.adjustable === true;
      if ( this.quickStretchToggleAvailable )
         item.quickStretchLinked = this.quickStretchLinked;
      item.quickStretchAutomatic = stretchState.automatic === true;
      this.updateQuickStretchLinkButton();
      this.cropMode = false;
      this.cropEditMode = this.cropSelection != null;
      this.panEnabled = !this.cropEditMode;
      this.panButton.checked = this.panEnabled;
      this.fitMode = true;
      this.scrollBox.horizontalScrollPosition = 0;
      this.scrollBox.verticalScrollPosition = 0;
      this.rebuildScaledBitmap();
      this.scrollBox.viewport.cursor = new Cursor(
         this.cropEditMode ? StdCursor_Cross : StdCursor_OpenHand );
      this.updateInformation();
      this.updateButtons();
   };

   this.showModuleResult = function( result, sourceId, alreadyStretched )
   {
      if ( !result || result.isNull ) return;
      let index = -1;
      for ( let i = 0; i < this.series.length; ++i ) {
         let window = this.series[i].window || this.series[i];
         if ( !window.isNull && window.mainView.id == sourceId ) { index = i; break; }
      }
      let previous = index >= 0 ? this.series[index] : StartImageEntry(result);
      let replacement = { window: result, source: previous,
         alreadyStretched: alreadyStretched !== false, kind: previous.kind,
         sourceItems: previous.sourceItems };

      let updated = this.series.slice();
      if ( index < 0 ) { index = updated.length; updated.push(replacement); }
      else updated[index] = replacement;
      if ( typeof this.onModuleResultShown == "function" )
         this.onModuleResultShown( previous, replacement );
      this.setSeries(updated, this.seriesLabel, index);
   };

   this.setSeries = function( series, label, preferredIndex )
   {
      this.series = series || [];
      this.seriesLabel = label || "Images";
      this.index = this.series.length > 0 ? Math.range(
         preferredIndex === undefined ? 0 : preferredIndex,
         0, this.series.length - 1 ) : -1;
      this.bitmap = null;
      this.scaledBitmap = null;
      this.quickStretchLinked = null;
      this.quickStretchToggleAvailable = false;
      this.cropSelection = null;
      this.cropMode = false;
      this.cropEditMode = false;
      this.cropDrag = null;
      if ( this.index >= 0 )
         this.showCurrent();
      else {
         this.updateInformation();
         this.updateButtons();
         this.scrollBox.viewport.update();
      }
   };

   this.zoom = function( factor )
   {
      this.scrollBox.zoomFor( this, factor );
      this.updateInformation();
   };

   this.previousButton.onClick = function()
   {
      if ( viewer.index > 0 ) {
         --viewer.index;
         viewer.showCurrent();
         if ( typeof viewer.onIndexChanged == "function" )
            viewer.onIndexChanged( viewer.index );
      }
   };
   this.nextButton.onClick = function()
   {
      if ( viewer.index + 1 < viewer.series.length ) {
         ++viewer.index; viewer.showCurrent();
         if ( typeof viewer.onIndexChanged == "function" )
            viewer.onIndexChanged( viewer.index );
      }
   };
   this.zoomInButton.onClick = function() { viewer.zoom( 1.35 ); };
   this.fitButton.onClick = function()
   {
      viewer.scrollBox.fitFor( viewer );
      viewer.updateInformation();
   };
   this.zoomOutButton.onClick = function() { viewer.zoom( 1/1.35 ); };
   this.panButton.onClick = function()
   {
      viewer.cropMode = false;
      viewer.cropEditMode = false;
      viewer.cropStart = null;
      viewer.cropDrag = null;
      viewer.panEnabled = this.checked;
      viewer.scrollBox.viewport.cursor = new Cursor(
         viewer.panEnabled ? StdCursor_OpenHand : StdCursor_Arrow );
   };
   this.cropToolButton.onClick = function()
   {
      if ( viewer.onCropRequested != null ) viewer.onCropRequested();
   };
   this.restoreCropButton.onClick = function()
   {
      if ( viewer.onRestoreCropRequested != null )
         viewer.onRestoreCropRequested();
   };
   this.removeButton.onClick = function()
   {
      if ( viewer.index >= 0 && viewer.onRemoveRequested != null )
         viewer.onRemoveRequested( viewer.series[viewer.index], viewer.index );
   };
   this.multiExposureButton.onClick = function()
   {
      if ( viewer.index >= 0 && viewer.onMultiExposureRequested != null )
         viewer.onMultiExposureRequested( viewer.series[viewer.index],
            this.checked );
   };

   this.scrollBox.viewport.onResize = function()
   {
      if ( viewer.fitMode ) viewer.rebuildScaledBitmap();
   };
   this.scrollBox.onHorizontalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
   this.scrollBox.onVerticalScrollPosUpdated = function()
   {
      this.viewport.update();
   };
      this.scrollBox.viewport.onMousePress = function(
      x, y, button, buttonState, modifiers )
   {
      if ( button != MouseButton_Left ) return;
      if ( viewer.cropMode ) {
         let point = viewer.viewportToSource( x, y );
         if ( point == null ) return;
         viewer.cropStart = point;
         viewer.cropSelection = { x: point.x, y: point.y,
            width: 1, height: 1 };
         this.update();
         return;
      }
      if ( viewer.cropEditMode && viewer.cropSelection != null ) {
         let point = viewer.viewportToSource( x, y );
         if ( point == null ) return;
         let action = viewer.cropHitAction( point );
         if ( action == "new" ) {
            viewer.cropEditMode = false;
            viewer.cropMode = true;
            viewer.cropStart = point;
            viewer.cropSelection = { x: point.x, y: point.y,
               width: 1, height: 1 };
         } else {
            let r = viewer.cropSelection;
            viewer.cropDrag = { action: action, start: point,
               original: { x: r.x, y: r.y,
                  width: r.width, height: r.height } };
         }
         this.update();
         return;
      }
      if ( !viewer.panEnabled ) return;
      viewer.scrollBox.beginPanFor( viewer, x, y );
   };
   this.scrollBox.viewport.onMouseMove = function(
      x, y, buttonState, modifiers )
   {
      if ( viewer.cropMode && viewer.cropStart != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point == null ) return;
         let left = Math.min( viewer.cropStart.x, point.x );
         let top = Math.min( viewer.cropStart.y, point.y );
         viewer.cropSelection = { x: left, y: top,
            width: Math.abs( point.x - viewer.cropStart.x ) + 1,
            height: Math.abs( point.y - viewer.cropStart.y ) + 1 };
         this.update();
         return;
      }
      if ( viewer.cropDrag != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point == null ) return;
         viewer.updateCropDrag( point );
         this.update();
         return;
      }
      viewer.scrollBox.movePanFor( viewer, x, y );
   };
   this.scrollBox.viewport.onMouseRelease = function(
      x, y, button, buttonState, modifiers )
   {
      if ( viewer.cropMode && viewer.cropStart != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point != null ) {
            let left = Math.min( viewer.cropStart.x, point.x );
            let top = Math.min( viewer.cropStart.y, point.y );
            viewer.cropSelection = { x: left, y: top,
               width: Math.abs( point.x - viewer.cropStart.x ) + 1,
               height: Math.abs( point.y - viewer.cropStart.y ) + 1 };
         }
         let rectangle = viewer.cropSelection;
         viewer.cropStart = null;
         viewer.cropMode = false;
         viewer.cropEditMode = true;
         viewer.panEnabled = false;
         viewer.panButton.checked = false;
         this.cursor = new Cursor( StdCursor_Cross );
         this.update();
         if ( rectangle != null && viewer.onCropSelected != null )
            viewer.onCropSelected( rectangle );
         return;
      }
      if ( viewer.cropDrag != null ) {
         let point = viewer.viewportToSource( x, y, true );
         if ( point != null ) viewer.updateCropDrag( point );
         viewer.cropDrag = null;
         this.update();
         if ( viewer.cropSelection != null && viewer.onCropSelected != null )
            viewer.onCropSelected( viewer.cropSelection );
         return;
      }
      viewer.scrollBox.endPanFor( viewer );
   };
   this.scrollBox.viewport.onPaint = function( x0, y0, x1, y1 )
   {
      let graphics = new Graphics( this );
      graphics.fillRect( x0, y0, x1, y1, new Brush( 0xff020613 ) );
      if ( viewer.scaledBitmap != null ) {
         let offset = viewer.scrollBox.drawBitmapFor( graphics, viewer );
         let ox = offset.x;
         let oy = offset.y;
         if ( viewer.cropSelection != null ) {
            let window = viewer.currentWindow();
            if ( window != null ) {
               let image = window.mainView.image;
               let rectangle = viewer.cropSelection;
               let left = ox + rectangle.x*viewer.scaledBitmap.width/image.width;
               let top = oy + rectangle.y*viewer.scaledBitmap.height/image.height;
               let right = ox + (rectangle.x + rectangle.width)*
                  viewer.scaledBitmap.width/image.width;
               let bottom = oy + (rectangle.y + rectangle.height)*
                  viewer.scaledBitmap.height/image.height;
               let imageRight = ox + viewer.scaledBitmap.width;
               let imageBottom = oy + viewer.scaledBitmap.height;
               let shade = new Brush( 0x98000000 );
               graphics.fillRect( ox, oy, imageRight, top, shade );
               graphics.fillRect( ox, bottom, imageRight, imageBottom, shade );
               graphics.fillRect( ox, top, left, bottom, shade );
               graphics.fillRect( right, top, imageRight, bottom, shade );
               graphics.pen = new Pen( 0xff33aaff, 2 );
               graphics.drawLine( left, top, right, top );
               graphics.drawLine( right, top, right, bottom );
               graphics.drawLine( right, bottom, left, bottom );
               graphics.drawLine( left, bottom, left, top );


               let middleX = (left + right)/2;
               let middleY = (top + bottom)/2;
               let handles = [ [left, top], [middleX, top], [right, top],
                  [left, middleY], [right, middleY], [left, bottom],
                  [middleX, bottom], [right, bottom] ];
               for ( let h = 0; h < handles.length; ++h ) {


                  let hx = Math.range( Math.round( handles[h][0] ),
                     10, this.width - 11 );
                  let hy = Math.range( Math.round( handles[h][1] ),
                     10, this.height - 11 );
                  graphics.fillRect( hx - 9, hy - 9, hx + 10, hy + 10,
                     new Brush( 0xffffffff ) );
                  graphics.fillRect( hx - 6, hy - 6, hx + 7, hy + 7,
                     new Brush( 0xff087bd5 ) );
                  graphics.pen = new Pen( 0xff002f62, 2 );
                  graphics.drawRect( hx - 9, hy - 9, hx + 9, hy + 9 );
               }
            }
         }
      }
      graphics.end();
   };

   let controls = new HorizontalSizer;
   controls.spacing = 7;
   controls.addStretch();
   controls.add( this.previousButton );
   controls.add( this.zoomInButton );
   controls.add( this.fitButton );
   controls.add( this.zoomOutButton );
   controls.add( this.panButton );
   controls.add( this.cropToolButton );
   controls.add( this.consoleButton );
   controls.add( this.imageSolverButton );
   controls.add( this.colorCalibrationButton );
   controls.add( this.quickStretchLinkButton );
   controls.add( this.adaptiveButton );
   controls.add( this.processorButton );
   controls.add( this.editorButton );
   controls.add( this.restoreCropButton );
   controls.add( this.removeButton );
   controls.add( this.multiExposureButton );
   controls.add( this.nextButton );
   controls.addStretch();

   this.sizer = new VerticalSizer;
   this.sizer.spacing = 5;
   this.sizer.add( this.scrollBox, 100 );
   this.sizer.add( controls );
   this.updateButtons();
}
}

function StartPixelHasData( image, x, y )
{
   x = Math.range( Math.round( x ), 0, image.width - 1 );
   y = Math.range( Math.round( y ), 0, image.height - 1 );
   for ( let c = 0; c < image.numberOfChannels; ++c )
      if ( Math.abs( image.sample( x, y, c ) ) > 1.0e-12 )
         return true;
   return false;
}

function StartCellHasData( image, x0, y0, x1, y1 )
{
   let cx = Math.floor( (x0 + x1)/2 );
   let cy = Math.floor( (y0 + y1)/2 );


   let xs = [x0, cx, x1];
   let ys = [y0, cy, y1];
   for ( let yi = 0; yi < ys.length; ++yi )
      for ( let xi = 0; xi < xs.length; ++xi )
         if ( !StartPixelHasData( image, xs[xi], ys[yi] ) )
            return false;
   return true;
}

function StartLargestRectangle( mask, width, height )
{
   let heights = new Array( width );
   for ( let i = 0; i < width; ++i ) heights[i] = 0;
   let best = { left: 0, top: 0, right: -1, bottom: -1, area: 0 };
   for ( let y = 0; y < height; ++y ) {
      for ( let x = 0; x < width; ++x )
         heights[x] = mask[y*width + x] ? heights[x] + 1 : 0;
      let stack = [];
      for ( let x = 0; x <= width; ++x ) {
         let current = x < width ? heights[x] : 0;
         while ( stack.length > 0 &&
                 heights[stack[stack.length - 1]] > current ) {
            let position = stack.pop();
            let h = heights[position];
            let left = stack.length > 0 ? stack[stack.length - 1] + 1 : 0;
            let area = h*(x - left);
            if ( area > best.area )
               best = { left: left, top: y - h + 1, right: x - 1,
                  bottom: y, area: area };
         }
         stack.push( x );
      }
   }
   return best;
}

function StartIncompleteCombinationCoverage( series )
{
   let invalid = [];
   for ( let i = 0; i < series.length; ++i ) {
      let source = StartSeriesSourceEntry( series[i] );
      let window = series[i].window || series[i];
      if ( source == null || source.multiExposureSelected !== true ||
           window == null || window.isNull )
         continue;
      let image = window.mainView.image;
      let grid = 240;
      let complete = true;
      for ( let gy = 0; gy <= grid && complete; ++gy ) {
         let y = Math.round( (image.height - 1)*gy/grid );
         for ( let gx = 0; gx <= grid; ++gx ) {
            let x = Math.round( (image.width - 1)*gx/grid );
            if ( !StartPixelHasData( image, x, y ) ) {
               complete = false;
               break;
            }
         }
      }
      if ( !complete ) invalid.push( window.mainView.id );
   }
   return invalid;
}

function StartCommonCrop( series, safetyMargin )
{
   if ( series.length < 2 )
      throw new Error( "Register at least two images first." );
   let width = series[0].window.mainView.image.width;
   let height = series[0].window.mainView.image.height;
   let step = Math.max( 2, Math.ceil( Math.max( width, height )/480 ) );
   let gridWidth = Math.ceil( width/step );
   let gridHeight = Math.ceil( height/step );
   let mask = new Array( gridWidth*gridHeight );
   for ( let gy = 0; gy < gridHeight; ++gy ) {
      CoreApplication.processEvents();
      let y0 = gy*step;
      let y1 = Math.min( height - 1, (gy + 1)*step - 1 );
      for ( let gx = 0; gx < gridWidth; ++gx ) {
         let x0 = gx*step;
         let x1 = Math.min( width - 1, (gx + 1)*step - 1 );
         let valid = true;
         for ( let i = 0; i < series.length && valid; ++i )
            valid = StartCellHasData( series[i].window.mainView.image,
               x0, y0, x1, y1 );
         mask[gy*gridWidth + gx] = valid;
      }
   }
   let gridRect = StartLargestRectangle( mask, gridWidth, gridHeight );
   if ( gridRect.area <= 0 )
      throw new Error( "No common image area was detected." );
   let inset = step + safetyMargin;
   let x = gridRect.left*step + inset;
   let y = gridRect.top*step + inset;
   let right = Math.min( width, (gridRect.right + 1)*step ) - inset;
   let bottom = Math.min( height, (gridRect.bottom + 1)*step ) - inset;
   if ( right - x < 64 || bottom - y < 64 )
      throw new Error( "The detected common area is too small." );
   return { x: x, y: y, width: right - x, height: bottom - y,
      sourceWidth: width, sourceHeight: height,
      coverage: 100*(right - x)*(bottom - y)/(width*height), step: step };
}

function StartApplyCropToCopy( source, rectangle )
{
   if ( source == null || source.isNull || source.mainView.isNull )
      throw new Error( "The crop source image is no longer available." );
   let image = source.mainView.image;
   let sourceWidth = Math.max( 1, rectangle.sourceWidth );
   let sourceHeight = Math.max( 1, rectangle.sourceHeight );
   let x = Math.round( rectangle.x*image.width/sourceWidth );
   let y = Math.round( rectangle.y*image.height/sourceHeight );
   let width = Math.round( rectangle.width*image.width/sourceWidth );
   let height = Math.round( rectangle.height*image.height/sourceHeight );
   x = Math.range( x, 0, image.width - 1 );
   y = Math.range( y, 0, image.height - 1 );
   width = Math.range( width, 1, image.width - x );
   height = Math.range( height, 1, image.height - y );
   if ( width < 64 || height < 64 )
      throw new Error( "The crop rectangle is outside the source image." );


   let output = StartCloneWindow( source,
      source.mainView.id + InNovaStartCropSuffix, false );
   let crop = new Crop;
   crop.leftMargin = -x;
   crop.topMargin = -y;
   crop.rightMargin = -(image.width - x - width);
   crop.bottomMargin = -(image.height - y - height);
   crop.mode = 1;
   crop.forceResolution = false;
   crop.noGUIMessages = true;
   if ( !crop.executeOn( output.mainView ) ) {
      output.forceClose();
      throw new Error( "Crop failed for " + source.mainView.id + "." );
   }
   return output;
}

class InNovaStartDialog extends Dialog
{
constructor( guidedWorkflow )
{
   super();
   let self = this;
   this.guidedWorkflow = guidedWorkflow !== false;
   this.unifiedBridgeWindow = true;
   this.preparationFinished = false;
   this.entries = [];
   this.registeredSeries = [];
   this.croppedSeries = [];
   this.integrationSeries = [];
   this.hdrSeries = [];
   this.multiExposureConfigured = false;
   this.combinationPreviewGenerated = false;
   this.combinationChoiceConfirmed = false;


   this.multiExposureCropRequired = false;
   this.multiExposureManualCropStarted = false;
   this.multiExposureSynchronizedCropAccepted = false;
   this.multiNightSaveOffered = false;
   this.combineDifferentFilters = false;
   this.autoBrightTarget = false;
   this.lastRegistrationFailure = "";
   this.cropRectangle = null;
   this.referenceId = "";
   this.windowTitle = "🔭 InNova Multi-Night — " + InNovaStartVersion +
      " — " + _0x88bfe5ab4a();
   this.minWidth = 650;
   this.userResizable = true;

   this.clearDerivedSeries = function()
   {
      let sourceEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true )
            sourceEntries.push( self.entries[i] );
      self.entries = sourceEntries;
      StartCloseSeriesWindows( self.integrationSeries );
      StartCloseSeriesWindows( self.hdrSeries );
      self.integrationSeries = [];
      self.hdrSeries = [];
   };

   this.buildViewerSeries = function( baseSeries, baseLabel )
   {


      if ( self.imageViewer != null ) {
         self.imageViewer.series = [];
         self.imageViewer.index = -1;
         self.imageViewer.bitmap = null;
         self.imageViewer.scaledBitmap = null;
         self.imageViewer.cropSelection = null;
         self.imageViewer.cropMode = false;
         self.imageViewer.cropEditMode = false;
         self.imageViewer.cropStart = null;
         self.imageViewer.cropDrag = null;
         self.imageViewer.scrolling = null;
      }
      self.clearDerivedSeries();


      if ( self.multiExposureConfigured &&
           self.combinationPreviewGenerated &&
           self.acquisitionCombo.currentItem == 1 )
         self.integrationSeries = StartCreateIntegrationSeries( baseSeries,
            self.combineDifferentFilters );
      if ( self.multiExposureConfigured &&
           self.combinationPreviewGenerated &&
           self.acquisitionCombo.currentItem == 2 )
         self.hdrSeries = StartCreateHDRSeries( baseSeries );
      let result = baseSeries.concat( self.integrationSeries ).concat(
         self.hdrSeries );
      let label = baseLabel;
      if ( self.integrationSeries.length > 0 ) label += " + integration";
      if ( self.hdrSeries.length > 0 ) label += " + HDR";
      return { series: result, label: label };
   };

   this.bridgeHeader = StartBridgeHeader(this, true, this.guidedWorkflow);

   function savedSetting( key, fallback )
   {
      let value = Settings.read( key, DataType_String );
      return Settings.lastReadOK && typeof value == "string" ? value : fallback;
   }

   this.projectGroup = new GroupBox( this );
   this.projectGroup.title = "Project";
   this.projectCombo = new ComboBox( this.projectGroup );
   let projectItems = [ "LRGB", "RGB", "SHO", "HOO",
      "OSC (RGB Color camera .xisf or Raw)", "SEESTAR (.fit)",
      "VAONIS VESPERA (.tiff)" ];
   let projectValues = [ "LRGB", "RGB", "SHO", "HOO", "OSC",
      "SEESTAR", "VAONIS_VESPERA" ];
   for ( let i = 0; i < projectItems.length; ++i )
      this.projectCombo.addItem( projectItems[i] );
   let savedProject = savedSetting( InNovaHandoffProjectSetting, "OSC" );
   this.projectCombo.currentItem = Math.max( 0,
      projectValues.indexOf( savedProject ) );
   this.projectCombo.toolTip =
      "Select the same project type used by InNova Astro Processor.";
   this.projectGroup.sizer = new VerticalSizer;
   this.projectGroup.sizer.margin = 7;
   this.projectGroup.sizer.add( this.projectCombo );
   this.projectGroup.visible = false;

   this.acquisitionGroup = new GroupBox( this );
   this.acquisitionGroup.title = "Acquisition";
   this.acquisitionCombo = new ComboBox( this.acquisitionGroup );
   let acquisitionItems = [ "One single night", "Multi-night",
      "HDR (High Dynamic Range)" ];
   let acquisitionValues = [ "SINGLE_NIGHT", "MULTI_NIGHT", "HDR" ];
   for ( let i = 0; i < acquisitionItems.length; ++i )
      this.acquisitionCombo.addItem( acquisitionItems[i] );


   this.acquisitionCombo.currentItem = 0;
   this.acquisitionCombo.toolTip =
      "Choose whether the images come from one night, multiple nights, or " +
      "multiple exposure levels for a high dynamic range composition.";
   this.acquisitionGroup.sizer = new VerticalSizer;
   this.acquisitionGroup.sizer.margin = 7;
   this.acquisitionGroup.sizer.add( this.acquisitionCombo );
   this.acquisitionGroup.visible = false;

   this.objectGroup = new GroupBox( this );
   this.objectGroup.title = "Object type";
   this.objectCombo = new ComboBox( this.objectGroup );
   this.objectCombo.addItem( "Nebula or Galaxy" );
   this.objectCombo.addItem( "Sun or Moon" );


   this.objectCombo.currentItem = 0;
   this.objectCombo.toolTip =
      "Nebula or Galaxy uses stellar registration and astrometry. Sun or " +
      "Moon uses the bright-target workflow.";
   this.objectGroup.sizer = new VerticalSizer;
   this.objectGroup.sizer.margin = 7;
   this.objectGroup.sizer.add( this.objectCombo );
   this.objectGroup.visible = false;

   this.selectionRow = new HorizontalSizer;
   this.selectionRow.spacing = 9;
   this.selectionRow.add( this.projectGroup, 100 );

   this.saveHandoffSelections = function()
   {
      Settings.write( InNovaHandoffProjectSetting, DataType_String,
         projectValues[self.projectCombo.currentItem] );
      Settings.write( InNovaHandoffAcquisitionSetting, DataType_String,
         acquisitionValues[self.acquisitionCombo.currentItem] );
      Settings.write( InNovaHandoffObjectSetting, DataType_String,
         self.objectCombo.currentItem == 1 ? "MOON_SUN" : "STARS" );
   };
   this.projectCombo.onItemSelected = function() { self.saveHandoffSelections(); };
   this.acquisitionCombo.onItemSelected = function() { self.saveHandoffSelections(); };
   this.objectCombo.onItemSelected = function() { self.saveHandoffSelections(); };

   this.imagesGroup = new GroupBox( this );
   this.imagesGroup.title = "Images";
   this.imagesTree = new TreeBox( this.imagesGroup );
   this.imagesTree.numberOfColumns = 10;
   this.imagesTree.headerVisible = true;
   this.imagesTree.rootDecoration = false;
   this.imagesTree.multipleSelection = true;
   this.imagesTree.alternateRowColor = true;
   this.imagesTree.setHeaderText( 0, "Use" );
   this.imagesTree.setHeaderText( 1, "Combine" );
   this.imagesTree.setHeaderText( 2, "Image" );
   this.imagesTree.setHeaderText( 3, "Exposure" );
   this.imagesTree.setHeaderText( 4, "Filter" );
   this.imagesTree.setHeaderText( 5, "Camera" );
   this.imagesTree.setHeaderText( 6, "Geometry" );
   this.imagesTree.setHeaderText( 7, "Quality" );
   this.imagesTree.setHeaderText( 8, "Project check" );
   this.imagesTree.setHeaderText( 9, "Reference" );
   this.imagesTree.setColumnWidth( 0, 38 );
   this.imagesTree.setColumnWidth( 1, 65 );
   this.imagesTree.setColumnWidth( 2, 190 );
   this.imagesTree.setColumnWidth( 3, 80 );
   this.imagesTree.setColumnWidth( 4, 70 );
   this.imagesTree.setColumnWidth( 5, 130 );
   this.imagesTree.setColumnWidth( 6, 110 );
   this.imagesTree.setColumnWidth( 7, 70 );
   this.imagesTree.setColumnWidth( 8, 180 );
   this.imagesTree.setColumnWidth( 9, 70 );
   this.imagesTree.setScaledMinSize( 620, 330 );

   this.inputViewerGroup = new GroupBox( this.imagesGroup );
   this.inputViewerGroup.title = "Preview";
   this.inputPreview = new StartSubframePreviewControl(
      this.inputViewerGroup, 430, 330 );
   this.inputViewerGroup.sizer = new VerticalSizer;
   this.inputViewerGroup.sizer.margin = 7;
   this.inputViewerGroup.sizer.add( this.inputPreview, 100 );

   let inputReviewRow = new HorizontalSizer;
   inputReviewRow.spacing = 10;


   inputReviewRow.add( this.imagesTree, 135 );
   inputReviewRow.add( this.inputViewerGroup, 100 );


   this.imageToolbar = new Control( this.imagesGroup );
   this.imageToolbar.setScaledFixedHeight( 44 );
   this.arrangeButton = new ToolButton( this.imageToolbar );
   this.arrangeButton.icon = this.scaledResource( ":/icons/windows.png" );
   this.arrangeButton.setScaledFixedSize( 28, 28 );
   this.arrangeButton.toolTip = "Minimize open images (Window > Arrange Icons organizes their icons)";
   this.arrangeButton.onClick = function()
   {
      MiraPrepareWorkspaceForRun( self );
      self.bringToFront();
   };
   this.loadButton = new ToolButton( this.imageToolbar );
   this.loadButton.icon = this.scaledResource( ":/icons/folder-open.png" );
   this.loadButton.setScaledFixedSize( 28, 28 );
   this.loadButton.toolTip = "Load images from disk";
   this.subframeMastersButton = new ToolButton( this.imageToolbar );
   this.subframeMastersButton.icon = this.scaledResource(":/icons/documents-import.png");
   this.subframeMastersButton.setScaledFixedSize( 28, 28 );
   this.subframeMastersButton.toolTip =
      "Load master images saved by InNova Subframe Review & Integration\n" +
      "Documents/InNova/Sub master files";
   this.refreshButton = new ToolButton( this.imageToolbar );
   this.refreshButton.icon = InNovaEditorRefreshIcon();
   this.refreshButton.setScaledFixedSize( 28, 28 );
   this.refreshButton.toolTip = "Refresh the list of open PixInsight images";
   this.clearButton = new ToolButton( this.imageToolbar );
   this.clearButton.icon = this.scaledResource( ":/icons/trash.png" );
   this.clearButton.setScaledFixedSize( 28, 28 );
   this.clearButton.toolTip =
      "Remove the selected image from the list";
   this.inputZoomInButton = new ToolButton( this.imageToolbar );
   this.inputZoomInButton.icon = this.scaledResource( ":/icons/zoom-in.png" );
   this.inputZoomInButton.setScaledFixedSize( 28, 28 );
   this.inputZoomInButton.toolTip = "Zoom+ · Zoom in on the preview";
   this.inputZoomInButton.enabled = false;
   this.inputPanButton = new ToolButton( this.imageToolbar );
   this.inputPanButton.text = "✋";
   this.inputPanButton.setScaledFixedSize( 30, 30 );
   this.inputPanButton.checkable = true;
   this.inputPanButton.checked = true;
   this.inputPanButton.toolTip =
      "Pan · Drag to move the zoomed image";
   this.inputPanButton.enabled = false;
   this.inputZoomOutButton = new ToolButton( this.imageToolbar );
   this.inputZoomOutButton.icon = this.scaledResource( ":/icons/zoom-out.png" );
   this.inputZoomOutButton.setScaledFixedSize( 28, 28 );
   this.inputZoomOutButton.toolTip = "Zoom− · Zoom out of the preview";
   this.inputZoomOutButton.enabled = false;
   this.inputQuickStretchLinked = null;
   this.inputQuickStretchToggleAvailable = false;
   this.inputQuickStretchLinkButton = new ToolButton( this.imageToolbar );
   this.inputQuickStretchLinkButton.icon = StartQuickStretchLinkIcon( true );
   this.inputQuickStretchLinkButton.setScaledFixedSize( 32, 32 );
   this.inputQuickStretchLinkButton.toolTip =
      "Unlink RGB channels and recalculate Quick Stretch";
   this.inputQuickStretchLinkButton.enabled = false;
   this.updateInputQuickStretchLinkButton = function()
   {
      self.inputQuickStretchLinkButton.icon =
         StartQuickStretchLinkIcon( self.inputQuickStretchLinked !== true );
      self.inputQuickStretchLinkButton.toolTip =
         self.inputQuickStretchLinked === true ?
         "RGB channels: Linked · Click to unlink and recalculate Quick Stretch" :
         "RGB channels: Unlinked · Click to link and recalculate Quick Stretch";
   };
   this.inputCombineButton = new ToolButton( this.imageToolbar );
   this.inputCombineButton.icon = StartMultiExposureIcon();
   this.inputCombineButton.setScaledFixedSize( 32, 32 );
   this.inputCombineButton.checkable = true;
   this.inputCombineButton.enabled = false;
   this.inputCombineButton.toolTip =
      "Add the selected source image to the multi-night combination and advance to the next image";
   this.inputCropButton = new ToolButton( this.imageToolbar );
   this.inputCropButton.icon = StartCropIcon();
   this.inputCropButton.setScaledFixedSize( 32, 32 );
   this.inputCropButton.checkable = true;
   this.inputCropButton.enabled = false;
   this.inputCropButton.toolTip =
      "Apply the automatic common crop to the prepared image copies";
   this.inputResetBridgeButton = new ToolButton( this.imageToolbar );
   this.inputResetBridgeButton.icon =
      this.scaledResource( ":/icons/reload.png" );
   this.inputResetBridgeButton.setScaledFixedSize( 28, 28 );
   this.inputResetBridgeButton.enabled = false;
   this.inputResetBridgeButton.toolTip =
      "Reset Multi-Night and return to the original input images";
   this.cleanOutputsButton = new ToolButton( this.imageToolbar );
   this.cleanOutputsButton.icon = this.scaledResource( ":/icons/delete.png" );
   this.cleanOutputsButton.setScaledFixedSize( 32, 32 );
   this.cleanOutputsButton.toolTip =
      "Close generated registration, integration, crop and HDR results, but keep the original input images";
   this.runButton = new PushButton( this.imageToolbar );
   this.runButton.text = "Run";
   this.runButton.icon = this.scaledResource( ":/icons/play.png" );
   this.runButton.defaultButton = true;
   this.runButton.toolTip =
      "Register and combine the selected multi-night images:\n" +
      "• inspect exposure, filter, camera, geometry and acquisition date;\n" +
      "• validate the selected multi-night group;\n" +
      "• detect auxiliary or potentially unrelated images;\n" +
      "• estimate quality and select the best reference from the dominant geometry;\n" +
      "• register non-reference images with StarAlignment;\n" +
      "• combine the registered copies with normalized SNR weighting;\n" +
      "• preserve every original image unchanged.";

   this.consoleButton = new ToolButton( this.imageToolbar );
   this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
   this.consoleButton.setScaledFixedSize( 28, 28 );
   this.consoleButton.toolTip = "Show the PixInsight Process Console";

   this.closeButton = new PushButton( this.imageToolbar );
   this.closeButton.text = "Close";
   this.closeButton.icon = this.scaledResource( ":/icons/close.png" );

   let imageButtons = new HorizontalSizer;
   imageButtons.spacing = 8;
   imageButtons.add( this.consoleButton );
   imageButtons.add( this.arrangeButton );
   imageButtons.add( this.loadButton );
   imageButtons.add( this.subframeMastersButton );
   imageButtons.add( this.refreshButton );
   imageButtons.add( this.cleanOutputsButton );
   imageButtons.add( this.clearButton );
   imageButtons.add( this.inputZoomInButton );
   imageButtons.add( this.inputPanButton );
   imageButtons.add( this.inputZoomOutButton );
   imageButtons.add( this.inputQuickStretchLinkButton );
   imageButtons.add( this.inputCombineButton );
   imageButtons.add( this.inputCropButton );
   imageButtons.add( this.inputResetBridgeButton );
   imageButtons.addStretch();
   imageButtons.add( this.runButton );
   imageButtons.add( this.closeButton );
   this.imageToolbar.sizer = imageButtons;
   this.imageToolbar.sizer.margin = 4;
   this.imagesGroup.setScaledMinHeight( 430 );
   this.imagesGroup.sizer = new VerticalSizer;
   this.imagesGroup.sizer.margin = 8;
   this.imagesGroup.sizer.spacing = 7;
   this.imagesGroup.sizer.add( inputReviewRow, 100 );
   this.imagesGroup.sizer.addSpacing( 10 );
   this.imagesGroup.sizer.add( this.imageToolbar );

   this.reviewDialog = new Dialog;
   this.reviewDialog.windowTitle =
      "🔭 InNova Multi-Night";
   this.reviewDialog.userResizable = true;

   this.reviewHeader = StartBridgeHeader(this.reviewDialog);

   this.viewerGroup = new GroupBox( this.reviewDialog );
   this.viewerGroup.title = "Image Viewer";
   this.imageInformationGroup = new GroupBox( this.reviewDialog );
   this.imageInformationGroup.title = "Image: 0 / 0";
   this.reviewInformationPanel = new Frame( this.reviewDialog );
   this.reviewInformationPanel.frameStyle = FrameStyle_Box;
   this.imageViewer = new InNovaStartImageViewer( this.viewerGroup,
      this.imageInformationGroup, this.reviewInformationPanel );


   this.latestPreparedByInputId = {};
   this.rememberLatestPrepared = function( inputItem, outputItem )
   {
      let inputWindow = inputItem != null ? (inputItem.window || inputItem) : null;
      let outputWindow = outputItem != null ? (outputItem.window || outputItem) : null;
      if ( inputWindow == null || inputWindow.isNull ||
           inputWindow.mainView == null || inputWindow.mainView.isNull ||
           outputWindow == null || outputWindow.isNull ||
           outputWindow.mainView == null || outputWindow.mainView.isNull ) return;
      self.latestPreparedByInputId[inputWindow.mainView.id] = outputItem;
   };
   this.resolveLatestPrepared = function( item )
   {
      let resolved = item;
      let visited = {};
      for ( ;; ) {
         let window = resolved != null ? (resolved.window || resolved) : null;
         if ( window == null || window.isNull || window.mainView == null ||
              window.mainView.isNull ) return item;
         let id = window.mainView.id;
         if ( visited[id] || self.latestPreparedByInputId[id] == null )
            return resolved;
         visited[id] = true;
         let candidate = self.latestPreparedByInputId[id];
         let candidateWindow = candidate.window || candidate;
         if ( candidateWindow == null || candidateWindow.isNull ||
              candidateWindow.mainView == null || candidateWindow.mainView.isNull ) {
            delete self.latestPreparedByInputId[id];
            return resolved;
         }
         resolved = candidate;
      }
   };
   this.resolveLatestPreparedSeries = function( series )
   {
      let resolved = [];
      for ( let i = 0; i < series.length; ++i )
         resolved.push( self.resolveLatestPrepared( series[i] ) );
      return resolved;
   };
   this.resolveLatestProcessorPrepared = function( item )
   {
      let resolved = self.resolveLatestPrepared( item );


      while ( resolved != null && resolved.alreadyStretched === true &&
              resolved.source != null )
         resolved = resolved.source;
      return resolved;
   };
   this.resolveLatestProcessorSeries = function( series )
   {
      let resolved = [];
      for ( let i = 0; i < series.length; ++i )
         resolved.push( self.resolveLatestProcessorPrepared( series[i] ) );
      return resolved;
   };
   this.imageViewer.onModuleResultShown = function( inputItem, outputItem )
   {
      self.rememberLatestPrepared( inputItem, outputItem );
   };
   this.imageViewer.adaptiveAccessEnabled = !this.guidedWorkflow;
   this.imageViewer.onConsoleRequested = function()
   {
      if ( self.consoleIsVisible ) self.hideProcessConsole();
      else self.showProcessConsole();
   };
   this.stretchedEditorSources = {};
   let runAdaptiveNow = function( window, skipConfirmation )
   {
      if ( self.guidedWorkflow ) return null;
      if ( skipConfirmation !== true &&
           StartAskCenteredQuestion( "InNova Adaptive Stretch",
           "Would you like to open InNova Adaptive Stretch?", true,
           "InNova Adaptive Stretch" ) != StdButton_Yes )
         return null;
      let mainPosition = MiraParkIntegratorForAdaptiveStretch(self);
      let reviewPosition = MiraParkIntegratorForAdaptiveStretch(self.reviewDialog);
      let resultWindow = null;
      try {
         window.bringToFront();
         let stretched = StartRunAdaptiveEmbedded();
         if ( stretched && stretched.window && !stretched.window.isNull ) {
            resultWindow = stretched.window;
            self.stretchedEditorSources[stretched.sourceId] = stretched.window;
            self.stretchedEditorSources[stretched.window.mainView.id] = stretched.window;
            self.imageViewer.showModuleResult(stretched.window, stretched.sourceId);
         }
      } catch ( error ) {
         new MessageBox( "InNova Adaptive Stretch could not be opened.\n\n" + error,
            "🔭 InNova Multi-Night", StdIcon_Error, StdButton_Ok ).execute();
      } finally {
         self.hideProcessConsole();


         if (mainPosition) self.position = mainPosition;
         MiraRestoreIntegratorAfterAdaptiveStretch(self.reviewDialog, reviewPosition);
         self.imageViewer.updateButtons();
      }
      return resultWindow;
   };
   this.imageViewer.onAdaptiveRequested = runAdaptiveNow;
   this.pendingSpccReport = null;
   this.imageViewer.onColorCalibrationRequested = function( window, item )
   {
      if ( self.guidedWorkflow ) return;
      self.imageViewer.colorCalibrationButton.enabled = false;
      self.beginElapsed( "Preparing SPCC color calibration…", true );
      let completed = false;
      try {
         let deferredReport = {};
         let calibrated = StartRunSpccCopy( window, item, function( message ) {
            self.updateElapsed( message );
         }, deferredReport );
         if ( calibrated != null && !calibrated.isNull ) {
            self.pendingSpccReport = deferredReport;
            self.imageViewer.showModuleResult( calibrated,
               window.mainView.id, false );
            completed = true;
         }
      } finally {
         let elapsed = self.finishElapsed();
         let result = completed ? "<b>SPCC completed.</b>" :
            "SPCC was not completed.";
         result += "  " + StartElapsedRichText( elapsed );
         self.status.text = result;
         self.reviewStatus.text = result;
         self.hideProcessConsole();
         self.imageViewer.updateButtons();
      }
   };
   this.imageViewer.onImageSolverRequested = function( window, item )
   {
      if ( self.guidedWorkflow ) return;
      self.imageViewer.imageSolverButton.enabled = false;
      self.beginElapsed( "Running ImageSolver…", true );
      let completed = false;
      try {
         if ( StartRunImageSolver( window, item, function( message ) {
            self.updateElapsed( message );
         } ) ) {
            self.imageViewer.showCurrent();
            completed = true;
         }
      } finally {
         let elapsed = self.finishElapsed();
         let result = completed ? "<b>ImageSolver completed.</b>" :
            "ImageSolver was not completed.";
         result += "  " + StartElapsedRichText( elapsed );
         self.status.text = result;
         self.reviewStatus.text = result;
         self.hideProcessConsole();
         self.imageViewer.updateButtons();
      }
   };
   this.imageViewer.onProcessorRequested = function( window )
   {
      if (self.guidedWorkflow) return;
      let selected = [];
      for ( let i = 0; i < self.imageViewer.series.length; ++i ) {
         let item = self.imageViewer.series[i];
         let itemWindow = item.window || item;
         if ( itemWindow != null && !itemWindow.isNull &&
              !itemWindow.mainView.isNull &&
              itemWindow.mainView.id == window.mainView.id ) {
            let latest = self.resolveLatestPrepared( item );
            let processorSource = self.resolveLatestProcessorPrepared( item );
            let latestWindow = latest.window || latest;
            let processorWindow = processorSource.window || processorSource;
            if ( latest.alreadyStretched === true &&
                 latestWindow.mainView.id != processorWindow.mainView.id ) {
               let answer = StartAskCenteredQuestion(
                  "InNova Multi-Night — Linear image required",
                  "The selected image is already stretched and cannot be " +
                  "sent to InNova Astro Processor.\n\nWould you like to use " +
                  "the latest linear prepared image instead?\n" +
                  processorWindow.mainView.id,
                  true, processorWindow.mainView.id );
               if ( answer != StdButton_Yes ) return;
            }
            selected.push( processorSource );
            break;
         }
      }
      if ( selected.length == 0 ) {
         let latest = self.resolveLatestPrepared( window );
         let processorSource = self.resolveLatestProcessorPrepared( window );
         let latestWindow = latest.window || latest;
         let processorWindow = processorSource.window || processorSource;
         if ( latest.alreadyStretched === true &&
              latestWindow.mainView.id != processorWindow.mainView.id ) {
            let answer = StartAskCenteredQuestion(
               "InNova Multi-Night — Linear image required",
               "The selected image is already stretched and cannot be sent " +
               "to InNova Astro Processor.\n\nWould you like to use the " +
               "latest linear prepared image instead?\n" +
               processorWindow.mainView.id,
               true, processorWindow.mainView.id );
            if ( answer != StdButton_Yes ) return;
         }
         selected.push( processorSource );
      }
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return;
      }
      if (StartAskCenteredQuestion("InNova Astro Processor",
         "Would you like to open InNova Astro Processor now?", true,
         "InNova Astro Processor") != StdButton_Yes) return;
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new MessageBox(
            "The selected image channel could not be identified. Check " +
            "its Filter or Bayer metadata.",
            "🔭 InNova Multi-Night — Channel not identified",
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }

      let handoffWindow = selected[0].window || selected[0];
      self.processorReturnSourceId = handoffWindow.mainView.id;
      self.processorDirectLaunchRequested = true;
      self.reviewNavigation = "processor";
      self.reviewDialog.ok();
   };
   let runEditorNow = function( window, stretched, skipConfirmation )
   {
      if ( self.guidedWorkflow ) return null;
      if ( skipConfirmation !== true &&
           StartAskCenteredQuestion( "InNova Photo Editor",
           "Would you like to open InNova Photo Editor?", true,
           "InNova Photo Editor" ) != StdButton_Yes )
         return null;
      let mainPosition = MiraParkIntegratorForAdaptiveStretch(self);
      let reviewPosition = MiraParkIntegratorForAdaptiveStretch(self.reviewDialog);
      let resultWindow = null;
      try {
         let edited = StartRunEditorEmbedded(stretched);
         if ( edited && !edited.isNull ) {
            resultWindow = edited;
            self.stretchedEditorSources[window.mainView.id] = edited;
            self.stretchedEditorSources[stretched.mainView.id] = edited;
            self.stretchedEditorSources[edited.mainView.id] = edited;
            self.imageViewer.showModuleResult(edited, window.mainView.id);
         }
      } catch ( error ) {
         new MessageBox( "InNova Photo Editor could not be opened.\n\n" + error,
            "🔭 InNova Multi-Night", StdIcon_Error, StdButton_Ok ).execute();
      } finally {
         self.hideProcessConsole();
         if (mainPosition) self.position = mainPosition;
         MiraRestoreIntegratorAfterAdaptiveStretch(self.reviewDialog, reviewPosition);
         self.imageViewer.updateButtons();
      }
      return resultWindow;
   };
   this.imageViewer.onEditorRequested = function( window )
   {
      if ( self.guidedWorkflow ) return;
      let stretched = self.stretchedEditorSources[window.mainView.id];
      if ( !stretched || stretched.isNull ) {
         if ( StartAskCenteredQuestion(
              "InNova Adaptive Stretch",
              "This image has not been stretched yet.\n\n" +
              "Would you like to run InNova Adaptive Stretch now?",
              true, "InNova Adaptive Stretch" ) != StdButton_Yes )
            return;


         stretched = runAdaptiveNow( window, true );
         if ( !stretched || stretched.isNull ) return;
         runEditorNow( window, stretched, true );
         return;
      }
      runEditorNow( window, stretched, false );
   };
   this.viewerGroup.sizer = new VerticalSizer;
   this.viewerGroup.sizer.margin = 8;
   this.viewerGroup.sizer.add( this.imageViewer, 100 );
   this.imageInformationGroup.sizer = new VerticalSizer;
   this.imageInformationGroup.sizer.margin = 8;
   this.imageInformationGroup.sizer.spacing = 4;
   this.imageInformationGroup.sizer.add( this.imageViewer.fileLabel );
   this.imageInformationGroup.sizer.add( this.imageViewer.exifLabel );
   this.imageViewer.onRemoveRequested = function( item, viewerIndex, confirmed )
   {
      let window = item.window || item;
      if ( confirmed !== true ) {
         let answer = StartAskCenteredQuestion(
            "🔭 InNova Multi-Night — Remove selected images",
            "Do you want to remove the selected images from the list?", true );
         if ( answer != StdButton_Yes ) return;
      }

      let sourceEntry = item;
      while ( sourceEntry != null && sourceEntry.source != null )
         sourceEntry = sourceEntry.source;

      let keptEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i] !== sourceEntry )
            keptEntries.push( self.entries[i] );
      self.entries = keptEntries;
      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;

      let keptRegistered = [];
      for ( let i = 0; i < self.registeredSeries.length; ++i )
         if ( self.registeredSeries[i].source !== sourceEntry )
            keptRegistered.push( self.registeredSeries[i] );
      self.registeredSeries = keptRegistered;

      let keptCropped = [];
      for ( let i = 0; i < self.croppedSeries.length; ++i ) {
         let croppedSource = self.croppedSeries[i];
         while ( croppedSource != null && croppedSource.source != null )
            croppedSource = croppedSource.source;
         if ( croppedSource !== sourceEntry )
            keptCropped.push( self.croppedSeries[i] );
      }
      self.croppedSeries = keptCropped;

      if ( sourceEntry != null && sourceEntry.id == self.referenceId )
         self.referenceId = "";
      self.updateTree();
      let showingCropped = self.imageViewer.seriesLabel.indexOf(
         "Cropped images" ) == 0;
      let remaining = showingCropped ?
         self.croppedSeries : self.registeredSeries;
      let rebuilt = self.buildViewerSeries( remaining,
         showingCropped ? "Cropped images" : "Registered images" );
      self.imageViewer.setSeries( rebuilt.series, rebuilt.label, viewerIndex );
      let enoughRegistered = self.registeredSeries.length >= 2;
      self.autoCropButton.enabled = enoughRegistered;
      self.cropButton.enabled = enoughRegistered;
      self.runButton.enabled = self.entries.length > 0;
      let removalStatus = "Removed <b>" + window.mainView.id +
         "</b> from the InNova Multi-Night project and image sequence. " +
         "The PixInsight image remains open and unchanged.";
      self.status.text = removalStatus;
      self.reviewStatus.text = removalStatus;
   };

   this.imageViewer.onMultiExposureRequested = function( item, selected )
   {
      if ( item == null || item.kind == "HDR" ||
           item.kind == "INTEGRATION" ) return;
      let source = item;
      while ( source != null && source.source != null ) source = source.source;
      if ( source == null ) return;
      let window = item.window || item;

      if ( selected && !self.multiExposureConfigured ) {
         let dialog = new StartMultiExposureDialog(
            self.acquisitionCombo.currentItem,
            [ window.mainView.id ], false );
         if ( dialog.execute() != StdDialogCode_Ok ) {
            source.multiExposureSelected = false;
            self.imageViewer.updateInformation();
            return;
         }
         self.multiExposureConfigured = true;
         self.saveHandoffSelections();
      }

      source.multiExposureSelected = selected === true;


      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;
      let selectedCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].multiExposureSelected === true ) ++selectedCount;
      if ( selectedCount == 0 ) {
         self.multiExposureConfigured = false;
         self.acquisitionCombo.currentItem = 0;
      }

      self.combinationPreviewGenerated = false;
      self.updateReviewNextButton();
      self.clearDerivedSeries();
      let showingCropped = self.imageViewer.seriesLabel.indexOf(
         "Cropped images" ) == 0;
      let baseSeries = showingCropped && self.croppedSeries.length > 0 ?
         self.croppedSeries : self.registeredSeries;
      let preferredIndex = self.imageViewer.index;
      self.imageViewer.setSeries( baseSeries,
         showingCropped ? "Cropped images" : "Registered images",
         preferredIndex );
      self.updateTree();

      let treatment = self.acquisitionCombo.currentItem == 2 ? "HDR" :
         "Multi-night";
      let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
      let selectionStatus = selectedCount == 0 ?
         "Multi-exposure selection cleared." :
         "<b style=\"color:#d97800\">" + treatment +
         " selection:</b> " + selectedCount + " image(s) selected. " +
         (selectedCount < required ?
            "Select at least " + required + " images." :
            "Click Run to register and combine the selected images.");
      self.status.text = selectionStatus;
      self.reviewStatus.text = selectionStatus;
   };

   this.cropGroup = new GroupBox( this.reviewDialog );
   this.cropGroup.title = "Crop";
   this.marginLabel = new Label( this.cropGroup );
   this.marginLabel.text = "Safety margin:";
   this.marginSpin = new SpinBox( this.cropGroup );
   this.marginSpin.minValue = 0;
   this.marginSpin.maxValue = 256;
   this.marginSpin.value = 12;
   this.marginSpin.suffix = " px";
   this.autoCropButton = new PushButton( this.cropGroup );
   this.autoCropButton.text = "Auto common crop";
   this.autoCropButton.enabled = false;
   this.cropButton = new PushButton( this.cropGroup );
   this.cropButton.text = "Crop";
   this.cropButton.enabled = false;
   this.cropButton.toolTip =
      "Draw a rectangle on the image. The area inside is kept; the shaded area outside is cropped.";
   this.applyCropButton = new PushButton( this.cropGroup );
   this.applyCropButton.text = "Apply to registered copies";
   this.applyCropButton.enabled = false;
   this.cropValueLabel = new Label( this.cropGroup );
   this.cropValueLabel.useRichText = true;
   this.cropValueLabel.wordWrapping = true;
   this.cropValueLabel.text =
      "Click Crop, then drag over the image to select the area to keep.";
   let cropRow = new HorizontalSizer;
   cropRow.spacing = 7;
   cropRow.add( this.marginLabel );
   cropRow.add( this.marginSpin );
   cropRow.addSpacing( 10 );
   cropRow.add( this.autoCropButton );
   cropRow.addSpacing( 10 );
   cropRow.add( this.cropButton );
   cropRow.add( this.applyCropButton );
   cropRow.addStretch();
   this.cropGroup.sizer = new VerticalSizer;
   this.cropGroup.sizer.margin = 8;
   this.cropGroup.sizer.spacing = 7;
   this.cropGroup.sizer.add( cropRow );
   this.cropGroup.sizer.add( this.cropValueLabel );
   this.cropGroup.visible = false;


   this.reviewStatus = this.imageViewer.footer;
   this.reviewInformationPanel.sizer = new VerticalSizer;
   this.reviewInformationPanel.sizer.margin = 7;
   this.reviewInformationPanel.sizer.spacing = 0;
   this.reviewInformationPanel.sizer.add( this.reviewStatus );
   this.reviewBackButton = new PushButton( this.reviewDialog );
   this.reviewBackButton.text = "←  Back";
   this.reviewBackButton.toolTip =
      "Close the image review and return to InNova Multi-Night";
   this.reviewNextButton = new PushButton( this.reviewDialog );
   this.reviewNextButton.text = "Next  →";
   if ( this.guidedWorkflow )
      this.reviewNextButton.styleSheet =
         "color:#087bd5;font-weight:bold;";
   this.reviewBackButton.setScaledFixedHeight( 28 );
   this.reviewNextButton.setScaledFixedHeight( 28 );
   this.updateReviewNextButton = function()
   {
      let needsCombination = self.multiExposureConfigured &&
         !self.combinationPreviewGenerated;
      let cropBusy = self.imageViewer.cropInteractionActive === true ||
         self.confirmedCropApplyPending === true;
      self.reviewNextButton.text = needsCombination ? "Apply Multi-night" :
         (self.guidedWorkflow ? "Next  →" : "Close");
      self.reviewNextButton.styleSheet = needsCombination ||
         self.guidedWorkflow ? "color:#087bd5;font-weight:bold;" : "";
      self.reviewNextButton.icon = needsCombination ?
         self.scaledResource( ":/icons/play.png" ) :
         (self.guidedWorkflow ? new Bitmap : self.scaledResource( ":/icons/close.png" ));
      self.reviewNextButton.toolTip = needsCombination ?
         "Review the selected images and choose the combination type" :
         (self.guidedWorkflow ? "Choose images to send to InNova Astro Processor" :
          "Close preparation and keep the images open without sending them to another module");
      self.reviewNextButton.enabled = !cropBusy &&
         !(needsCombination && self.multiExposureCropRequired);
   };
   this.updateReviewNextButton();
   let reviewBottom = new HorizontalSizer;
   reviewBottom.addStretch();
   reviewBottom.add( this.reviewBackButton );
   reviewBottom.addSpacing( 12 );
   reviewBottom.add( this.reviewNextButton );
   reviewBottom.addStretch();
   this.reviewDialog.sizer = new VerticalSizer;
   this.reviewDialog.sizer.margin = 10;
   this.reviewDialog.sizer.spacing = 9;
   this.reviewDialog.sizer.add( this.reviewHeader );
   this.reviewDialog.sizer.add( this.viewerGroup, 100 );
   this.reviewDialog.sizer.add( this.imageInformationGroup );
   this.reviewDialog.sizer.add( this.reviewInformationPanel );
   this.reviewDialog.sizer.add( reviewBottom );
   this.reviewNavigation = "back";


   this.applyConfirmedCropInReview = function()
   {
      let launchProcessor = false;
      try {
         let cropWasRequired = self.multiExposureCropRequired;
         let cropApplied = self.applyCropButton.onClick() === true;
         launchProcessor = self.runProcessorAfterCropRequested === true;
         self.runProcessorAfterCropRequested = false;
         if ( cropApplied && cropWasRequired ) {
            self.multiExposureCropRequired = false;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = true;
            self.reviewStatus.text +=
               "<br/><b>Crop completed. Multi-night integration can continue.</b>";
            self.status.text = self.reviewStatus.text;
         }
      }
      finally {
         self.imageViewer.setCropInteractionActive( false );
         self.reviewDialog.enabled = true;
         self.updateReviewNextButton();
      }
      if ( launchProcessor ) {
         self.reviewNavigation = "next";
         self.reviewDialog.ok();
      }
   };
   this.confirmedCropApplyPending = false;
   this.confirmedCropApplyTimer = new Timer;
   this.confirmedCropApplyTimer.interval = 0.05;
   this.confirmedCropApplyTimer.periodic = false;
   this.confirmedCropApplyTimer.onTimeout = function()
   {
      if ( !self.confirmedCropApplyPending ) return;
      self.confirmedCropApplyPending = false;
      self.applyConfirmedCropInReview();
   };
   this.reviewBackButton.onClick = function()
   {
      if (self.reviewOperationDepth > 0) return;
      self.reviewNavigation = "back";
      self.reviewDialog.ok();
   };
   this.reviewNextButton.onClick = function()
   {
      if ( self.multiExposureConfigured &&
           !self.combinationPreviewGenerated ) {
         let selectedSources = [];
         for ( let i = 0; i < self.entries.length; ++i )
            if ( self.entries[i].multiExposureSelected === true )
               selectedSources.push( self.entries[i] );
         let selectedImageIds = [];
         for ( let i = 0; i < selectedSources.length; ++i ) {
            let displayId = selectedSources[i].id;
            for ( let j = 0; j < self.imageViewer.series.length; ++j )
               if ( StartSeriesSourceEntry( self.imageViewer.series[j] ) ===
                    selectedSources[i] ) {
                  let selectedWindow = self.imageViewer.series[j].window ||
                     self.imageViewer.series[j];
                  if ( selectedWindow != null && !selectedWindow.isNull &&
                       selectedWindow.mainView != null &&
                       !selectedWindow.mainView.isNull )
                     displayId = selectedWindow.mainView.id;
                  break;
               }
            selectedImageIds.push( displayId );
         }
         if ( !self.combinationChoiceConfirmed ) {
            let combinationDialog = new StartMultiExposureDialog(
               self.acquisitionCombo.currentItem, selectedImageIds, true );
            if ( combinationDialog.execute() != StdDialogCode_Ok ) return;
            self.acquisitionCombo.currentItem =
               combinationDialog.acquisitionCombo.currentItem == 0 ? 1 : 2;
            self.combinationChoiceConfirmed = true;
            self.saveHandoffSelections();
         }
         let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
         if ( selectedSources.length < required ) {
            new MessageBox(
               self.acquisitionCombo.currentItem == 2 ?
                  "<p align=\"center\">HDR requires <b>at least 3 images</b> with distinct exposure levels.<br/><br/>" +
                  "Use the star icon to add more images, then click <b>Apply Multi-night</b>.</p>" :
                  "<p align=\"center\">Multi-night integration requires <b>at least 2 images</b>.<br/><br/>" +
                  "Use the star icon to add more images, then click <b>Apply Multi-night</b>.</p>",
               "🔭 InNova Multi-Night — More images required",
               StdIcon_Information, StdButton_Ok ).execute();
            return;
         }
         if ( self.acquisitionCombo.currentItem == 2 ) {
            let levels = {};
            for ( let i = 0; i < selectedSources.length; ++i ) {
               if ( !isFinite( selectedSources[i].exposure ) ||
                    selectedSources[i].exposure <= 0 ) {
                  new MessageBox(
                     "Every selected HDR image must provide a valid exposure value.",
                     "🔭 InNova Multi-Night — HDR exposure unavailable",
                     StdIcon_Warning, StdButton_Ok ).execute();
                  return;
               }
               levels[Math.round( 1000*selectedSources[i].exposure )] = true;
            }
            let levelCount = 0;
            for ( let level in levels ) ++levelCount;
            if ( levelCount < 3 ) {
               new MessageBox(
                  "HDR requires at least three distinct exposure levels.",
                  "🔭 InNova Multi-Night — HDR requires three exposures",
                  StdIcon_Warning, StdButton_Ok ).execute();
               return;
            }
         }

         let showingCropped = self.croppedSeries.length > 0 &&
            self.imageViewer.seriesLabel.indexOf( "Cropped images" ) == 0;
         let baseSeries = showingCropped ?
            self.croppedSeries : self.registeredSeries;


         let incompleteCoverage = self.multiExposureSynchronizedCropAccepted ?
            [] : StartIncompleteCombinationCoverage( baseSeries );
         if ( incompleteCoverage.length > 0 ) {
            self.multiExposureCropRequired = true;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = false;
            self.updateReviewNextButton();
            StartShowMultiNightCropRequired(
               "The selected images still contain registration borders " +
                  "without valid image data.",
               "<p align=\"center\"><span style=\"color:#c62828\"><b>" +
                  StartHTMLText( incompleteCoverage.join( ", " ) ) +
                  "</b></span></p>",
               "Use Crop to keep only the common covered area.<br/><br/>" +
                  "<b>The multi-night integration will then continue " +
                  "automatically.</b>" );
            self.focusCropRequiredImage(
               baseSeries, incompleteCoverage[0], showingCropped );
            return;
         }
         let compatibility = StartCombinationCompatibility(
            selectedSources, baseSeries );
         let selectedDetails = StartCombinationImageDetails(
            selectedSources, baseSeries );
         if ( !compatibility.sameGeometry ) {
            self.multiExposureCropRequired = true;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = false;
            self.updateReviewNextButton();
            StartShowMultiNightCropRequired(
               "The selected images cannot be combined because their " +
                  "registered geometry is different.",
               "<p align=\"center\"><b>Selected image characteristics" +
                  "</b><br/><br/>" + selectedDetails + "</p>",
               "Use Crop to define a common image area. The multi-night " +
                  "integration will then continue automatically." );
            return;
         }
         let differingValues = [];
         if ( compatibility.differentCamera )
            differingValues.push( "Cameras: " +
               compatibility.cameras.join( " / " ) );
         if ( self.acquisitionCombo.currentItem == 1 &&
              compatibility.differentExposure )
            differingValues.push( "Exposure times: " +
               compatibility.exposures.join( " / " ) );
         if ( differingValues.length > 0 ) {
            let answer = StartAskCenteredQuestion(
               "🔭 InNova Multi-Night — Different image characteristics",
               "The selected images have the same registered geometry, " +
               "but these characteristics are different:\n\n" +
               differingValues.join( "\n" ) +
               "\n\nDo you want to combine them anyway?",
               false, "Do you want to combine them anyway?" );
            if ( answer != StdButton_Yes ) return;
         }
         self.combinationPreviewGenerated = true;
         let resultName = self.acquisitionCombo.currentItem == 2 ?
            "HDR" : "Multi-night integration";
         self.beginElapsed( "Generating " + resultName + "…", true );
         let generated = null;
         let generationError = null;
         try {
            generated = self.buildViewerSeries( baseSeries,
               showingCropped ? "Cropped images" : "Registered images" );
         } catch ( error ) {
            generationError = error;
         }
         let generationElapsed = self.finishElapsed();
         if ( generationError != null ) {
            self.combinationPreviewGenerated = false;
            self.updateReviewNextButton();
            self.reviewStatus.text = "<b style=\"color:#c33\">" +
               resultName + " failed:</b> " + generationError +
               "  " + StartElapsedRichText( generationElapsed );
            self.status.text = self.reviewStatus.text;
            new MessageBox( String( generationError ),
               "🔭 InNova Multi-Night — Combination failed",
               StdIcon_Error, StdButton_Ok ).execute();
            return;
         }
         let derivedCount = self.integrationSeries.length +
            self.hdrSeries.length;
         if ( derivedCount == 0 &&
              self.acquisitionCombo.currentItem == 1 ) {
            let filters = {};
            let filterNames = [];
            for ( let i = 0; i < selectedSources.length; ++i ) {
               let filter = selectedSources[i].filter == "—" ?
                  (selectedSources[i].channels >= 3 ?
                     "OSC/COLOR" : "UNFILTERED") :
                  String( selectedSources[i].filter ).toUpperCase();
               if ( filters[filter] == null ) {
                  filters[filter] = true;
                  filterNames.push( filter );
               }
            }
            if ( filterNames.length > 1 ) {
               let combineAnswer = new MessageBox(
                  "<p align=\"center\">Images captured with different " +
                  "filter types have been found: <b>" +
                  StartHTMLText( filterNames.join( " / " ) ) +
                  "</b>.</p><p align=\"center\"><b>Selected image " +
                  "characteristics</b><br/><br/>" + selectedDetails +
                  "</p><p align=\"center\"><b>Do you want to combine " +
                  "them anyway?</b></p>",
                  "🔭 InNova Multi-Night — Different filter types found",
                  StdIcon_Warning, StdButton_Yes,
                  StdButton_No ).execute();
               if ( combineAnswer == StdButton_Yes ) {
                  self.combineDifferentFilters = true;
                  self.combinationPreviewGenerated = true;
                  self.beginElapsed(
                     "Generating a mixed-filter Multi-night integration…", true );
                  generationError = null;
                  try {
                     generated = self.buildViewerSeries( baseSeries,
                        showingCropped ?
                           "Cropped images" : "Registered images" );
                  } catch ( error ) {
                     generationError = error;
                  }
                  generationElapsed = self.finishElapsed();
                  if ( generationError != null ) {
                     self.combinationPreviewGenerated = false;
                     self.combineDifferentFilters = false;
                     self.updateReviewNextButton();
                     self.reviewStatus.text =
                        "<b style=\"color:#c33\">" + resultName +
                        " failed:</b> " + generationError + "  " +
                        StartElapsedRichText( generationElapsed );
                     self.status.text = self.reviewStatus.text;
                     new MessageBox( String( generationError ),
                        "🔭 InNova Multi-Night — Combination failed",
                        StdIcon_Error, StdButton_Ok ).execute();
                     return;
                  }
                  derivedCount = self.integrationSeries.length +
                     self.hdrSeries.length;
               } else {
                  self.combinationPreviewGenerated = false;
                  self.updateReviewNextButton();
                  self.reviewStatus.text =
                     "The images were not combined because their filters " +
                     "are different.";
                  self.status.text = self.reviewStatus.text;
                  return;
               }
            }
         }
         if ( derivedCount == 0 ) {
            self.combinationPreviewGenerated = false;
            self.updateReviewNextButton();
            self.reviewStatus.text =
               "<b style=\"color:#c33\">The selected images could not " +
               "be combined.</b> " + StartElapsedRichText( generationElapsed );
            self.status.text = self.reviewStatus.text;
            new MessageBox(
               "<p align=\"center\">The selected images could not be " +
               "combined. Check their filter, registered geometry and " +
               "exposure values.<br/><br/><b>Selected image " +
               "characteristics</b><br/><br/>" + selectedDetails + "</p>",
               "🔭 InNova Multi-Night — Combination unavailable",
               StdIcon_Warning, StdButton_Ok ).execute();
            return;
         }
         self.imageViewer.setSeries( generated.series, generated.label,
            generated.series.length - 1 );
         self.multiExposureSynchronizedCropAccepted = false;
         self.reviewStatus.text = "<b>" + resultName +
            " generated.</b> " + StartElapsedRichText( generationElapsed );
         self.updateReviewNextButton();
         self.status.text = self.reviewStatus.text;
         return;
      }
      self.reviewNavigation = "next";
      self.reviewDialog.ok();
   };
   this.reviewDialog.adjustToContents();


   this.reviewCenterTimer = new Timer;
   this.reviewCenterTimer.interval = 0.05;
   this.reviewCenterTimer.periodic = false;
   this.reviewCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self.reviewDialog );
   };
   this.reviewDialog.onShow = function()
   {
      MiraCenterDialog( this );
      self.reviewCenterTimer.start();
   };
   MiraCenterDialog( this.reviewDialog );

   this.nextStepDialog = new Dialog;
   this.nextStepDialog.windowTitle =
      "🔭 InNova Multi-Night — Processing Destination";

   this.destinationHeader = StartLauncherPanel(this.nextStepDialog, true);
   this.destinationHeader.setScaledFixedHeight(92);
   this.destinationHeader.sizer = new HorizontalSizer;
   this.destinationHeader.sizer.margin = 12;
   this.destinationHeader.sizer.spacing = 16;
   this.destinationHeader.sizer.add(StartLauncherIcon(this.destinationHeader, "astro-processor", 68));
   let destinationText = new VerticalSizer;
   destinationText.spacing = 5;
   destinationText.addStretch();
   destinationText.add(StartLauncherLabel(this.destinationHeader,
      "<b>InNova Astro Processor</b>", 20, "#102b50", false));
   this.nextStepIntro = StartLauncherLabel(this.destinationHeader,
      "Select the images to open in <b>InNova Astro Processor</b>. " +
      "The processing mode is selected after clicking Run there.",
      12, "#243f5b", false);
   destinationText.add(this.nextStepIntro);
   destinationText.addStretch();
   this.destinationHeader.sizer.add(destinationText, 100);

   this.nextStepTree = new TreeBox( this.nextStepDialog );
   this.nextStepTree.numberOfColumns = 3;
   this.nextStepTree.headerVisible = true;
   this.nextStepTree.rootDecoration = false;
   this.nextStepTree.alternateRowColor = true;
   this.nextStepTree.setHeaderText( 0, "Send" );
   this.nextStepTree.setHeaderText( 1, "Image" );
   this.nextStepTree.setHeaderText( 2, "Prepared type" );
   this.nextStepTree.setColumnWidth( 0, 60 );
   this.nextStepTree.setColumnWidth( 1, 300 );
   this.nextStepTree.setColumnWidth( 2, 150 );
   this.nextStepTree.setScaledMinSize( 520, 190 );
   this.destinationSeries = [];
   this.destinationSelection = [];

   this.populateDestinationImages = function()
   {
      self.nextStepTree.clear();
      self.destinationSeries = self.resolveLatestPreparedSeries(
         self.imageViewer.series );
      let hasCombinedResult = self.destinationSeries.some( function( item ) {
         return item.kind == "INTEGRATION" || item.kind == "HDR";
      } );
      for ( let i = 0; i < self.destinationSeries.length; ++i ) {
         let item = self.destinationSeries[i];
         let window = item.window || item;
         let isCombinedResult = item.kind == "INTEGRATION" ||
            item.kind == "HDR";
         let type = item.kind == "INTEGRATION" ?
            "✅ NEW MULTI-EXPOSURE IMAGE" :
            (item.kind == "HDR" ? "✅ NEW HDR" :
             (self.imageViewer.seriesLabel.indexOf( "Cropped images" ) == 0 ?
                "Cropped image" : "Registered image"));
         let node = new TreeBoxNode( self.nextStepTree );
         node.checkable = true;


         node.checked = hasCombinedResult ? isCombinedResult : true;
         node.setText( 1, window.mainView.id );
         node.setText( 2, type );
         if ( item.kind == "INTEGRATION" || item.kind == "HDR" )
            for ( let column = 0; column < 3; ++column ) {
               node.setBackgroundColor( column, 0xffcce9ff );
               node.setTextColor( column, 0xff075b9b );
            }
      }
      self.nextStepIntro.text =
         "Select the images to open in <b>InNova Astro Processor</b>. " +
         "The processing mode is selected after clicking <b>Run</b> there.";
   };

   this.hasDestinationCroppedImages = function()
   {
      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              /innovastartcrop/i.test( windows[i].mainView.id ) )
            return true;
      return false;
   };

   this.deleteDestinationRegisteredImages = function( protectedSeries )
   {
      let protectedIds = {};
      for ( let i = 0; i < protectedSeries.length; ++i ) {
         let protectedWindow = protectedSeries[i].window || protectedSeries[i];
         if ( protectedWindow != null && !protectedWindow.isNull &&
              protectedWindow.mainView != null &&
              !protectedWindow.mainView.isNull )
            protectedIds[protectedWindow.mainView.id] = true;
      }
      let windows = ImageWindow.windows;
      let deleted = 0;
      for ( let i = 0; i < windows.length; ++i ) {
         let window = windows[i];
         if ( window == null || window.isNull || window.mainView.isNull ||
              !/innovastartregistered/i.test( window.mainView.id ) ||
              protectedIds[window.mainView.id] )
            continue;
         let id = window.mainView.id;
         try {
            window.forceClose();
            ++deleted;
            console.noteln( "🗑️ Deleted superseded registered image: " + id );
         } catch ( error ) {
            console.warningln( "⚠️ Could not delete registered image " +
               id + ": " + error );
         }
      }
      let retained = [];
      for ( let i = 0; i < self.registeredSeries.length; ++i ) {
         let itemWindow = self.registeredSeries[i].window ||
            self.registeredSeries[i];
         if ( itemWindow != null && !itemWindow.isNull &&
              itemWindow.mainView != null && !itemWindow.mainView.isNull )
            retained.push( self.registeredSeries[i] );
      }
      self.registeredSeries = retained;
      return deleted;
   };

   this.selectedDestinationImages = function()
   {
      let selected = [];
      for ( let i = 0; i < self.destinationSeries.length; ++i )
         if ( self.nextStepTree.child( i ).checked )
            selected.push( self.destinationSeries[i] );
      return selected;
   };

   this.prepareIntegratorHandoff = function( selected )
   {
      let requested = self.resolveLatestPreparedSeries( selected );
      selected = self.resolveLatestProcessorSeries( selected );
      for ( let i = 0; i < requested.length && i < selected.length; ++i ) {
         let requestedWindow = requested[i].window || requested[i];
         let selectedWindow = selected[i].window || selected[i];
         if ( requestedWindow != null && selectedWindow != null &&
              !requestedWindow.isNull && !selectedWindow.isNull &&
              !requestedWindow.mainView.isNull &&
              !selectedWindow.mainView.isNull &&
              requestedWindow.mainView.id != selectedWindow.mainView.id )
            console.noteln(
               "ℹ️ InNova Multi-Night: Astro Processor requires a linear image; " +
               "using " + selectedWindow.mainView.id + " instead of the " +
               "stretched result " + requestedWindow.mainView.id + "." );
      }
      let keys = [ "PimageSii", "PimageHa", "PimageOiii",
         "PimageRed", "PimageGreen", "PimageBlue",
         "PimageLuminance", "PimageOsc" ];
      let assignments = {};
      let priorities = {};
      for ( let i = 0; i < selected.length; ++i ) {
         let key = StartPreparedChannelKey( selected[i] );
         if ( key.length == 0 ) continue;
         let priority = StartPreparedImagePriority( selected[i] );
         if ( assignments[key] == null || priority > priorities[key] ) {
            let window = selected[i].window || selected[i];
            assignments[key] = window.mainView.id;
            priorities[key] = priority;
         }
      }
      let assignedCount = 0;
      for ( let i = 0; i < keys.length; ++i ) {
         let value = assignments[keys[i]] || "";
         Settings.write( InNovaIntegratorHandoffImagePrefix + keys[i],
            DataType_String, value );
         if ( value.length > 0 ) ++assignedCount;
      }
      if ( assignedCount == 0 ) return false;
      self.saveHandoffSelections();
      let project = projectValues[self.projectCombo.currentItem];
      if ( assignments.PimageSii && assignments.PimageHa &&
           assignments.PimageOiii )
         project = "SHO";
      else if ( assignments.PimageHa && assignments.PimageOiii )
         project = "HOO";
      else if ( assignments.PimageRed && assignments.PimageGreen &&
                assignments.PimageBlue && assignments.PimageLuminance )
         project = "LRGB";
      else if ( assignments.PimageRed && assignments.PimageGreen &&
                assignments.PimageBlue )
         project = "RGB";
      else if ( assignments.PimageOsc ) {
         project = "OSC";
         for ( let i = 0; i < selected.length; ++i ) {
            let colorItemWindow = selected[i].window || selected[i];
            if ( colorItemWindow != null && !colorItemWindow.isNull &&
                 !colorItemWindow.mainView.isNull &&
                 colorItemWindow.mainView.id == assignments.PimageOsc ) {
               project = StartPreparedOscProject( selected[i] );
               break;
            }
         }
      }
      let useRgbStars =
         (project == "SHO" || project == "HOO") &&
         assignments.PimageRed && assignments.PimageGreen &&
         assignments.PimageBlue;
      let useHaBlend =
         (project == "RGB" || project == "LRGB") &&
         assignments.PimageHa;
      Settings.write( InNovaIntegratorHandoffRgbStarsSetting,
         DataType_String, useRgbStars ? "1" : "0" );
      Settings.write( InNovaIntegratorHandoffHaBlendSetting,
         DataType_String, useHaBlend ? "1" : "0" );
      Settings.write( InNovaIntegratorHandoffProjectSetting,
         DataType_String, project );
      Settings.write( InNovaIntegratorHandoffPendingSetting,
         DataType_String, "1" );
      return true;
   };

   this.integratorDestinationButton = new PushButton(
      this.nextStepDialog );
   this.integratorDestinationButton.text = "Run";
   this.integratorDestinationButton.icon =
      this.scaledResource( ":/icons/play.png" );
   this.integratorDestinationButton.toolTip =
      "Open the selected images in InNova Astro Processor";
   this.integratorDestinationButton.setScaledFixedSize( 92, 24 );
   this.integratorDestinationButton.onClick = function()
   {
      if ( !self.guidedWorkflow ) return;
      let selected = self.selectedDestinationImages();
      if ( selected.length == 0 ) {
         new MessageBox(
            "Select at least one prepared image to continue.",
            "🔭 InNova Multi-Night — No images selected",
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return;
      }
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new MessageBox(
            "The selected image channels could not be identified. Check " +
            "their Filter metadata or use channel names such as Sii, Ha, " +
            "Oiii, R, G, B or L.",
            "🔭 InNova Multi-Night — Channels not identified",
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }


      if ( self.hasDestinationCroppedImages() )
         self.deleteDestinationRegisteredImages( selected );
      self.destinationSelection = selected;
      self.integratorLaunchRequested = true;
      self.nextStepDialog.ok();
   };

   this.cancelDestinationButton = new PushButton( this.nextStepDialog );
   this.cancelDestinationButton.text = "Cancel";
   this.cancelDestinationButton.icon =
      this.scaledResource( ":/icons/cancel.png" );
   this.cancelDestinationButton.toolTip =
      "Close this selection without opening InNova Astro Processor";
   this.cancelDestinationButton.setScaledFixedSize( 92, 24 );
   this.cancelDestinationButton.onClick = function()
   {
      self.integratorLaunchRequested = false;
      self.nextStepDialog.cancel();
   };

   let destinations = new HorizontalSizer;
   destinations.spacing = 10;
   destinations.addStretch();
   destinations.add( this.integratorDestinationButton );
   destinations.add( this.cancelDestinationButton );

   this.nextStepDialog.sizer = new VerticalSizer;
   this.nextStepDialog.sizer.margin = 16;
   this.nextStepDialog.sizer.spacing = 12;
   this.nextStepDialog.sizer.add( this.destinationHeader );
   this.nextStepDialog.sizer.addSpacing( 4 );
   this.nextStepDialog.sizer.add( this.nextStepTree, 100 );
   this.nextStepDialog.sizer.addSpacing( 4 );
   this.nextStepDialog.sizer.add( destinations );
   this.nextStepDialog.adjustToContents();
   this.integratorLaunchRequested = false;

   this.continueGuidedMultiNightToProcessor = function()
   {
      if ( !self.guidedWorkflow ) return false;
      let selected = [];
      let combined = self.integrationSeries.concat( self.hdrSeries );
      for ( let i = 0; i < combined.length; ++i ) {
         let window = combined[i].window || combined[i];
         if ( window != null && !window.isNull &&
              window.mainView != null && !window.mainView.isNull )
            selected.push( combined[i] );
      }
      if ( selected.length == 0 ) return false;
      let processorSelection = self.resolveLatestProcessorSeries( selected );
      if ( !StartProcessorSelectionSupportsMonochrome( processorSelection ) ) {
         StartShowMonochromeProcessorInformation();
         return false;
      }
      if ( !self.prepareIntegratorHandoff( selected ) ) {
         new MessageBox(
            "The combined image channels could not be identified. Check " +
            "their Filter metadata or channel names before continuing.",
            "🔭 InNova Multi-Night — Channels not identified",
            StdIcon_Warning, StdButton_Ok ).execute();
         return false;
      }
      self.destinationSelection = selected;
      self.integratorLaunchRequested = true;
      self.ok();
      return true;
   };

   this.executeReviewStep = function()
   {
      if ( self.unifiedBridgeWindow ) {
         let completed = self.runUnifiedMultiNightCombination();
         self.presentPreparedInBridge();
         if ( completed ) {
            self.offerMultiNightSave();
            self.continueGuidedMultiNightToProcessor();
         }
         return;
      }

      self.hideProcessConsole();
      self.reviewNavigation = "back";
      self.reviewDialog.enabled = true;
      self.updateReviewNextButton();
      self.reviewDialog.execute();


      if ( self.processorDirectLaunchRequested ) {
         self.pendingSpccReport = null;
         self.ok();
         return;
      }
      if ( self.pendingSpccReport != null ) {
         let pendingReport = self.pendingSpccReport;
         self.pendingSpccReport = null;
         StartShowDeferredSpccReport( pendingReport );
      }
      if ( self.reviewNavigation == "next" ) {
         if ( !self.guidedWorkflow ) {
            self.preparationFinished = true;
            self.ok();
            return;
         }
         self.populateDestinationImages();
         self.nextStepDialog.execute();
         if ( self.integratorLaunchRequested ) self.ok();
      }
   };

   this.status = new Label( this );
   this.status.useRichText = true;
   this.status.wordWrapping = true;
   this.status.textAlignment =
      TextAlign_HorzCenter | TextAlign_VertCenter;
   this.status.frameStyle = FrameStyle_Box;
   this.status.margin = 8;
   this.status.setScaledMinHeight( 88 );
   this.elapsedStarted = 0;
   this.elapsedMessage = "";
   this.elapsedInReview = false;
   this.elapsedText = function()
   {
      let seconds = Math.max( 0,
         Math.floor( (Date.now() - self.elapsedStarted)/1000 ) );
      function two( value ) { return value < 10 ? "0" + value : String( value ); }
      return two( Math.floor( seconds/3600 ) ) + ":" +
         two( Math.floor( (seconds%3600)/60 ) ) + ":" +
         two( seconds%60 );
   };
   this.elapsedTimer = new Timer( 1, true, this );
   this.elapsedTimer.onTimeout = function()
   {
      if ( self.elapsedStarted <= 0 ) return;
      self.status.text = self.elapsedMessage +
         "  " + StartElapsedRichText( self.elapsedText() );
      self.status.update();
      if ( self.elapsedInReview ) {
         self.reviewStatus.text = self.elapsedMessage +
            "  " + StartElapsedRichText( self.elapsedText() );
         self.reviewStatus.update();
      }
   };
   this.beginElapsed = function( message, inReview )
   {
      console.noteln( "⚙️ " + message );
      self.elapsedMessage = message;
      self.elapsedInReview = inReview === true;
      self.elapsedStarted = Date.now();
      self.elapsedTimer.stop();
      self.elapsedTimer.start();
      self.status.text = message + "  " + StartElapsedRichText( "00:00:00" );
      self.status.update();
      if ( self.elapsedInReview ) {
         self.reviewStatus.text =
            message + "  " + StartElapsedRichText( "00:00:00" );
         self.reviewStatus.update();
      }
      CoreApplication.processEvents();
   };
   this.updateElapsed = function( message )
   {
      if ( self.elapsedStarted <= 0 ) return;
      self.elapsedMessage = message;
      self.elapsedTimer.onTimeout();
      CoreApplication.processEvents();
   };
   this.finishElapsed = function()
   {
      let text = self.elapsedStarted > 0 ? self.elapsedText() : "00:00:00";
      self.elapsedTimer.stop();
      self.elapsedStarted = 0;
      self.elapsedInReview = false;
      return text;
   };

   this.consoleIsVisible = false;
   this.showProcessConsole = function()
   {
      console.show();
      self.consoleIsVisible = true;
      self.consoleButton.toolTip = "Hide the PixInsight Process Console";
      if (self.imageViewer && self.imageViewer.consoleButton)
         self.imageViewer.consoleButton.toolTip =
            "Hide the PixInsight Process Console";
      CoreApplication.processEvents();
   };
   this.hideProcessConsole = function()
   {
      console.hide();
      self.consoleIsVisible = false;
      self.consoleButton.toolTip = "Show the PixInsight Process Console";
      if (self.imageViewer && self.imageViewer.consoleButton)
         self.imageViewer.consoleButton.toolTip =
            "Show the PixInsight Process Console";
      CoreApplication.processEvents();
   };

   this.sizer = new VerticalSizer;
   this.sizer.margin = 10;
   this.sizer.spacing = 9;
   this.sizer.add( this.bridgeHeader );
   this.sizer.add( this.imagesGroup, 100 );
   this.sizer.add( this.status );

   this.selectedEntries = function()
   {
      let selected = [];
      for ( let i = 0; i < self.entries.length; ++i ) {
         if ( self.entries[i].generatedMultiNight === true ) continue;
         self.entries[i].enabled = self.imagesTree.child( i ).checked;
         if ( self.entries[i].enabled &&
              (!self.multiExposureConfigured ||
               self.entries[i].multiExposureSelected === true) )
            selected.push( self.entries[i] );
      }
      return selected;
   };

   this.focusCropRequiredImage = function( series, imageId, showingCropped )
   {
      let seriesIndex = -1;
      let sourceEntry = null;
      for ( let i = 0; i < series.length; ++i ) {
         let window = series[i].window || series[i];
         if ( window != null && !window.isNull &&
              !window.mainView.isNull && window.mainView.id == imageId ) {
            seriesIndex = i;
            sourceEntry = StartSeriesSourceEntry( series[i] );
            break;
         }
      }
      if ( seriesIndex < 0 ) return false;

      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i] === sourceEntry ||
              (sourceEntry != null && self.entries[i].id == sourceEntry.id) ) {


            self.inputPreviewIndex = i;
            break;
         }


      self.imageViewer.setSeries( series,
         showingCropped ? "Cropped images" : "Registered images",
         seriesIndex );
      return true;
   };

   this.selectInputPreview = function( index )
   {
      if ( index < 0 || index >= self.entries.length ) return;
      let entry = self.entries[index];


      let preserveManualZoom = !self.inputPreview.fitMode;
      let previousScale = self.inputPreview.scale;
      let previousCenter = null;
      if ( preserveManualZoom && self.inputPreview.scaledBitmap != null ) {
         let viewport = self.inputPreview.viewport.viewport;
         let offset = self.inputPreview.viewport.bitmapOffsetFor(
            self.inputPreview );
         previousCenter = {
            x: (viewport.width/2 - offset.x)/
               self.inputPreview.scaledBitmap.width,
            y: (viewport.height/2 - offset.y)/
               self.inputPreview.scaledBitmap.height
         };
      }
      self.inputPreviewIndex = index;
      let state = {};
      let previewWindow = entry.loaderPreviewWindow != null &&
         !entry.loaderPreviewWindow.isNull ?
         entry.loaderPreviewWindow : entry.window;
      let linked = typeof entry.inputQuickStretchLinked == "boolean" &&
         entry.inputQuickStretchAutomatic !== true ?
         entry.inputQuickStretchLinked : undefined;
      self.inputPreview.setBitmap( StartQuickStretchBitmap(
         previewWindow, false, linked, state ),
         previewWindow.mainView.image.width,
         previewWindow.mainView.image.height );
      self.inputQuickStretchLinked = state.linked;
      self.inputQuickStretchToggleAvailable = state.adjustable === true;
      entry.inputQuickStretchLinked = state.linked;
      entry.inputQuickStretchAutomatic = state.automatic === true;
      self.updateInputQuickStretchLinkButton();
      if ( preserveManualZoom && self.inputPreview.bitmap != null ) {
         self.inputPreview.setZoom( previousScale );
         if ( previousCenter != null &&
              self.inputPreview.scaledBitmap != null ) {
            let viewport = self.inputPreview.viewport.viewport;
            self.inputPreview.viewport.horizontalScrollPosition = Math.range(
               Math.round( previousCenter.x*
                  self.inputPreview.scaledBitmap.width - viewport.width/2 ),
               0, self.inputPreview.viewport.maxHorizontalScrollPosition );
            self.inputPreview.viewport.verticalScrollPosition = Math.range(
               Math.round( previousCenter.y*
                  self.inputPreview.scaledBitmap.height - viewport.height/2 ),
               0, self.inputPreview.viewport.maxVerticalScrollPosition );
            viewport.update();
         }
      }
      self.inputZoomInButton.enabled = self.inputPreview.bitmap != null;
      self.inputPanButton.enabled = self.inputPreview.bitmap != null;
      self.inputZoomOutButton.enabled = self.inputPreview.bitmap != null;
      self.inputQuickStretchLinkButton.enabled =
         self.inputPreview.bitmap != null &&
         self.inputQuickStretchToggleAvailable;
      self.inputCombineButton.enabled = true;
      if ( entry.generatedMultiNight === true )
         self.inputCombineButton.enabled = false;
      self.inputCombineButton.checked = entry.multiExposureSelected === true;
      self.inputCropButton.enabled = self.registeredSeries.length >= 2;
      self.inputResetBridgeButton.enabled = self.registeredSeries.length > 0 ||
         self.croppedSeries.length > 0 || self.integrationSeries.length > 0 ||
         self.hdrSeries.length > 0;
   };

   this.inputZoomInButton.onClick = function()
   {
      self.inputPreview.setZoom( self.inputPreview.scale*1.35 );
   };
   this.inputPanButton.onClick = function( checked )
   {
      self.inputPreview.panEnabled = checked;
      self.inputPreview.scrolling = null;
      self.inputPreview.viewport.viewport.cursor = new Cursor( checked ?
         StdCursor_OpenHand : StdCursor_Arrow );
   };
   this.inputZoomOutButton.onClick = function()
   {
      self.inputPreview.setZoom( self.inputPreview.scale/1.35 );
   };
   this.inputQuickStretchLinkButton.onClick = function()
   {
      if ( !self.inputQuickStretchToggleAvailable ||
           self.inputPreviewIndex < 0 ||
           self.inputPreviewIndex >= self.entries.length ) return;
      let entry = self.entries[self.inputPreviewIndex];
      entry.inputQuickStretchLinked =
         self.inputQuickStretchLinked !== true;
      entry.inputQuickStretchAutomatic = false;
      self.selectInputPreview( self.inputPreviewIndex );
   };

   this.setInputCombine = function( index, selected )
   {
      if ( index < 0 || index >= self.entries.length ) return;
      self.entries[index].multiExposureSelected = selected === true;
      let selectedCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].multiExposureSelected === true ) ++selectedCount;
      self.multiExposureConfigured = selectedCount > 0;
      self.acquisitionCombo.currentItem = selectedCount > 0 ? 1 : 0;
      self.combinationPreviewGenerated = false;
      self.combinationChoiceConfirmed = false;
      self.updateTree( index );
      self.status.text = selectedCount > 0 ?
         "<b style=\"color:#d97800\">Combine:</b> " + selectedCount +
         " image(s) selected. Select at least two compatible images before Run." :
         "Combine selection cleared.";
   };

   this.advanceInputPreviewAfterCombine = function( index, selected )
   {


      if ( selected !== true ) return;
      let nextIndex = index + 1;
      while ( nextIndex < self.entries.length &&
              self.entries[nextIndex].generatedMultiNight === true )
         ++nextIndex;

      if ( nextIndex >= self.entries.length ) return;
      self.selectInputPreview( nextIndex );
      let current = self.imagesTree.child( nextIndex );
      if ( current != null ) self.imagesTree.currentNode = current;
   };

   this.inputCombineButton.onClick = function()
   {
      let index = self.inputPreviewIndex;
      let selected = this.checked;
      self.setInputCombine( index, selected );
      self.advanceInputPreviewAfterCombine( index, selected );
   };

   this.imagesTree.onCurrentNodeUpdated = function( node )
   {
      if ( node == null ) return;
      let index = node.__index__;
      if ( index >= 0 && index < self.entries.length &&
           index != self.inputPreviewIndex )
         self.selectInputPreview( index );
   };

   this.imagesTree.onNodeClicked = function( node, column )
   {
      if ( node == null || column != 1 ) return;
      let index = node.__index__;
      if ( index < 0 || index >= self.entries.length ) return;
      if ( self.entries[index].generatedMultiNight === true ) return;
      self.setInputCombine( index,
         self.entries[index].multiExposureSelected !== true );
   };

   this.imagesTree.onNodeUpdated = function( node, column )
   {
      if ( column != 0 || node == null ) return;
      let index = node.__index__;
      if ( index < 0 || index >= self.entries.length ) return;
      if ( self.entries[index].generatedMultiNight === true ) return;
      self.entries[index].enabled = node.checked;
      for ( let c = 0; c < 10; ++c )
         node.setTextColor( c, node.checked ? 0xff202020 : 0xffd00000 );
      self.runButton.enabled = self.entries.some(
         function( entry ) { return entry.enabled; } ) &&
         self.integrationSeries.length == 0;
   };

   this.updateTree = function( preferredIndex )
   {
      if ( preferredIndex === undefined )
         preferredIndex = self.inputPreviewIndex === undefined ?
            0 : self.inputPreviewIndex;
      self.imagesTree.clear();
      for ( let i = 0; i < self.entries.length; ++i ) {
         let entry = self.entries[i];
         let displayWindow = entry.loaderPreviewWindow != null &&
            !entry.loaderPreviewWindow.isNull ?
            entry.loaderPreviewWindow : entry.window;
         let displayImage = displayWindow.mainView.image;
         let node = new TreeBoxNode( self.imagesTree );
         node.__index__ = i;
         node.checkable = entry.generatedMultiNight !== true;
         node.checked = entry.enabled;
         node.setText( 1, entry.generatedMultiNight === true ? "—" :
            (entry.multiExposureSelected ? "★" : "☆") );
         node.setText( 2, displayWindow.mainView.id );
         node.setText( 3, StartExposureText( entry.exposure ) );
         node.setText( 4, entry.filter );
         node.setText( 5, entry.camera );
         node.setText( 6, displayImage.width + " × " + displayImage.height );
         node.setText( 7, entry.quality == null ? "—" :
            format( "%.3f", entry.quality.score ) );
         node.setText( 8, entry.projectStatus );
         node.setText( 9, entry.id == self.referenceId ? "✓" : "" );
         if ( entry.generatedMultiNight === true )
            for ( let column = 0; column < 10; ++column ) {
               node.setBackgroundColor( column, 0xffd9f2dd );
               node.setTextColor( column, 0xff126b2d );
            }
         else if ( entry.multiExposureSelected || entry.hdrCompatible )
            for ( let column = 0; column < 10; ++column ) {
               node.setBackgroundColor( column, 0xffffbd66 );
               node.setTextColor( column, 0xff202020 );
            }
         else if ( !entry.enabled )
            for ( let column = 0; column < 10; ++column )
               node.setTextColor( column, 0xffd00000 );
      }
      if ( self.entries.length > 0 ) {
         preferredIndex = Math.range( preferredIndex, 0,
            self.entries.length - 1 );
         self.selectInputPreview( preferredIndex );
         let current = self.imagesTree.child( preferredIndex );
         if ( current != null ) self.imagesTree.currentNode = current;
      } else {
         self.inputPreviewIndex = -1;
         self.inputPreview.setBitmap( null );
         self.inputZoomInButton.enabled = false;
         self.inputPanButton.enabled = false;
         self.inputZoomOutButton.enabled = false;
         self.inputQuickStretchLinkButton.enabled = false;
         self.inputCombineButton.enabled = false;
         self.inputCombineButton.checked = false;
         self.inputCropButton.enabled = false;
         self.inputResetBridgeButton.enabled = false;
      }
   };

   this.presentPreparedInBridge = function()
   {
      let sourceEntries = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true )
            sourceEntries.push( self.entries[i] );
      self.entries = sourceEntries;
      let prepared = self.croppedSeries.length > 0 ?
         self.croppedSeries : self.registeredSeries;
      for ( let i = 0; i < self.entries.length; ++i )
         self.entries[i].loaderPreviewWindow = null;
      for ( let i = 0; i < prepared.length; ++i ) {
         let source = StartSeriesSourceEntry( prepared[i] );
         let preparedWindow = prepared[i].window || prepared[i];
         for ( let j = 0; j < self.entries.length; ++j )
            if ( self.entries[j] === source ||
                 self.entries[j].id == (source != null ? source.id : "") ) {
               self.entries[j].loaderPreviewWindow = preparedWindow;
               break;
            }
      }
      let resultIndex = self.inputPreviewIndex;
      for ( let i = 0; i < self.integrationSeries.length; ++i ) {
         let resultWindow = self.integrationSeries[i].window ||
            self.integrationSeries[i];
         if ( resultWindow == null || resultWindow.isNull ) continue;
         let resultEntry = StartImageEntry( resultWindow );
         resultEntry.generatedMultiNight = true;
         resultEntry.enabled = false;
         resultEntry.projectCompatible = false;
         resultEntry.projectStatus = "✓ Multi-night result";
         resultEntry.loaderPreviewWindow = resultWindow;
         self.entries.push( resultEntry );
         resultIndex = self.entries.length - 1;
      }
      self.updateTree( resultIndex );
      self.inputCropButton.enabled = self.registeredSeries.length >= 2;
      self.inputResetBridgeButton.enabled = prepared.length > 0;
      self.runButton.enabled = self.entries.some(
         function( entry ) { return entry.enabled; } ) &&
         self.integrationSeries.length == 0;
      let resultType = self.croppedSeries.length > 0 ? "cropped" :
         (self.registeredSeries.length > 1 ? "registered" : "prepared");
      self.status.text = self.integrationSeries.length > 0 ?
         "<b>Multi-night integration completed.</b><br/>The combined result " +
         "is selected in the table. Registered copies and originals remain " +
         "unchanged." :
         "<b>Multi-night preparation completed.</b><br/>" + prepared.length +
         " " + resultType + " image(s) are ready. If registration borders " +
         "remain, use Crop to continue the combination.";
   };

   this.runUnifiedMultiNightCombination = function()
   {
      if ( !self.multiExposureConfigured ) return false;
      self.acquisitionCombo.currentItem = 1;
      self.combinationChoiceConfirmed = true;
      self.combinationPreviewGenerated = false;
      self.reviewNextButton.onClick();
      return self.integrationSeries.length > 0;
   };

   this.offerMultiNightSave = function()
   {
      if ( self.multiNightSaveOffered || self.integrationSeries.length == 0 )
         return;
      self.multiNightSaveOffered = true;
      self.runButton.enabled = false;
      self.runButton.update();
      let masterDirectory = StartSubframeMasterDirectory();
      let saveChoice = StartSubframeAskToSaveMasters( masterDirectory, {
         dialogTitle: "🔭 InNova Multi-Night — Save master files",
         iconName: "bridge",
         heading: "Save master files?",
         completedText: "The multi-night combination has finished successfully.",
         locationIntro: "Combination completed successfully."
      } );
      if ( saveChoice.answer != StdButton_Yes ) {
         self.status.text += "<br/>The combined master remains open in PixInsight.";
         return;
      }
      let saved = [];
      let failed = [];
      for ( let i = 0; i < self.integrationSeries.length; ++i ) {
         let window = self.integrationSeries[i].window ||
            self.integrationSeries[i];
         if ( window == null || window.isNull || window.mainView.isNull )
            continue;
         let sourceName = StartSafeId( window.mainView.id ) + ".xisf";
         let target = StartSubframeUniqueMasterPath(
            saveChoice.directory, sourceName );
         try {
            if ( !window.saveAs( target, false, false, false, false ) )
               throw new Error( "PixInsight did not save the image." );
            saved.push( target );
         } catch ( error ) {
            failed.push( window.mainView.id + ": " + error );
         }
      }
      if ( saved.length > 0 ) {
         self.status.text += "<br/><b>Saved " + saved.length +
            " combined master file(s)</b> in " +
            StartHTMLText( saveChoice.directory ) + ".";
         console.noteln( "✅ Saved " + saved.length +
            " combined Multi-Night master file(s) in: " +
            saveChoice.directory );
      }
      if ( failed.length > 0 )
         new MessageBox( "Some combined master files could not be saved:\n\n" +
            failed.join( "\n" ),
            "🔭 InNova Multi-Night — Save master files",
            StdIcon_Error, StdButton_Ok ).execute();
   };

   this.inputCropInteractionActive = false;
   this.inputCropControlStates = null;
   this.setInputCropInteractionActive = function( active )
   {
      active = active === true;
      if ( active == self.inputCropInteractionActive ) return;
      self.inputCropInteractionActive = active;
      if ( active ) {
         let controls = [ self.imagesTree, self.runButton, self.closeButton,
            self.consoleButton, self.arrangeButton, self.loadButton,
            self.subframeMastersButton, self.refreshButton, self.clearButton,
            self.cleanOutputsButton, self.inputZoomInButton,
            self.inputPanButton, self.inputZoomOutButton,
            self.inputQuickStretchLinkButton, self.inputCombineButton ];
         self.inputCropControlStates = controls.map( function( control ) {
            let state = { control: control, enabled: control.enabled };
            control.enabled = false;
            return state;
         } );
         self.inputCropResetEnabled = self.inputResetBridgeButton.enabled;
         self.inputCropResetToolTip = self.inputResetBridgeButton.toolTip;
         self.inputResetBridgeButton.enabled = true;
         self.inputResetBridgeButton.toolTip =
            "Cancel the crop selection and keep the prepared images";
      } else {
         for ( let i = 0; i < self.inputCropControlStates.length; ++i ) {
            let state = self.inputCropControlStates[i];
            state.control.enabled = state.enabled;
         }
         self.inputCropControlStates = null;
         self.inputResetBridgeButton.enabled = self.inputCropResetEnabled;
         self.inputResetBridgeButton.toolTip = self.inputCropResetToolTip;
      }
   };

   this.inputCropButton.onClick = function()
   {
      if ( self.registeredSeries.length < 2 ) return;
      if ( self.inputPreview.cropSelection == null ) {
         self.inputPreview.setCropMode( true );
         if ( !self.inputPreview.cropMode ) return;
         self.setInputCropInteractionActive( true );
         self.inputCropButton.checked = true;
         self.status.text = "<b>Visual crop:</b> Drag over the Preview to " +
            "draw the area to keep. Then click Crop again to apply it to " +
            "all registered images.";
         return;
      }
      let selectedCrop = self.inputPreview.cropSelection;
      if ( selectedCrop.width < 64 || selectedCrop.height < 64 ) {
         new MessageBox(
            "The crop rectangle must be at least 64 × 64 pixels.",
            "🔭 InNova Multi-Night — Crop",
            StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      if ( StartAskCenteredQuestion(
           "🔭 InNova Multi-Night — Confirm crop",
           "Apply the selected crop to all registered images?",
           true, "Apply this crop?" ) != StdButton_Yes ) return;
      self.cropRectangle = { x: selectedCrop.x, y: selectedCrop.y,
         width: selectedCrop.width, height: selectedCrop.height,
         sourceWidth: self.inputPreview.sourceWidth,
         sourceHeight: self.inputPreview.sourceHeight,
         coverage: 100*selectedCrop.width*selectedCrop.height/
            (self.inputPreview.sourceWidth*self.inputPreview.sourceHeight),
         step: 0 };
      self.applyCropButton.enabled = true;
      self.setInputCropInteractionActive( false );
      let inputDialogEnabled = self.enabled;
      self.enabled = false;
      try {
         self.inputPreview.clearCrop();
         self.inputCropButton.checked = false;
         self.combinationPreviewGenerated = false;
         if ( self.cropRectangle != null && self.applyCropButton.enabled ) {
            let cropApplied = self.applyCropButton.onClick() === true;
            if ( cropApplied ) {


               self.multiExposureCropRequired = false;
               self.multiExposureManualCropStarted = false;
               self.multiExposureSynchronizedCropAccepted = true;
               let completed = self.runUnifiedMultiNightCombination();
               self.presentPreparedInBridge();
               if ( completed ) {
                  self.offerMultiNightSave();
                  self.continueGuidedMultiNightToProcessor();
               }
            }
         }
      } finally {
         self.enabled = inputDialogEnabled;
      }
   };

   this.inputPreview.onCropSelected = function( rectangle )
   {
      self.status.text = "<b>Visual crop ready:</b> " + rectangle.width +
         " × " + rectangle.height + " pixels. Click Crop again to apply " +
         "it to the complete multi-night sequence.";
   };

   this.inputResetBridgeButton.onClick = function()
   {
      if ( self.inputCropInteractionActive ) {
         self.inputPreview.clearCrop();
         self.inputCropButton.checked = false;
         self.setInputCropInteractionActive( false );
         self.status.text = "Crop selection cancelled. Prepared images are unchanged.";
         return;
      }
      StartCloseSeriesWindows( self.croppedSeries );
      StartCloseSeriesWindows( self.registeredSeries );
      self.croppedSeries = [];
      self.registeredSeries = [];
      self.clearDerivedSeries();
      self.cropRectangle = null;
      self.inputPreview.clearCrop();
      self.inputCropButton.checked = false;
      self.referenceId = "";
      self.combinationPreviewGenerated = false;
      self.multiNightSaveOffered = false;
      for ( let i = 0; i < self.entries.length; ++i ) {
         self.entries[i].loaderPreviewWindow = null;
         self.entries[i].quality = null;
         self.entries[i].projectStatus = "Pending";
      }
      self.updateTree( self.inputPreviewIndex );
      self.inputCropButton.enabled = false;
      self.inputResetBridgeButton.enabled = false;
      self.status.text = "Multi-Night reset. The original input " +
         "images are shown and remain selected.";
   };

   this.deleteAuxiliaryImages = function( auxiliary )
   {
      let removed = {};
      let count = 0;
      for ( let i = 0; i < auxiliary.length; ++i ) {
         let entry = auxiliary[i];
         try {
            if ( entry.window != null && !entry.window.isNull )
               entry.window.forceClose();
            removed[entry.id] = true;
            ++count;
         } catch ( error ) {
            console.warningln( "⚠️ Could not close auxiliary image " +
               entry.id + ": " + error );
         }
      }
      let retained = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( !removed[self.entries[i].id] )
            retained.push( self.entries[i] );
      self.entries = retained;
      return count;
   };

   this.refreshImages = function( showWarning )
   {
      self.entries = [];
      self.registeredSeries = [];
      self.croppedSeries = [];


      self.integrationSeries = [];
      self.hdrSeries = [];
      self.multiNightSaveOffered = false;
      self.cropRectangle = null;
      self.referenceId = "";
      self.multiExposureConfigured = false;
      self.combinationPreviewGenerated = false;
      self.combinationChoiceConfirmed = false;
      self.multiExposureCropRequired = false;
      self.multiExposureManualCropStarted = false;
      self.multiExposureSynchronizedCropAccepted = false;
      self.combineDifferentFilters = false;
      self.updateReviewNextButton();
      self.autoBrightTarget = false;
      self.acquisitionCombo.currentItem = 0;
      self.objectCombo.currentItem = 0;
      self.imageViewer.setSeries( [], "" );
      let windows = ImageWindow.windows;
      let auxiliary = [];
      for ( let i = 0; i < windows.length; ++i ) {
         if ( windows[i] == null || windows[i].isNull ||
              windows[i].mainView.isNull )
            continue;
         let id = windows[i].mainView.id;
         if ( StartIsTransientBridgeOutput( id ) )
            continue;
         let entry = StartImageEntry( windows[i] );
         self.entries.push( entry );
         if ( entry.auxiliaryReason.length > 0 )
            auxiliary.push( entry );
      }
      let deletedAuxiliary = 0;
      let deleteAccepted = false;
      if ( showWarning && auxiliary.length > 0 ) {
         let auxiliaryDialog = new StartAuxiliaryImagesDialog( auxiliary );
         if ( auxiliaryDialog.execute() == StdDialogCode_Ok ) {
            deleteAccepted = true;
            deletedAuxiliary = self.deleteAuxiliaryImages( auxiliary );
         }
      }
      self.updateTree();
      let usableCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].enabled ) ++usableCount;
      self.runButton.enabled = usableCount > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.cropValueLabel.text =
         "Click Crop, then drag over the image to select the area to keep.";
      if ( auxiliary.length > 0 ) {
         self.status.text = deleteAccepted ?
            "<b>" + deletedAuxiliary +
            " auxiliary image(s) were deleted.</b> They were removed from " +
            "Input images and closed in PixInsight." :
            "<b style=\"color:#b05a00\">Project warning:</b> " +
            auxiliary.length + " auxiliary image(s) were left unchecked.";
      } else
         self.status.text = self.entries.length > 0 ?
            "Detected:<br/><b>" + self.entries.length +
            " open source image(s)</b>." :
            "Load or open your astronomical images.<br/>" +
            "<b>To create a multi-night integration</b>, add compatible images " +
            "of the same target captured on different nights.";
      if ( usableCount > 0 )
         self.status.text +=
            "<br/><span style=\"color:#165bb5\"><b>Check</b> that all the loaded images are correct." +
            "<br/>Click <b>Run</b> to begin processing.</span>";
   };

   this.loadButton.onClick = function()
   {
      let dialog = new OpenFileDialog;
      dialog.multipleSelections = true;
      dialog.caption = "🔭 InNova Multi-Night — Load images";
      let rawExtensions =
         "*.raw *.RAW *.dng *.DNG *.cr2 *.CR2 *.cr3 *.CR3 " +
         "*.nef *.NEF *.nrw *.NRW *.arw *.ARW *.srf *.SRF *.sr2 *.SR2 " +
         "*.raf *.RAF *.orf *.ORF *.ori *.ORI *.rw2 *.RW2 *.rwl *.RWL " +
         "*.pef *.PEF *.ptx *.PTX *.3fr *.3FR *.fff *.FFF *.iiq *.IIQ " +
         "*.mos *.MOS *.mef *.MEF *.mrw *.MRW *.x3f *.X3F *.kdc *.KDC " +
         "*.dcr *.DCR *.erf *.ERF *.bay *.BAY *.cap *.CAP *.eip *.EIP";
      dialog.filters = [ [ "Supported astronomical and camera images",
         "*.xisf *.fits *.fit *.fts *.tif *.tiff *.TIF *.TIFF " +
         rawExtensions ],
                         [ "Camera RAW images — all manufacturers",
                           rawExtensions ],
                         [ "Vaonis TIFF images", "*.tif *.tiff *.TIF *.TIFF" ],
                         [ "All files", "*" ] ];
      if ( self.nextLoadInitialPath != null &&
           self.nextLoadInitialPath.length > 0 )
         dialog.initialPath = self.nextLoadInitialPath;
      self.nextLoadInitialPath = "";
      if ( !dialog.execute() )
         return;
      let paths = dialog.filePaths;
      let openedWindows = [];
      let failedPaths = [];
      self.beginElapsed( "Loading 0 / " + paths.length + " image(s)…" );
      for ( let i = 0; i < paths.length; ++i ) {
         self.elapsedMessage = "Loading " + (i + 1) + " / " +
            paths.length + " image(s)…";
         self.elapsedTimer.onTimeout();
         CoreApplication.processEvents();
         try {
            let opened = ImageWindow.open( paths[i] );
            if ( opened.length == 0 ) failedPaths.push( paths[i] );
            for ( let j = 0; j < opened.length; ++j ) {
               opened[j].iconize();
               openedWindows.push( opened[j] );
            }
         } catch ( error ) {
            console.warningln( "⚠️ Could not open " + paths[i] + ": " + error );
            failedPaths.push( paths[i] );
         }
      }
      if ( openedWindows.length > 0 )
         MiraPrepareWorkspaceForRun( self );
      let loadElapsed = self.finishElapsed();
      let known = {};
      for ( let i = 0; i < self.entries.length; ++i )
         known[self.entries[i].id] = true;
      let auxiliary = [];
      for ( let i = 0; i < openedWindows.length; ++i ) {
         let entry = StartImageEntry( openedWindows[i] );
         if ( known[entry.id] ) continue;
         self.entries.push( entry );
         known[entry.id] = true;
         if ( entry.auxiliaryReason.length > 0 ) auxiliary.push( entry );
      }
      let auxiliaryDialog = auxiliary.length > 0 ?
         new StartAuxiliaryImagesDialog( auxiliary ) : null;
      let deleteAccepted = auxiliaryDialog != null &&
         auxiliaryDialog.execute() == StdDialogCode_Ok;
      let deletedAuxiliary = deleteAccepted ?
         self.deleteAuxiliaryImages( auxiliary ) : 0;
      self.registeredSeries = [];
      self.croppedSeries = [];
      self.clearDerivedSeries();
      self.cropRectangle = null;
      self.referenceId = "";
      self.autoBrightTarget = false;
      self.objectCombo.currentItem = 0;
      self.imageViewer.setSeries( [], "" );
      self.updateTree();
      let usableCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].enabled ) ++usableCount;
      self.runButton.enabled = usableCount > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.status.text = "Loaded <b>" +
         Math.max( 0, openedWindows.length - deletedAuxiliary ) +
         " image(s)</b> from disk. " + StartElapsedRichText( loadElapsed ) +
         (failedPaths.length > 0 ? " <b style=\"color:#b05a00\">" +
          failedPaths.length + " file(s) could not be decoded by " +
          "PixInsight.</b>" : "") +
         (deleteAccepted ? " <b>" + deletedAuxiliary +
          " auxiliary image(s) were deleted.</b>" :
          (auxiliary.length > 0 ? " <b style=\"color:#b05a00\">" +
           auxiliary.length +
           " auxiliary image(s) were left unchecked.</b>" : ""));
      if ( usableCount > 0 )
         self.status.text +=
            "<br/><span style=\"color:#165bb5\"><b>Check</b> that all the loaded images are correct." +
            "<br/>Click <b>Run</b> to begin processing.</span>";
      if ( failedPaths.length > 0 ) {
         let failedNames = [];
         for ( let i = 0; i < failedPaths.length && i < 8; ++i )
            failedNames.push( "• " + failedPaths[i] );
         new MessageBox(
            "PixInsight could not decode these selected camera RAW files:\n\n" +
            failedNames.join( "\n" ) +
            (failedPaths.length > 8 ? "\n• …" : "") +
            "\n\nCheck that the DSLR_RAW format module in PixInsight supports " +
            "the camera model and that the file is not damaged.",
            "🔭 InNova Multi-Night — RAW decoding warning",
            StdIcon_Warning, StdButton_Ok ).execute();
      }
   };

   this.subframeMastersButton.onClick = function()
   {
      self.nextLoadInitialPath = StartSubframeMasterDirectory();
      self.loadButton.onClick();
   };

   this.refreshButton.onClick = function() { self.refreshImages( true ); };

   this.clearButton.onClick = function()
   {
      let nodes = self.imagesTree.selectedNodes;
      if ( nodes.length == 0 && self.imagesTree.currentNode != null )
         nodes = [ self.imagesTree.currentNode ];
      if ( nodes.length == 0 ) return;
      let selected = [];
      let preferredIndex = self.entries.length;
      for ( let i = 0; i < nodes.length; ++i ) {
         let index = nodes[i].__index__;
         if ( index < 0 || index >= self.entries.length ) continue;
         selected.push( self.entries[index] );
         preferredIndex = Math.min( preferredIndex, index );
      }
      if ( selected.length == 0 ) return;
      let answer = StartAskCenteredQuestion(
         "🔭 InNova Multi-Night — Remove selected images",
         "Do you want to remove the selected images from the list?", true );
      if ( answer != StdButton_Yes ) return;
      for ( let i = 0; i < selected.length; ++i )
         self.imageViewer.onRemoveRequested( selected[i], preferredIndex, true );
   };

   this.cleanOutputsButton.onClick = function()
   {
      let generated = [];
      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              StartIsGeneratedOutput( windows[i].mainView.id ) )
            generated.push( windows[i] );
      if ( generated.length == 0 ) {
         self.status.text = "There are no generated registration, integration, crop or HDR " +
            "results to clean. Original input images remain ready.";
         return;
      }
      let answer = StartAskCenteredQuestion(
         "🔭 InNova Multi-Night — Clean generated results",
         "Do you want to close " + generated.length +
         " generated registration/integration/crop/HDR image(s) in PixInsight?\n\n" +
         "Only generated results will be removed. Original input images " +
         "will remain open and loaded so you can run the project again.", true );
      if ( answer != StdButton_Yes ) return;
      for ( let i = 0; i < generated.length; ++i )
         if ( !generated[i].isNull ) generated[i].forceClose();
      let kept = [];
      for ( let i = 0; i < self.entries.length; ++i )
         if ( !StartIsGeneratedOutput( self.entries[i].id ) &&
              self.entries[i].window != null &&
              !self.entries[i].window.isNull )
            kept.push( self.entries[i] );
      self.entries = kept;
      self.registeredSeries = [];
      self.croppedSeries = [];
      self.integrationSeries = [];
      self.hdrSeries = [];
      self.cropRectangle = null;
      self.referenceId = "";
      self.imageViewer.setSeries( [], "" );
      self.updateTree();
      self.runButton.enabled = self.entries.length > 0;
      self.autoCropButton.enabled = false;
      self.cropButton.enabled = false;
      self.applyCropButton.enabled = false;
      self.status.text = "Closed <b>" + generated.length +
         " generated image(s)</b>. The original inputs remain ready to run again.";
   };

   this.analyzeProject = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length < 1 ) {
         new MessageBox( "Select at least one image.", "🔭 InNova Multi-Night",
            StdIcon_Warning, StdButton_Ok ).execute();
         return false;
      }
      self.enabled = false;
      console.noteln( "🔎 Analyzing image quality and metadata…" );
      self.status.text = "Analyzing image quality and metadata…";
      CoreApplication.processEvents();
      let best = null;
      let groups = {};
      let geometryGroups = {};
      for ( let i = 0; i < selected.length; ++i ) {
         selected[i].quality = StartImageQuality( selected[i].window );
         let key = StartExposureText( selected[i].exposure ) + " | " +
            selected[i].filter + " | " + selected[i].camera + " | " +
            selected[i].width + "x" + selected[i].height;
         groups[key] = (groups[key] || 0) + 1;
         let geometryKey = selected[i].width + "x" + selected[i].height +
            "x" + selected[i].channels;
         if ( geometryGroups[geometryKey] == null )
            geometryGroups[geometryKey] = [];
         geometryGroups[geometryKey].push( selected[i] );
         CoreApplication.processEvents();
      }
      let dominant = null;
      for ( let geometryKey in geometryGroups )
         if ( dominant == null ||
              geometryGroups[geometryKey].length > dominant.length )
            dominant = geometryGroups[geometryKey];
      for ( let i = 0; i < dominant.length; ++i )
         if ( best == null || dominant[i].quality.score > best.quality.score )
            best = dominant[i];
      self.referenceId = best.id;
      let issues = StartProjectIssues( selected, best );
      let acquisitionValues = [ "SINGLE_NIGHT", "MULTI_NIGHT", "HDR" ];
      self.projectDiagnosis = StartClassifyProject( selected,
         acquisitionValues[self.acquisitionCombo.currentItem] );
      self.projectDiagnosis.detail = "Project: " +
         self.projectCombo.itemText( self.projectCombo.currentItem ) +
         "; Object: " +
         self.objectCombo.itemText( self.objectCombo.currentItem ) + ". " +
         self.projectDiagnosis.detail;
      for ( let i = 0; i < selected.length; ++i )
      {
         selected[i].projectStatus = "Compatible";
         selected[i].projectCompatible = true;
      }
      let compatibleEntries = [];
      for ( let i = 0; i < selected.length; ++i ) {
         selected[i].hdrCompatible = false;
         selected[i].hdrGroup = "";
      }
      for ( let i = 0; i < selected.length; ++i ) {
         let hasIssue = false;
         for ( let j = 0; j < issues.length; ++j )
            if ( issues[j].entry === selected[i] ) {
               hasIssue = true;
               break;
            }
         if ( !hasIssue ) compatibleEntries.push( selected[i] );
      }
      let hdrDetectionEntries = [];
      for ( let i = 0; i < compatibleEntries.length; ++i )
         if ( !self.multiExposureConfigured ||
              compatibleEntries[i].multiExposureSelected === true )
            hdrDetectionEntries.push( compatibleEntries[i] );
      let hdrGroups = StartDetectHDRGroups( hdrDetectionEntries );
      for ( let i = 0; i < compatibleEntries.length; ++i )
         if ( compatibleEntries[i].hdrCompatible )
            compatibleEntries[i].projectStatus = "HDR compatible";
      for ( let i = 0; i < issues.length; ++i )
      {
         issues[i].entry.projectCompatible = false;
         issues[i].entry.projectStatus = "⚠ Review";
      }
      self.updateTree();
      let groupCount = 0;
      for ( let key in groups ) ++groupCount;
      self.status.text = "<b>Project diagnosis: " +
         self.projectDiagnosis.title + ".</b> " +
         self.projectDiagnosis.detail + "<br/>Reference selected from the " +
         "dominant geometry: <b>" +
         best.id + "</b>. Detected <b>" + groupCount +
         " exposure/filter/camera group(s)</b>." +
         (issues.length > 0 ? " <b style=\"color:#b05a00\">" +
          issues.length + " image(s) require review before registration.</b>" :
          " All selected images pass the project preflight.");
      if ( hdrGroups.length > 0 ) {
         let hdrDescriptions = [];
         for ( let i = 0; i < hdrGroups.length; ++i ) {
            let names = [];
            for ( let j = 0; j < hdrGroups[i].entries.length; ++j )
               names.push( hdrGroups[i].entries[j].id );
            hdrDescriptions.push( hdrGroups[i].label + ": " +
               names.join( ", " ) );
         }
         self.status.text +=
            "<br/><b style=\"color:#d66a00\">HDR-compatible images:</b> " +
            hdrDescriptions.join( "; " ) +
            ". These images are compatible and will be combined in the HDR stage.";
      }
      self.enabled = true;
      console.noteln( "🔎 Project diagnosis: " + self.projectDiagnosis.title );
      console.writeln( "ℹ️ " + self.projectDiagnosis.detail );
      return true;
   };

   this.registerProject = function()
   {
      self.lastRegistrationFailure = "";
      let selected = self.selectedEntries();
      if ( selected.length < 2 || self.referenceId.length == 0 ) return false;
      let reference = null;
      for ( let i = 0; i < selected.length; ++i )
         if ( selected[i].id == self.referenceId ) reference = selected[i];
      if ( reference == null ) {
         self.status.text = "The selected reference is no longer enabled. Analyze again.";
         return false;
      }
      let projectIssues = StartProjectIssues( selected, reference );
      if ( projectIssues.length > 0 ) {
         let warningDialog = new StartUnrelatedImagesDialog(
            reference.id, projectIssues );
         if ( warningDialog.execute() != StdDialogCode_Ok ) {
            self.status.text = "Registration cancelled so the project " +
               "selection can be reviewed.";
            return false;
         }
      }
      self.beginElapsed( "Registering images with StarAlignment…", false );
      self.enabled = false;
      console.noteln( "⭐ Registering copies with StarAlignment…" );
      CoreApplication.processEvents();
      let registrationSucceeded = false;
      try {
         let targets = [];
         for ( let i = 0; i < selected.length; ++i )
            if ( selected[i].id != reference.id )
               targets.push( [ true, false, selected[i].id ] );
         let idsBefore = StartWindowIdSet();
         let alignment = new StarAlignment;
         alignment.structureLayers = 5;
         alignment.noiseLayers = 1;
         alignment.referenceImage = reference.id;
         alignment.referenceIsFile = false;
         alignment.targets = targets;
         alignment.mode = 0;
         alignment.outputPrefix = "";
         alignment.outputPostfix = InNovaStartRegisteredSuffix;
         alignment.outputExtension = ".xisf";
         alignment.writeKeywords = true;
         let alignmentCompleted = alignment.executeGlobal();
         self.registeredSeries = [];
         let referenceCopy = StartCloneWindow( reference.window,
            reference.id + InNovaStartRegisteredSuffix );
         self.registeredSeries.push( { window: referenceCopy,
            source: reference } );
         let failed = [];
         for ( let i = 0; i < selected.length; ++i ) {
            if ( selected[i].id == reference.id ) continue;
            let registered = StartFindNewRegisteredWindow(
               selected[i].id, idsBefore );
            if ( registered == null || registered.isNull ) {
               failed.push( selected[i].id );
               selected[i].projectStatus = "Registration failed";
            } else {


               registered = StartRenameRegisteredWindow(
                  registered, selected[i].id );
               self.registeredSeries.push( { window: registered,
                  source: selected[i] } );


               selected[i].projectCompatible = true;
               selected[i].projectStatus = selected[i].hdrCompatible ?
                  "HDR compatible · Registered" : "Registered";
            }
         }
         reference.projectCompatible = true;
         reference.projectStatus = reference.hdrCompatible ?
            "HDR compatible · Reference" : "Reference";
         self.updateTree();
         if ( self.registeredSeries.length < 2 )
            throw new Error( "No target image could be registered to " +
               reference.id + ". The images may belong to different " +
               "objects or may not contain enough common stars." );
         self.autoCropButton.enabled = true;
         self.cropButton.enabled = true;
         self.croppedSeries = [];
         let registeredViewer = self.buildViewerSeries(
            self.registeredSeries, "Registered images" );
         self.imageViewer.setSeries(
            registeredViewer.series, registeredViewer.label );
         registrationSucceeded = true;
         if ( failed.length > 0 ) {
            self.status.text = "<b>Project diagnosis: " +
               self.projectDiagnosis.title + ".</b> " +
               self.projectDiagnosis.detail + "<br/>" +
               "<b style=\"color:#b05a00\">Registration " +
               "warning:</b> " + (self.registeredSeries.length - 1) +
               " target(s) succeeded and " + failed.length +
               " failed. Failed images were excluded from the crop.";
            StartShowMultiNightRegistrationWarning( reference.id, failed );
         } else {
            self.status.text = "<b>Project diagnosis: " +
               self.projectDiagnosis.title + ".</b> " +
               self.projectDiagnosis.detail + "<br/>Created <b>" +
               self.registeredSeries.length +
               " registered copies</b>. Originals remain unchanged.";
         }
         let hdrNamesByGroup = {};
         for ( let i = 0; i < self.registeredSeries.length; ++i ) {
            let source = StartSeriesSourceEntry( self.registeredSeries[i] );
            if ( source != null && source.hdrCompatible ) {
               if ( hdrNamesByGroup[source.hdrGroup] == null )
                  hdrNamesByGroup[source.hdrGroup] = [];
               hdrNamesByGroup[source.hdrGroup].push( source.id );
            }
         }
         let registeredHDRDescriptions = [];
         for ( let groupName in hdrNamesByGroup )
            registeredHDRDescriptions.push( groupName + ": " +
               hdrNamesByGroup[groupName].join( ", " ) );
         if ( registeredHDRDescriptions.length > 0 )
            self.status.text +=
               "<br/><b style=\"color:#d66a00\">HDR-compatible images:</b> " +
               registeredHDRDescriptions.join( "; " ) +
               ". These images are compatible and will be combined in " +
               "the HDR stage.";
         if ( self.hdrSeries.length > 0 )
            self.status.text += "<br/><b style=\"color:#d66a00\">HDR " +
               "created:</b> " + self.hdrSeries.length +
               " HDR composition(s) have been appended after the individual " +
               "images in the viewer.";
         if ( self.integrationSeries.length > 0 )
            self.status.text += "<br/><b>Multi-night integration created:</b> " +
               self.integrationSeries.length +
               " compatible same-capture group(s) were averaged and appended " +
               "after the individual images in the viewer.";
         if ( !alignmentCompleted && failed.length == 0 )
            console.warningln( "⚠️ StarAlignment reported an incomplete run, " +
               "but every requested registered view was recovered." );
      } catch ( error ) {
         self.lastRegistrationFailure = String( error );
         let recoverable =
            self.lastRegistrationFailure.indexOf(
               "No target image could be registered" ) >= 0 ||
            self.lastRegistrationFailure.indexOf(
               "not contain enough common stars" ) >= 0;
         if ( recoverable ) {
            console.writeln(
               "⚙️ InNova Multi-Night registration adjustment: " + error );
            self.status.text =
               "<b>Registration adjustment:</b> " + error;
         } else {
            console.criticalln(
               "❌ InNova Multi-Night registration failed: " + error );
            self.status.text =
               "<b style=\"color:#c33\">Registration failed:</b> " + error;
         }
      }
      let registrationElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( registrationElapsed );
      self.enabled = true;
      return registrationSucceeded;
   };

   this.prepareSingleImage = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length != 1 ) return false;
      let source = selected[0];
      self.enabled = false;
      console.noteln( "🖼️ Preparing a non-destructive review copy…" );
      self.status.text = "Preparing a non-destructive review copy…";
      CoreApplication.processEvents();
      try {
         let copy = StartCloneWindow( source.window,
            source.id + InNovaStartRegisteredSuffix );
         self.registeredSeries = [ { window: copy, source: source } ];
         self.croppedSeries = [];
         self.clearDerivedSeries();
         self.cropRectangle = null;
         source.projectStatus = "Reference";
         self.updateTree();
         self.imageViewer.setSeries( self.registeredSeries,
            "Review copy" );
         self.autoCropButton.enabled = false;
         self.cropButton.enabled = true;
         self.applyCropButton.enabled = false;
         self.status.text =
            "Created a <b>non-destructive review copy</b> of " + source.id +
            ". The original image remains unchanged.";
         self.imageViewer.updateInformation();
         return true;
      } catch ( error ) {
         console.criticalln( "❌ InNova Multi-Night single-image preparation failed: " +
            error );
         self.status.text =
            "<b style=\"color:#c33\">Single-image preparation failed:</b> " +
            error;
         return false;
      } finally {
         self.enabled = true;
      }
   };

   this.prepareBrightTargetImages = function()
   {
      let selected = self.selectedEntries();
      if ( selected.length < 2 ) return false;
      self.enabled = false;
      self.status.text =
         "Preparing non-destructive Sun/Moon review copies without stellar alignment…";
      console.noteln( "☀️ " + self.status.text );
      CoreApplication.processEvents();
      try {
         StartCloseSeriesWindows( self.registeredSeries );
         self.registeredSeries = [];
         self.croppedSeries = [];
         self.clearDerivedSeries();
         self.cropRectangle = null;
         let sameGeometry = true;
         let width = selected[0].width;
         let height = selected[0].height;
         let channels = selected[0].channels;
         for ( let i = 0; i < selected.length; ++i )
            if ( selected[i].width != width ||
                 selected[i].height != height ||
                 selected[i].channels != channels ) sameGeometry = false;
         for ( let i = 0; i < selected.length; ++i ) {
            let source = selected[i];
            let copy = StartCloneWindow( source.window,
               source.id + InNovaStartBrightTargetSuffix );
            self.registeredSeries.push( { window: copy, source: source } );
            source.projectCompatible = sameGeometry;
            source.projectStatus = source.id == self.referenceId ?
               "Bright-target reference" : "Bright-target review";
         }
         self.updateTree();
         self.imageViewer.setSeries( self.registeredSeries,
            "Bright-target review copies" );
         self.autoCropButton.enabled = sameGeometry;
         self.cropButton.enabled = true;
         self.applyCropButton.enabled = false;
         self.status.text =
            "Created <b>" + self.registeredSeries.length +
            " Sun/Moon review copies</b>. Stellar StarAlignment was skipped " +
            "because bright-target images do not provide a normal star field." +
            (sameGeometry ? " Their geometry is compatible for synchronized crop." :
             " <b style=\"color:#b05a00\">The source geometries differ; " +
             "inspect them before attempting a synchronized crop.</b>");
         self.imageViewer.updateInformation();
         return true;
      } catch ( error ) {
         console.criticalln( "❌ InNova Multi-Night bright-target preparation failed: " +
            error );
         self.status.text =
            "<b style=\"color:#c33\">Bright-target preparation failed:</b> " +
            error;
         return false;
      } finally {
         self.enabled = true;
      }
   };

   this.runPreparationRequested = false;


   this.performRunPreparation = function()
   {
      try {
      self.combinationPreviewGenerated = false;
      self.updateReviewNextButton();
      if ( self.multiExposureConfigured ) {
         let configuredCount = 0;
         let activeEntries = self.selectedEntries();
         for ( let i = 0; i < activeEntries.length; ++i )
            if ( activeEntries[i].multiExposureSelected === true )
               ++configuredCount;
         let required = self.acquisitionCombo.currentItem == 2 ? 3 : 2;
         if ( configuredCount < required ) {
            new MessageBox(
               "The configured Multi-exposure group no longer has enough " +
               "enabled images. Open Multi-exposure and review the selection.",
               "🔭 InNova Multi-Night — Review Multi-exposure selection",
               StdIcon_Warning, StdButton_Ok ).execute();
            return;
         }
      }
      self.objectCombo.currentItem = self.autoBrightTarget ? 1 : 0;
      self.saveHandoffSelections();
      self.hideProcessConsole();
      console.noteln( "⚙️ InNova Multi-Night selection: Project = " +
         self.projectCombo.itemText( self.projectCombo.currentItem ) +
         " | Acquisition = " +
         self.acquisitionCombo.itemText( self.acquisitionCombo.currentItem ) +
         " | Object = " +
         self.objectCombo.itemText( self.objectCombo.currentItem ) );
      if ( !self.analyzeProject() ) return;
      if ( !self.autoBrightTarget && self.selectedEntries().length > 1 ) {
         let referenceEntry = null;
         let preflightEntries = self.selectedEntries();
         for ( let i = 0; i < preflightEntries.length; ++i )
            if ( preflightEntries[i].id == self.referenceId ) {
               referenceEntry = preflightEntries[i];
               break;
            }
         if ( referenceEntry != null ) {
            self.status.text = "Checking the reference star field…";
            CoreApplication.processEvents();
            let starCount = StartPreflightStarCount( referenceEntry.window );
            if ( starCount >= 0 )
               console.writeln(
                  "🔎 InNova Multi-Night star-field preflight: " + starCount +
                  " source(s) detected." );
            if ( starCount >= 0 && starCount < 3 ) {
               self.autoBrightTarget = true;
               self.objectCombo.currentItem = 1;
               self.saveHandoffSelections();
               console.writeln(
                  "⚙️ InNova Multi-Night adjustment: fewer than three stars were " +
                  "detected. Switching to Sun or Moon treatment." );
               self.status.text =
                  "<b>Processing adjustment:</b> No usable stellar field " +
                  "was detected. Continuing with Sun or Moon treatment…";
               CoreApplication.processEvents();
               if ( self.prepareBrightTargetImages() )
                  self.executeReviewStep();
               return;
            }
         }
      }
      if ( self.acquisitionCombo.currentItem == 2 &&
           self.projectDiagnosis.insufficientHDRFilters.length > 0 )
         new MessageBox(
            "Only two compatible images with distinct exposure levels were detected for: " +
            self.projectDiagnosis.insufficientHDRFilters.join( ", " ) +
            ".\n\nInNova Multi-Night requires at least three compatible exposure " +
            "levels for HDR. Registration will continue, but no HDR " +
            "composition will be created.",
            "🔭 InNova Multi-Night — HDR requires three exposures",
            StdIcon_Warning, StdButton_Ok ).execute();
      if ( self.selectedEntries().length == 1 ) {
         if ( self.prepareSingleImage() )
            self.executeReviewStep();
         return;
      }
      if ( self.objectCombo.currentItem == 1 ) {
         if ( self.prepareBrightTargetImages() )
            self.executeReviewStep();
         return;
      }
      if ( self.selectedEntries().length > 1 ) {
         if ( self.registerProject() ) {
            self.imageViewer.updateInformation();
            self.executeReviewStep();
            return;
         }
         let registrationText = String( self.lastRegistrationFailure );
         if ( registrationText.indexOf(
                 "No target image could be registered" ) >= 0 ||
              registrationText.indexOf( "not contain enough common stars" ) >= 0 ) {
            self.autoBrightTarget = true;
            self.objectCombo.currentItem = 1;
            self.saveHandoffSelections();
            console.writeln(
               "⚙️ InNova Multi-Night automatic adjustment: stellar registration found " +
               "no usable star field. Switching to Sun or Moon treatment." );
            self.status.text =
               "<b style=\"color:#168de2\">Sun or Moon detected " +
               "automatically.</b> Stellar registration found no usable " +
               "star field; retrying with bright-target preparation…";
            CoreApplication.processEvents();
            if ( self.prepareBrightTargetImages() )
               self.executeReviewStep();
         }
      }
      } finally {
         self.runButton.enabled = self.integrationSeries.length == 0 &&
            self.entries.some( function( entry ) { return entry.enabled; } );
         self.runButton.update();
      }
   };

   this.runButton.onClick = function()
   {
      if ( self.inputCropInteractionActive || !self.runButton.enabled ) return;
      let combineCount = 0;
      for ( let i = 0; i < self.entries.length; ++i )
         if ( self.entries[i].generatedMultiNight !== true &&
              self.entries[i].enabled &&
              self.entries[i].multiExposureSelected === true )
            ++combineCount;
      if ( combineCount < 2 ) {
         new MessageBox(
            "<p align=\"center\">Select at least <b>two images</b> in " +
            "the Combine column before clicking Run.</p>",
            "🔭 InNova Multi-Night — More images required",
            StdIcon_Information, StdButton_Ok ).execute();
         return;
      }
      self.runButton.enabled = false;
      self.runButton.update();
      CoreApplication.processEvents();
      let confirmationTitle = "🔭 InNova Multi-Night — Run";
      let confirmationText = "Do you want to combine the images?";
      if ( StartAskCenteredQuestion(
           confirmationTitle, confirmationText,
           true, confirmationText ) == StdButton_Yes ) {
         if ( self.unifiedBridgeWindow ) {
            self.runPreparationRequested = false;
            self.performRunPreparation();
         } else {
            self.runPreparationRequested = true;
            self.ok();
         }
      } else {
         self.runButton.enabled = self.entries.some(
            function( entry ) { return entry.enabled; } );
         self.runButton.update();
      }
   };

   this.autoCropButton.onClick = function()
   {
      self.hideProcessConsole();
      self.reviewDialog.enabled = false;
      self.beginElapsed(
         "Calculating the largest safe rectangle at 100% common coverage…",
         true );
      console.noteln(
         "✂️ Calculating the largest safe rectangle at 100% common coverage…" );
      CoreApplication.processEvents();
      try {
         self.cropRectangle = StartCommonCrop( self.registeredSeries,
            self.marginSpin.value );
         let r = self.cropRectangle;
         self.imageViewer.setCropMode( false );
         self.imageViewer.setCropSelection( r );
         self.cropValueLabel.text = "<b>Automatic crop ready.</b> " +
            "The bright rectangle is kept; the shaded area is removed. " +
            "<b>Frame retained:</b> " +
            format( "%.1f%%", r.coverage );
         self.applyCropButton.enabled = true;
         self.status.text = "The automatic crop is ready. The extra safety " +
            "margin is included; applying it will create new copies.";
         self.reviewStatus.text = self.status.text;
      } catch ( error ) {
         self.status.text = "<b style=\"color:#c33\">Crop analysis failed:</b> " + error;
         self.reviewStatus.text = self.status.text;
      }
      let cropElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( cropElapsed );
      self.reviewStatus.text = self.status.text;
      self.reviewDialog.enabled = true;
   };

   this.cropButton.onClick = function()
   {
      if ( self.imageViewer.series.length < 1 ) return;
      self.imageViewer.setCropMode( true );
      self.cropValueLabel.text =
         "<b>Draw on the image:</b> drag a rectangle around the area to keep.";
      self.reviewStatus.text =
         "Crop selection is active. Drag over the image; everything outside " +
         "the rectangle will be removed.";
   };

   this.imageViewer.onCropRequested = function()
   {


      if ( self.imageViewer.cropSelection == null ) {
         if (new StartCropInstructionDialog().execute() != StdDialogCode_Ok)
            return;
         if ( self.multiExposureCropRequired )
            self.multiExposureManualCropStarted = true;
         self.imageViewer.setCropInteractionActive( true );
         self.updateReviewNextButton();
         self.cropButton.onClick();
         return;
      }
      if ( self.multiExposureCropRequired )
         self.multiExposureManualCropStarted = true;
      if ( !self.imageViewer.cropEditMode ) {
         self.imageViewer.setCropInteractionActive( true );
         self.updateReviewNextButton();
         self.imageViewer.setCropEditMode( true );
         self.reviewStatus.text =
            "Crop editing is active. Drag inside to move; drag an edge or " +
            "corner handle to resize; click Crop again to apply.";
         return;
      }
      let answer = StartAskCenteredQuestion(
         "🔭 InNova Multi-Night — Confirm crop",
         "Is this crop correct?\n\nIf you choose Yes, the selected crop " +
         "will be synchronized and applied to all images in the sequence.", true,
         "Is this crop correct?" );
      if ( answer == StdButton_Yes ) {
         self.reviewStatus.text =
            "Applying the synchronized crop to all images…";


         self.imageViewer.setCropEditMode( false );
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_Arrow );
         self.imageViewer.cropToolButton.enabled = false;
         self.reviewDialog.enabled = false;
         self.confirmedCropApplyPending = true;
         self.confirmedCropApplyTimer.start();
      } else {
         self.imageViewer.setCropEditMode( false );
         self.imageViewer.panEnabled = true;
         self.imageViewer.panButton.checked = true;
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_OpenHand );
         self.imageViewer.setCropInteractionActive( false );
         self.updateReviewNextButton();
         self.status.text = "Crop not applied.";
         self.reviewStatus.text =
            "Crop not applied. All viewer controls are available.";
      }
   };

   this.imageViewer.onRestoreCropRequested = function()
   {
      let answer = StartAskCenteredQuestion(
         "🔭 InNova Multi-Night — Restore crop",
         "The image will be restored to its initial state. All crop " +
         "adjustments will be lost.\n\nDo you want to restore it?", true );
      if ( answer != StdButton_Yes ) return;

      self.imageViewer.setCropMode( false );
      self.imageViewer.setCropEditMode( false );
      self.imageViewer.setCropInteractionActive( false );
      self.updateReviewNextButton();
      self.cropRectangle = null;
      self.multiExposureSynchronizedCropAccepted = false;
      self.applyCropButton.enabled = false;

      let windows = ImageWindow.windows;
      for ( let i = 0; i < windows.length; ++i )
         if ( windows[i] != null && !windows[i].isNull &&
              !windows[i].mainView.isNull &&
              String( windows[i].mainView.id ).toLowerCase().indexOf(
                 "innovastartcrop" ) >= 0 )
            windows[i].forceClose();

      self.croppedSeries = [];
      let restoredViewer = self.buildViewerSeries(
         self.registeredSeries, "Registered images" );
      self.imageViewer.setSeries(
         restoredViewer.series, restoredViewer.label );
      self.autoCropButton.enabled = self.registeredSeries.length >= 2;
      self.cropValueLabel.text =
         "Click Crop, then drag over the image to select the area to keep.";
      self.status.text =
         "Crop adjustments discarded. The registered image sequence has " +
         "been restored.";
      self.reviewStatus.text = self.status.text;
   };

   this.imageViewer.onCropSelected = function( rectangle )
   {
      let window = self.imageViewer.currentWindow();
      if ( window == null ) return;
      let image = window.mainView.image;
      if ( rectangle.width < 64 || rectangle.height < 64 ) {
         self.imageViewer.setCropSelection( null );
         self.imageViewer.cropEditMode = false;
         self.imageViewer.panEnabled = true;
         self.imageViewer.panButton.checked = true;
         self.imageViewer.scrollBox.viewport.cursor =
            new Cursor( StdCursor_OpenHand );
         self.imageViewer.setCropInteractionActive( false );
         self.updateReviewNextButton();
         new MessageBox(
            "The crop rectangle must be at least 64 × 64 pixels.",
            "🔭 InNova Multi-Night", StdIcon_Warning, StdButton_Ok ).execute();
         return;
      }
      self.cropRectangle = { x: rectangle.x, y: rectangle.y,
         width: rectangle.width, height: rectangle.height,
         sourceWidth: image.width, sourceHeight: image.height,
         coverage: 100*rectangle.width*rectangle.height/
            (image.width*image.height), step: 0 };
      self.cropValueLabel.text =
         "<b>Visual crop ready.</b> The bright rectangle is kept; the " +
         "shaded area is removed. <b>Frame retained:</b> " +
         format( "%.1f%%", self.cropRectangle.coverage );
      self.applyCropButton.enabled = true;
      self.status.text = "Visual crop ready and editable.";
      self.reviewStatus.text =
         "Drag inside the rectangle to move it. Drag an edge or corner " +
         "handle to resize it. Click Crop again to apply it to " +
         "the complete sequence.";
   };

   this.applyCropButton.onClick = function()
   {
      self.hideProcessConsole();
      if ( self.cropRectangle == null ) return false;
      let requiredCropApplied = self.multiExposureCropRequired;
      self.reviewDialog.enabled = false;
      self.beginElapsed( "Applying crop to image copies…", true );
      self.croppedSeries = [];
      try {


         let sourceSeries = self.resolveLatestPreparedSeries(
            self.registeredSeries );
         for ( let i = 0; i < sourceSeries.length; ++i ) {
            let cropMessage = "Cropping registered copy " + (i + 1) +
               " of " + sourceSeries.length + "…";
            self.updateElapsed( cropMessage );
            console.noteln( "✂️ " + cropMessage );
            let sourceItem = sourceSeries[i];
            let sourceWindow = sourceItem.window || sourceItem;
            let scale = StartCropAstrometryScale(sourceWindow);


            if (!scale) {
               let original = StartSeriesSourceEntry(sourceItem);
               if (original)
                  scale = original.astrometryScale || StartCropAstrometryScale(original.window);
            }
            if (scale) {
               console.noteln("🔭 Crop image scale: " + (scale * 3600) + " arcsec/pixel.");
            } else {
               console.warningln("⚠️ No angular scale or complete focal-length/pixel-size metadata found for " +
                  sourceWindow.mainView.id + " or its original source.");
            }
            let output = StartApplyCropToCopy(
               sourceWindow, self.cropRectangle );
            let croppedItem = { window: output,
               astrometryScale: scale, source: sourceItem,
               alreadyStretched: sourceItem.alreadyStretched === true };


            if ( croppedItem.alreadyStretched ) {
               let linearItem = self.resolveLatestProcessorPrepared(sourceItem);
               let linearWindow = linearItem.window || linearItem;
               if ( linearWindow != null && !linearWindow.isNull &&
                    linearWindow.mainView.id != sourceWindow.mainView.id ) {
                  croppedItem.astrometrySolveWindow = StartApplyCropToCopy(
                     linearWindow, self.cropRectangle );
                  croppedItem.astrometrySolveWindow.hide();
               }
            }
            self.croppedSeries.push( croppedItem );
            self.rememberLatestPrepared( sourceItem, croppedItem );
            if ( croppedItem.alreadyStretched )
               self.stretchedEditorSources[output.mainView.id] = output;
         }
         let croppedViewer = self.buildViewerSeries(
            self.croppedSeries, "Cropped images" );
         self.imageViewer.setSeries(
            croppedViewer.series, croppedViewer.label );
         if ( requiredCropApplied && self.croppedSeries.length > 0 &&
              self.croppedSeries.length == sourceSeries.length ) {


            self.multiExposureCropRequired = false;
            self.multiExposureManualCropStarted = false;
            self.multiExposureSynchronizedCropAccepted = true;
         }
         self.status.text = "Created <b>" + self.croppedSeries.length +
            " identically cropped copies</b>. These are ready for " +
            "inspection in the viewer, multi-night integration and HDR " +
            "composition.";
         self.reviewStatus.text = self.status.text;
         self.applyCropButton.enabled = false;
         self.autoCropButton.enabled = false;
      } catch ( error ) {
         for ( let i = 0; i < self.croppedSeries.length; ++i ) {
            let failedOutput = self.croppedSeries[i].window;
            if ( failedOutput != null && !failedOutput.isNull )
               failedOutput.forceClose();
            let failedProxy = self.croppedSeries[i].astrometrySolveWindow;
            if ( failedProxy != null && !failedProxy.isNull )
               failedProxy.forceClose();
         }
         self.croppedSeries = [];
         self.status.text = "<b style=\"color:#c33\">Crop failed:</b> " + error;
         self.reviewStatus.text = self.status.text;
      }
      self.reviewDialog.enabled = true;


      if (self.croppedSeries.length > 0) {
         for ( let i = 0; i < self.croppedSeries.length; ++i ) {
            let proxy = self.croppedSeries[i].astrometrySolveWindow;
            if ( proxy != null && !proxy.isNull ) proxy.forceClose();
            self.croppedSeries[i].astrometrySolveWindow = null;
         }
         let result = "Cropped images are ready. Astrometry will be requested " +
            "only if a coordinate-dependent process is selected.";
         self.status.text += "<br/>" + result;
         self.reviewStatus.text = self.status.text;
      }
      let applyCropElapsed = self.finishElapsed();
      self.status.text += "  " + StartElapsedRichText( applyCropElapsed );
      self.reviewStatus.text = self.status.text;
      return self.croppedSeries.length > 0;
   };

   this.consoleButton.onClick = function()
   {
      if ( self.consoleIsVisible ) self.hideProcessConsole();
      else self.showProcessConsole();
   };
   this.temporaryWindowsCleaned = false;
   this.cleanupTemporaryWindowsOnExit = function()
   {
      if ( self.temporaryWindowsCleaned ) return;
      self.temporaryWindowsCleaned = true;
      StartCloseMultiNightTemporaryWindows();
      self.registeredSeries = [];
      self.croppedSeries = [];
   };
   this.closeButton.onClick = function()
   {
      self.cleanupTemporaryWindowsOnExit();
      self.ok();
   };
   this.onClose = function()
   {
      self.cleanupTemporaryWindowsOnExit();
      return true;
   };


   this.reviewOperationDepth = 0;
   function lockReviewNavigation(owner, name, rejectReentry)
   {
      let operation = owner[name];
      if (typeof operation != "function") return;
      owner[name] = function()
      {
         if (rejectReentry && self.reviewOperationDepth > 0) return;
         let outermost = self.reviewOperationDepth == 0;
         let backEnabled = self.reviewBackButton.enabled;
         let nextEnabled = self.reviewNextButton.enabled;
         ++self.reviewOperationDepth;
         self.reviewBackButton.enabled = false;
         self.reviewNextButton.enabled = false;
         try {
            return operation.apply(this, arguments);
         } finally {
            --self.reviewOperationDepth;
            if (outermost) {
               self.reviewBackButton.enabled = backEnabled;
               self.reviewNextButton.enabled = self.multiExposureCropRequired ?
                  false : nextEnabled;
            }
         }
      };
   }
   lockReviewNavigation(this.reviewNextButton, "onClick", true);
   lockReviewNavigation(this.autoCropButton, "onClick", true);
   lockReviewNavigation(this.applyCropButton, "onClick", false);
   ["onCropRequested", "onRestoreCropRequested", "onAdaptiveRequested",
      "onImageSolverRequested", "onColorCalibrationRequested",
      "onEditorRequested", "onProcessorRequested", "onRemoveRequested", "onMultiExposureRequested"].forEach(function(name) {
      lockReviewNavigation(self.imageViewer, name, true);
   });

   lockReviewNavigation(this, "buildViewerSeries", false);
   lockReviewNavigation(this.imageViewer, "setSeries", false);

   this.refreshImages( false );
   if ( !this.consoleIsVisible ) console.hide();
   this.adjustToContents();


   let bridgeScreen = this.availableScreenRect;
   if ( bridgeScreen ) {
      let availableBridgeWidth = bridgeScreen.x1 - bridgeScreen.x0 -
         Math.round( this.logicalPixelsToPhysical( 24 ) );
      this.resize( Math.min( this.width, availableBridgeWidth ), this.height );
   }


   this.bridgeCenterTimer = new Timer;
   this.bridgeCenterTimer.interval = 0.05;
   this.bridgeCenterTimer.periodic = false;
   this.bridgeCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self );
   };
   this.onShow = function()
   {
      MiraCenterDialog( this );
      self.bridgeCenterTimer.start();
   };
   MiraCenterDialog( this );
}
}


var StartLauncherRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);
#include "lib/LauncherAppearance.js"
#include "SubframeReview.js"

function StartLauncherSelectorIcon(parent, module, compact, selectModule,
   openModule)
{
   let control = new Control(parent);
   let slotSize = compact ? 86 : 104;
   let normalSize = compact ? 68 : 82;
   let hoverSize = compact ? 80 : 96;
   control.setScaledFixedSize(slotSize, slotSize);
   control.bitmap = StartLauncherBitmap("icons/" + module.icon + ".png");
   if (!control.bitmap)
      control.bitmap = StartLauncherBitmap("icons/" + module.icon + ".svg");
   control.module = module;
   control.selected = false;
   control.hovered = false;
   control.mouseTracking = true;
   control.toolTip = module.enabled === false ?
      module.name + " — Coming soon!" :
      module.name + " — " + module.subtitle + "\nClick to open.";
   control.onPaint = function()
   {
      let graphics = new Graphics(this);


      let activeHover = module.enabled !== false && this.hovered;
      graphics.fillRect(0, 0, this.width, this.height,
         new Brush(activeHover ? 0xffdceeff : 0xffeceef1));
      if (activeHover) {
         graphics.pen = new Pen(0xff0875dc,
            this.logicalPixelsToPhysical(2));
         graphics.drawRect(0, 0, this.width - 1, this.height - 1);
      }
      if (this.bitmap) {
         let logicalSize = activeHover ? hoverSize : normalSize;
         let drawSize = this.logicalPixelsToPhysical(logicalSize);
         let x = Math.round((this.width - drawSize)/2);
         let y = Math.round((this.height - drawSize)/2);
         graphics.drawScaledBitmap(new Rect(x, y, x + drawSize,
            y + drawSize), this.bitmap);
      }
      if (!activeHover)
         graphics.fillRect(0, 0, this.width, this.height,
            new Brush(0x88eceef1));
      graphics.end();
   };
   control.onMouseMove = function()
   {
      selectModule(module, control, true);
      return true;
   };
   control.onMousePress = function( x, y, button )
   {
      if (button != MouseButton_Left) return false;
      selectModule(module, control, true);
      if (module.enabled !== false) openModule();
      return true;
   };
   return control;
}

var _0x6ef6bfb640 =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiIwZThlNmI2My1hZTk1LTQ1MjctOWNjMS1iN2JlMzc2N2ViZmYiLCJjaGVja291dEZsb3dJZCI6ImVlNjNjNTliLWI1OTQtNGY3MS1iMTFiLWJmZjlmNDA2MTIzNyIsImlzVjMiOnRydWV9";

var _0x910895180d =
   "https://www.teoriadelcolor.es/plans-pricing/payment/" +
   "eyJpbnRlZ3JhdGlvbkRhdGEiOnt9LCJwbGFuSWQiOiJiNDE5M2JlNi00NTg0LTRjYmMtOWEyOS1iYjE0YjJjYzRlM2IiLCJjaGVja291dEZsb3dJZCI6ImY4YTMyNmVjLTI4MDQtNGIzNi1iN2UxLTlmZTMyYTlmNGY0NiIsImlzVjMiOnRydWV9";

var _0xcaf371e39b =
   String.fromCharCode(104,116,116,112,115,58,47,47,119,119,119,46,116,101,111,114,105,97,100,101,108,99,111,108,111,114,46,101,115,47,97,99,99,111,117,110,116,47,109,121,45,115,117,98,115,99,114,105,112,116,105,111,110,115);

function _0xcd43dab699()
{
   let _0x15139f4b5f = _0x7eee2bd14f();
   if (!_0xd86c035f60(_0x15139f4b5f) || !_0x3f51e778c9(_0x15139f4b5f) ||
       _0xbbbb498022(_0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)]))
      return "";
   let code = String(_0x15139f4b5f.code || "").toUpperCase();
   if (code.indexOf("INNOVA-M-") === 0)
      return "Monthly";
   if (code.indexOf("INNOVA-A-") === 0)
      return "Annual";
   return String.fromCharCode(65,99,116,105,118,101,32,115,117,98,115,99,114,105,112,116,105,111,110);
}


class _0x6feb98e8f3 extends Dialog
{
   constructor(_0x9433ba1bbc)
   {
      super();

      let self = this;
      this.selectedUrl = "";
      this.recoverExisting = false;
      this.supportRecovery = false;
      let currentPlan = _0xcd43dab699();
      let paidRecoveryAvailable = currentPlan !== "" || _0xb4b48f6b83();
      this.windowTitle = String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110,32,80,108,97,110,115);

      let titleLabel = new Label(this);
      titleLabel.useRichText = true;
      titleLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      titleLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,67,104,111,111,115,101,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,60,47,112,62) +
         "<p align=\"center\">Select the billing period that suits you.</p>";


      titleLabel.onMousePress = function ()
      {
         if (paidRecoveryAvailable)
            return;
         paidRecoveryAvailable = true;
         transferGroup.visible = true;
         supportGroup.visible = true;
         self.adjustToContents();
         self.setFixedSize();
      };

      let monthlyGroup = new GroupBox(this);
      monthlyGroup.title = "Monthly";
      monthlyGroup.setFixedWidth(260);
      monthlyGroup.sizer = new VerticalSizer;
      monthlyGroup.sizer.margin = 12;
      monthlyGroup.sizer.spacing = 10;

      let monthlyPriceLabel = new Label(monthlyGroup);
      monthlyPriceLabel.useRichText = true;
      monthlyPriceLabel.wordWrapping = true;
      monthlyPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      monthlyPriceLabel.text =
         "<p align=\"center\"><b>&euro;6.99 / month</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Billed every month until cancelled.</p>";

      let monthlyButton = new PushButton(monthlyGroup);
      monthlyButton.text = "Choose Monthly";
      monthlyButton.icon = this.scaledResource( ":/icons/internet.png" );
      monthlyButton.setFixedHeight(34);
      monthlyButton.onClick = function ()
      {
         self.selectedUrl = _0x6ef6bfb640;
         self.ok();
      };

      monthlyGroup.sizer.add(monthlyPriceLabel);
      monthlyGroup.sizer.addStretch();
      monthlyGroup.sizer.add(monthlyButton);

      let annualGroup = new GroupBox(this);
      annualGroup.title = "Annual";
      annualGroup.setFixedWidth(260);
      annualGroup.sizer = new VerticalSizer;
      annualGroup.sizer.margin = 12;
      annualGroup.sizer.spacing = 10;

      let annualPriceLabel = new Label(annualGroup);
      annualPriceLabel.useRichText = true;
      annualPriceLabel.wordWrapping = true;
      annualPriceLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      annualPriceLabel.text =
         "<p align=\"center\"><b>&euro;69.99 / year</b><br><br>" +
         "<b>1 Device</b></p>" +
         "<p align=\"center\">Taxes included.<br>" +
         "Save &euro;13.89 compared with<br>12 monthly payments.</p>";

      let annualButton = new PushButton(annualGroup);
      annualButton.text = "Choose Annual - Best Value";
      annualButton.icon = this.scaledResource( ":/icons/ok.png" );
      annualButton.toolTip =
         "Recommended: save EUR 13.89 compared with 12 monthly payments.";
      annualButton.setFixedHeight(34);
      annualButton.onClick = function ()
      {
         self.selectedUrl = _0x910895180d;
         self.ok();
      };

      annualGroup.sizer.add(annualPriceLabel);
      annualGroup.sizer.addStretch();
      annualGroup.sizer.add(annualButton);


      monthlyButton.enabled = currentPlan === "";
      annualButton.enabled = currentPlan === "";

      let plansSizer = new HorizontalSizer;
      plansSizer.spacing = 12;
      plansSizer.add(monthlyGroup);
      plansSizer.add(annualGroup);

      let currentPlanPanel = new Control(this);
      currentPlanPanel.visible = currentPlan !== "";
      currentPlanPanel.sizer = new VerticalSizer;
      currentPlanPanel.sizer.spacing = 5;

      let currentPlanLabel = new Label(currentPlanPanel);
      currentPlanLabel.useRichText = true;
      currentPlanLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      currentPlanLabel.text =
         "<p align=\"center\">Your current plan is: <b>" + currentPlan +
         "</b>.</p>";

      let _0xa32e12ea8b = new Label(currentPlanPanel);
      _0xa32e12ea8b.useRichText = true;
      _0xa32e12ea8b.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      _0xa32e12ea8b.text =
         "<p align=\"center\"><span style=\"color:#0077cc;\"><u>" +
         String.fromCharCode(67,108,105,99,107,32,104,101,114,101,32,105,102,32,121,111,117,32,119,97,110,116,32,116,111,32,97,99,99,101,115,115,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,115,46,60,47,117,62,60,47,115,112,97,110,62,60,47,112,62);
      _0xa32e12ea8b.toolTip = String.fromCharCode(79,112,101,110,32,121,111,117,114,32,73,110,78,111,118,97,32,115,117,98,115,99,114,105,112,116,105,111,110,115,46);
      _0xa32e12ea8b.cursor = new Cursor(StdCursor_PointingHand);
      _0xa32e12ea8b.onMousePress = function ()
      {
         if (typeof _0x9433ba1bbc === "function")
            _0x9433ba1bbc();
      };

      currentPlanPanel.sizer.add(currentPlanLabel);
      currentPlanPanel.sizer.add(_0xa32e12ea8b);

      let bonusGroup = new GroupBox(this);
      bonusGroup.title = "Bonus";
      bonusGroup.sizer = new VerticalSizer;
      bonusGroup.sizer.margin = 12;

      let bonusLabel = new Label(bonusGroup);
      bonusLabel.useRichText = true;
      bonusLabel.wordWrapping = true;
      bonusLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      bonusLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,42,32,66,111,116,104,32,115,117,98,115,99,114,105,112,116,105,111,110,115,32,105,110,99,108,117,100,101,32,97,99,99,101,115,115,32,116,111,32,116,104,101,32) +
         "<b>Premium site</b> with exclusive learning videos<br>" +
         "and early access to new tools.</p>" +
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,42,32,84,104,101,32,97,110,110,117,97,108,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,110,99,108,117,100,101,115,32,97,99,99,101,115,115,32) +
         "to a questions and answers channel.</b></p>";
      bonusGroup.sizer.add(bonusLabel);

      let transferGroup = new GroupBox(this);
      transferGroup.title = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      transferGroup.visible = paidRecoveryAvailable;
      transferGroup.sizer = new VerticalSizer;
      transferGroup.sizer.margin = 12;
      transferGroup.sizer.spacing = 10;

      let transferLabel = new Label(transferGroup);
      transferLabel.useRichText = true;
      transferLabel.wordWrapping = true;
      transferLabel.textAlignment =
         TextAlign_HorzCenter | TextAlign_VertCenter;
      transferLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,87,111,117,108,100,32,121,111,117,32,108,105,107,101,32,116,111,32,116,114,97,110,115,102,101,114,32,121,111,117,114,32,108,105,99,101,110,115,101,32,116,111,32,97,110,111,116,104,101,114,32,99,111,109,112,117,116,101,114,63,60,98,114,62) +
         "Open InNova Start on the other computer and click this button.</p>";

      let recoveryButton = new PushButton(transferGroup);
      recoveryButton.text = String.fromCharCode(84,114,97,110,115,102,101,114,32,76,105,99,101,110,115,101);
      recoveryButton.icon = this.scaledResource( ":/icons/internet.png" );
      recoveryButton.setFixedWidth(230);
      recoveryButton.toolTip =
         "Authorize this computer with the purchasing platform account. No payment is made.";
      recoveryButton.onClick = function ()
      {
         self.recoverExisting = true;
         self.ok();
      };

      let recoverySizer = new HorizontalSizer;
      recoverySizer.addStretch();
      recoverySizer.add(recoveryButton);
      recoverySizer.addStretch();
      transferGroup.sizer.add(transferLabel);
      transferGroup.sizer.add(recoverySizer);

      let supportGroup = new GroupBox(this);
      supportGroup.title = String.fromCharCode(83,117,112,112,111,114,116,32,76,105,99,101,110,115,101,32,82,101,99,111,118,101,114,121);
      supportGroup.visible = paidRecoveryAvailable;
      supportGroup.sizer = new VerticalSizer;
      supportGroup.sizer.margin = 12;
      supportGroup.sizer.spacing = 10;

      let supportLabel = new Label(supportGroup);
      supportLabel.useRichText = true;
      supportLabel.wordWrapping = true;
      supportLabel.textAlignment = TextAlign_HorzCenter | TextAlign_VertCenter;
      supportLabel.text =
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,85,115,101,32,116,104,105,115,32,111,112,116,105,111,110,32,119,104,101,110,32,97,32,99,117,114,114,101,110,116,108,121,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,97,110,110,111,116,32) +
         "be recovered normally. The platform will verify the paid period automatically.</p>";

      let supportButton = new PushButton(supportGroup);
      supportButton.text = String.fromCharCode(82,101,99,111,118,101,114,32,76,105,99,101,110,115,101,32,119,105,116,104,32,83,117,112,112,111,114,116);
      supportButton.icon = this.scaledResource( ":/icons/internet.png" );
      supportButton.setFixedWidth(230);
      supportButton.toolTip =
         "Creates a 30-minute Linking Code for automatic paid-period recovery. No payment is made.";
      supportButton.onClick = function ()
      {
         self.supportRecovery = true;
         self.ok();
      };
      let supportSizer = new HorizontalSizer;
      supportSizer.addStretch();
      supportSizer.add(supportButton);
      supportSizer.addStretch();
      supportGroup.sizer.add(supportLabel);
      supportGroup.sizer.add(supportSizer);

      let cancelButton = new PushButton(this);
      cancelButton.text = "Cancel";
      cancelButton.icon = this.scaledResource( ":/icons/cancel.png" );
      cancelButton.setFixedWidth(120);
      cancelButton.onClick = function () { self.cancel(); };

      let cancelSizer = new HorizontalSizer;
      cancelSizer.addStretch();
      cancelSizer.add(cancelButton);
      cancelSizer.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 14;
      this.sizer.spacing = 12;
      this.sizer.add(titleLabel);
      this.sizer.add(plansSizer);
      this.sizer.add(currentPlanPanel);
      this.sizer.add(bonusGroup);


      this.sizer.add(transferGroup);
      this.sizer.add(supportGroup);
      this.sizer.add(cancelSizer);

      this.adjustToContents();
      this.setFixedSize();
   }
}


function StartOpenLicenceManager()
{
   _0x195e32f0d7();
   let dialog = new Dialog;
   dialog.windowTitle = String.fromCharCode(73,110,78,111,118,97,32,76,105,99,101,110,99,101,32,77,97,110,97,103,101,114);
   let self = dialog;
   let firstPurchaseControlsRequested = false;
   let purchaseStepButtonStates = null;

   let header = StartLauncherPanel(dialog, true);
   header.setScaledFixedHeight(92);
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   header.sizer.add(StartLauncherIcon(header, "guided-compass", 68));
   let heading = new VerticalSizer;
   heading.addStretch();
   heading.add(StartLauncherLabel(header, String.fromCharCode(60,98,62,73,110,78,111,118,97,32,76,105,99,101,110,99,101,32,77,97,110,97,103,101,114,60,47,98,62), 20, "#102b50", false));
   heading.add(StartLauncherLabel(header, String.fromCharCode(77,97,110,97,103,101,32,116,104,101,32,108,105,99,101,110,99,101,32,102,111,114,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,46), 12, "#243f5b", false));
   heading.addStretch();
   header.sizer.add(heading, 100);

   let info = new GroupBox(dialog);
   info.title = String.fromCharCode(76,105,99,101,110,115,101,32,73,110,102,111,114,109,97,116,105,111,110);
   info.sizer = new VerticalSizer;
   info.sizer.margin = 10;
   info.sizer.spacing = 6;
   function field(name)
   {
      let row = new HorizontalSizer;
      row.spacing = 8;
      let label = new Label(info);
      label.text = name;
      label.setFixedWidth(90);
      let edit = new Edit(info);
      edit.readOnly = true;
      edit.setScaledMinWidth(390);
      row.add(label);
      row.add(edit, 100);
      info.sizer.add(row);
      return edit;
   }
   dialog.emailEdit = field("Email:");
   dialog.codeEdit = field("Code:");
   dialog[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)] = field(String.fromCharCode(69,120,112,105,114,121,58));
   dialog[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)] = field(String.fromCharCode(77,97,99,104,105,110,101,32,73,68,58));
   dialog.signatureEdit = field("Signature:");

   let accountLinkControl = new Control(info);
   accountLinkControl.visible = false;
   let linkLabel = new Label(accountLinkControl);
   linkLabel.text = "Linking code:";
   linkLabel.setFixedWidth(90);
   dialog.accountLinkEdit = new Edit(accountLinkControl);
   dialog.accountLinkEdit.readOnly = true;
   dialog.accountLinkEdit.text = SoftwareLinkCode();
   dialog.accountLinkEdit.toolTip = "Copy this code to the InNova website while signed in as the purchaser. Valid for 30 minutes.";
   let accountLinkSizer = new HorizontalSizer;
   accountLinkSizer.spacing = 8;
   accountLinkSizer.add(linkLabel);
   accountLinkSizer.add(dialog.accountLinkEdit, 1);
   let activatePurchaseButton = new PushButton(accountLinkControl);
   activatePurchaseButton.text = "Activate Purchase";
   activatePurchaseButton.icon = dialog.scaledResource(":/icons/ok.png");
   activatePurchaseButton.toolTip = String.fromCharCode(65,102,116,101,114,32,112,97,121,109,101,110,116,44,32,99,104,101,99,107,32,87,105,120,32,99,111,110,102,105,114,109,97,116,105,111,110,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,78,111,32,112,114,111,102,105,108,101,32,115,105,103,110,97,116,117,114,101,32,111,114,32,97,100,100,105,116,105,111,110,97,108,32,112,97,121,109,101,110,116,32,105,115,32,110,101,101,100,101,100,32,102,111,114,32,97,32,110,101,119,32,112,117,114,99,104,97,115,101,46);
   accountLinkSizer.add(activatePurchaseButton);
   linkLabel.adjustToContents();
   dialog.accountLinkEdit.adjustToContents();
   activatePurchaseButton.adjustToContents();
   let accountLinkLayout = new VerticalSizer;
   accountLinkLayout.margin = 0;
   accountLinkLayout.spacing = 0;
   accountLinkLayout.addSpacing(8);
   accountLinkLayout.add(accountLinkSizer);
   accountLinkControl.sizer = accountLinkLayout;
   accountLinkControl.setFixedHeight(8 + Math.max(linkLabel.height,
      dialog.accountLinkEdit.height, activatePurchaseButton.height));
   info.sizer.add(accountLinkControl);

   let status = StartLauncherLabel(dialog, "", 12, "#102b50", true);
   let actions = new HorizontalSizer;
   actions.spacing = 8;
   actions.addStretch();
   function button(text, icon)
   {
      let b = new PushButton(dialog);
      b.text = text;
      b.icon = dialog.scaledResource(icon);
      b.setScaledFixedSize(150, 24);
      actions.add(b);
      return b;
   }
   let _0xcf363a877f = button(String.fromCharCode(77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110), ":/icons/clipboard-internet.png");
   _0xcf363a877f.toolTip = String.fromCharCode(80,117,114,99,104,97,115,101,32,121,111,117,114,32,102,105,114,115,116,32,115,117,98,115,99,114,105,112,116,105,111,110,32,111,114,32,111,112,101,110,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,32,116,111,32,109,97,110,97,103,101,32,97,110,32,101,120,105,115,116,105,110,103,32,115,117,98,115,99,114,105,112,116,105,111,110,46);
   let _0x82aca11b35 = button(String.fromCharCode(67,104,101,99,107,32,76,105,99,101,110,115,101,32,83,116,97,116,117,115), ":/icons/ok.png");
   _0x82aca11b35.toolTip = String.fromCharCode(82,101,97,100,32,116,104,101,32,115,116,97,116,117,115,32,102,114,111,109,32,87,105,120,46,32,68,111,101,115,32,110,111,116,32,114,101,110,101,119,32,111,114,32,97,99,116,105,118,97,116,101,32,116,104,101,32,108,105,99,101,110,115,101,46);
   actions.addStretch();

   let secondary = new HorizontalSizer;
   secondary.spacing = 8;
   secondary.addStretch();
   let _0xc35cffac5a = new PushButton(dialog);
   _0xc35cffac5a.text = String.fromCharCode(76,105,99,101,110,115,101,32,112,114,111,98,108,101,109,115,63);
   _0xc35cffac5a.icon = dialog.scaledResource(":/icons/info.png");
   _0xc35cffac5a.setScaledFixedSize(150, 24);
   _0xc35cffac5a.toolTip = String.fromCharCode(69,109,97,105,108,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,32,97,98,111,117,116,32,97,32,108,105,99,101,110,115,101,32,112,114,111,98,108,101,109,46);
   secondary.add(_0xc35cffac5a);
   let premiumSiteButton = new PushButton(dialog);
   premiumSiteButton.text = "Premium site";
   premiumSiteButton.icon = dialog.scaledResource(":/icons/internet.png");
   premiumSiteButton.setScaledFixedSize(150, 24);
   premiumSiteButton.toolTip = "Open the InNova Premium site. Available with an active paid plan.";
   premiumSiteButton.enabled = false;
   secondary.add(premiumSiteButton);
   secondary.addStretch();

   function _0x7a6ccd1c8b(url, browserTitle)
   {
      if (!RequireInNovaServerConnection())
         return null;
      let platform = String(CoreApplication.platform).toLowerCase();
      let command;
      if (platform.indexOf("mac") >= 0)
         command = ["/usr/bin/open", [url]];
      else if (platform.indexOf("win") >= 0)
         command = ["cmd.exe", ["/c", "start", "", url]];
      else
         command = ["xdg-open", [url]];
      try
      {
         let process = new ExternalProcess;
         process.start(command[0], command[1]);
         if (process.waitForStarted(3000))
            return true;
      }
      catch (error) {}
      try
      {
         Dialog.openBrowser(url, browserTitle || String.fromCharCode(73,110,78,111,118,97,32,83,117,98,115,99,114,105,112,116,105,111,110));
         return true;
      }
      catch (error)
      {
         return false;
      }
   }

   function CopyTextToSystemClipboard(text)
   {
      let platform = String(CoreApplication.platform).toLowerCase();
      let commands = platform.indexOf("mac") >= 0 ? [["/usr/bin/pbcopy", []]] :
         (platform.indexOf("win") >= 0 ? [["cmd.exe", ["/c", "clip"]]] :
         [["xclip", ["-selection", "clipboard"]], ["xsel", ["--clipboard", "--input"]]]);
      for (let i = 0; i < commands.length; ++i)
         try
         {
            let process = new ExternalProcess;
            process.start(commands[i][0], commands[i][1]);
            if (!process.waitForStarted(3000))
               continue;
            process.standardInput = text;
            if (!process.waitForDataWritten(3000))
            {
               process.closeStandardInput();
               continue;
            }
            process.closeStandardInput();
            if (process.waitForFinished(3000) && process.exitCode === 0)
               return true;
         }
         catch (error) {}
      return false;
   }

   function _0x8e08420ae5()
   {
      let mailUrl = "mailto:soporte@teoriadelcolor.net" +
         String.fromCharCode(63,115,117,98,106,101,99,116,61,73,110,78,111,118,97,37,50,48,65,115,116,114,111,37,50,48,45,37,50,48,76,105,99,101,110,115,101,37,50,48,80,114,111,98,108,101,109);
      let platform = String(CoreApplication.platform).toLowerCase();
      let command;
      if (platform.indexOf("mac") >= 0)
         command = ["/usr/bin/open", [mailUrl]];
      else if (platform.indexOf("win") >= 0)
         command = ["cmd.exe", ["/c", "start", "", mailUrl]];
      else
         command = ["xdg-open", [mailUrl]];
      try
      {
         let process = new ExternalProcess;
         process.start(command[0], command[1]);
         if (process.waitForStarted(3000))
            return true;
      }
      catch (error) {}
      try
      {
         Dialog.openBrowser(mailUrl, String.fromCharCode(73,110,78,111,118,97,32,76,105,99,101,110,115,101,32,83,117,112,112,111,114,116));
         return true;
      }
      catch (error)
      {
         return false;
      }
   }

   function UpdatePurchaseActivationControls()
   {
      let paid = _0xb4b48f6b83();
      let code = SoftwareLinkCode();
      let hasCode = /^[A-F0-9]{4}(?:-[A-F0-9]{4}){5}$/.test(code);
      let showCode = hasCode && (paid || firstPurchaseControlsRequested);
      let showActivate = !paid && firstPurchaseControlsRequested;
      let layoutChanged = accountLinkControl.visible !== (showCode || showActivate) ||
         linkLabel.visible !== showCode || activatePurchaseButton.visible !== showActivate;
      dialog.accountLinkEdit.text = hasCode ? code : "";
      linkLabel.visible = showCode;
      dialog.accountLinkEdit.visible = showCode;
      activatePurchaseButton.visible = showActivate;
      accountLinkControl.visible = showCode || showActivate;
      if (layoutChanged && dialog.sizer)
      {
         info.adjustToContents();
         dialog.adjustToContents();
         dialog.setFixedSize();
      }
   }

   function refresh()
   {
      _0x195e32f0d7();
      let licence = _0x7eee2bd14f();
      dialog.emailEdit.text = _0xd86c035f60(licence) ? String(licence.email || "") : "";
      dialog.codeEdit.text = _0xd86c035f60(licence) ? String(licence.code || "") : "";
      dialog[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = _0xd86c035f60(licence) ? String(licence[String.fromCharCode(101,120,112,105,114,121)] || "") : "";
      dialog.signatureEdit.text = _0xd86c035f60(licence) ? String(licence[String.fromCharCode(115,105,103,110,97,116,117,114,101)] || "") : "";
      dialog[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0xfc55fa3ee9();
      status.text = String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,76,105,99,101,110,115,101,32,109,111,100,101,58,32) + InNovaStartSuiteStatus + "</b></p>";
      premiumSiteButton.enabled = _0xb4b48f6b83() && _0xf30298b9b9 === "FULL" &&
         _0xd86c035f60(licence) && _0x3f51e778c9(licence) &&
         !_0xbbbb498022(licence[String.fromCharCode(101,120,112,105,114,121)]) && _0xc230aa4345(licence);
      UpdatePurchaseActivationControls();
      status.update();
   }

   function SetPurchaseStepPending(pending)
   {
      if (pending)
      {
         if (purchaseStepButtonStates === null)
            purchaseStepButtonStates = [_0xcf363a877f.enabled,
               _0x82aca11b35.enabled, _0xc35cffac5a.enabled,
               premiumSiteButton.enabled];
         _0xcf363a877f.enabled = false;
         _0x82aca11b35.enabled = false;
         _0xc35cffac5a.enabled = false;
         premiumSiteButton.enabled = false;
      }
      else if (purchaseStepButtonStates !== null)
      {
         _0xcf363a877f.enabled = purchaseStepButtonStates[0];
         _0x82aca11b35.enabled = purchaseStepButtonStates[1];
         _0xc35cffac5a.enabled = purchaseStepButtonStates[2];
         premiumSiteButton.enabled = purchaseStepButtonStates[3];
         purchaseStepButtonStates = null;
      }
   }

   function _0x794c655db4()
   {
      SetPurchaseStepPending(false);
      firstPurchaseControlsRequested = true;
      try
      {
         let _0x42c39fcc91 = _0x9241b1de83(dialog[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);
         let result = RequestInNovaFirstActivation(_0x42c39fcc91, true);
         dialog.accountLinkEdit.text = SoftwareLinkCode();
         if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
             !(_0x27bbc4e88d && _0x27bbc4e88d.pending && _0x27bbc4e88d.pending.autoPurchase))
         {
            _0xdfd3a31f30("InNova Astro Processor",
               "After completing your purchase, authorize this computer.",
               { firstPurchase: true });
            result = RequestInNovaFirstActivation(_0x42c39fcc91, false);
         }
         if (result === "ACTIVATED")
         {
            let saved = _0x7eee2bd14f();
            dialog.emailEdit.text = saved.email;
            dialog.codeEdit.text = saved.code;
            dialog[String.fromCharCode(101,120,112,105,114,121,69,100,105,116)].text = saved[String.fromCharCode(101,120,112,105,114,121)];
            dialog.signatureEdit.text = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)];
            dialog.accountLinkEdit.text = SoftwareLinkCode();
            _0x9627d349e7 = saved[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
            _0xf30298b9b9 = _0xbbbb498022(saved[String.fromCharCode(101,120,112,105,114,121)]) ? "FULL_GRACE" : "FULL";
            if (_0xf30298b9b9 === "FULL_GRACE")
               _0x6e987547f6("InNova Astro Processor", saved, true);
            else
               new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,112,117,114,99,104,97,115,101,100,32,108,105,99,101,110,115,101,32,105,115,32,110,111,119,32,97,99,116,105,118,97,116,101,100,46,60,47,112,62),
                  "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
         }
         else if (result === "PAYMENT_PENDING")
         {
            new MessageBox("<p align=\"center\" style=\"color:#168bc1;font-size:32pt\">ⓘ</p>" +
               "<p align=\"center\">The platform has not yet confirmed your payment.</p>" +
               "<p align=\"center\">If you have completed payment, click <b>Activate Purchase</b><br/>in a few seconds.</p>" +
               "<p align=\"center\"><b>Do not pay again.</b></p>",
               "InNova Astro Processor", 0, StdButton_Ok).execute();
         }
         else if (result === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
                  _0x27bbc4e88d && _0x27bbc4e88d.pending && _0x27bbc4e88d.pending.autoPurchase)
            throw new Error(String.fromCharCode(84,104,105,115,32,112,117,114,99,104,97,115,101,32,114,101,113,117,105,114,101,115,32,97,99,99,111,117,110,116,32,114,101,99,111,118,101,114,121,32,111,114,32,114,101,110,101,119,97,108,32,97,117,116,104,111,114,105,122,97,116,105,111,110,46,32,67,111,110,116,97,99,116,32,73,110,78,111,118,97,32,115,117,112,112,111,114,116,59,32,100,111,32,110,111,116,32,112,97,121,32,97,103,97,105,110,46));
         else if (result !== String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68))
            throw new Error("Activation status: " + result);
      }
      catch (error)
      {
         if (error.innovaServerUnavailable)
            return;
         new MessageBox("Purchase activation could not be completed.\n\n" +
            "Check your connection and retry. Contact InNova support if the problem persists.\n" +
            "Do not purchase again.\n\n" + String(error.message || error),
            "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
      }
      finally
      {
         refresh();
      }
   }
   activatePurchaseButton.onClick = _0x794c655db4;

   _0xcf363a877f.onClick = function()
   {
      let _0x42c39fcc91 = _0x9241b1de83(dialog[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text);
      if (_0x42c39fcc91 === "")
      {
         new MessageBox(String.fromCharCode(65,32,118,97,108,105,100,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,114,101,113,117,105,114,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,105,110,103,32,97,32,115,117,98,115,99,114,105,112,116,105,111,110,46),
            "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      let planDialog = new _0x6feb98e8f3(function ()
      {
         if (_0x7a6ccd1c8b(_0xcaf371e39b, String.fromCharCode(73,110,78,111,118,97,32,115,117,98,115,99,114,105,112,116,105,111,110,115)) === false)
            new MessageBox(String.fromCharCode(89,111,117,114,32,73,110,78,111,118,97,32,115,117,98,115,99,114,105,112,116,105,111,110,115,32,99,111,117,108,100,32,110,111,116,32,98,101,32,111,112,101,110,101,100,46,10,10) +
               _0xcaf371e39b, "InNova Astro Processor",
               StdIcon_Warning, StdButton_Ok).execute();
      });
      if (!planDialog.execute())
         return;
      if (planDialog.recoverExisting || planDialog.supportRecovery)
      {
         try
         {
            let recovery = RequestInNovaFirstActivation(_0x42c39fcc91, true);
            dialog.accountLinkEdit.text = SoftwareLinkCode();
            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();
            if (recovery === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68))
               _0xdfd3a31f30("InNova Astro Processor",
                  planDialog.supportRecovery ?
                     "Recover this computer with the one-time code supplied by InNova Support." :
                     "Authorize this computer with the account used for your purchase.",
                  planDialog.supportRecovery ? { supportRecovery: true } : { [String.fromCharCode(108,105,99,101,110,115,101,84,114,97,110,115,102,101,114)]: true });
            else
               throw new Error("Recovery status: " + recovery);
         }
         catch (error)
         {
            if (error.innovaServerUnavailable)
               return;
            new MessageBox(String.fromCharCode(84,104,101,32,108,105,99,101,110,115,101,32,114,101,99,111,118,101,114,121,32,114,101,113,117,101,115,116,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,114,101,97,116,101,100,46,10,10) +
               String(error.message || error), "InNova Astro Processor",
               StdIcon_Warning, StdButton_Ok).execute();
         }
         return;
      }
      if (planDialog.selectedUrl === "")
         return;
      try
      {
         _0x42c39fcc91 = _0x0e063cb0f0(_0x42c39fcc91);
         dialog[String.fromCharCode(109,97,99,104,105,110,101,73,100,69,100,105,116)].text = _0x42c39fcc91;
         PrepareInNovaFirstPurchase(_0x42c39fcc91);
      }
      catch (error)
      {
         if (error.innovaServerUnavailable)
            return;
         let purchaseError = String(error.message || error);
         if (purchaseError === "PURCHASE_ACTIVATION_REQUIRED")
         {
            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();
            new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,105,115,32,77,97,99,104,105,110,101,32,73,68,32,105,115,32,97,108,114,101,97,100,121,32,97,115,115,111,99,105,97,116,101,100,32,119,105,116,104,32,97,32,112,117,114,99,104,97,115,101,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(60,98,62,89,111,117,114,32,77,97,99,104,105,110,101,32,73,68,32,104,97,115,32,98,101,101,110,32,107,101,112,116,32,117,110,99,104,97,110,103,101,100,46,60,47,98,62,60,98,114,47,62,60,98,114,47,62) +
               "If you have already paid, click <b>Activate Purchase</b> and sign in<br/>" +
               "with the account used for your purchase. Do not purchase again.<br/><br/>" +
               "If this is not your purchase, contact InNova support.</p>",
               "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
            return;
         }
         if (purchaseError.indexOf(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)) === 0)
         {
            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();
            let _0x8461f502a9 = purchaseError.substring(String(String.fromCharCode(65,67,84,73,86,69,95,83,85,66,83,67,82,73,80,84,73,79,78,58)).length);
            let _0x7c6e403734 = _0x8461f502a9 !== "" ? String.fromCharCode(10,10,69,120,112,105,114,121,32,40,121,121,121,121,47,109,109,47,100,100,41,58,32) + [String.fromCharCode(97,99,116,105,118,101,69,120,112,105,114,121)] : "";
            new MessageBox(String.fromCharCode(89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,105,115,32,97,108,114,101,97,100,121,32,97,99,116,105,118,101,46) + _0x7c6e403734 +
               String.fromCharCode(10,10,85,115,101,32,65,99,116,105,118,97,116,101,32,80,117,114,99,104,97,115,101,32,116,111,32,97,117,116,104,111,114,105,122,101,32,116,104,105,115,32,99,111,109,112,117,116,101,114,32,97,110,100,32,100,111,119,110,108,111,97,100,32,121,111,117,114,32,108,105,99,101,110,115,101,46,32,68,111,32,110,111,116,32,112,117,114,99,104,97,115,101,32,97,103,97,105,110,46),
               "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
            return;
         }
         new MessageBox(String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,98,101,102,111,114,101,32,112,117,114,99,104,97,115,101,46,10,10) +
            purchaseError + "\n\nCheck your Internet connection and try again.",
            "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      if (!CopyTextToSystemClipboard(_0x42c39fcc91))
      {
         new MessageBox(String.fromCharCode(84,104,101,32,77,97,99,104,105,110,101,32,73,68,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,111,112,105,101,100,46,10,10) +
            "Select it manually and press Cmd+C or Ctrl+C.",
            "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      SetPurchaseStepPending(true);
      let pageOpened = false;
      try
      {
         new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46,60,47,112,62) +
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,99,104,101,99,107,111,117,116,32,112,97,103,101,32,119,105,108,108,32,110,111,119,32,111,112,101,110,46,60,47,112,62) +
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,60,98,62,80,97,115,116,101,32,116,104,101,32,77,97,99,104,105,110,101,32,73,68,32,105,110,116,111,32,116,104,101,32,112,117,114,99,104,97,115,101,32,102,111,114,109,32,119,105,116,104,32,67,109,100,43,86,32,111,114,32,67,116,114,108,43,86,46,60,47,98,62,60,47,112,62),
            "InNova Astro Processor", StdIcon_Information, StdButton_Ok).execute();
         console.noteln(String.fromCharCode(9989,32,77,97,99,104,105,110,101,32,73,68,32,99,111,112,105,101,100,32,116,111,32,116,104,101,32,99,108,105,112,98,111,97,114,100,46));
         pageOpened = _0x7a6ccd1c8b(planDialog.selectedUrl);
         if (pageOpened === false)
            new MessageBox(String.fromCharCode(84,104,101,32,115,117,98,115,99,114,105,112,116,105,111,110,32,112,97,103,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,111,112,101,110,101,100,46,10,10) + planDialog.selectedUrl,
               "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
         else if (pageOpened === true)
         {
            firstPurchaseControlsRequested = true;
            UpdatePurchaseActivationControls();
            ShowInNovaPurchaseReminderDialog();
         }
      }
      finally
      {
         if (pageOpened !== true)
            SetPurchaseStepPending(false);
      }
   };

   _0x82aca11b35.onClick = function()
   {
      try
      {
         let _0x8d6a71cdc5 = _0x7eee2bd14f();
         if (!_0xd86c035f60(_0x8d6a71cdc5) || !_0x3f51e778c9(_0x8d6a71cdc5))
         {
            if (!_0xd86c035f60(_0x8d6a71cdc5) && _0xf30298b9b9 === "PROJECT" && IsProjectDateValid())
            {
               _0x033648a243(_0x584b867740());
               refresh();
               return;
            }
            console.writeln(String.fromCharCode(9888,65039,32,78,111,32,118,97,108,105,100,32,115,97,118,101,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,97,118,97,105,108,97,98,108,101,46,32,89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46));
            new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,78,111,32,118,97,108,105,100,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,115,97,118,101,100,32,111,110,32,116,104,105,115,32,99,111,109,112,117,116,101,114,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(89,111,117,114,32,116,114,105,97,108,32,115,116,97,116,117,115,32,105,115,32,117,110,99,104,97,110,103,101,100,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(84,104,105,115,32,99,104,101,99,107,32,100,111,101,115,32,110,111,116,32,112,117,114,99,104,97,115,101,32,111,114,32,97,99,116,105,118,97,116,101,32,97,32,108,105,99,101,110,115,101,46,60,47,112,62),
               "InNova Astro Processor", 0, StdButton_Ok).execute();
            refresh();
            return;
         }
         let statusText = _0xc02826440e();
         console.writeln(statusText);
         let centeredStatus = "<p align=\"center\">" + statusText
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(new RegExp(String.fromCharCode(94,40,83,117,98,115,99,114,105,112,116,105,111,110,32,115,116,97,116,117,115,32,92,40,87,105,120,92,41,58,32,41,40,65,67,84,73,86,69,124,71,82,65,67,69,124,69,88,80,73,82,69,68,124,82,69,86,79,75,69,68,41,36), "m"), "$1<b>$2</b>")
            .replace(new RegExp(String.fromCharCode(94,40,69,120,112,105,114,121,32,92,40,121,121,121,121,92,47,109,109,92,47,100,100,92,41,58,32,41,40,92,100,123,52,125,45,92,100,123,50,125,45,92,100,123,50,125,41,36), "m"), "$1<b>$2</b>")
            .replace(/^(✅ Installation authorized for this period: )(YES)$/m, "$1<b>$2</b>")
            .replace(/^(Installation authorized for this period: )(NO)$/m, "$1<b>$2</b>")
            .replace(new RegExp(String.fromCharCode(94,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,92,46,36), "m"),
               String.fromCharCode(60,98,62,60,115,112,97,110,32,115,116,121,108,101,61,34,99,111,108,111,114,58,35,100,48,48,48,48,48,34,62,89,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,32,104,97,115,32,98,101,101,110,32,99,97,110,99,101,108,108,101,100,46,60,47,115,112,97,110,62,60,47,98,62))
            .replace(/^(You can continue using InNova for \d+ more day\(s\), until )(\d{4}-\d{2}-\d{2})(\.)$/m,
               "$1<b>$2</b>$3")
            .replace(/\n/g, "<br/>") + "</p>";
         new MessageBox(centeredStatus, "InNova Astro Processor", 0, StdButton_Ok).execute();
      }
      catch (error)
      {
         if (!error.innovaServerUnavailable)
            new MessageBox(String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,76,105,99,101,110,115,101,32,115,116,97,116,117,115,32,99,111,117,108,100,32,110,111,116,32,98,101,32,99,104,101,99,107,101,100,46,60,98,114,47,62,60,98,114,47,62) +
               String.fromCharCode(67,104,101,99,107,32,121,111,117,114,32,73,110,116,101,114,110,101,116,32,99,111,110,110,101,99,116,105,111,110,32,111,114,32,99,111,110,116,97,99,116,32,115,117,112,112,111,114,116,46,32,89,111,117,114,32,108,105,99,101,110,115,101,32,104,97,115,32,110,111,116,32,98,101,101,110,32,99,104,97,110,103,101,100,46,60,47,112,62),
               "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
      }
      refresh();
   };

   _0xc35cffac5a.onClick = function()
   {
      if (!_0x8e08420ae5())
         new MessageBox("Your email application could not be opened.\n\n" +
            "Email: soporte@teoriadelcolor.net\n" +
            String.fromCharCode(83,117,98,106,101,99,116,58,32,73,110,78,111,118,97,32,65,115,116,114,111,32,45,32,76,105,99,101,110,115,101,32,80,114,111,98,108,101,109),
            "InNova Astro Processor", StdIcon_Warning, StdButton_Ok).execute();
   };
   premiumSiteButton.onClick = function()
   {
      _0x7a6ccd1c8b("https://www.teoriadelcolor.es/innova-premium", "InNova Premium");
   };

   let close = new PushButton(dialog);
   close.text = "Close";
   close.icon = dialog.scaledResource(":/icons/close.png");
   close.onClick = function() { dialog.ok(); };
   let bottom = new HorizontalSizer;
   bottom.addStretch();
   bottom.add(close);

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 14;
   dialog.sizer.spacing = 12;
   dialog.sizer.add(header);
   dialog.sizer.add(info);
   dialog.sizer.add(status);
   dialog.sizer.add(actions);
   dialog.sizer.add(secondary);
   dialog.sizer.add(bottom);
   refresh();
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.execute();
   _0x195e32f0d7();
}

function StartChooseGuidedInput( disableSubframes )
{
   let dialog = new Dialog;
   dialog.windowTitle = "✦ InNova Guided Workflow — Choose an option";
   dialog.choice = "";

   let background = StartLauncherPanel( dialog, true );
   background.setScaledFixedSize( 820, 432 );
   background.sizer = new VerticalSizer;
   background.sizer.margin = 22;
   background.sizer.spacing = 16;

   let heading = new HorizontalSizer;
   heading.spacing = 18;
   heading.add( StartLauncherIcon( background, "guided-compass", 96 ) );
   let headingText = new VerticalSizer;
   headingText.addStretch();
   headingText.add( StartLauncherLabel( background,
      "<b>How would you like to begin?</b>", 21, "#102b50", false ) );
   headingText.add( StartLauncherLabel( background,
      "Choose the option you want to open in Guided Workflow.",
      13, "#174675", false ) );
   headingText.addStretch();
   heading.add( headingText, 100 );
   background.sizer.add( heading );

   function choiceCard( iconName, option, title, description, route )
   {
      let cardDisabled = disableSubframes === true &&
         route == "subframes-guided";
      let column = new Control( background );
      column.setScaledFixedSize( 240, 207 );
      column.sizer = new VerticalSizer;
      column.sizer.margin = 0;
      column.sizer.spacing = 6;
      let optionLabel = StartLauncherLabel( column, option,
         12, cardDisabled ? "#777b80" : "#ffffff", true );
      optionLabel.styleSheet = cardDisabled ?
         "font-size:12pt;color:#777b80;background-color:#c7c9cc;" :
         "font-size:12pt;color:white;background-color:#087bd5;";
      optionLabel.setScaledFixedSize( 240, 23 );
      column.sizer.add( optionLabel );
      let card = StartLauncherPanel( column, false );
      card.setScaledFixedSize( 240, 178 );
      card.sizer = new VerticalSizer;
      card.sizer.margin = 9;
      card.sizer.spacing = 5;
      let content = new HorizontalSizer;
      content.spacing = 7;
      let cardIcon = StartLauncherIcon( card, iconName, 68 );
      cardIcon.enabled = !cardDisabled;
      content.add( cardIcon );
      let labels = new VerticalSizer;
      labels.add( StartLauncherLabel( card, "<b>" + title + "</b>",
         14, cardDisabled ? "#858b91" : "#102b50", false ) );
      labels.addSpacing( 6 );
      labels.add( StartLauncherLabel( card, description,
         12, cardDisabled ? "#969ba0" : "#344b63", false ) );
      labels.addStretch();
      content.add( labels, 100 );
      card.sizer.add( content, 100 );
      let open = new PushButton( card );
      open.text = cardDisabled ? "Completed" : "Open  ▶";
      open.styleSheet = cardDisabled ?
         "background-color:#c7c9cc;color:#777b80;" +
            "font-weight:bold;font-size:11pt;" :
         "background-color:#0869d6;color:white;" +
            "font-weight:bold;font-size:11pt;";
      open.setScaledFixedHeight( 28 );
      open.onClick = function()
      {
         if ( cardDisabled ) return;
         dialog.choice = route;
         dialog.ok();
      };
      card.sizer.add( open );
      if ( cardDisabled ) {
         open.enabled = false;
      }
      column.sizer.add( card );
      return column;
   }

   let choices = new HorizontalSizer;
   choices.spacing = 10;
   choices.add( choiceCard( "subframe-review",
      "Option 1", "Load subframes",
      "Preview and reject individual light subs, then integrate the accepted " +
      "files with <b>FBPP or WBPP</b>.", "subframes-guided" ) );
   choices.add( choiceCard( "astro-processor",
      "Option 2", "One image",
      "Open one image already stacked by Seestar, Vespera or another " +
      "device.<br/><b>Astro Processor</b> will process your image.",
      "processor-guided" ) );
   choices.add( choiceCard( "bridge",
      "Option 3", "Combine multi-night",
      "Open two or more master images, register them and generate one " +
      "<b>multi-night integration</b>.", "guided" ) );
   background.sizer.add( choices );

   let cancelRow = new HorizontalSizer;
   cancelRow.addStretch();
   let cancel = new PushButton( background );
   cancel.text = "Cancel";
   cancel.icon = dialog.scaledResource( ":/icons/close.png" );
   cancel.onClick = function() { dialog.cancel(); };
   cancelRow.add( cancel );
   background.sizer.add( cancelRow );
   background.sizer.addSpacing( 12 );

   dialog.sizer = new VerticalSizer;
   dialog.sizer.margin = 0;
   dialog.sizer.add( background );
   dialog.adjustToContents();
   dialog.setFixedSize();
   dialog.onShow = function() { MiraCenterDialog( this ); };
   MiraCenterDialog( dialog );
   return dialog.execute() == StdDialogCode_Ok ? dialog.choice : "";
}

class InNovaStartLauncherDialog extends Dialog
{
constructor()
{
   super();
   let self = this;
   this.windowTitle = "✦ " + TITLE + " — " + InNovaStartVersion;
   this.route = "";
   let screenRect = this.availableScreenRect;
   let uiScale = Math.max(1, this.logicalPixelsToPhysical(100)/100);
   let availableLogicalWidth = screenRect ?
      (screenRect.x1 - screenRect.x0)/uiScale : 1200;
   let availableLogicalHeight = screenRect ?
      (screenRect.y1 - screenRect.y0)/uiScale : 900;


   let compact = availableLogicalHeight < 790 ||
      availableLogicalWidth < 940;
   this.sizer = new VerticalSizer;
   this.sizer.margin = compact ? 10 : 18;
   this.sizer.spacing = compact ? 6 : 12;


   let launcherContentWidth = compact ? 770 : 862;

   let header = new HorizontalSizer;
   header.spacing = compact ? 12 : 20;
   let brand = new VerticalSizer;
   brand.spacing = 0;

   let logoBitmap = StartLauncherBitmap("branding/logo.svg") || StartLauncherBitmap("branding/logo.png");
   if (logoBitmap) {
      let logo = new Control(this);
      logo.setScaledFixedSize(compact ? 140 : 170, compact ? 35 : 43);
      logo.onPaint = function() {
         let g = new Graphics(this);
         let scale = Math.min(this.width/logoBitmap.width, this.height/logoBitmap.height);
         let w=logoBitmap.width*scale, h=logoBitmap.height*scale;
         g.drawScaledBitmap(new Rect(0, (this.height-h)/2, w, (this.height+h)/2), logoBitmap);
         g.end();
      };
      brand.add(logo);
   } else {
      brand.add(StartLauncherLabel(this, "In<span style=\"color:#075bdd\">N</span>ova", 42, "#0b1426", false));
      brand.add(StartLauncherLabel(this, "ASTRO PHOTO SUITE", 13, "#182238", false));
   }
   header.add(brand);
   let tagline = new HorizontalSizer;
   tagline.addStretch();
   let taglineText = StartLauncherLabel(this, "A complete workflow for astrophotography", compact ? 11 : 13, "#484e57", true);
   tagline.add(taglineText);
   tagline.addStretch();
   header.add(tagline, 100);
   let licenceLink = StartLauncherLabel(this, "", compact ? 11 : 12, "#0066c4", false);
   licenceLink.wordWrapping = false;
   function updateLicenceLink()
   {
      licenceLink.text = _0xb4b48f6b83() ?
         String.fromCharCode(67,108,105,99,107,32,104,101,114,101,32,116,111,32,109,97,110,97,103,101,32,121,111,117,114,32,108,105,99,101,110,115,101) :
         String.fromCharCode(67,108,105,99,107,32,104,101,114,101,32,116,111,32,112,117,114,99,104,97,115,101,32,97,32,108,105,99,101,110,115,101);
      licenceLink.adjustToContents();
   }
   updateLicenceLink();
   licenceLink.toolTip = String.fromCharCode(79,112,101,110,32,73,110,78,111,118,97,32,76,105,99,101,110,99,101,32,77,97,110,97,103,101,114);
   function openStartLicenceManager()
   {
      StartOpenLicenceManager();
      updateLicenceLink();
      if (self[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)])
         self[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)].text = "In<span style=\"color:#075bdd\">N</span>ova Astro Photo Suite © Jesús Manuel García Flores · Mode " +
            InNovaStartSuiteStatus.replace(/ · \d+ day\(s\)/, "");
   }
   licenceLink.onMousePress = openStartLicenceManager;
   header.add(licenceLink);
   this.sizer.add(header);
   this.sizer.add(StartLauncherLabel(this, "<i>Choose how you want to begin.</i>", compact ? 12 : 13, "#0066c4", true));

   let guided = StartLauncherPanel(this, true);
   guided.setScaledFixedSize(launcherContentWidth, compact ? 142 : 174);
   guided.sizer = new HorizontalSizer;
   guided.sizer.margin = compact ? 12 : 18;
   guided.sizer.spacing = compact ? 12 : 18;
   guided.sizer.add(StartLauncherIcon(guided, "guided-compass", compact ? 88 : 112));
   let heroText = new VerticalSizer;
   heroText.spacing = compact ? 4 : 8;
   heroText.add(StartLauncherLabel(guided, "<b>GUIDED WORKFLOW</b>", compact ? 15 : 17, "#102b50", false));
   heroText.add(StartLauncherLabel(guided, "From images to final result", compact ? 12 : 13, "#174675", false));
   heroText.add(StartLauncherLabel(guided, "Start with your images and let InNova<br/>guide you through the complete workflow.", compact ? 11 : 13, "#243f5b", false));
   heroText.addStretch();
   let begin = new PushButton(guided);
   begin.text = "Start step by step  ▶";
   begin.setScaledFixedSize(compact ? 195 : 225, compact ? 30 : 34);
   begin.styleSheet =
      "QPushButton { background-color:#0869d6; color:white; border:2px solid #79b5ff; " +
      "font-weight:bold; font-size:" + (compact ? 12 : 13) + "pt; }" +
      "QPushButton:hover { background-color:white; color:#0869d6; border:2px solid #0869d6; }" +
      "QPushButton:pressed { background-color:#e7f2ff; color:#075eb0; border:2px solid #075eb0; }";
   begin.onClick = function()
   {
      let choice = StartChooseGuidedInput();
      if ( choice.length > 0 ) {
         if (self.selectorHoverTimer) self.selectorHoverTimer.stop();
         self.route = choice;
         self.ok();
      }
   };
   heroText.add(begin);
   guided.sizer.add(heroText, 100);
   let journeyPanel = new Control( guided );
   journeyPanel.setScaledFixedSize( compact ? 320 : 400,
      compact ? 108 : 132 );
   let journey = new HorizontalSizer;
   journey.spacing = compact ? 4 : 6;
   let steps = [["subframe-review", "Load files"],
      ["astro-processor", "Process a single-night<br/>or multi-night"],
      ["photo-editor", "Edit & Export"]];
   for (let i=0; i<steps.length; ++i) {
      let column = new VerticalSizer;
      column.addStretch();
      let iconRow = new HorizontalSizer;
      iconRow.addStretch();
      iconRow.add(StartLauncherIcon(guided, steps[i][0], compact ? 58 : 72));
      iconRow.addStretch();
      column.add(iconRow);
      column.add(StartLauncherLabel(guided, steps[i][1],
         compact ? 11 : 13, "#102b50", true));
      column.addStretch();
      journey.add(column);
      if (i<steps.length-1)
         journey.add(StartLauncherLabel(guided, "→",
            compact ? 14 : 17, "#075eb0", true));
   }
   journeyPanel.sizer = journey;
   guided.sizer.add(journeyPanel);
   this.sizer.add(guided);
   this.sizer.add(StartLauncherLabel(this, "OR OPEN A MODULE", compact ? 11 : 13, "#293344", true));

   let launcherModules = [
      { name: "InNova Subframe Review & Integration", shortName: "Subframe Integrator",
        icon: "subframe-review", subtitle: "Review · Integrate · Create Masters",
        description: "Preview light subframes · Blink · Accept or reject · FBPP/WBPP",
        route: "subframes" },
      { name: "InNova Multi-Night", shortName: "Multi-Night", icon: "bridge",
        subtitle: "Register · Crop · Combine",
        description: "Combine master images captured over multiple nights",
        route: "quick" },
      { name: "InNova Astro Processor", shortName: "Astro Processor",
        icon: "astro-processor", subtitle: "Process Images",
        description: "Align · Solve · Combine · Gradients · MGC · H-Alpha blend",
        route: "processor" },
      { name: "InNova Adaptive Stretch", shortName: "Adaptive Stretch",
        icon: "adaptive", subtitle: "Stretch Images",
        description: "Intelligent linear-to-nonlinear transformation",
        route: "stretch" },
      { name: "InNova Photo Editor", shortName: "Photo Editor",
        icon: "photo-editor", subtitle: "Edit and Export",
        description: "Light · Color · Contrast · Detail · Noise · Stars · Export",
        route: "editor" }
   ];
   let selectedModule = launcherModules[0];
   let selectorIcons = [];
   let moduleDetails = StartLauncherPanel(this, false);
   moduleDetails.setScaledFixedSize(launcherContentWidth, compact ? 72 : 82);
   moduleDetails.sizer = new HorizontalSizer;
   moduleDetails.sizer.margin = compact ? 8 : 10;
   moduleDetails.sizer.spacing = compact ? 8 : 12;
   let detailText = StartLauncherLabel(moduleDetails, "", compact ? 11 : 12,
      "#243f5b", true);
   let openSelected = new PushButton(moduleDetails);
   openSelected.text = "Open  ▶";
   openSelected.styleSheet = "font-size:" + (compact ? 11 : 12) + "pt;";
   openSelected.setScaledFixedSize(compact ? 84 : 94, 24);
   function refreshModuleDetails()
   {
      detailText.text = "<b style=\"font-size:" + (compact ? 14 : 16) +
         "pt;color:#101b30\">" + selectedModule.name + "</b>" +
         "<br/><span style=\"color:#075eb0\"><b>" +
         selectedModule.subtitle + "</b></span> · " +
         selectedModule.description;
      openSelected.toolTip = "Open " + selectedModule.name;
      openSelected.enabled = selectedModule.enabled !== false;
   }
   function openSelectedModule()
   {
      if (selectedModule.enabled === false) return;
      self.selectorHoverTimer.stop();
      self.route = selectedModule.route;
      self.ok();
   }
   function selectLauncherModule(module, iconControl, hovered)
   {
      if (selectedModule != module) {
         selectedModule = module;
         refreshModuleDetails();
      }
      for (let i = 0; i < selectorIcons.length; ++i) {
         let selected = selectorIcons[i].module == selectedModule;
         let underMouse = selectorIcons[i] == iconControl && hovered === true;
         if (selectorIcons[i].selected != selected ||
             selectorIcons[i].hovered != underMouse) {
            selectorIcons[i].selected = selected;
            selectorIcons[i].hovered = underMouse;
            selectorIcons[i].update();
         }
      }
   }
   openSelected.onClick = openSelectedModule;
   moduleDetails.sizer.add(detailText, 100);
   moduleDetails.sizer.add(openSelected);

   let moduleRow = new HorizontalSizer;
   moduleRow.spacing = compact ? 2 : 4;
   moduleRow.addStretch();
   for (let i = 0; i < launcherModules.length; ++i) {
      let column = new VerticalSizer;
      column.spacing = 1;
      let iconControl = StartLauncherSelectorIcon(this, launcherModules[i],
         compact, selectLauncherModule, openSelectedModule);
      selectorIcons.push(iconControl);
      let iconLine = new HorizontalSizer;
      iconLine.addStretch();
      iconLine.add(iconControl);
      iconLine.addStretch();
      column.add(iconLine);
      let moduleNameLabel = StartLauncherLabel(this,
         launcherModules[i].shortName, compact ? 10 : 11,
         launcherModules[i].enabled === false ? "#8a8a8a" : "#102b50", true);
      moduleNameLabel.setScaledFixedWidth(compact ? 100 : 112);
      column.add(moduleNameLabel);
      moduleRow.add(column);
   }
   moduleRow.addStretch();
   this.sizer.add(moduleRow);
   this.sizer.add(moduleDetails);
   refreshModuleDetails();
   selectLauncherModule(selectedModule, null, false);

   this.selectorHoverTimer = new Timer;
   this.selectorHoverTimer.interval = 0.05;
   this.selectorHoverTimer.periodic = true;
   this.selectorHoverTimer.onTimeout = function()
   {
      let hoveredIcon = null;
      for (let i = 0; i < selectorIcons.length; ++i)
         if (selectorIcons[i].isUnderMouse) {
            hoveredIcon = selectorIcons[i];
            break;
         }
      if (hoveredIcon != null)
         selectLauncherModule(hoveredIcon.module, hoveredIcon, true);
      else
         selectLauncherModule(selectedModule, null, false);
   };

   let footer = new HorizontalSizer;
   footer.spacing = 12;
   let web = new ToolButton(this);
   web.icon = new Bitmap(StartLauncherRoot + "/assets/icons/web.svg");
   web.setScaledFixedSize(28, 28);
   web.toolTip = "Visit the InNova Astro Photo Suite website";
   web.onClick = function() {
      Dialog.openBrowser("https://www.teoriadelcolor.es/innova-astro-photo-suite");
   };
   footer.add(web);
   let updates = new ToolButton(this);
   updates.icon = this.scaledResource(":/toolbar/resources-updates-check.png");
   updates.setScaledFixedSize(28, 28);
   updates.toolTip = "PixInsight updates — open the menu instructions";
   updates.onClick = function() {
      new MessageBox(
         "<p align=\"center\">To check for updates, close InNova Start and use PixInsight's menu:<br/><br/>" +
         "<b>Resources &gt; Updates &gt; Check for Updates</b></p>",
         "Check for Updates", StdIcon_Information, StdButton_Ok).execute();
   };
   footer.add(updates);
   let bugReport = new ToolButton(this);
   bugReport.icon = new Bitmap(StartLauncherRoot + "/assets/icons/bug.svg");
   bugReport.setScaledFixedSize(28, 28);
   bugReport.toolTip = "Create and email a bug report";
   bugReport.onClick = function() {
      if (StartAskCenteredQuestion(
         "InNova Bug Report",
         "Do you want to send a bug report?",
         true, "Bug report") != StdButton_Yes)
         return;
      let reportPath = File.systemTempDirectory + "/bug-report.log";
      try {
         File.writeTextFile(reportPath, StartBugReportText());
      } catch (error) {
         new MessageBox(
            "<p align=\"center\">The bug report could not be created.<br/><br/>" +
            StartHTMLText(String(error)) + "</p>",
            "InNova Bug Report", StdIcon_Error, StdButton_Ok).execute();
         return;
      }
      console.noteln("🐞 Bug report created: " + reportPath);
      if (!StartOpenBugReportEmail(reportPath))
         new MessageBox(
            "<p align=\"center\">The bug report was created, but the mail " +
            "application could not be opened.<br/><br/><b>" +
            StartHTMLText(reportPath) + "</b></p>",
            "InNova Bug Report", StdIcon_Warning, StdButton_Ok).execute();
   };
   footer.add(bugReport);
   let _0xee26cb5e98 = new ToolButton(this);
   _0xee26cb5e98.icon = this.scaledResource(":/icons/lock.png");
   _0xee26cb5e98.setScaledFixedSize(28, 28);
   _0xee26cb5e98.toolTip = String.fromCharCode(79,112,101,110,32,73,110,78,111,118,97,32,76,105,99,101,110,99,101,32,77,97,110,97,103,101,114);
   _0xee26cb5e98.onClick = openStartLicenceManager;
   footer.add(_0xee26cb5e98);
   footer.addStretch();
   let close = new PushButton(this);
   close.text = "Close";
   close.styleSheet = "font-size:13pt;";
   close.icon = this.scaledResource(":/icons/close.png");
   close.setScaledFixedSize(100, 24);
   this.exitConfirmed = false;
   this.exitLogged = false;
   function logSuiteExit()
   {
      if (self.exitLogged)
         return;
      self.exitLogged = true;
      console.writeln("\n👋 Exiting InNova Astro Photo Suite...");
   }
   function confirmSuiteExit()
   {
      return StartAskCenteredQuestion(
         "Exit InNova Astro Photo Suite",
         "Do you want to exit\nInNova Astro Photo Suite?",
         true, "InNova Astro Photo Suite", "guided-compass" ) == StdButton_Yes;
   }
   close.onClick = function() {
      if (confirmSuiteExit()) {
         self.selectorHoverTimer.stop();
         self.exitConfirmed = true;
         logSuiteExit();
         self.cancel();
      }
   };
   this.onClose = function() {
      if (self.exitConfirmed)
         return true;
      if (!confirmSuiteExit())
         return false;
      self.exitConfirmed = true;
      self.selectorHoverTimer.stop();
      logSuiteExit();
      return true;
   };
   footer.add(close);
   this.sizer.add(footer);
   this[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)] = StartLauncherLabel(this, "In<span style=\"color:#075bdd\">N</span>ova Astro Photo Suite © Jesús Manuel García Flores · Mode " +
      InNovaStartSuiteStatus.replace(/ · \d+ day\(s\)/, ""), 10, "#606670", true);
   this.sizer.add(this[String.fromCharCode(108,105,99,101,110,115,101,83,116,97,116,117,115)]);
   this.adjustToContents();
   this.setFixedSize();


   this.initialCenterTimer = new Timer;
   this.initialCenterTimer.interval = 0.05;
   this.initialCenterTimer.periodic = false;
   this.initialCenterTimer.onTimeout = function()
   {
      MiraCenterDialog( self );
   };
   this.onShow = function()
   {
      MiraCenterDialog( this );
      self.selectorHoverTimer.start();
      self.initialCenterTimer.start();
   };
   MiraCenterDialog(this);
}
}


#define INNOVA_ADAPTIVE_EMBEDDED
#include "../InNova/InNova03.js"
#undef INNOVA_ADAPTIVE_EMBEDDED
#define INNOVA_EDITOR_EMBEDDED
#include "../InNova/InNova02.js"
#undef INNOVA_EDITOR_EMBEDDED

function StartRunEditorEmbedded(source)
{
   let savedName = ProjecTname;
   let savedVersion = ProjecTver;
   let savedToken = _0x9627d349e7;
   let _0x8d6a71cdc5 = _0xf30298b9b9;
   let savedTitle = InNovaEditorTitle;
   let savedType = ProjecTypevar;
   let savedTypeRec = ProjecTypevarRec;
   let output = null;
   try {
      ProjecTname = InNovaEditorTitle = "🪐 InNova Photo Editor";
      ProjecTver = "v.1.0.build.0227";
      if (!_0x3114d41d72()) return;
      InitializeInNovaProviderPaths();
      InNovaEditorResetEditorState();
      if (!source) {
         originalFilePathMLDenoisefin = GetInNovaDataFilePath(StarMLDenoiseModel);
         Settings.write("originalFilePathMLDenoisefin", DataType_String,
            originalFilePathMLDenoisefin);
         let selector = new InNovaEditorDialog;
         selector.onShow = function() { MiraCenterDialog(this); };
         selector.adjustToContents();
         MiraCenterDialog(selector);
         return selector.runDirect();
      }
      ProjecTypevar = ProjecTypevarRec =
         InNovaEditorInferProjectType(source.mainView.id);
      output = InNovaEditorCloneWindow(source,
         MiraUniqueWindowId(source.mainView.id + "_InNovaPhotoEditor"));


      if (output.mainView.image.numberOfChannels < 3) {
         let image = output.mainView.image;
         let rgb = InNovaEditorImageFromRgb(image.width, image.height,
            InNovaEditorReadRgb(image));
         output.mainView.beginProcess(UndoFlag_NoSwapFile);
         try { output.mainView.image.assign(rgb); }
         finally { output.mainView.endProcess(); rgb.free(); }
      }
      let result = InNovaEditorRunProEditor(output.mainView, ProjecTypevar);
      if (result.accepted) {
         output.show();
         output.bringToFront();
         let acceptedOutput = output;
         output = null;
         return acceptedOutput;
      } else if (result.openRequested && result.requestedSourceId) {
         output.forceClose();
         output = null;
         return StartRunEditorEmbedded(ImageWindow.windowById(result.requestedSourceId));
      } else if (!result.cancelled && !result.openRequested)
         throw new Error("The selected image could not be prepared for editing.");
   } finally {
      if (output && !output.isNull) output.forceClose();
      ProjecTname = savedName;
      ProjecTver = savedVersion;
      _0x9627d349e7 = savedToken;
      _0xf30298b9b9 = _0x8d6a71cdc5;
      InNovaEditorTitle = savedTitle;
      ProjecTypevar = savedType;
      ProjecTypevarRec = savedTypeRec;
   }
}

function StartRunAdaptiveEmbedded(showSelector)
{
   let savedName = ProjecTname;
   let savedVersion = ProjecTver;
   let savedToken = _0x9627d349e7;
   let _0x8d6a71cdc5 = _0xf30298b9b9;
   try {
      ProjecTname = "💫 InNova Adaptive Stretch";
      ProjecTver = "v.1.0.build.0094";
      if (_0x9744e7442c()) return InNovaAdaptiveRunMain(showSelector);
   } finally {
      ProjecTname = savedName;
      ProjecTver = savedVersion;
      _0x9627d349e7 = savedToken;
      _0xf30298b9b9 = _0x8d6a71cdc5;
   }
}

function StartConsumeBridgeReturn()
{
   let value = Settings.read("InNova/BridgeReturn", DataType_String);
   let valid = Settings.lastReadOK;
   Settings.remove("InNova/BridgeReturn");
   if (!valid || !value) return null;
   try {
      let request = JSON.parse(value);
      let age = Date.now() - request.created;
      return age >= 0 && age < 120000 ? request : null;
   } catch (error) {
      return null;
   }
}

function StartRestoreBridgeAfterProcessor(request)
{
   let dialog = new InNovaStartDialog(false);
   dialog.windowTitle = "🔭 InNova Multi-Night — Prepare Images — " +
      InNovaStartVersion + " — " + _0x88bfe5ab4a();
   let result = request && request.resultId ?
      ImageWindow.windowById(request.resultId) : null;
   if ((result == null || result.isNull) && request && request.sourceId)
      result = ImageWindow.windowById(request.sourceId);
   if (result != null && !result.isNull && !result.mainView.isNull) {
      let processed = request != null && request.processed === true &&
         request.resultId && request.resultId != request.sourceId;
      let resultItem = StartImageEntry(result);
      resultItem.alreadyStretched = processed;
      if (processed)
         dialog.stretchedEditorSources[result.mainView.id] = result;
      dialog.imageViewer.setSeries([resultItem],
         processed ? "Astro Processor result" : "Prepared image", 0);
      dialog.reviewStatus.text = processed ?
         "Returned from <b>InNova Astro Processor</b>. Showing <b>" +
            result.mainView.id + "</b>." :
         "Returned from <b>InNova Astro Processor</b> without processing. " +
            "Showing the prepared image <b>" + result.mainView.id + "</b>.";
      result.show();
      result.bringToFront();
      dialog.reviewDialog.adjustToContents();
      MiraCenterDialog(dialog.reviewDialog);
      dialog.reviewDialog.execute();
      if (dialog.processorDirectLaunchRequested) {
         StartLaunchInNovaIntegrator(dialog.processorReturnSourceId);
         return true;
      }
   }
   dialog.execute();
   if (dialog.processorDirectLaunchRequested) {
      StartLaunchInNovaIntegrator(dialog.processorReturnSourceId);
      return true;
   }
   return false;
}

function StartLoadSubframeMasterWindows( paths, cleanupDirectory )
{
   let opened = [];
   let failed = [];
   for ( let i = 0; i < paths.length; ++i ) {
      try {
         let windows = ImageWindow.open( paths[i] );
         if ( windows == null || windows.length == 0 )
            failed.push( paths[i] );
         else
            for ( let j = 0; j < windows.length; ++j ) {
               windows[j].iconize();
               opened.push( windows[j] );
            }
      } catch ( error ) {
         failed.push( paths[i] );
         console.warningln( "⚠️ FBPP master could not be opened: " +
            paths[i] + " — " + error );
      }
   }
   if ( failed.length > 0 )
      new MessageBox( failed.length + " FBPP master image(s) could not be " +
         "opened.\n\n" + failed.join( "\n" ),
         "InNova Subframe Review & Integration — Multi-Night",
         StdIcon_Warning, StdButton_Ok ).execute();


   if ( opened.length > 0 && failed.length == 0 && cleanupDirectory &&
        cleanupDirectory.length > 0 ) {
      try {
         StartSubframeRemoveTemporaryDirectory( cleanupDirectory );
         console.noteln( "🧹 Temporary Subframe Review files removed from: " +
            cleanupDirectory );
      }
      catch ( error ) {
         console.warningln( "⚠️ Temporary Subframe Review files could not be " +
            "removed: " + error );
      }
   }

   return opened;
}

function main()
{
   StartBeginBugReportCapture();
   console.writeln( "✦ " + TITLE + " " + InNovaStartVersion );
   console.writeln( "-------------------------------------" );
   console.noteln( "🟢 Ready..." );
   if ( !MiraRequireCompatiblePixInsight( TITLE ) )
      return;
   _0x195e32f0d7();
   console.hide();
   let bridgeReturn = StartConsumeBridgeReturn();
   if (bridgeReturn != null && StartRestoreBridgeAfterProcessor(bridgeReturn))
      return;
   let launcher = new InNovaStartLauncherDialog;
   while ( launcher.execute() ) {

      launcher.hide();
      if ( launcher.route == "subframes" ||
           launcher.route == "subframes-guided" ) {
         try {
            let guidedFromSubs = launcher.route == "subframes-guided";
            let review = StartRunSubframeReview( guidedFromSubs );


            if ( !guidedFromSubs ) {
               if ( review.cleanupDirectory &&
                    review.cleanupDirectory.length > 0 ) {
                  try {
                     StartSubframeRemoveTemporaryDirectory(
                        review.cleanupDirectory );
                     console.noteln( "🧹 Temporary Subframe Review files " +
                        "removed after stand-alone processing." );
                  } catch ( cleanupError ) {
                     console.warningln( "⚠️ Temporary Subframe Review files " +
                        "could not be removed: " + cleanupError );
                  }
               }
               continue;
            }
            if ( !review.continueToBridge )
               continue;


            let loadedSubframeMasters = StartLoadSubframeMasterWindows(
               review.masterPaths, review.cleanupDirectory );
            if ( loadedSubframeMasters.length == 0 )
               continue;
            if ( loadedSubframeMasters.length == review.masterPaths.length )
               review.cleanupDirectory = "";
            if ( !StartPrepareSubframeMastersForProcessor(
                    loadedSubframeMasters ) )
               continue;
            StartLaunchInNovaIntegrator( "" );
            return;
         } catch ( error ) {
            console.criticalln( "❌ Subframe Review failed: " + error );
            new MessageBox( "InNova Subframe Review & Integration could not complete the " +
               "workflow.\n\n" + error, "InNova Subframe Review & Integration",
               StdIcon_Error, StdButton_Ok ).execute();
         }
         continue;
      }
      if ( launcher.route == "processor-guided" ) {
         StartPrepareProcessorLaunchWithoutImages();
         StartLaunchInNovaIntegrator( "" );
         return;
      }
      let moduleScripts = { processor: "InNova01.js",
         stretch: "InNova03.js", editor: "InNova02.js" };
      if ( moduleScripts[launcher.route] ) {
         try {
            if (launcher.route == "stretch") {
               StartRunAdaptiveEmbedded(true);
               continue;
            }
            if (launcher.route == "editor") {
               try { StartRunEditorEmbedded(); }
               finally { console.hide(); }
               continue;
            }
            let scriptPath = File.extractDrive(#__FILE__) +
               File.extractDirectory(#__FILE__) + "/../InNova/" +
               moduleScripts[launcher.route];
            let returnRequest = "InNova/ProcessorReturnToStart";
            Settings.write(returnRequest, DataType_String, JSON.stringify({
               path: File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/InNovaStart.js",
               created: Date.now()
            }));
            try { StartLaunchModule( scriptPath ); }
            catch (error) {
               Settings.write(returnRequest, DataType_String, "");
               throw error;
            }
            return;
         } catch ( error ) {
            new MessageBox( "The module could not be opened.\n\n" + error,
               TITLE, StdIcon_Error, StdButton_Ok ).execute();
         }
         continue;
      }
      let dialog = new InNovaStartDialog( launcher.route == "guided" );
      dialog.windowTitle = launcher.route == "guided" ?
         "🔭 InNova Guided Workflow — Step 1: InNova Multi-Night — " +
            InNovaStartVersion + " — " + _0x88bfe5ab4a() :
         "🔭 InNova Multi-Night — " + InNovaStartVersion +
            " — " + _0x88bfe5ab4a();
      for ( ;; ) {
         dialog.runPreparationRequested = false;
         dialog.execute();
         if ( !dialog.runPreparationRequested ) break;
         dialog.runPreparationRequested = false;
         dialog.performRunPreparation();
         if ( dialog.preparationFinished ||
              dialog.processorDirectLaunchRequested ||
              (dialog.guidedWorkflow && dialog.integratorLaunchRequested) )
            break;

      }
      if ( dialog.preparationFinished ) continue;
      if ( dialog.processorDirectLaunchRequested ||
           (dialog.guidedWorkflow && dialog.integratorLaunchRequested) ) {
         try {
            StartLaunchInNovaIntegrator(
               dialog.processorDirectLaunchRequested && !dialog.guidedWorkflow ?
                  dialog.processorReturnSourceId : "" );
            return;
         } catch ( error ) {
            console.criticalln( "❌ Could not launch InNova Astro Processor: " + error );
            new MessageBox(
               "InNova Astro Processor could not be opened automatically.\n\n" + error,
               "🔭 InNova Multi-Night — InNova Astro Processor launch failed",
               StdIcon_Error, StdButton_Ok ).execute();
         }
      }
   }


   if ( launcher.exitConfirmed ) {


      MiraOrdena1();
      console.hide();
      CoreApplication.processEvents();
      console.hide();
   }
}

main();

#endif
