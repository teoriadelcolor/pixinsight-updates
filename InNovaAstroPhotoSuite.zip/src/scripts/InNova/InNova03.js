#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaAdaptiveStretch : InNova Astro Photo Suite > InNova Adaptive Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open linear images. \
Uses the shared InNova Astro Photo Suite access state. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#ifndef INNOVA_ADAPTIVE_EMBEDDED
#define TITLE "InNova Adaptive Stretch"
#endif

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

#ifndef INNOVA_ADAPTIVE_EMBEDDED
var ProjecTname = "💫 InNova Adaptive Stretch";
var ProjecTver = "v.1.0.build.0094";
var _0x6d1f63ff9b = String.fromCharCode(49,56,97,100,48,57,120,106,114);
var _0xd70ef7a89b =
   String.fromCharCode(101,102,48,50,56,100,50,54,101,100,55,52,54,50,99,52,54,53,102,52,48,57,49,101,57,54,53,98,52,97,102,57,102,99,100,54,102,97,49,50,53,98,50,53,57,55,48,101,56,51,51,51,98,98,55,49,97,52,102,53,50,100,49,52);
var _0x9627d349e7 = "";
var _0xf30298b9b9 = "EMPTY";
#endif
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionObjectType = "STARS";
var OptionSeestar = "OFF";
var OptionVaonisVespera = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Adaptive Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#ifndef INNOVA_ADAPTIVE_EMBEDDED
#include "lib/lite01.js"
#endif
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function _0x9744e7442c()
{
   if (!_0xa9be17efdf()) {
      _0x9627d349e7 = "";
      _0xf30298b9b9 = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Adaptive Stretch",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let _0x15139f4b5f = _0xbc3a6b09d4();
   let complete = _0xd86c035f60(_0x15139f4b5f);
   let signatureValid = complete && _0x3f51e778c9(_0x15139f4b5f);
   let _0xa95094b41d = signatureValid && _0xbbbb498022(_0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)]);

   let refreshOutcome = {};
   if (signatureValid && _0x76a223b74d(_0x15139f4b5f, _0xa95094b41d, refreshOutcome)) {
      _0x15139f4b5f = _0x7eee2bd14f();
      complete = _0xd86c035f60(_0x15139f4b5f);
      signatureValid = complete && _0x3f51e778c9(_0x15139f4b5f);
      _0xa95094b41d = signatureValid && _0xbbbb498022(_0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)]);
   }

   if (signatureValid) _0x2e9fdb16df();
   let _0xb5607bd1b8 = _0xb4b48f6b83();
   _0xa95094b41d = signatureValid && _0xbbbb498022(_0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)]);
   let grace = signatureValid && _0xa95094b41d && _0x8f9399a7cb &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)] && InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)].status === "GRACE" &&
      _0xf6764ad7f0(_0x15139f4b5f[String.fromCharCode(101,120,112,105,114,121)]);

   if (signatureValid && refreshOutcome.status === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
       refreshOutcome.paidRenewalPending && !_0x8f9399a7cb) {
      _0x9627d349e7 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
      _0xf30298b9b9 = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Adaptive Stretch");
      return false;
   }

   if (signatureValid && _0x8f9399a7cb && (!_0xa95094b41d || grace)) {
      _0x9627d349e7 = _0x15139f4b5f[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
      _0xf30298b9b9 = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         _0x6e987547f6("InNova Adaptive Stretch", _0x15139f4b5f, true);
      else
         console.noteln(String.fromCharCode(9989,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,108,105,99,101,110,115,101,32,97,99,116,105,118,97,116,101,100,46));
      return true;
   }

   if (!complete && !_0xb5607bd1b8 && IsProjectDateValid()) {
      _0x9627d349e7 = _0x875becaf01().substr(0, 8);
      _0xf30298b9b9 = "PROJECT";
      console.noteln(String.fromCharCode(55358,56810,32,76,105,99,101,110,115,101,32,109,111,100,101,58,32,84,82,73,65,76));
      console.noteln(String.fromCharCode(55357,56517,32,84,114,105,97,108,32,116,105,109,101,32,114,101,109,97,105,110,105,110,103,58,32) + _0x584b867740() + " day(s).");
      return true;
   }

   _0x9627d349e7 = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
   if (_0xa95094b41d && !grace) {
      _0xf30298b9b9 = String.fromCharCode(69,88,80,73,82,69,68);
      _0x6e987547f6("InNova Adaptive Stretch", _0x15139f4b5f, false);
      return false;
   }
   if (signatureValid && !_0x8f9399a7cb) {
      _0xf30298b9b9 = "DEVICE_REQUIRED";
      _0xdfd3a31f30("InNova Adaptive Stretch",
         String.fromCharCode(84,104,105,115,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,111,110,32,116,104,105,115,32,100,101,118,105,99,101,46));
      return false;
   }
   _0xf30298b9b9 = "EMPTY";
   if (_0xb5607bd1b8 || complete) {
      _0xdfd3a31f30("InNova Adaptive Stretch",
         String.fromCharCode(89,111,117,114,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,109,105,115,115,105,110,103,32,111,114,32,105,110,118,97,108,105,100,46,32,80,108,101,97,115,101,32,114,101,115,116,111,114,101,32,121,111,117,114,32,108,105,99,101,110,115,101,32,102,114,111,109,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,46),
         { [String.fromCharCode(109,105,115,115,105,110,103,76,105,99,101,110,115,101)]: true });
      return false;
   }
   new MessageBox(
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,116,114,105,97,108,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
         String.fromCharCode(80,108,101,97,115,101,32,111,112,101,110,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,114,111,99,101,115,115,111,114,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32) +
         String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32,116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
      "InNova Adaptive Stretch",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaAdaptiveStretchUniqueWindowId(baseId)
{
   let candidate = baseId;
   let suffix = 2;
   while (ImageWindow.windowById(candidate) &&
          !ImageWindow.windowById(candidate).isNull)
      candidate = baseId + "_" + suffix++;
   return candidate;
}

function InNovaAdaptiveRefreshIcon()
{
   let bitmap = new Bitmap(24, 24);
   bitmap.fill(0x00000000);
   let graphics = new Graphics(bitmap);
   graphics.antialiasing = true;
   graphics.pen = new Pen(0xff30343a, 2);


   let upperArc = [[4,10], [5,7], [7,5], [10,4], [14,4], [18,6]];
   let lowerArc = [[20,14], [19,17], [17,19], [14,20], [10,20], [6,18]];
   for (let i = 0; i + 1 < upperArc.length; ++i)
      graphics.drawLine(upperArc[i][0], upperArc[i][1],
                        upperArc[i + 1][0], upperArc[i + 1][1]);
   for (let j = 0; j + 1 < lowerArc.length; ++j)
      graphics.drawLine(lowerArc[j][0], lowerArc[j][1],
                        lowerArc[j + 1][0], lowerArc[j + 1][1]);
   graphics.drawLine(18, 6, 18, 2);
   graphics.drawLine(18, 6, 14, 7);
   graphics.drawLine(6, 18, 6, 22);
   graphics.drawLine(6, 18, 10, 17);
   graphics.end();
   return bitmap.scaled(2, 2, BitmapInterpolation_Bilinear);
}

function InNovaAdaptiveStretchDebayerCopy(sourceWindow, outputId)
{
   let pattern = MiraMoonSunKeywordValue(sourceWindow, "BAYERPAT");
   if (pattern !== "RGGB" && pattern !== "BGGR" &&
       pattern !== "GBRG" && pattern !== "GRBG")
      return null;
   let temporaryInput = File.uniqueFileName(
      File.systemTempDirectory, 10, "InNova-Adaptive-CFA-", ".fits");
   let temporaryOutput = File.extractDrive(temporaryInput) +
      File.extractDirectory(temporaryInput) + "/" +
      File.extractName(temporaryInput) + "_InNova_d.xisf";
   let opened = null;
   let temporarySource = null;
   try {
      if (sourceWindow.filePath && File.exists(sourceWindow.filePath))
         File.copyFile(temporaryInput, sourceWindow.filePath);
      else {


         let sourceImage = sourceWindow.mainView.image;
         temporarySource = new ImageWindow(
            sourceImage.width, sourceImage.height,
            sourceImage.numberOfChannels, 32, true, false,
            InNovaAdaptiveStretchUniqueWindowId("InNovaAdaptive_CFA_Input"));
         temporarySource.mainView.beginProcess(UndoFlag_NoSwapFile);
         temporarySource.mainView.image.assign(sourceImage);
         temporarySource.mainView.endProcess();
         try { temporarySource.keywords = sourceWindow.keywords; }
         catch (keywordError) {}
         if (!temporarySource.saveAs(
              temporaryInput, false, false, false, false))
            throw new Error(
               "The in-memory Bayer image could not be prepared for Debayer.");
         temporarySource.forceClose();
         temporarySource = null;
      }
      let process = new Debayer;
      process.targetItems = [[true, temporaryInput]];
      process.cfaPattern = MiraMoonSunDebayerPattern(pattern);
      process.debayerMethod = Debayer.VNG;
      process.evaluateNoise = false;
      process.evaluateSignal = false;
      process.outputRGBImages = true;
      process.outputSeparateChannels = false;
      process.outputDirectory = File.extractDrive(temporaryInput) +
                                File.extractDirectory(temporaryInput);
      process.outputExtension = ".xisf";
      process.outputPostfix = "_InNova_d";
      process.overwriteExistingFiles = true;
      if (!process.executeGlobal() || !File.exists(temporaryOutput))
         throw new Error("PixInsight Debayer did not create its RGB output.");
      opened = ImageWindow.open(temporaryOutput);
      if (!opened || opened.length === 0 || opened[0].isNull ||
          !opened[0].mainView.image.isColor)
         throw new Error("The Debayer output is not a valid RGB image.");
      opened[0].mainView.id = outputId;
      console.noteln("✅ Standalone preparation: VNG Debayer " + pattern + ".");
      return opened[0];
   }
   catch (error) {
      if (opened && opened.length > 0 && opened[0] && !opened[0].isNull)
         opened[0].forceClose();
      if (temporarySource && !temporarySource.isNull)
         temporarySource.forceClose();
      throw error;
   }
   finally {
      try {
         if (temporarySource && !temporarySource.isNull)
            temporarySource.forceClose();
      } catch (ignoreSourceError) {}
      try { if (File.exists(temporaryInput)) File.remove(temporaryInput); }
      catch (ignoreInputError) {}
      try { if (File.exists(temporaryOutput)) File.remove(temporaryOutput); }
      catch (ignoreOutputError) {}
   }
}

function InNovaAdaptiveStretchPrepareCopy(sourceWindow, objectType,
                                           imageType)
{
   let baseId = InNovaAdaptiveStretchUniqueWindowId(
      sourceWindow.mainView.id + "_InNova_Prepared");
   let prepared = null;
   let corrected = null;
   try {
      let image = sourceWindow.mainView.image;
      if (image.isColor && image.numberOfChannels >= 3)
         prepared = MiraAdaptiveStretchWindowFromImage(image, baseId);
      else if (objectType === "MOON_SUN" ||
               imageType.indexOf("SEESTAR") === 0 ||
               imageType.indexOf("VAONIS") === 0) {
         prepared = InNovaAdaptiveStretchDebayerCopy(sourceWindow, baseId);
         if (!prepared)
            prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
      }
      else {
         prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
         console.noteln(
            "✅ Standalone preparation: monochrome source expanded to neutral RGB.");
      }


      if (objectType === "MOON_SUN") {
         console.noteln(
            "🌙 Moon or Sun preparation: preserving the source without ABE.");
         prepared.mainView.id = InNovaAdaptiveStretchUniqueWindowId(
            sourceWindow.mainView.id + "_InNova_Adaptive");
         prepared.show();
         prepared.position = new Point(0, 0);
         prepared.bringToFront();
         let brightTarget = prepared;
         prepared = null;
         return brightTarget;
      }

      console.noteln("🧹 Standalone preparation: applying ABE to a temporary copy.");
      MiraABE(prepared);
      corrected = ImageWindow.windowById(prepared.mainView.id + "_ABE");
      if (!corrected || corrected.isNull || !corrected.mainView ||
          corrected.mainView.isNull)
         throw new Error("ABE did not create the prepared image.");
      prepared.forceClose();
      prepared = null;
      corrected.mainView.id = InNovaAdaptiveStretchUniqueWindowId(
         sourceWindow.mainView.id + "_InNova_Adaptive");
      corrected.show();
      corrected.position = new Point(0, 0);
      corrected.bringToFront();
      return corrected;
   }
   catch (error) {
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (corrected && !corrected.isNull) corrected.forceClose();
      throw error;
   }
}

function InNovaAdaptiveSelectSourceFile(masters)
{
   let files = new OpenFileDialog;
   files.caption = "Open an image for InNova Adaptive Stretch";
   files.multipleSelections = false;
   files.filters = [["Images", "*.xisf *.fits *.fit *.fts *.tif *.tiff *.png *.jpg *.jpeg"],
                    ["All files", "*"]];
   if (masters) files.initialPath = InNovaImageMasterDirectory() + "/";
   if (!files.execute()) return null;
   let opened = ImageWindow.open(files.fileName);
   if (!opened || opened.length === 0) return null;
   for (let i = 0; i < opened.length; ++i) opened[i].show();
   return opened[0];
}

function InNovaAdaptiveSourceType(source)
{
   return !source.mainView.image.isColor ||
      source.mainView.image.numberOfChannels < 3 ? 0 : 1;
}

function InNovaAdaptiveKeywordValue(source, names)
{
   if (!source || source.isNull) return "";
   let keywords = source.keywords;
   for (let i = 0; i < keywords.length; ++i) {
      let name = String(keywords[i].name).toUpperCase();
      for (let j = 0; j < names.length; ++j)
         if (name === names[j])
            return String(keywords[i].strippedValue).trim();
   }
   return "";
}

function InNovaAdaptiveDetectedSourceType(source)
{
   let names = ["CREATOR", "PRODUCER", "ORIGIN", "TELESCOP", "INSTRUME", "CAMERA",
      "MAKE", "MODEL", "SOFTWARE", "DESCRIPTION", "IMAGEDESCRIPTION",
      "INNVDEV"];
   let identity = InNovaAdaptiveKeywordValue(source, names) + " " +
      (source && source.filePath ? String(source.filePath) : "") + " " +
      (source && source.mainView && !source.mainView.isNull ?
         String(source.mainView.id) : "");
   if (/SEESTAR[^\n]*S50\s*PRO|S50\s*PRO(?![A-Z0-9])/i.test(identity)) return 4;
   if (/SEESTAR[^\n]*S50(?![^\n]*PRO)|S50(?!\s*PRO)(?![A-Z0-9])/i.test(identity)) return 3;
   if (/SEESTAR[^\n]*S30\s*PRO|S30\s*PRO(?![A-Z0-9])/i.test(identity)) return 2;
   if (/SEESTAR/i.test(identity)) return 5;
   if (/VAONIS_VESPERA_III|VESPERA[^A-Z0-9]*(III|3)([^A-Z0-9]|$)/i.test(identity)) return 6;
   if (/VAONIS|VESPERA/i.test(identity)) return 7;
   return InNovaAdaptiveSourceType(source);
}


function InNovaAdaptiveAcquisition(state)
{
   this.pending = null;
   let context = this;
   this.buildControls = function(dialog)
   {
      let group = new GroupBox(dialog);
      group.title = "1. Acquisition";
      group.sizer = new VerticalSizer;
      group.sizer.margin = 8;
      group.sizer.spacing = 6;
      let line = new HorizontalSizer;
      line.spacing = 6;
      let typeLabel = new Label(group);
      typeLabel.text = "Image type:";
      typeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let type = new ComboBox(group);
      for (let name of ["Monochrome (B/W)", "OSC", "Seestar S30 Pro",
                        "Seestar S50", "Seestar S50 Pro",
                        "Seestar (Automatic)", "VAONIS Vespera III",
                        "VAONIS Vespera (Automatic)"])
         type.addItem(name);
      type.currentItem = state.imageType;
      let objectLabel = new Label(group);
      objectLabel.text = "Object:";
      objectLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      let object = new ComboBox(group);
      object.addItem("Nebula or Galaxy");
      object.addItem("Moon or Sun");
      object.currentItem = state.objectType;
      line.add(typeLabel);
      line.add(type, 100);
      line.addSpacing(8);
      line.add(objectLabel);
      line.add(object, 100);
      group.sizer.add(line);
      dialog.acquisitionOpenButton = new ToolButton(dialog);
      let open = dialog.acquisitionOpenButton;
      open.icon = dialog.scaledResource(":/icons/folder-open.png");
      open.setScaledFixedSize(28, 28);
      open.toolTip = "Open an image file";
      dialog.acquisitionMastersButton = new ToolButton(dialog);
      let masters = dialog.acquisitionMastersButton;
      masters.icon = dialog.scaledResource(":/icons/documents-import.png");
      masters.setScaledFixedSize(28, 28);
      masters.toolTip = "Open masters from Documents/InNova/Sub master files";
      group.toolTip = "Changing acquisition restarts the stretch adjustments from the original image.";
      function request(sourceId, imageType, objectType) {
         if (sourceId === state.sourceId && imageType === state.imageType &&
             objectType === state.objectType) return;
         context.pending = { sourceId: sourceId, imageType: imageType,
            objectType: objectType };
         dialog.cancel();
      }
      type.onItemSelected = function(index) {
         request(state.sourceId, index, object.currentItem);
      };
      object.onItemSelected = function(index) {
         request(state.sourceId, type.currentItem, index);
      };
      function loadSource(fromMasters) {
         try {
            let win = fromMasters ? InNovaAdaptiveSelectSourceFile(true) :
               InNovaAdaptiveChooseOpenSource();
            if (win) request(win.mainView.id,
               InNovaAdaptiveDetectedSourceType(win), object.currentItem);
         } catch (error) {
            new MessageBox(String(error), "InNova Adaptive Stretch",
               StdIcon_Error, StdButton_Ok).execute();
         }
      };
      open.onClick = function() { loadSource(false); };
      masters.onClick = function() { loadSource(true); };
      return group;
   };
}

function InNovaAdaptiveChooseOpenSource()
{
   let id = InNovaChooseWorkspaceSource("InNova Adaptive Stretch", "adaptive", false,
      InNovaAdaptiveSelectSourceFile);
   return id ? ImageWindow.windowById(id) : null;
}

function InNovaAdaptiveRunMain(showSelector)
{
   let source = ImageWindow.activeWindow;
   if (showSelector || !source || source.isNull) {
      try { source = InNovaAdaptiveChooseOpenSource(); }
      catch (error) {
         new MessageBox(String(error), "InNova Adaptive Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         return;
      }
   }
   if (!source || source.isNull) return;
   let state = { sourceId: source.mainView.id,
      imageType: InNovaAdaptiveDetectedSourceType(source), objectType: 0 };
   let previous = null;
   for (;;) {
      if (!_0x5c468cd8b2()) return;
      let prepared = null;
      let context = null;
      try {
         source = ImageWindow.windowById(state.sourceId);
         if (!source || source.isNull) throw new Error("The selected image is no longer available.");
         let selectedType = ["MONOCHROME", "OSC", "SEESTAR_S30_PRO",
            "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
            "VAONIS_VESPERA_III", "VAONIS_AUTO"][state.imageType];
         ProjecTypevar = "OSC";
         ProjecTypevarRec = ProjecTypevar;
         OptionObjectType = state.objectType === 1 ? "MOON_SUN" : "STARS";
         OptionSeestar = selectedType.indexOf("SEESTAR") === 0 ? "ON" : "OFF";
         OptionVaonisVespera = selectedType.indexOf("SEESTAR") === 0 ||
            selectedType.indexOf("VAONIS") === 0 ? "ON" : "OFF";
         OptionSmartTelescopeModel = OptionVaonisVespera === "ON" ?
            selectedType : "NONE";
         prepared = InNovaAdaptiveStretchPrepareCopy(source, OptionObjectType, selectedType);
         context = new InNovaAdaptiveAcquisition({ sourceId: state.sourceId,
            imageType: state.imageType, objectType: state.objectType, prepared: prepared });
         if (MiraRunAdaptiveStretch(prepared, true, selectedType === "MONOCHROME", context)) {
            prepared.show();
            prepared.zoomToFit(true, false);
            prepared.bringToFront();
            return { window: prepared, sourceId: state.sourceId };
         }
      } catch (error) {
         new MessageBox("The selected image could not be prepared.\n\n" +
            (error.message || error), "InNova Adaptive Stretch",
            StdIcon_Error, StdButton_Ok).execute();
         if (prepared && !prepared.isNull) prepared.forceClose();
         if (previous) { state = previous; previous = null; continue; }
         return;
      }
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (!context || !context.pending) return;
      previous = state;
      state = context.pending;
   }
}

#ifndef INNOVA_ADAPTIVE_EMBEDDED

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Adaptive Stretch") &&
    _0x9744e7442c()) {
   InNovaAdaptiveRunMain(true);
}


#endif

#endif
