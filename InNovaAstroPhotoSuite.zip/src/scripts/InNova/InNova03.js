#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaAdaptiveStretch : InNova Astro Photo Suite > InNova Adaptive Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open color images. \
Uses the shared InNova Astro Photo Suite access state. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Adaptive Stretch"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

var ProjecTname = "💫 InNova Adaptive Stretch";
var ProjecTver = "v.1.0.build.0066";
var _0x6c1b9519f7 = String.fromCharCode(48,49,97,100,48,57,120,106,114);
var _0xf9fe6189d6 =
   "5dda0b039553a63d807d51a969764e74d961cbec1b7fac16b527e2870e300f07";
var _0xd5064eab4e = "";
var _0x3a5b42adaf = "EMPTY";
var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);


var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionObjectType = "STARS";
var OptionSeestar = "OFF";
var OptionVaonisVespera = "OFF";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var Option300 = "OFF";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Adaptive Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function _0x9b415bae04()
{
   if (!_0x38490f4047()) {
      _0xd5064eab4e = "";
      _0x3a5b42adaf = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Adaptive Stretch",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   CompletePendingInNovaPurchase();
   let _0x56be11ff61 = _0xfa28a38636();
   let complete = _0x5656e57976(_0x56be11ff61);
   let signatureValid = complete && _0x6c9d2af7f0(_0x56be11ff61);
   let _0x6f14e96ecd = signatureValid && _0x952e972807(_0x56be11ff61[String.fromCharCode(101,120,112,105,114,121)]);

   let refreshOutcome = {};
   if (signatureValid && _0xdfd8337cf3(_0x56be11ff61, _0x6f14e96ecd, refreshOutcome)) {
      _0x56be11ff61 = _0x76d47b56b5();
      complete = _0x5656e57976(_0x56be11ff61);
      signatureValid = complete && _0x6c9d2af7f0(_0x56be11ff61);
      _0x6f14e96ecd = signatureValid && _0x952e972807(_0x56be11ff61[String.fromCharCode(101,120,112,105,114,121)]);
   }

   if (signatureValid) _0x8ced081d6a();
   let _0x55e4d87ad7 = _0xb2c48814cb();
   _0x6f14e96ecd = signatureValid && _0x952e972807(_0x56be11ff61[String.fromCharCode(101,120,112,105,114,121)]);
   let grace = signatureValid && _0x6f14e96ecd && _0x107804e40a &&
      typeof InNovaSoftwareState !== "undefined" && InNovaSoftwareState &&
      InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)] && InNovaSoftwareState[String.fromCharCode(108,101,97,115,101)].status === "GRACE" &&
      _0x3d64f59295(_0x56be11ff61[String.fromCharCode(101,120,112,105,114,121)]);

   if (signatureValid && refreshOutcome.status === String.fromCharCode(65,67,67,79,85,78,84,95,65,85,84,72,79,82,73,90,65,84,73,79,78,95,82,69,81,85,73,82,69,68) &&
       refreshOutcome.paidRenewalPending && !_0x107804e40a) {
      _0xd5064eab4e = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
      _0x3a5b42adaf = "DEVICE_REQUIRED";
      ShowInNovaPaidRenewalNotice("InNova Adaptive Stretch");
      return false;
   }

   if (signatureValid && _0x107804e40a && (!_0x6f14e96ecd || grace)) {
      _0xd5064eab4e = _0x56be11ff61[String.fromCharCode(115,105,103,110,97,116,117,114,101)].substr(0, 8);
      _0x3a5b42adaf = grace ? "FULL_GRACE" : "FULL";
      if (grace)
         _0xa6fa71cef1("InNova Adaptive Stretch", _0x56be11ff61, true);
      else
         console.noteln(String.fromCharCode(9989,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,108,105,99,101,110,115,101,32,97,99,116,105,118,97,116,101,100,46));
      return true;
   }

   if (!complete && !_0x55e4d87ad7 && IsProjectDateValid()) {
      _0xd5064eab4e = _0x0a21482775().substr(0, 8);
      _0x3a5b42adaf = "PROJECT";
      console.noteln(String.fromCharCode(55358,56810,32,76,105,99,101,110,115,101,32,109,111,100,101,58,32,84,82,73,65,76));
      console.noteln(String.fromCharCode(55357,56517,32,84,114,105,97,108,32,116,105,109,101,32,114,101,109,97,105,110,105,110,103,58,32) + _0x11f73f2850() + " day(s).");
      return true;
   }

   _0xd5064eab4e = String.fromCharCode(76,73,67,69,78,83,69,95,82,69,81,85,73,82,69,68);
   if (_0x6f14e96ecd && !grace) {
      _0x3a5b42adaf = String.fromCharCode(69,88,80,73,82,69,68);
      _0xa6fa71cef1("InNova Adaptive Stretch", _0x56be11ff61, false);
      return false;
   }
   if (signatureValid && !_0x107804e40a) {
      _0x3a5b42adaf = "DEVICE_REQUIRED";
      _0x1365507077("InNova Adaptive Stretch",
         String.fromCharCode(84,104,105,115,32,112,97,105,100,32,108,105,99,101,110,115,101,32,99,111,117,108,100,32,110,111,116,32,98,101,32,118,101,114,105,102,105,101,100,32,111,110,32,116,104,105,115,32,100,101,118,105,99,101,46));
      return false;
   }
   _0x3a5b42adaf = "EMPTY";
   if (_0x55e4d87ad7 || complete) {
      _0x1365507077("InNova Adaptive Stretch",
         String.fromCharCode(89,111,117,114,32,112,97,105,100,32,108,105,99,101,110,115,101,32,105,115,32,109,105,115,115,105,110,103,32,111,114,32,105,110,118,97,108,105,100,46,32,80,108,101,97,115,101,32,114,101,115,116,111,114,101,32,121,111,117,114,32,108,105,99,101,110,115,101,32,102,114,111,109,32,121,111,117,114,32,73,110,78,111,118,97,32,112,114,111,102,105,108,101,46),
         { [String.fromCharCode(109,105,115,115,105,110,103,76,105,99,101,110,115,101)]: true });
      return false;
   }
   new MessageBox(
         String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,84,104,101,32,73,110,78,111,118,97,32,65,115,116,114,111,32,80,104,111,116,111,32,83,117,105,116,101,32,116,114,105,97,108,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
         String.fromCharCode(80,108,101,97,115,101,32,111,112,101,110,32,73,110,78,111,118,97,32,73,110,116,101,103,114,97,116,111,114,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32,105,110,32,116,104,101,32) +
         String.fromCharCode(60,98,62,76,105,99,101,110,115,101,32,116,97,98,60,47,98,62,32,116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
      "InNova Adaptive Stretch",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaAdaptiveStretchInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

function InNovaAdaptiveStretchUniqueWindowId(baseId)
{
   let candidate = baseId;
   let suffix = 2;
   while (ImageWindow.windowById(candidate) &&
          !ImageWindow.windowById(candidate).isNull)
      candidate = baseId + "_" + suffix++;
   return candidate;
}

function InNovaAdaptiveStretchDebayerCopy(sourceWindow, outputId)
{
   let pattern = MiraMoonSunKeywordValue(sourceWindow, "BAYERPAT");
   if (pattern !== "RGGB" && pattern !== "BGGR" &&
       pattern !== "GBRG" && pattern !== "GRBG")
      return null;
   if (!sourceWindow.filePath || !File.exists(sourceWindow.filePath))
      throw new Error(
         "The Bayer image has no readable source file for Debayer.");

   let temporaryInput = File.uniqueFileName(
      File.systemTempDirectory, 10, "InNova-Adaptive-CFA-", ".fits");
   let temporaryOutput = File.extractDrive(temporaryInput) +
      File.extractDirectory(temporaryInput) + "/" +
      File.extractName(temporaryInput) + "_InNova_d.xisf";
   let opened = null;
   try {
      File.copyFile(temporaryInput, sourceWindow.filePath);
      let process = new Debayer;
      process.targetItems = [[true, temporaryInput]];
      process.cfaPattern = MiraMoonSunDebayerPattern(pattern);
      process.debayerMethod = Debayer.VNG;
      process.evaluateNoise = false;
      process.evaluateSignal = false;
      process.outputRGBImages = true;
      process.outputSeparateChannels = false;
      process.outputDirectory = File.extractDrive(temporaryInput) +
                                File.extractDirectory(temporaryInput);
      process.outputExtension = ".xisf";
      process.outputPostfix = "_InNova_d";
      process.overwriteExistingFiles = true;
      if (!process.executeGlobal() || !File.exists(temporaryOutput))
         throw new Error("PixInsight Debayer did not create its RGB output.");
      opened = ImageWindow.open(temporaryOutput);
      if (!opened || opened.length === 0 || opened[0].isNull ||
          !opened[0].mainView.image.isColor)
         throw new Error("The Debayer output is not a valid RGB image.");
      opened[0].mainView.id = outputId;
      console.noteln("✅ Standalone preparation: VNG Debayer " + pattern + ".");
      return opened[0];
   }
   catch (error) {
      if (opened && opened.length > 0 && opened[0] && !opened[0].isNull)
         opened[0].forceClose();
      throw error;
   }
   finally {
      try { if (File.exists(temporaryInput)) File.remove(temporaryInput); }
      catch (ignoreInputError) {}
      try { if (File.exists(temporaryOutput)) File.remove(temporaryOutput); }
      catch (ignoreOutputError) {}
   }
}

function InNovaAdaptiveStretchPrepareCopy(sourceWindow, objectType)
{
   let baseId = InNovaAdaptiveStretchUniqueWindowId(
      sourceWindow.mainView.id + "_InNova_Prepared");
   let prepared = null;
   let corrected = null;
   try {
      let image = sourceWindow.mainView.image;
      if (image.isColor && image.numberOfChannels >= 3)
         prepared = MiraAdaptiveStretchWindowFromImage(image, baseId);
      else if (objectType === "MOON_SUN") {
         prepared = InNovaAdaptiveStretchDebayerCopy(sourceWindow, baseId);
         if (!prepared)
            prepared = MiraCreateMoonSunNeutralRGB(sourceWindow, baseId);
      }
      else
         throw new Error(
            "Nebula or Galaxy mode requires an open RGB image. Use Moon or Sun for a Bayer or monochrome source.");

      console.noteln("🧹 Standalone preparation: applying ABE to a temporary copy.");
      MiraABE(prepared);
      corrected = ImageWindow.windowById(prepared.mainView.id + "_ABE");
      if (!corrected || corrected.isNull || !corrected.mainView ||
          corrected.mainView.isNull)
         throw new Error("ABE did not create the prepared image.");
      prepared.forceClose();
      prepared = null;
      corrected.mainView.id = InNovaAdaptiveStretchUniqueWindowId(
         sourceWindow.mainView.id + "_InNova_Adaptive");
      corrected.show();
      corrected.position = new Point(0, 0);
      corrected.bringToFront();
      return corrected;
   }
   catch (error) {
      if (prepared && !prepared.isNull) prepared.forceClose();
      if (corrected && !corrected.isNull) corrected.forceClose();
      throw error;
   }
}

class InNovaAdaptiveStretchLauncherDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "💫 InNova Adaptive Stretch";

      let logoPath = "";
      this.logoBitmap = null;
      try {
         logoPath = File.extractDrive(#__FILE__) +
            File.extractDirectory(#__FILE__) +
            "/InNova-Astro_Photo_Suite_logo.jpg";
         if (File.exists(logoPath))
            this.logoBitmap = new Bitmap(logoPath);
      }
      catch (logoError) {
         this.logoBitmap = null;
      }
      this.logoControl = null;
      if (this.logoBitmap && !this.logoBitmap.isNull) {
         this.logoControl = new Control(this);
         this.logoControl.bitmap = this.logoBitmap;
         this.logoControl.setScaledFixedSize(160, 120);
         this.logoControl.onPaint = function() {
            let graphics = new Graphics(this);
            graphics.drawScaledBitmap(
               new Rect(0, 0, this.width, this.height), this.bitmap);
            graphics.end();
         };
      }

      this.description = new Label(this);
      this.description.text = "Select the project, object and an open image.";
      this.description.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;


      let selectorLabelWidth = this.font.width("Project:") + 8;

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(selectorLabelWidth);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.projectLabel = new Label(this);
      this.projectLabel.text = "Project:";
      this.projectLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.projectLabel.setFixedWidth(selectorLabelWidth);
      this.projectCombo = new ComboBox(this);
      this.projectCombo.addItem("RGB");
      this.projectCombo.addItem("LRGB");
      this.projectCombo.addItem("SHO");
      this.projectCombo.addItem("HOO");
      this.projectCombo.addItem("OSC");
      this.projectCombo.addItem("SEESTAR");
      this.projectCombo.addItem("VAONIS Vespera");
      this.projectCombo.currentItem = 4;
      this.projectCombo.setMinWidth(430);

      this.objectLabel = new Label(this);
      this.objectLabel.text = "Object:";
      this.objectLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.objectLabel.setFixedWidth(selectorLabelWidth);
      this.objectCombo = new ComboBox(this);
      this.objectCombo.addItem("Nebula or Galaxy");
      this.objectCombo.addItem("Moon or Sun");
      this.objectCombo.currentItem = 0;
      this.objectCombo.setMinWidth(430);
      this.projectCombo.onItemSelected = function() { dialog.populateImages(); };
      this.objectCombo.onItemSelected = function() { dialog.populateImages(); };

      this.refreshButton = new PushButton(this);
      this.refreshButton.text = "Refresh";
      this.refreshButton.icon = this.scaledResource(":/icons/reload.png");
      this.refreshButton.onClick = function() { dialog.populateImages(); };

      this.runButton = new PushButton(this);
      this.runButton.text = "Open Adaptive Stretch";
      this.runButton.icon = this.scaledResource(":/icons/power.png");
      this.runButton.defaultButton = true;
      this.runButton.onClick = function() { dialog.runAdaptiveStretch(); };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function() { dialog.cancel(); };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.refreshButton);

      let projectRow = new HorizontalSizer;
      projectRow.spacing = 8;
      projectRow.add(this.projectLabel);
      projectRow.add(this.projectCombo, 100);

      let objectRow = new HorizontalSizer;
      objectRow.spacing = 8;
      objectRow.add(this.objectLabel);
      objectRow.add(this.objectCombo, 100);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      let logoRow = null;
      if (this.logoControl) {
         logoRow = new HorizontalSizer;
         logoRow.addStretch();
         logoRow.add(this.logoControl);
         logoRow.addStretch();
      }

      let descriptionRow = new HorizontalSizer;
      descriptionRow.addStretch();
      descriptionRow.add(this.description);
      descriptionRow.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      if (logoRow) {
         this.sizer.add(logoRow);
         this.sizer.addSpacing(8);
      }
      this.sizer.add(descriptionRow);
      this.sizer.add(projectRow);
      this.sizer.add(objectRow);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;
      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image)
            continue;
         let allowMono = this.objectCombo.currentItem === 1 &&
            this.projectCombo.currentItem >= 4;
         if (window.mainView.image.numberOfChannels < 3 && !allowMono)
            continue;
         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }
      this.sourceCombo.currentItem = selectedIndex;
   }

   runAdaptiveStretch()
   {
      if (!_0x03ca636fe4()) return;
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Adaptive Stretch",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView || source.mainView.isNull) {
         this.populateImages();
         return;
      }

      let projectTypes = ["RGB", "LRGB", "SHO", "HOO", "OSC", "OSC", "OSC"];
      ProjecTypevar = projectTypes[this.projectCombo.currentItem];
      ProjecTypevarRec = ProjecTypevar;
      OptionObjectType = this.objectCombo.currentItem === 1 ?
         "MOON_SUN" : "STARS";
      OptionSeestar = this.projectCombo.currentItem === 5 ? "ON" : "OFF";
      OptionVaonisVespera = this.projectCombo.currentItem >= 5 ? "ON" : "OFF";
      MiraConsoleSection("💫 InNova Adaptive Stretch editing: " + sourceId);
      MiraConsoleSection("⚙️ Project: " +
         this.projectCombo.itemText(this.projectCombo.currentItem) +
         " | Object: " + this.objectCombo.itemText(this.objectCombo.currentItem));

      let prepared = null;
      try {
         prepared = InNovaAdaptiveStretchPrepareCopy(source, OptionObjectType);
      }
      catch (preparationError) {
         new MessageBox(
            "The selected image could not be prepared.\n\n" +
            (preparationError.message || preparationError),
            "InNova Adaptive Stretch",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

      if (MiraRunAdaptiveStretch(prepared, true)) {
         this.ok();
         CoreApplication.processEvents();
         prepared.show();
         CoreApplication.processEvents();
         prepared.zoomToFit(true, false);
         prepared.bringToFront();
         CoreApplication.processEvents();
         MiraConsoleSection("✅ Process finished.");
      }
      else {
         if (prepared && !prepared.isNull) prepared.forceClose();
         this.populateImages();
      }
   }
}

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");


if (MiraRequireCompatiblePixInsight("InNova Adaptive Stretch") &&
    _0x9b415bae04()) {
   let dialog = new InNovaAdaptiveStretchLauncherDialog;
   dialog.onShow = function() { MiraCenterDialog(this); };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}


#endif
