#engine v8

/*
 ****************************************************************************
 * InNova Adaptive Stretch
 *
 * Standalone progressive stretch application for InNova Astro Photo Suite.
 * Copyright (C) 2024-2026 Jesús Manuel García Flores
 ****************************************************************************
 */

#feature-id    InNovaAdaptiveStretch : InNova Astro Photo Suite > 💫 InNova Adaptive Stretch
#feature-icon  InNovaIcon.svg
#feature-info  Progressive highlight-protected stretch for open color images. \
Uses the shared InNova Astro Photo Suite trial and license. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#define TITLE "InNova Adaptive Stretch"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

var ProjecTname = "💫 InNova Adaptive Stretch";
var ProjecTver = "v.1.0.build.0029";
var ProjectND = "17ad08xjr";
var ProjectHash =
   "8466d8482fc97e19b00bd6737e26428188613f18078b60a5b0438ec80db4c50f";
var RuntimeToken = "";
var VarLicense = "EMPTY";

// Compatibility state required by the shared Suite processing engine.
var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionLinkRGB = "false";
var OptionNarrowbandToRGB = "OFF";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var Option300 = "OFF";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var InNovaEditorTitle = "💫 InNova Adaptive Stretch";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0, tint: 0, exposure: 0, contrast: 0,
   highlights: 0, shadows: 0, whites: 0, blacks: 0, saturation: 0
};

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process02.js"

function InNovaAdaptiveStretchInitializeLicense()
{
   if (!IsProjectHashValid()) {
      RuntimeToken = "";
      VarLicense = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Adaptive Stretch",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   let license = ReadLicenseData();
   let complete = IsLicenseComplete(license);
   let signatureValid = complete && IsLicenseSignatureValid(license);
   let expired = signatureValid && IsLicenseExpired(license.expiry);

   if (signatureValid && !expired) {
      RuntimeToken = license.signature.substr(0, 8);
      VarLicense = "FULL";
      console.noteln("✅ InNova Astro Photo Suite license activated.");
      return true;
   }

   if (IsProjectDateValid()) {
      RuntimeToken = CreateProjectHash().substr(0, 8);
      VarLicense = "PROJECT";
      console.noteln("License mode: TRIAL");
      return true;
   }

   RuntimeToken = "LICENSE_REQUIRED";
   VarLicense = expired ? "EXPIRED" : "EMPTY";
   new MessageBox(
      expired ?
         "Your InNova Astro Photo Suite license has expired.\n\n" +
         "Please renew the license from InNova Integrator." :
         "The InNova Astro Photo Suite trial has expired.\n\n" +
         "Please activate a license from InNova Integrator.",
      "InNova Adaptive Stretch",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaAdaptiveStretchInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

class InNovaAdaptiveStretchLauncherDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "💫 InNova Adaptive Stretch";

      this.description = new Label(this);
      this.description.wordWrapping = true;
      this.description.text =
         "Select an open color image. Apply stretches the selected image in place; " +
         "Cancel leaves it unchanged.";

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(90);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.refreshButton = new PushButton(this);
      this.refreshButton.text = "Refresh";
      this.refreshButton.icon = this.scaledResource(":/icons/reload.png");
      this.refreshButton.onClick = function() { dialog.populateImages(); };

      this.runButton = new PushButton(this);
      this.runButton.text = "Open Adaptive Stretch";
      this.runButton.icon = this.scaledResource(":/icons/power.png");
      this.runButton.defaultButton = true;
      this.runButton.onClick = function() { dialog.runAdaptiveStretch(); };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon = this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function() { dialog.cancel(); };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.refreshButton);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add(this.description);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;
      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image ||
             window.mainView.image.numberOfChannels < 3)
            continue;
         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }
      this.sourceCombo.currentItem = selectedIndex;
   }

   runAdaptiveStretch()
   {
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Adaptive Stretch",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView || source.mainView.isNull) {
         this.populateImages();
         return;
      }

      ProjecTypevar = InNovaAdaptiveStretchInferProjectType(sourceId);
      ProjecTypevarRec = ProjecTypevar;
      MiraConsoleSection("💫 InNova Adaptive Stretch editing: " + sourceId);

      if (MiraRunAdaptiveStretch(source, true)) {
         this.ok();
         CoreApplication.processEvents();
         source.show();
         CoreApplication.processEvents();
         source.zoomToFit(true, false);
         source.bringToFront();
         CoreApplication.processEvents();
         MiraConsoleSection("✅ Process finished.");
      }
      else
         this.populateImages();
   }
}

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");

if (InNovaAdaptiveStretchInitializeLicense()) {
   let dialog = new InNovaAdaptiveStretchLauncherDialog;
   dialog.onShow = function() { MiraCenterDialog(this); };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}
