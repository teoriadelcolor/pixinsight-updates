


#iflt __PI_VERSION__ 01.09.04

#feature-id    InNovaIntegrator : InNova Astro Photo Suite > InNova Astro Processor
#feature-icon  InNovaIcon.svg
#feature-info  Integration and astrophotography processing for InNova Astro Photo Suite. \
<br/>\
Copyright &copy; 2024-2026 Jesús M. García Flores.

#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>

var InNovaMinimumVersionMessage =
   "This PixInsight version is not compatible with InNova Astro Photo Suite.\n\n" +
   String.fromCharCode(73,110,78,111,118,97,32,114,101,113,117,105,114,101,115,32,80,105,120,73,110,115,105,103,104,116,32,49,46,57,46,52,32,111,114,32,108,97,116,101,114,46,32,80,108,101,97,115,101,32,117,112,100,97,116,101,32,80,105,120,73,110,115,105,103,104,116,32) +
   "to the latest available version.\n\n" +
   "Esta versión de PixInsight no es compatible con InNova Astro Photo Suite.\n\n" +
   "InNova requiere PixInsight 1.9.4 o posterior. Actualice PixInsight " +
   "a la última versión disponible.";

console.criticalln( InNovaMinimumVersionMessage );
new MessageBox(
   InNovaMinimumVersionMessage,
   "InNova Astro Photo Suite",
   StdIcon_Error,
   StdButton_Ok
).execute();

#else

#engine v8


#define TITLE "InNova Astro Processor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

function InNovaProcessorProgressPanel(dialog, showInformationBox)
{
   let panel = new Control(dialog);
   let header = new Control(panel);
   header.setScaledFixedHeight(92);
   let artworkRoot = File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__) + "/assets/headers/";
   let background = File.exists(artworkRoot + "guided.png") ? new Bitmap(artworkRoot + "guided.png") : null;
   header.onPaint = function() {
      let g = new Graphics(this);
      g.fillRect(0, 0, this.width, this.height, new Brush(0xffe5f2ff));
      if (background && !background.isNull)
         g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), background);
      g.pen = new Pen(0xff237aca, this.logicalPixelsToPhysical(1));
      g.drawRect(0, 0, this.width-1, this.height-1);
      g.end();
   };
   header.sizer = new HorizontalSizer;
   header.sizer.margin = 12;
   header.sizer.spacing = 16;
   let icon = new Control(header);
   icon.setScaledFixedSize(68, 68);
   let artwork = File.exists(artworkRoot + "processor.png") ? new Bitmap(artworkRoot + "processor.png") : null;
   icon.onPaint = function() {
      if (!artwork || artwork.isNull) return;
      let g = new Graphics(this);
      g.drawScaledBitmap(new Rect(0, 0, this.width, this.height), artwork);
      g.end();
   };
   header.sizer.add(icon);
   let text = new VerticalSizer;
   text.spacing = 5;
   text.addStretch();
   function headerLabel(value, size) {
      let label = new Label(header);
      label.useRichText = true;
      label.wordWrapping = true;
      label.text = value;
      label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      label.styleSheet = "font-size:" + size + "pt;color:#102b50;background:transparent;";
      text.add(label);
   }
   headerLabel("<b>InNova Astro Processor</b>", 20);
   text.addStretch();
   header.sizer.add(text, 100);
   panel.setScaledMinWidth(600);
   panel.setScaledFixedHeight(showInformationBox === true ? 180 : 150);
   panel.sizer = new VerticalSizer;
   panel.sizer.spacing = 12;
   panel.sizer.add(header);
   let statusParent = panel;
   let informationBox = null;
   if (showInformationBox === true) {
      informationBox = new GroupBox(panel);
      informationBox.title = "Information";
      informationBox.sizer = new VerticalSizer;
      informationBox.sizer.margin = 10;
      statusParent = informationBox;
   }
   panel.status = new Label(statusParent);
   panel.status.text = "Loading...";
   panel.status.textAlignment = TextAlign_Center | TextAlign_VertCenter;
   panel.status.wordWrapping = true;
   panel.status.setScaledMinHeight(46);
   if (informationBox) {
      informationBox.sizer.add(panel.status);
      panel.sizer.add(informationBox);
   } else
      panel.sizer.add(panel.status);
   return panel;
}

function InNovaProcessorLoading()
{
   let splash = new Dialog;
   splash.windowTitle = "🚀 InNova Astro Processor";
   splash.sizer = new VerticalSizer;
   splash.sizer.margin = 12;
   splash.sizer.spacing = 10;
   splash.sizer.add(InNovaProcessorProgressPanel(splash));
   let close = new PushButton(splash);
   close.text = "Close";
   close.icon = splash.scaledResource(":/icons/close.png");
   close.onClick = function() { splash.cancel(); };
   let row = new HorizontalSizer;
   row.addStretch(); row.add(close); row.addStretch();
   splash.sizer.add(row);
   splash.adjustToContents();
   splash.show();
   CoreApplication.processEvents();
   return splash;
}


var InNovaStartupSplash = InNovaProcessorLoading();
try {
#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "InNovaIntegratorImageSolver"
#include "lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "InNova Astro Processor"

var InNovaInstallationDirectory =
   File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__);

#include "lib/lite01.js"


var InNovaReturnToStartPath = "";
var InNovaReturnToBridgeRequest = null;
try {
   let request = Settings.read("InNova/ProcessorReturnToStart", DataType_String);
   let valid = Settings.lastReadOK;
   Settings.write("InNova/ProcessorReturnToStart", DataType_String, "");
   if (valid && request) {
      let parsed = JSON.parse(request);
      let age = Date.now() - parsed.created;
      if (age >= 0 && age < 60000 && typeof parsed.path == "string" && File.exists(parsed.path)) {
         InNovaReturnToStartPath = parsed.path;
         if (parsed.returnMode == "bridge")
            InNovaReturnToBridgeRequest = parsed;
      }
   }
} catch (error) {}

#include "lib/process04.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process05.js"
#include "lib/process01.js"
#include "lib/process12.js"
#include "lib/color-calibration.js"
#include "lib/process02.js"


var ProjecTname = "🚀 InNova Astro Processor";


var ProjecTver  = "v.1.0.build.0430";
var InNovaAdaptiveStretchBuild = "0086";
var _0x5d0b64ce15 = String.fromCharCode(48,56,97,100,48,57,120,106,114);
var _0xdbfebaadcc = String.fromCharCode(57,53,97,57,56,100,54,52,98,97,56,99,55,102,55,48,56,100,52,53,51,102,99,49,49,50,101,99,98,100,56,98,52,53,54,57,101,49,56,50,55,49,97,102,97,51,100,101,99,100,49,57,49,100,54,52,56,99,97,54,55,101,49,48);
var CanStartApp = MiraRequireCompatiblePixInsight("InNova Astro Processor");
var ProjecTypevar = "SHO";
var ProjecTypevar2 = "0";
var ProjecTypevarRec = "SHO";
var InNovaProjectSelectionLoggingEnabled = false;
var InNovaIntegratorHandoffImageIds = {};
var InNovaIntegratorHandoffPendingSetting =
   "InNovaGetStartedIntegratorHandoffPending";
var InNovaIntegratorHandoffProjectSetting =
   "InNovaGetStartedIntegratorProject";
var InNovaIntegratorHandoffImagePrefix =
   "InNovaGetStartedIntegratorImage_";


var InNovaIntegratorMainDialog = null;
var AlignmenTypevar = "Ha";
var OptionLinkRGB = "false";
var PimageSii = "EMPTY";
var PimageHa = "EMPTY";
var PimageOiii = "EMPTY";
var PimageRed = "EMPTY";
var PimageGreen = "EMPTY";
var PimageBlue = "EMPTY";
var PimageLuminance = "EMPTY";
var PimageOsc = "EMPTY";
var Option1var = "OFF";
var OptionHavar = "OFF";
var OptionColorCalibration = "OFF";
var InNovaColorCalibrationStartupConsoleState = "";
var VarProcesStar = "OFF";
var Option2var2 = "OFF";
var OptionGraXNoise = "OFF";


var OptionNarrowbandToRGB = "OFF";
var OptionOpenInNovaEditor = "ON";
var InNovaEditorPendingLaunch = false;
var InNovaEditorPendingSourceId = "";
var InNovaEditorPendingProjectType = "RGB";
var InNovaRunActive = false;
var InNovaStopRequested = false;
var InNovaStopCleanupRequested = false;

function InNovaRequestStop(origin)
{
   if (!InNovaRunActive)
      return false;

   InNovaStopRequested = true;
   InNovaStopCleanupRequested = true;
   InNovaEditorPendingLaunch = false;
   console.show();
   console.warningln(
      "\n⛔ STOP requested" +
      (origin && origin.length > 0 ? " from " + origin : "") +
      ". InNova will stop at the nearest safe checkpoint and clean the project.");

   if (typeof dialog !== "undefined" && dialog) {
      dialog.workingLabel.foregroundColor = 0xd71920;
      dialog.workingStatusText =
         "⛔ Stopping safely. Cleaning the project next...";
      dialog.elapsedStartTime = Date.now();
      dialog.refreshWorkingLabel();
      dialog.exitButton.toolTip = "Stopping...";
      dialog.exitButton.enabled = false;
      dialog.exitButton.update();
   }
   CoreApplication.processEvents();
   return true;
}

function InNovaAbortCheckpoint()
{
   CoreApplication.processEvents();
   if (!InNovaStopRequested)
      return;

   let stopError = new Error("InNova project stopped by the user.");
   stopError.inNovaUserStop = true;
   throw stopError;
}
var OptionDarkStructureEnhance = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var OptionNoiseXterminator  = "OFF";
var OptionMLDenoise = "OFF";
var OptionStarXterminator = "OFF";
var OptionBlurXterminator = "OFF";
var OptionHighpass = "OFF";
var OptionGradient ="ON";
var OptionImageSolver = "OFF";


var OptionObjectType = "STARS";
var OptionDBE = "OFF";
var OptionVarStars = "OFF";
var OptionMgc ="OFF";
var OptionVaonisVespera = "OFF";


var OptionSeestar = "OFF";
var OptionSmartTelescopeModel = "NONE";
var OptionFast = "OFF";
var VarPGlobal = "EMPTY";
var _0xce8ee91fbb ="EMPTY";
var NewGreenValue = 0.0;
var NewMagentaValue = 1;
var NewStarsValue = 1;
var isStarProcess = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";


var InNovaBridgeProcessedResultReady = false;
var OptionHSOvar = "OFF";
var OptionSharpenNonstellar = 0.20;


function MiraRequirePipelineWindow(windowId, stageName)
{
   let window = ImageWindow.windowById(windowId);
   if (window && !window.isNull && window.mainView &&
       !window.mainView.isNull)
      return true;

   console.criticalln(
      "❌ " + stageName + " did not create the required window: " +
      windowId + ". Processing has been stopped safely.");
   return false;
}

function MiraValidateFinalWindowContract(requireStars, stageName)
{
   if (!MiraRequirePipelineWindow("Final_starless", stageName))
      return false;

   if (requireStars) {
      if (!MiraRequirePipelineWindow("Final_stars", stageName))
         return false;
      if (!MiraRequirePipelineWindow("Final_Result", stageName))
         return false;
   }

   return true;
}


var InteractiveProcessStrengths = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var InteractiveProcessMaskModes = {
   DeepSNR: "none",
   MLDenoise: "none",
   NoiseXTerminator: "none",
   BlurXTerminator: "none",
   HighPass: "none",
   NarrowbandToRGB: "none"
};
var InteractiveProcessMaskBanks = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};


var InNovaEditorTitle = "🪐 InNova Photo Editor";

function InNovaIntegratorResetInNovaEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaIntegratorCloneForInNovaEditor(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      image.isColor,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaIntegratorOpenInNovaEditor(sourceId, projectType)
{
   InNovaEditorPendingLaunch = false;

   let source = ImageWindow.windowById(sourceId);
   if (!source || source.isNull || !source.mainView ||
       source.mainView.isNull || !source.mainView.image ||
       source.mainView.image.numberOfChannels < 3) {
      console.show();
      console.warningln(
         "⚠️ 🪐 InNova Photo Editor was not opened because the final color image is no longer available.");
      return false;
   }

   let editorProjectType =
      projectType === "SHO" || projectType === "HOO" ||
      projectType === "LRGB" || projectType === "OSC" ?
      projectType : "RGB";
   let outputId = MiraUniqueWindowId(sourceId + "_InNovaPhotoEditor");
   let output = null;

   try {
      output = InNovaIntegratorCloneForInNovaEditor(source, outputId);
      InNovaIntegratorResetInNovaEditorState();
      ProjecTypevar = editorProjectType;
      ProjecTypevarRec = editorProjectType;

      console.noteln("\n🪐 Opening InNova Photo Editor: " + sourceId);
      console.writeln("🔭 Project type received from InNova Astro Processor: " +
                      editorProjectType);

      let editorLaunchContext = {
         source: "InNova Integrator",
         requestedModule: ""
      };
      let detectedStarPair =
         typeof InNovaEditorFindStandaloneStarPair === "function" ?
         InNovaEditorFindStandaloneStarPair(output) : null;

      if (detectedStarPair) {
         editorLaunchContext.starlessId = detectedStarPair.starlessId;
         editorLaunchContext.starsId = detectedStarPair.starsId;
         console.noteln("\n🌟 InNova Star Refinement layers linked:");
         console.writeln("   Starless: " + detectedStarPair.starlessId);
         console.writeln("   Stars: " + detectedStarPair.starsId);
      }

      let editorResult = InNovaEditorRunProEditor(
         output.mainView,
         editorProjectType,
         editorLaunchContext);
      if (!editorResult.accepted && editorResult.openRequested) {
         output.forceClose();
         output = null;
         let requestedId = InNovaEditorChooseOpenColorImage();
         if (requestedId.length === 0)
            return false;
         let upperId = requestedId.toUpperCase();
         let requestedType =
            upperId.indexOf("SHO") !== -1 ? "SHO" :
            upperId.indexOf("HOO") !== -1 ? "HOO" :
            upperId.indexOf("LRGB") !== -1 ? "LRGB" :
            upperId.indexOf("OSC") !== -1 ||
            upperId.indexOf("VAONIS") !== -1 ||
            upperId.indexOf("SEESTAR") !== -1 ? "OSC" : "RGB";
         return InNovaIntegratorOpenInNovaEditor(
            requestedId, requestedType);
      }
      if (!editorResult.accepted && editorResult.cancelled) {
         output.forceClose();
         output = null;
         console.noteln("🪐 InNova Photo Editor editing cancelled.");
         return false;
      }
      if (!editorResult.accepted)
         throw new Error(
            "The image editor could not prepare the final image.");

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Photo Editor result created: " + outputId);
      return true;
   }
   catch (error) {
      if (output && !output.isNull)
         output.forceClose();

      console.show();
      console.criticalln("❌ 🪐 InNova Photo Editor could not be opened: " +
                         (error.message || error));
      new MessageBox(
         "InNova Photo Editor could not open the final image.\n\n" +
         "Review the Process Console for details.",
         "InNova Photo Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }
}
var _0xc7acb59813 = "";
var OptionMergePro1  = "<Select an Image>";
var OptionshowConsolRadio = "ON";
var OptionRemaind2 = null;
var OptionSTFvar = "OFF";
var OptionEnabledPreview2 ="OFF";
var OptionGreen = "OFF";
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
var defaultProjectPath = _0x8f7c36af44() + "/";
var originalFilePathMars1 = defaultProjectPath;
var originalFilePathMars2 = defaultProjectPath;
var originalFilePathMarsfin1 = defaultProjectPath;
var originalFilePathMarsfin2 = defaultProjectPath;
var originalFilePathMLDenoise = defaultProjectPath;
var originalFilePathMLDenoisefin = defaultProjectPath;
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MLDenoiseFound ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMarsFirst ="MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond ="MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel ="MLDenoise_v5.xmlm";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;


console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
if (CanStartApp)
   _0xe10958a86c();
console.writeln("");
console.noteln("Checking third-party software:");

defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";


let savedMgcSensorName = Settings.read("MgcSensorName", DataType_String);
if (typeof savedMgcSensorName === "string" &&
    savedMgcSensorName.trim().length > 0)
   SensorName = savedMgcSensorName;

let savedMgcNarrowband = Settings.read("MgcNarrowband", DataType_String);
if (savedMgcNarrowband === "ON" || savedMgcNarrowband === "OFF")
   Narrowband = savedMgcNarrowband;

function MiraRestorePositiveMgcNumber(key, fallback)
{
   let savedValue = Settings.read(key, DataType_Double);
   return typeof savedValue === "number" && isFinite(savedValue) &&
          savedValue > 0 ? savedValue : fallback;
}

defaultGrayWavelength = MiraRestorePositiveMgcNumber(
   "MgcGrayWavelength", defaultGrayWavelength);
defaultGrayBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGrayBandwidth", defaultGrayBandwidth);
defaultRedWavelength = MiraRestorePositiveMgcNumber(
   "MgcRedWavelength", defaultRedWavelength);
defaultRedBandwidth = MiraRestorePositiveMgcNumber(
   "MgcRedBandwidth", defaultRedBandwidth);
defaultGreenWavelength = MiraRestorePositiveMgcNumber(
   "MgcGreenWavelength", defaultGreenWavelength);
defaultGreenBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGreenBandwidth", defaultGreenBandwidth);
defaultBlueWavelength = MiraRestorePositiveMgcNumber(
   "MgcBlueWavelength", defaultBlueWavelength);
defaultBlueBandwidth = MiraRestorePositiveMgcNumber(
   "MgcBlueBandwidth", defaultBlueBandwidth);

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


getFilePath(originalFilePathMars1, originalFilePathMars2);

if (CanStartApp && !RuntimeReady())
{
   CanStartApp = false;

   console.criticalln("Initialization cancelled.");

   new MessageBox(
      "Unable to initialize processing engine.",
      "InNova Astro Processor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
}
else if (CanStartApp)
{
   CanStartApp = true;
}


class IntegratorDialog extends Dialog {

    constructor() {

        super();

        this.windowTitle = ProjecTname;

    var self = this;


    function createIntegrationOptionRadioButton(parent) {
       let container = new Control(parent);
       container.sizer = new HorizontalSizer;
       container.sizer.margin = 0;
       container.sizer.spacing = 0;

       let radioButton = new RadioButton(container);
       container.sizer.add(radioButton);
       radioButton.integrationOptionContainer = container;
       radioButton.checkedBeforeInteraction = false;

       radioButton.onMousePress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       radioButton.onKeyPress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       return radioButton;
    }

    function preserveIntegrationOptionToggle(radioButton) {
       let originalOnClick = radioButton.onClick;

       radioButton.onClick = function () {

          this.checked = !this.checkedBeforeInteraction;
          this.checkedBeforeInteraction = this.checked;

          if (originalOnClick)
             originalOnClick.call(this);
       };
    }

    function addIntegrationOption(sizer, radioButton) {
       let container = radioButton.integrationOptionContainer;


       container.adjustToContents();
       container.setFixedHeight(container.height);
       sizer.add(container);
    }


    this.userResizable = true;

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 650;


    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;


    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;


    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "2. Gradients:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.ImageSolverCheckBox = new CheckBox(this.integrationPage);
    this.ImageSolverCheckBox.text = "Run ImageSolver";
    this.ImageSolverCheckBox.checked = false;
    this.ImageSolverCheckBox.enabled = true;
    this.ImageSolverCheckBox.toolTip =
       "Run ImageSolver on every selected project image before processing.";

    this.ImageSolverCheckBox.onClick = function () {
       OptionImageSolver = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Run ImageSolver = " + OptionImageSolver);
       this.dialog.update();
    };

    this.gradientCorrectionLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientCorrectionLabel.text = "Select gradient correction:";
    this.gradientCorrectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.gradientCorrectionComboBox = new ComboBox(this.CropprojectTypeGroupBox);
    this.gradientCorrectionComboBox.addItem("Run Gradient Correction");
    this.gradientCorrectionComboBox.addItem("Run Multiscale Gradient Correction");
    this.gradientCorrectionComboBox.currentItem = 0;
    this.gradientCorrectionComboBox.setScaledMinWidth(240);

    this.gradientCorrectionComboBox.onItemSelected = function (itemIndex) {
       if (itemIndex === 0) {
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.noteln("⚙️ Gradient Correction = ON");
          console.noteln("⚙️ Multiscale Gradient Correction : OFF");
          return;
       }

       new MessageBox(
          "Remember to adjust the SFC parameters using the 'Settings' button before running the script.\n\n" +
          "MGC requires SFC calibration, MARS and Gaia DR3/SP databases.",
          "Multiscale Gradient Correction",
          StdIcon_Information,
          StdButton_Ok
       ).execute();

       try {
          new MultiscaleGradientCorrection();
          console.noteln("🟢 MultiscaleGradientCorrection is available.");
       } catch (error) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
          new MessageBox(
             "MultiscaleGradientCorrection is not available in this PixInsight version.",
             "InNova Astro Processor",
             StdIcon_Error,
             StdButton_Ok
          ).execute();
          return;
       }

       if (!MiraValidateMgcConfiguration(true)) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          return;
       }

       OptionGradient = "OFF";
       OptionMgc = "ON";
       console.noteln("⚙️ Gradient Correction = OFF");
       console.noteln("⚙️ Multiscale Gradient Correction : ON");
    };


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionLabel);
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionComboBox);
    this.gradientSettingsLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientSettingsLabel.text = "Clic on 'Settings' for SFC and MGC options";
    this.gradientSettingsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientSettingsLabel);
    this.CropprojectTypeGroupBox.adjustToContents();
    this.CropprojectTypeGroupBox.setFixedHeight(
       this.CropprojectTypeGroupBox.height
    );


    this.HalphaCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.HalphaCheckBox.text = "Create 'HAlpha' for blending (RGB/LRGB)";
    this.HalphaCheckBox.checked = false;

    this.colorCalibrationCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.colorCalibrationCheckBox.text = "Color Calibration";
    this.colorCalibrationCheckBox.checked = false;
    let colorCalibrationLastConsoleState =
       InNovaColorCalibrationStartupConsoleState;

    function updateColorCalibrationAvailability(selectWhenAvailable) {
       if (!self.colorCalibrationCheckBox) return;
       let reason = "";
       let projectIndex = self.projectTypeComboBox ?
          self.projectTypeComboBox.currentItem : -1;
       let lrgbProject = projectIndex === 0;
       let rgbProject = projectIndex === 1;
       let oscProject = projectIndex === 4;
       let seestarProject = projectIndex >= 5 && projectIndex <= 8;
       let vaonisProject = projectIndex >= 9 && projectIndex <= 10;

       if (!lrgbProject && !rgbProject && !oscProject &&
           !seestarProject && !vaonisProject)
          reason = "Color Calibration is available for LRGB, RGB, OSC, Seestar and Vaonis projects.";
       else if (OptionObjectType === "MOON_SUN")
          reason = "Color Calibration is unavailable in Moon or Sun mode.";
       else if (typeof SpectrophotometricColorCalibration == "undefined")
          reason = "SpectrophotometricColorCalibration is not installed.";
       else {
          let gaia = MiraGaiaDr3SpStatus();
          if (!gaia.processInstalled || !gaia.supported || !gaia.ready)
             reason = gaia.error ||
                "Color Calibration requires a configured Gaia DR3/SP database.";
          else {
             let source = null;
             if (PimageOsc && PimageOsc !== "EMPTY")
                source = ImageWindow.windowById(PimageOsc);
             let context = {
                forceSeestar: seestarProject,
                forceVaonis: vaonisProject,
                identity: OptionSmartTelescopeModel,
                allowDefaultRgb: lrgbProject || rgbProject || oscProject,
                sourceWindows: source && !source.isNull ? [source] : []
             };
             let profile = MiraColorCalibrationProfile(source, context);
             if (profile == null)
                reason = vaonisProject ?
                   "Select a supported Vaonis Vespera II, III or Pro image." :
                   "No supported Seestar RGB response profile was detected.";
             else {
                let curves = MiraColorCalibrationLoadCurves(profile);
                if (curves.error) reason = curves.error;
             }
          }
       }

       self.colorCalibrationCheckBox.enabled = reason.length === 0;
       self.colorCalibrationCheckBox.toolTip = reason.length === 0 ?
          "Disabled by default. Enable this option to run SPCC on a copy of the linear combined image and review it before continuing. ImageSolver is enabled automatically." :
          reason;
       if (reason.length > 0) {
          self.colorCalibrationCheckBox.checked = false;
          OptionColorCalibration = "OFF";
       }
       else
          OptionColorCalibration = self.colorCalibrationCheckBox.checked ?
             "ON" : "OFF";
       let consoleState = reason.length > 0 ? "OFF: " + reason : "AVAILABLE";
       if (consoleState !== colorCalibrationLastConsoleState) {
          if (reason.length > 0)
             console.writeln(
                "🌈 Color Calibration Disabled: " + reason);
          else
             console.writeln(
                "🌈 Color Calibration Available (disabled by default).");
          colorCalibrationLastConsoleState = consoleState;
       }
       self.colorCalibrationCheckBox.update();
    }
    this.updateColorCalibrationAvailability =
       updateColorCalibrationAvailability;


    function MiraComboProyect() {

    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].enabled = false;
        self.comboBoxReferences[key].update();
    }


    switch (ProjecTypevar) {
        case "RGB":
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            self.comboBoxReferences["PimageLuminance"].enabled = true;
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            self.comboBoxReferences["PimageSii"].enabled = true;
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            self.comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            if (InNovaProjectSelectionLoggingEnabled)
               console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }


    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "1. Project:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    let imageSolverWasEnabledBeforeVaonis = false;
    let imageSolverWasCheckedBeforeVaonis = false;
    let imageSolverForcedByVaonis = false;

    function selectProjectType(projectType, enableFast, vaonisMode,
                               seestarMode, smartModel) {
       ProjecTypevar = projectType;
       let smartTelescopeMode = vaonisMode || seestarMode;
       OptionSeestar = seestarMode ? "ON" : "OFF";
       OptionSmartTelescopeModel = smartTelescopeMode ? smartModel : "NONE";

       OptionVaonisVespera = smartTelescopeMode ? "ON" : "OFF";

       if (self.oscImageLabel) {
          self.oscImageLabel.text = seestarMode ? "SEESTAR:" :
             (vaonisMode ? "VAONIS Vespera:" : "OSC Image:");
          self.oscImageLabel.update();
       }

       if (smartTelescopeMode && OptionObjectType === "STARS") {
          if (!imageSolverForcedByVaonis) {
             imageSolverWasEnabledBeforeVaonis = self.ImageSolverCheckBox.enabled;
             imageSolverWasCheckedBeforeVaonis = self.ImageSolverCheckBox.checked;
          }

          self.ImageSolverCheckBox.checked = true;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "ON";
          imageSolverForcedByVaonis = true;
          console.noteln("⚙️ " +
             (seestarMode ? "SEESTAR" : "VAONIS Vespera") +
             " mode: interactive ImageSolver enabled.");
       }
       else if (imageSolverForcedByVaonis) {
          self.ImageSolverCheckBox.enabled = imageSolverWasEnabledBeforeVaonis;
          self.ImageSolverCheckBox.checked = imageSolverWasCheckedBeforeVaonis;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;
       }

       if (OptionObjectType === "MOON_SUN") {
          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;
       }

       self.FastCheckBox.enabled = enableFast;
       if (!enableFast) {
          self.FastCheckBox.checked = false;
          self.FastCheckBox.text = "Fast integration mode 'OFF' ";
          self.FastCheckBox.styleSheet = "color: black;";
          OptionFast = "OFF";
       }

       let narrowbandProject = projectType === "SHO" || projectType === "HOO";
       let rgbProject = projectType === "RGB" || projectType === "LRGB";

       if (self.finalStarsComboBox && !narrowbandProject &&
           self.finalStarsComboBox.currentItem === 2) {
          self.finalStarsComboBox.currentItem = 0;
          Option1var = "OFF";
          OptionHSOvar = "OFF";
       }

       if (self.HalphaCheckBox) {
          self.HalphaCheckBox.enabled = rgbProject;
          if (!rgbProject) {
             self.HalphaCheckBox.checked = false;
             OptionHavar = "OFF";
          }
       }

       MiraComboProyect();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.projectTypeComboBox = new ComboBox(this.projectTypeGroupBox);
    this.projectTypeComboBox.addItem("LRGB");
    this.projectTypeComboBox.addItem("RGB");
    this.projectTypeComboBox.addItem("SHO");
    this.projectTypeComboBox.addItem("HOO");
    this.projectTypeComboBox.addItem("OSC (RGB Color camera .xisf or Raw)");
    this.projectTypeComboBox.addItem("Seestar S30 Pro");
    this.projectTypeComboBox.addItem("Seestar S50");
    this.projectTypeComboBox.addItem("Seestar S50 Pro");
    this.projectTypeComboBox.addItem("Seestar (Automatic)");
    this.projectTypeComboBox.addItem("VAONIS Vespera III");
    this.projectTypeComboBox.addItem("VAONIS Vespera (Automatic)");
    this.projectTypeComboBox.currentItem = 2;
    this.projectTypeComboBox.setScaledMinWidth(285);
    this.projectTypeComboBox.toolTip =
       "Select the project type. SEESTAR and VAONIS VESPERA FITS/TIFF modes " +
       "automatically open ImageSolver when an astrometric solution is required.";

    this.projectTypeComboBox.onItemSelected = function (itemIndex) {
       let projectTypes = [
          "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
          "OSC", "OSC", "OSC"
       ];
       let smartModels = [
          "NONE", "NONE", "NONE", "NONE", "NONE",
          "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
          "VAONIS_VESPERA_III", "VAONIS_AUTO"
       ];
       let enableFast = itemIndex < 4;
       selectProjectType(
          projectTypes[itemIndex], enableFast,
          itemIndex >= 9, itemIndex >= 5 && itemIndex <= 8,
          smartModels[itemIndex]);
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;
    this.projectTypeLabel = new Label(this.projectTypeGroupBox);
    this.projectTypeLabel.text = "Select project type:";
    this.projectTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.projectTypeGroupBox.sizer.add(this.projectTypeLabel);
    this.projectTypeGroupBox.sizer.add(this.projectTypeComboBox);
    this.projectTypeGroupBox.sizer.add(this.ImageSolverCheckBox);
    this.projectTypeGroupBox.adjustToContents();
    this.projectTypeGroupBox.setFixedHeight(this.projectTypeGroupBox.height);


    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);


    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "3. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    self.comboBoxReferences = {};


    let taggingLabelWidth = this.font.width("Luminance Image:M");

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer;
       rowSizer.spacing = 6;

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(taggingLabelWidth);

       if (variableKey === "PimageOsc")
          self.oscImageLabel = label;

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];

           if (!window || window.isNull || !window.mainView || window.mainView.isNull)
               continue;


           comboBox.addItem(window.mainView.id);
       }

       self.comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = index === 0 ? "EMPTY" : comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
           if (variableKey === "PimageOsc")
              updateColorCalibrationAvailability(true);
       };


       rowSizer.add(label);
       rowSizer.add(comboBox, 1);


       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;


      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC Image:", "PimageOsc");
      this.taggingGroupBox.sizer.addSpacing(6);


    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "4. Object:";
    this.optionsGroupBox.sizer = new VerticalSizer;


    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;


      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.FastCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
   this.FastCheckBox.text = "Fast integration mode 'OFF' ";
   this.FastCheckBox.checked = false;

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' ";
           this.styleSheet = "color: blue;";
           console.writeln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = "Fast integration mode 'OFF' ";
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


    this.darkStructureEnhanceCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.darkStructureEnhanceCheckBox.text =
       "InNova Dark Structure Enhance";
    this.darkStructureEnhanceCheckBox.checked = true;
    this.darkStructureEnhanceCheckBox.onClick = function () {
        OptionDarkStructureEnhance = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ InNova Dark Structure Enhance: " +
                       OptionDarkStructureEnhance);
    };

    this.finalStarRefinementCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.finalStarRefinementCheckBox.text = "InNova Star Refinement";
    this.finalStarRefinementCheckBox.checked = false;
    this.finalStarRefinementCheckBox.enabled = false;
    this.finalStarRefinementCheckBox.onClick = function () {
       if (this.checked && OptionVarStars !== "ON") {
          this.checked = false;
          OptionFinalStarRefinement = "OFF";
          console.warningln(
             "⚠️ InNova Star Refinement requires a Final_starless method.");
          return;
       }
       OptionFinalStarRefinement = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ InNova Star Refinement: " +
                      OptionFinalStarRefinement);
    };


    ProjecTypevar = "SHO";
    MiraComboProyect();


    this.OptionVarStarsCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.OptionVarStarsCheckBox.integrationOptionContainer.visible = false;
    this.starsHSOCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsHSOCheckBox.integrationOptionContainer.visible = false;


    this.starsRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    var self = this;


    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.warningln("\n⚠️ Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


    if (!this.checked) {
        Option1var = "OFF";
        console.noteln("⚙️ Create RGB 'Final_stars' : OFF");
        return;
    }


    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            OptionHSOvar = "OFF";
            self.starsHSOCheckBox.checked = false;

            ProjecTypevar2 = "1";
            self.starsRGBCheckBox.checked = true;

    } else {

        self.comboBoxReferences["PimageRed"].enabled = false;
        self.comboBoxReferences["PimageGreen"].enabled = false;
        self.comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
};

    this.colorCalibrationCheckBox.onClick = function () {
       if (!this.enabled) {
          this.checked = false;
          OptionColorCalibration = "OFF";
          return;
       }
       OptionColorCalibration = this.checked ? "ON" : "OFF";
       if (this.checked && self.ImageSolverCheckBox) {
          self.ImageSolverCheckBox.checked = true;
          OptionImageSolver = "ON";
          self.ImageSolverCheckBox.update();
       }
       console.noteln("⚙️ Color Calibration: " + OptionColorCalibration);
    };


var self = this;


self.starXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
self.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
self.starXterminatorCheckBox.checked = true;


this.starNetCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;


this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           if (starXterminatorInstalled) {
              self.starXterminatorCheckBox.checked = true;
              self.starNetCheckBox.checked = false;
              OptionStarXterminator = "ON";
           } else if (starNet2Installed) {
              self.starXterminatorCheckBox.checked = false;
              self.starNetCheckBox.checked = true;
              OptionStarXterminator = "OFF";
           } else {
              this.checked = false;
              OptionVarStars = "OFF";
              OptionStarXterminator = "OFF";
              console.warningln("⚠️ StarXTerminator or StarNet2 must be installed to create a starless image.");
              return;
           }

           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = starXterminatorInstalled;
           self.starNetCheckBox.enabled = starNet2Installed;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           OptionHSOvar = "ON";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = false;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "OFF";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           OptionHSOvar = "OFF";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };


let starRemovalMethodLabel = "Star Removal by StarXterminator";
OptionStarXterminator = "ON";


self.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        if (!starXterminatorInstalled) {
            this.checked = false;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";

        console.writeln("Fast Process !!!");
    } else {
        if (!starNet2Installed) {
            this.checked = true;
            OptionStarXterminator = "ON";
            console.warningln("⚠️ StarNet2 is not installed. StarXTerminator remains selected.");
            return;
        }


        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};


this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        if (!starNet2Installed) {
            this.checked = false;
            console.warningln("⚠️ StarNet2 is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");


        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        console.writeln("Slow Process !!!");
    } else {
        if (!starXterminatorInstalled) {
            this.checked = true;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed. StarNet2 remains selected.");
            return;
        }


        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};


    this.blurXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;


    this.highPassCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.highPassCheckBox.text = "Sharpen by InNova Focus";
    this.highPassCheckBox.checked = false;


    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.warningln("⚠️ Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;


    let msgBox = new MessageBox("Enable Ha Image for blending?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {

            self.comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {

        self.comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
};

    this.blurXterminatorCheckBox.onClick = function () {
        if (this.checked && !blurXterminatorInstalled) {
           this.checked = false;
           self.highPassCheckBox.checked = true;
           OptionBlurXterminator = "OFF";
           OptionHighpass = "ON";
           console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus remains enabled.");
           return;
        }

        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {

         self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
         OptionHighpass = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");

           } else {

         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
         OptionHighpass = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator : ON");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";

         if (!this.checked && !blurXterminatorInstalled) {
            this.checked = true;
            self.blurXterminatorCheckBox.checked = false;
            OptionHighpass = "ON";
            OptionBlurXterminator = "OFF";
            console.warningln("⚠️ BlurXTerminator is not installed. InNova Focus is required.");
            return;
         }

         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator: ON. InNova Focus disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator: OFF. InNova Focus enabled.");
       }
      };


    let legacyHiddenControls = [
       this.OptionVarStarsCheckBox,
       this.starsHSOCheckBox,
       this.starsRGBCheckBox,
       self.starXterminatorCheckBox,
       this.starNetCheckBox,
       this.blurXterminatorCheckBox,
       this.highPassCheckBox,
       this.darkStructureEnhanceCheckBox,
       this.finalStarRefinementCheckBox
    ];
    for (let i = 0; i < legacyHiddenControls.length; ++i)
       legacyHiddenControls[i].integrationOptionContainer.visible = false;

    let integrationOptionRadioButtons = [
       this.FastCheckBox,
       this.HalphaCheckBox,
       this.colorCalibrationCheckBox
    ];

    for (let i = 0; i < integrationOptionRadioButtons.length; ++i)
       preserveIntegrationOptionToggle(integrationOptionRadioButtons[i]);


    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 4;

    function addThirdPartyCombo(combo, items) {
       combo.setScaledMinWidth(240);
       for (let i = 0; i < items.length; ++i)
          combo.addItem(items[i]);
       combo.currentItem = 0;
       self.optionsGroupBox.sizer.add(combo);
    }

    function warnMissingThirdPartyPlugin(pluginName) {
       console.warningln("⚠️ " + pluginName +
          " plugin is not installed. Choose another option.");
    }

    this.objectTypeLabel = new Label(this.optionsGroupBox);
    this.objectTypeLabel.text = "Object Type:";
    this.objectTypeLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.objectTypeLabel);

    this.objectTypeComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.objectTypeComboBox, [
       "Nebula or Galaxy",
       "Moon or Sun"
    ]);
    this.objectTypeComboBox.toolTip =
       "Nebula or Galaxy uses the normal astrometry and star-processing workflow. " +
       "Moon or Sun skips ImageSolver and all star-dependent processes.";

    this.optionsGroupBox.sizer.addSpacing(3);

    this.starlessImageLabel = new Label(this.optionsGroupBox);
    this.starlessImageLabel.text = "Starless Image:";
    this.starlessImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.starlessImageLabel);

    this.starlessMethodComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.starlessMethodComboBox, [
       "No create 'Final_starless'",
       "Create 'Final_starless' by StarXTerminator",
       "Create 'Final_starless' by StarXNet2"
    ]);

    this.optionsGroupBox.sizer.addSpacing(3);
    this.finalStarsImageLabel = new Label(this.optionsGroupBox);
    this.finalStarsImageLabel.text = "Final stars Image:";
    this.finalStarsImageLabel.textAlignment =
       TextAlign_Left | TextAlign_VertCenter;
    this.optionsGroupBox.sizer.add(this.finalStarsImageLabel);

    this.finalStarsComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.finalStarsComboBox, [
       "<Create 'Final_stars' image (Project stars)>",
       "Create 'Final_stars' image (Project stars)",
       "Create RGB 'Final_stars' (SHO/HOO)"
    ]);
    this.finalStarsComboBox.enabled = false;

    function resetFinalStarsSelection() {
       self.finalStarsComboBox.currentItem = 0;
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.finalStarRefinementCheckBox.checked = false;
       self.finalStarRefinementCheckBox.enabled = false;
       OptionFinalStarRefinement = "OFF";
       FinalStarRefinementReady = false;
       MiraComboProyect();
    }

    function enableFinalStarRefinement() {
       self.finalStarRefinementCheckBox.enabled = true;
       self.finalStarRefinementCheckBox.checked = true;
       OptionFinalStarRefinement = "ON";
       FinalStarRefinementReady = false;
    }

    let objectModeSavedImageSolverChecked =
       this.ImageSolverCheckBox.checked;

    function applyObjectTypeMode(itemIndex, announce) {
       let moonSunMode = itemIndex === 1;
       OptionObjectType = moonSunMode ? "MOON_SUN" : "STARS";

       if (moonSunMode) {
          objectModeSavedImageSolverChecked =
             self.ImageSolverCheckBox.checked;

          self.ImageSolverCheckBox.checked = false;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "OFF";
          imageSolverForcedByVaonis = false;

          self.gradientCorrectionComboBox.currentItem = 0;
          self.gradientCorrectionComboBox.enabled = false;
          OptionGradient = "ON";
          OptionMgc = "OFF";

          self.starlessMethodComboBox.currentItem = 0;
          self.starlessMethodComboBox.enabled = false;
          self.starlessImageLabel.enabled = false;
          self.finalStarsImageLabel.enabled = false;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          OptionVarStars = "OFF";
          OptionStarXterminator = "OFF";
          OptionFinalStarRefinement = "OFF";
          OptionHavar = "OFF";
          OptionColorCalibration = "OFF";

          if (self.HalphaCheckBox) {
             self.HalphaCheckBox.checked = false;
             self.HalphaCheckBox.enabled = false;
          }
          self.colorCalibrationCheckBox.checked = false;
          self.colorCalibrationCheckBox.enabled = false;

          if (announce !== false)
             console.noteln(
                "🌙 Moon or Sun mode: ImageSolver, MGC and star-dependent " +
                "processes are disabled.");
       }
       else {
          self.starlessMethodComboBox.enabled = true;
          self.starlessImageLabel.enabled = true;
          self.finalStarsImageLabel.enabled = true;
          self.finalStarsComboBox.enabled = false;
          self.gradientCorrectionComboBox.enabled = true;

          let smartTelescopeMode =
             self.projectTypeComboBox.currentItem >= 5;
          self.ImageSolverCheckBox.checked = smartTelescopeMode ?
             true : objectModeSavedImageSolverChecked;
          self.ImageSolverCheckBox.enabled = !smartTelescopeMode;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = smartTelescopeMode;

          let selectedProject = [
             "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
             "OSC", "OSC", "OSC"
          ][self.projectTypeComboBox.currentItem];
          let rgbProject = selectedProject === "RGB" ||
             selectedProject === "LRGB";
          self.HalphaCheckBox.enabled = rgbProject;

          if (announce !== false)
             console.noteln(
                "⭐ Stars mode: normal astrometry and star processing enabled.");
       }

       self.ImageSolverCheckBox.update();
       self.gradientCorrectionComboBox.update();
       self.starlessMethodComboBox.update();
       self.finalStarsComboBox.update();
       updateColorCalibrationAvailability(true);
       self.update();
    }

    this.objectTypeComboBox.onItemSelected = function (itemIndex) {
       applyObjectTypeMode(itemIndex, true);
    };

    this.starlessMethodComboBox.onItemSelected = function (itemIndex) {
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionVarStars = "OFF";
       OptionStarXterminator = "OFF";

       if (itemIndex === 1 && !starXterminatorInstalled) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarXTerminator");
          return;
       }

       if (itemIndex === 2 && !starNet2Installed) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarNet2");
          return;
       }

       if (itemIndex === 0) {
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          console.noteln("⚙️ Final_starless creation: OFF");
          return;
       }

       OptionVarStars = "ON";
       OptionStarXterminator = itemIndex === 1 ? "ON" : "OFF";
       self.finalStarsComboBox.enabled = true;


       self.finalStarsComboBox.currentItem = 1;
       OptionHSOvar = "ON";
       Option1var = "OFF";
       enableFinalStarRefinement();
       MiraComboProyect();
       console.noteln("⚙️ Final_starless method: " +
          (itemIndex === 1 ? "StarXTerminator" : "StarNet2"));
       console.noteln("⚙️ Final_stars: Project stars (default)");
    };

    let finalStarsSelectionResetInProgress = false;
    this.finalStarsComboBox.onItemSelected = function (itemIndex) {
       if (finalStarsSelectionResetInProgress)
          return;
       if (OptionObjectType === "MOON_SUN") {
          this.currentItem = 0;
          return;
       }
       OptionHSOvar = "OFF";
       Option1var = "OFF";

       if (itemIndex === 0) {
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
          console.noteln("⚙️ Final_stars creation: OFF");
          return;
       }

       if (OptionVarStars !== "ON") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ Select a Final_starless method first.");
          return;
       }

       if (itemIndex === 1) {
          OptionHSOvar = "ON";
          enableFinalStarRefinement();
          MiraComboProyect();
          console.noteln("⚙️ Final_stars: Project stars");
          return;
       }

       if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
          finalStarsSelectionResetInProgress = true;
          try {
             this.currentItem = 0;
             self.finalStarRefinementCheckBox.checked = false;
             self.finalStarRefinementCheckBox.enabled = false;
             OptionFinalStarRefinement = "OFF";
             FinalStarRefinementReady = false;
             console.warningln(
                "⚠️ RGB Final_stars is only available for SHO and HOO projects.");
             new MessageBox(
                "RGB Final_stars is only available for SHO and HOO " +
                "projects. The current " + ProjecTypevar +
                " project is not compatible with this stellar-layer " +
                "mode. Select Project stars instead, or change the " +
                "project type to SHO or HOO.",
                "InNova Astro Processor — RGB stars unavailable",
                StdIcon_Warning,
                StdButton_Ok
             ).execute();
          }
          finally {
             finalStarsSelectionResetInProgress = false;
          }
          return;
       }

       let msgBox = new MessageBox(
          "Enable RGB Images for stars?",
          "Confirmation",
          StdIcon_Question,
          StdButton_Yes,
          StdButton_No
       );

       if (msgBox.execute() === StdButton_Yes) {
          self.comboBoxReferences["PimageRed"].enabled = true;
          self.comboBoxReferences["PimageGreen"].enabled = true;
          self.comboBoxReferences["PimageBlue"].enabled = true;
          Option1var = "ON";
          ProjecTypevar2 = "1";
          enableFinalStarRefinement();
          console.noteln("⚙️ Final_stars: RGB stars");
       }
       else {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
       }
    };


    this.finalOptionsGroupBox = new GroupBox(this.integrationPage);
    this.finalOptionsGroupBox.title = "5. Options:";
    this.finalOptionsGroupBox.sizer = new VerticalSizer;
    this.finalOptionsGroupBox.sizer.margin = 6;
    this.finalOptionsGroupBox.sizer.spacing = 6;

    this.finalOptionsGroupBox.sizer.addSpacing(10);
    let linkRgbOptionRow = new HorizontalSizer;
    linkRgbOptionRow.margin = 0;
    linkRgbOptionRow.spacing = 0;
    linkRgbOptionRow.add(this.linkRGBChannels);
    this.finalOptionsGroupBox.sizer.add(linkRgbOptionRow);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.FastCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.HalphaCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer,
       this.colorCalibrationCheckBox);
    updateColorCalibrationAvailability(false);


    this.optionsGroupBox.adjustToContents();
    this.finalOptionsGroupBox.adjustToContents();
    let commonOptionsGroupHeight = Math.max(
       this.optionsGroupBox.height,
       this.finalOptionsGroupBox.height);
    this.optionsGroupBox.setFixedHeight(commonOptionsGroupHeight);
    this.finalOptionsGroupBox.setFixedHeight(commonOptionsGroupHeight);

    this.optionsGroupsSizer = new HorizontalSizer;
    this.optionsGroupsSizer.spacing = 10;
    this.optionsGroupsSizer.add(this.optionsGroupBox);
    this.optionsGroupsSizer.add(this.finalOptionsGroupBox);


    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;
      CropprojectTypeSizer.spacing = 10;
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);


      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;
      projectTypeSizer.spacing = 10;
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;
      alignmentSizer.spacing = 10;


      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;
      projectAndAlignmentSizer.spacing = 10;
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);


      this.integrationPage.sizer.add(projectAndAlignmentSizer);


      this.integrationPage.sizer.add(this.taggingGroupBox);


      this.integrationPage.sizer.add(this.optionsGroupsSizer);


      this.runButton = new PushButton(this);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select Project type\nSelect Gradient Correction\nSelect images\nSelect Integration options\nand click on Run";
      this.runButton.setFixedWidth(102);
      this.runButton.setScaledFixedHeight(28);


      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";
      this.workingLabel.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;
      this.workingLabel.setFixedHeight(WindowsOsx1);


      this.workingLabel.hide();

      this.workingStatusText = "";
      this.elapsedStartTime = 0;
      this.elapsedTimer = new Timer(1, true, this);

      this.formatElapsedTime = function (elapsedMilliseconds) {
         let totalSeconds = Math.max(0, Math.floor(elapsedMilliseconds/1000));
         let hours = Math.floor(totalSeconds/3600);
         let minutes = Math.floor((totalSeconds % 3600)/60);
         let seconds = totalSeconds % 60;

         function twoDigits(value) {
            return value < 10 ? "0" + value : "" + value;
         }

         return twoDigits(hours) + ":" + twoDigits(minutes) + ":" +
            twoDigits(seconds);
      };

      this.refreshWorkingLabel = function () {
         if (this.elapsedStartTime <= 0)
            return;

         this.workingLabel.text = this.workingStatusText +
            "  ⏱ Elapsed: " +
            this.formatElapsedTime(Date.now() - this.elapsedStartTime);
         this.workingLabel.update();
         if (this.progressPanel) {
            this.progressPanel.status.text = this.workingLabel.text;
            this.progressPanel.status.update();
         }
      };

      this.setWorkingStatus = function (statusText) {
         if (InNovaRunActive)
            InNovaAbortCheckpoint();
         this.workingStatusText = statusText;
         this.refreshWorkingLabel();
      };

      this.startElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.elapsedStartTime = Date.now();
         this.refreshWorkingLabel();
         this.elapsedTimer.start();
      };

      this.stopElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.refreshWorkingLabel();
      };

      this.elapsedTimer.onTimeout = function () {
         self.refreshWorkingLabel();
      };

      this.setProcessingLock = function (locked) {
         let configurationEnabled = !locked;


         this.projectTypeGroupBox.enabled = configurationEnabled;
         this.CropprojectTypeGroupBox.enabled = configurationEnabled;
         this.taggingGroupBox.enabled = configurationEnabled;
         this.optionsGroupBox.enabled = configurationEnabled;
         this.finalOptionsGroupBox.enabled = configurationEnabled;

         if (locked) {
            this.runButton.enabled = false;
            this.Iconize3.enabled = false;
            this.Iconize6.enabled = false;

            this.exitButton.text = "STOP";
            this.exitButton.icon =
               this.scaledResource( ":/icons/cancel.png" );
            this.exitButton.toolTip =
               "Stop the current project safely and delete its temporary results";
            this.exitButton.enabled = true;
         } else {
            this.runButton.enabled = CanProcess();
            this.Iconize3.enabled = true;
            this.Iconize6.enabled = true;

            this.exitButton.text = "Close";
            this.exitButton.icon =
               this.scaledResource( ":/icons/close.png" );
            this.exitButton.toolTip = "Close InNova Astro Processor";
            this.exitButton.enabled = true;
         }

         if (this.progressPanel) {
            if (locked) this.configurationWindowSize = { width: this.width, height: this.height };
            this.integrationPage.visible = !locked;
            this.progressPanel.visible = locked;
            this.consoleButton.visible = !locked;
            this.openImagesButton.visible = !locked;
            this.Iconize3.visible = !locked;
            this.Iconize6.visible = !locked;
            this.runButton.visible = !locked;
            this.progressButtonSpacer.visible = locked;
            this.progressConsoleButton.visible = locked;
            this.progressConsoleBalance.visible = locked;

            this.minHeight = 0;
            this.maxHeight = 16777215;
            this.adjustToContents();
            if (locked) {
               this.setScaledFixedHeight(250);
               this.resize(this.logicalPixelsToPhysical(624), this.logicalPixelsToPhysical(250));
            } else if (this.configurationWindowSize)
               this.resize(this.configurationWindowSize.width, this.configurationWindowSize.height);
            MiraCenterDialog(this);
         }
         this.update();
      };


      this.Iconize3 = new ToolButton(this);

      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setScaledFixedSize(28, 28);
      this.Iconize3.toolTip = "Delete actual project";
      if (!CanProcess())
      {
         self.runButton.enabled = false;
      }
      else
      {
         self.runButton.enabled = true;
      }


      self.Iconize6 = new ToolButton(this);

      self.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      self.Iconize6.setScaledFixedSize(28, 28);
      self.Iconize6.toolTip = "Options and Settings";
      self.Iconize6.enabled = true;


      var self = this;

      this.runButton.onClick = function () {
      if (!CanProcess())
      {
         new MessageBox(
            String.fromCharCode(60,112,32,97,108,105,103,110,61,34,99,101,110,116,101,114,34,62,89,111,117,114,32,116,114,105,97,108,32,111,114,32,108,105,99,101,110,115,101,32,104,97,115,32,101,120,112,105,114,101,100,46,60,98,114,47,62,60,98,114,47,62) +
            String.fromCharCode(79,112,101,110,32,60,98,62,73,110,78,111,118,97,32,83,116,97,114,116,60,47,98,62,32,97,110,100,32,99,108,105,99,107,32,60,98,62,77,97,110,97,103,101,32,83,117,98,115,99,114,105,112,116,105,111,110,60,47,98,62,32) +
            String.fromCharCode(116,111,32,112,117,114,99,104,97,115,101,32,111,114,32,114,101,110,101,119,32,121,111,117,114,32,115,117,98,115,99,114,105,112,116,105,111,110,46,60,47,112,62),
            "InNova Astro Processor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }


     let selectedProjectTypes = [
        "LRGB", "RGB", "SHO", "HOO", "OSC", "OSC", "OSC", "OSC",
        "OSC", "OSC", "OSC"
     ];
     let selectedSmartModels = [
        "NONE", "NONE", "NONE", "NONE", "NONE",
        "SEESTAR_S30_PRO", "SEESTAR_S50", "SEESTAR_S50_PRO", "SEESTAR_AUTO",
        "VAONIS_VESPERA_III", "VAONIS_AUTO"
     ];
     let selectedProjectType = selectedProjectTypes[self.projectTypeComboBox.currentItem];
     OptionObjectType = self.objectTypeComboBox.currentItem === 1 ?
        "MOON_SUN" : "STARS";
     OptionSeestar = self.projectTypeComboBox.currentItem >= 5 &&
        self.projectTypeComboBox.currentItem <= 8 ? "ON" : "OFF";
     OptionVaonisVespera =
        self.projectTypeComboBox.currentItem >= 5 ? "ON" : "OFF";
     OptionSmartTelescopeModel =
        selectedSmartModels[self.projectTypeComboBox.currentItem];


     function selectedImageFromCombo(key) {
        let combo = self.comboBoxReferences[key];
        return combo && combo.currentItem > 0 ?
           combo.itemText(combo.currentItem) : "EMPTY";
     }
     PimageSii = selectedImageFromCombo("PimageSii");
     PimageHa = selectedImageFromCombo("PimageHa");
     PimageOiii = selectedImageFromCombo("PimageOiii");
     PimageRed = selectedImageFromCombo("PimageRed");
     PimageGreen = selectedImageFromCombo("PimageGreen");
     PimageBlue = selectedImageFromCombo("PimageBlue");
     PimageLuminance = selectedImageFromCombo("PimageLuminance");
     PimageOsc = selectedImageFromCombo("PimageOsc");

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS") {
        self.ImageSolverCheckBox.checked = true;
        self.ImageSolverCheckBox.enabled = false;
        OptionImageSolver = "ON";
     }

     ProjecTypevar = selectedProjectType;
     ProjecTypevarRec = selectedProjectType;


     OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
     OptionFast = self.FastCheckBox.enabled && self.FastCheckBox.checked ?
        "ON" : "OFF";
     OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";


     OptionDarkStructureEnhance = "ON";
     OptionOpenInNovaEditor = "ON";
     OptionHavar = self.HalphaCheckBox.enabled &&
        self.HalphaCheckBox.checked ? "ON" : "OFF";
     updateColorCalibrationAvailability(false);
     OptionColorCalibration = self.colorCalibrationCheckBox.enabled &&
        self.colorCalibrationCheckBox.checked ? "ON" : "OFF";
     OptionGradient = self.gradientCorrectionComboBox.currentItem === 0 ?
        "ON" : "OFF";
     OptionMgc = self.gradientCorrectionComboBox.currentItem === 1 ?
        "ON" : "OFF";

     if (OptionVaonisVespera === "ON" && OptionObjectType === "STARS")
        OptionImageSolver = "ON";


     OptionGraXNoise = "OFF";
     OptionMLDenoise = "OFF";
     OptionNoiseXterminator = "OFF";
     OptionBlurXterminator = "OFF";
     OptionHighpass = "OFF";
     OptionVarStars = self.starlessMethodComboBox.currentItem > 0 ? "ON" : "OFF";
     OptionStarXterminator = self.starlessMethodComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionFinalStarRefinement =
        OptionVarStars === "ON" ? "ON" : "OFF";
     FinalStarRefinementReady = false;


     if (OptionVarStars === "ON" && self.finalStarsComboBox.currentItem === 0)
        self.finalStarsComboBox.currentItem = 1;
     OptionHSOvar = self.finalStarsComboBox.currentItem === 1 ? "ON" : "OFF";
     Option1var = self.finalStarsComboBox.currentItem === 2 ? "ON" : "OFF";
     ProjecTypevar2 = Option1var === "ON" ? "1" : "0";


     if (OptionObjectType === "MOON_SUN") {
        if (selectedProjectType !== "OSC") {
           new MessageBox(
              "Moon or Sun mode requires an OSC, SEESTAR or VAONIS Vespera " +
              "project with one selected image.",
              "InNova Astro Processor - Moon or Sun",
              StdIcon_Error,
              StdButton_Ok
           ).execute();
           return;
        }

        self.ImageSolverCheckBox.checked = false;
        self.ImageSolverCheckBox.enabled = false;
        self.gradientCorrectionComboBox.currentItem = 0;
        self.gradientCorrectionComboBox.enabled = false;
        self.starlessMethodComboBox.currentItem = 0;
        self.starlessMethodComboBox.enabled = false;
        self.finalStarsComboBox.currentItem = 0;
        self.finalStarsComboBox.enabled = false;
        self.HalphaCheckBox.checked = false;
        self.HalphaCheckBox.enabled = false;
        self.colorCalibrationCheckBox.checked = false;
        self.colorCalibrationCheckBox.enabled = false;

        OptionImageSolver = "OFF";
        OptionGradient = "ON";
        OptionMgc = "OFF";
        OptionVarStars = "OFF";
        OptionStarXterminator = "OFF";
        OptionFinalStarRefinement = "OFF";
        OptionHSOvar = "OFF";
        Option1var = "OFF";
        OptionHavar = "OFF";
        OptionColorCalibration = "OFF";
        ProjecTypevar2 = "0";

        console.noteln(
           "🌙 Moon or Sun project: ImageSolver, MGC, Final_starless " +
           "creation and final-star processing will be skipped.");
     }


     if (OptionFast === "ON" && Option1var === "ON") {
        console.warningln(
           "⚠️ FAST mode does not run the separate RGB star integration. " +
           "Using project stars for this run.");
        self.finalStarsComboBox.currentItem = 1;
        Option1var = "OFF";
        OptionHSOvar = "ON";
        ProjecTypevar2 = "0";
     }
     VarProcesStar = "OFF";
     VarPGlobal = "EMPTY";
     isStarProcess = false;
     OptionRemaind2 = null;
     OptionEnabledPreview2 = "OFF";
     InteractiveProcessStrengths.DeepSNR = null;
     InteractiveProcessStrengths.MLDenoise = null;
     InteractiveProcessStrengths.NoiseXTerminator = null;
     InteractiveProcessStrengths.BlurXTerminator = null;
     InteractiveProcessStrengths.HighPass = null;
     InteractiveProcessStrengths.NarrowbandToRGB = null;
     InteractiveProcessMaskModes.DeepSNR = "none";
     InteractiveProcessMaskModes.MLDenoise = "none";
     InteractiveProcessMaskModes.NoiseXTerminator = "none";
     InteractiveProcessMaskModes.BlurXTerminator = "none";
     InteractiveProcessMaskModes.HighPass = "none";
     InteractiveProcessMaskModes.NarrowbandToRGB = "none";
     InteractiveProcessMaskBanks.DeepSNR = null;
     InteractiveProcessMaskBanks.MLDenoise = null;
     InteractiveProcessMaskBanks.NoiseXTerminator = null;
     InteractiveProcessMaskBanks.BlurXTerminator = null;
     InteractiveProcessMaskBanks.HighPass = null;
     InteractiveProcessMaskBanks.NarrowbandToRGB = null;


     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {

            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {

            self.finalStarsComboBox.currentItem = 0;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");


      if (!MiraRestoreSelectedSourceIds()) {
         console.criticalln(
            "❌ Source-window identifiers are ambiguous. Close or rename the duplicate window reported above, then run the script again.");
         return;
      }


      if (!MiraCheckWindowsABE()) {
         console.warningln("\n⚠️ Run cancelled because previous intermediate windows are still open.");
         return;
      }

      let msgBox = new MessageBox(
         "<p align=\"center\">Do you want to run <b>Astro Processor</b>?</p>",
         "Confirmation", StdIcon_Question,
         StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {


        MiraPrepareWorkspaceForRun(dialog);

        FinalFocusWindowId = "";
        FinalConvertedFocusWindowId = "";
        InNovaBridgeProcessedResultReady = false;
        let startTime = Date.now();
        dialog.workingStatusText = String.fromCharCode(83,116,97,114,116,105,110,103,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46);
        dialog.startElapsedTimer();
        let processCompleted = false;
        InNovaStopRequested = false;
        InNovaStopCleanupRequested = false;
        InNovaRunActive = true;
        try {
        dialog.setProcessingLock(true);

        MiraConsoleSection("🚀 Launching InNova Astro Processor project...");

        dialog.workingLabel.foregroundColor = 0x0000FF;
        dialog.workingLabel.update();


         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln(String.fromCharCode(10,10060,32,86,97,108,105,100,97,116,105,111,110,32,102,97,105,108,101,100,46,32,80,108,101,97,115,101,32,115,101,108,101,99,116,32,105,109,97,103,101,115,46));
          return;
        } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
        }


        if (OptionObjectType === "STARS" &&
            OptionImageSolver !== "ON" &&
            !MiraValidateSelectedImageAstrometry(ProjecTypevar)) {
           OptionImageSolver = "ON";
           self.ImageSolverCheckBox.checked = true;
           self.ImageSolverCheckBox.update();

           console.noteln(
              "🔭 Astrometric data are missing. ImageSolver has been enabled automatically."
           );

           new MessageBox(
              "InNova has detected that one or more selected images require an " +
              "astrometric solution.<br><br>" +
              "<b>ImageSolver will now run automatically.</b> You do not need to enable " +
              "the option or restart the process.<br><br>" +
              "InNova will continue the integration as soon as the astrometric " +
              "solution has been generated.",
              "InNova Astro Processor - Automatic ImageSolver",
              StdIcon_Information,
              StdButton_Ok
           ).execute();
        }


        if (OptionObjectType === "STARS" && OptionImageSolver === "ON") {
           dialog.setWorkingStatus(String.fromCharCode(82,117,110,110,105,110,103,32,73,109,97,103,101,83,111,108,118,101,114,32,111,110,32,115,101,108,101,99,116,101,100,32,105,109,97,103,101,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
           let imageSolverBaselineWindows = ImageWindow.windows.slice();
           if (!MiraRunImageSolverForSelectedImages(ProjecTypevar)) {
              MiraCleanupImageSolverAttempt(imageSolverBaselineWindows);

              let imageSolverRequiredByColorCalibration =
                 OptionColorCalibration === "ON";
              let imageSolverCanContinue = OptionMgc !== "ON" &&
                 !imageSolverRequiredByColorCalibration;
              let imageSolverDetail =
                 (typeof MiraImageSolverLastError === "string" &&
                  MiraImageSolverLastError.length > 0) ?
                    MiraImageSolverLastError :
                    "ImageSolver could not generate a valid astrometric solution.";
              imageSolverDetail = String(imageSolverDetail)
                 .replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
              let imageSolverMessage =
                 "ImageSolver could not solve the selected image.<br><br>" +
                 "If this is an image of the Moon or the Sun, restart InNova and, " +
                 "in the Object section, choose <b>Moon or Sun</b>.<br><br>";

              if (imageSolverCanContinue) {
                 imageSolverMessage +=
                    "The options currently enabled do not require astrometry, so " +
                    "InNova Astro Processor will continue without ImageSolver.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Warning,
                    StdButton_Ok
                 ).execute();
                 OptionImageSolver = "OFF";
                 self.ImageSolverCheckBox.checked = false;
                 self.ImageSolverCheckBox.update();
                 console.warningln(
                    "⚠️ ImageSolver failed, but no active process requires astrometry. Continuing safely without ImageSolver.");
              }
              else {
                 let astrometryRequirement = OptionMgc === "ON" &&
                    imageSolverRequiredByColorCalibration ?
                       "Multiscale Gradient Correction and Color Calibration require" :
                    OptionMgc === "ON" ?
                       "Multiscale Gradient Correction requires" :
                       "Color Calibration requires";
                 imageSolverMessage +=
                    "The active " + astrometryRequirement + " astrometry. " +
                    "InNova Astro Processor must stop.<br><br>" +
                    "All temporary ImageSolver results have been removed and the " +
                    "original selected image has been preserved.<br><br>" +
                    "Details: " + imageSolverDetail;
                 new MessageBox(
                    imageSolverMessage,
                    "InNova Astro Processor - ImageSolver",
                    StdIcon_Error,
                    StdButton_Ok
                 ).execute();
                 console.criticalln(
                    "\n❌ 🔭 ImageSolver failed. Astrometry is required by " +
                    (OptionMgc === "ON" && imageSolverRequiredByColorCalibration ?
                       "Multiscale Gradient Correction and Color Calibration" :
                     OptionMgc === "ON" ? "Multiscale Gradient Correction" :
                       "Color Calibration") +
                    ", so InNova Astro Processor stopped before processing.");
                 return;
              }
           }
        }

        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
        if (!MiraProyecto())
            {
               console.criticalln("Process cancelled.");
               return;
            }


        if (OptionMgc ==="ON") {


           if (!MiraValidateMgcConfiguration(true)) {
              OptionMgc = "OFF";
              OptionGradient = "ON";
              dialog.gradientCorrectionComboBox.currentItem = 0;
           }
           else {
              MiraConsoleSection("Launching MARS databases...");
              dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,77,117,108,116,105,115,99,97,108,101,32,71,114,97,100,105,101,110,116,32,67,111,114,114,101,99,116,105,111,110,32,112,114,111,99,101,115,115,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
              console.noteln("Launching Multiscale Gradient Correction process...");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin1) + ": \n" + originalFilePathMarsfin1);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin2) + ": \n" + originalFilePathMarsfin2);


              if (!MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, MiraImageSolverSelectedIds(ProjecTypevar))) {
                 console.criticalln(
                    "❌ Multiscale Gradient Correction did not complete on every selected image. Processing has been stopped to avoid mixing corrected and uncorrected channels.");
                 return;
              }
           }
        }


        dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,49,50,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));

            if (MiraVentana()) {


            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraRenombre();
            if (ProjecTypevar === "OSC" &&
                !MiraPrepareOscColorSource(OptionObjectType === "MOON_SUN")) {
               console.criticalln(
                  "❌ OSC colour preparation failed. Processing has been stopped safely.");
               return;
            }
            dialog.setWorkingStatus(String.fromCharCode(76,97,117,110,99,104,105,110,103,32,80,114,111,99,101,115,115,58,32,91,49,32,116,111,32,52,93,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return;
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }


            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,53,47,57,46,32,77,97,105,110,32,112,114,111,99,101,115,115,44,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            MiraProcesoGeneral01();
            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,54,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!MiraChannelCom()) {
               console.criticalln(
                  "❌ Channel combination or final-window creation failed. Processing has been stopped safely.");
               return;
            }

            if (!MiraValidateFinalWindowContract(
                   OptionFast === "ON" && OptionVarStars === "ON",
                   "Channel combination"))
               return;

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,55,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


               let finalColorTarget = ImageWindow.windowById("Final_starless");
               if (finalColorTarget && !finalColorTarget.isNull)
                  finalColorTarget.bringToFront();
               MiraGreen();


            dialog.setWorkingStatus(
               "Adjusting background, denoise and sharpen on the visible final image...");
            if (!MiraApplyVisibleFinalProcesses())
               return;

            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (Option1var === "ON") {
                        if (OptionFast === "OFF"){
                              console.noteln("\n" + "Launching RGB stars process.");
                              try {
                                 MiraRGBStars();
                              } finally {


                                 VarProcesStar = "OFF";
                                 ProjecTypevar = ProjecTypevarRec;
                              }
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                } else if (OptionHSOvar === "ON") {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars2();

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n" + "Launching project stars process.");
                              MiraSHOStars();

                              }
                        }
                }
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            if (!MiraValidateFinalWindowContract(
                   OptionVarStars === "ON", "Final star creation"))
               return;


            if (OptionHavar ==="ON"){
               let imageWindow = "Filter_Ha_registered_ABE";
               if (!InNovaEditorRunHAlphaStage(
                     imageWindow, ProjecTypevarRec))
                  return;
            }

            dialog.setWorkingStatus(String.fromCharCode(83,116,101,112,32,57,47,57,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));


            dialog.setWorkingStatus(
               String.fromCharCode(73,110,78,111,118,97,32,68,97,114,107,32,83,116,114,117,99,116,117,114,101,32,69,110,104,97,110,99,101,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
            if (!InNovaEditorRunDarkStructuresStage(
                  ProjecTypevarRec))
               return;


            if (OptionVarStars === "ON") {
               dialog.setWorkingStatus(
                  String.fromCharCode(82,101,102,105,110,105,110,103,32,116,104,101,32,102,105,110,97,108,32,115,116,97,114,32,108,97,121,101,114,46,32,80,108,101,97,115,101,32,119,97,105,116,46,46,46));
               if (!InNovaEditorRunStarRefinementStage(
                     ProjecTypevarRec))
                  return;
            }

              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break;
                         }
                   }
              }

            MiraRenProyectos();

            InNovaAbortCheckpoint();
            MirashowTotalTime(startTime);
            Option2var2 = "ON";


            dialog.stopElapsedTimer();
            MiraBorraVentanas();

            MiraOrdena1();
            MiraFocusFinalOutput();
            InNovaAbortCheckpoint();


            if (OptionOpenInNovaEditor === "ON") {
               let finalId = FinalConvertedFocusWindowId ||
                             FinalFocusWindowId;
               if (!finalId || finalId.length === 0) {
                  let finalWindow = ImageWindow.activeWindow;
                  finalId = finalWindow && !finalWindow.isNull &&
                            finalWindow.mainView &&
                            !finalWindow.mainView.isNull ?
                            finalWindow.mainView.id : "";
               }
               let verifiedFinal = ImageWindow.windowById(finalId);
               if (verifiedFinal && !verifiedFinal.isNull &&
                   verifiedFinal.mainView &&
                   !verifiedFinal.mainView.isNull) {
                  InNovaEditorPendingSourceId = finalId;
                  InNovaEditorPendingProjectType = ProjecTypevarRec;
                  InNovaEditorPendingLaunch = true;
                  console.noteln(
                     "🪐 InNova Photo Editor queued for: " + finalId);
               }
               else {
                  console.warningln(
                     "⚠️ 🪐 InNova Photo Editor was not opened because no valid final image was found.");
               }
            }

            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            if (!InNovaEditorPendingLaunch)
               console.noteln("\n✅ End of project.");
            dialog.setWorkingStatus("✅ Process completed.");
            processCompleted = true;
            InNovaBridgeProcessedResultReady = true;
            if (InNovaEditorPendingLaunch)
               dialog.ok();


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
        } catch (processingError) {
            console.show();
            let processingMessage = processingError && processingError.message ?
               processingError.message : processingError;
            if ((processingError && processingError.inNovaUserStop) ||
                InNovaStopRequested) {
               console.warningln(
                  "\n⛔ InNova Astro Processor stopped by the user at a safe checkpoint.");
            }
            else {
               console.criticalln(
                  "\n❌ 🔭 InNova Astro Processor stopped after an unexpected processing error: " +
                  processingMessage);
               if (processingError && processingError.stack)
                  console.criticalln(processingError.stack);
               new MessageBox(
                  "InNova Astro Processor stopped safely.\n\n" + processingMessage +
                  "\n\nReview the Process Console for the stage and missing window details.",
                  "InNova Astro Processor processing error",
                  StdIcon_Error,
                  StdButton_Ok
               ).execute();
            }
        } finally {

            InNovaRunActive = false;


            try {
               MiraRestoreSelectedSourceIds();
            } catch (restoreError) {
               console.warningln(
                  "⚠️ Source-window names could not be fully restored: " +
                  restoreError.message);
            }
            VarProcesStar = "OFF";
            VarPGlobal = "EMPTY";
            isStarProcess = false;
            ProjecTypevar = ProjecTypevarRec;
            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            dialog.stopElapsedTimer();
            let stoppedByUser = InNovaStopRequested;


            InNovaRunActive = false;
            if (stoppedByUser && InNovaStopCleanupRequested) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Stopped. Cleaning project windows...";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
               try {
                  MiraCheckWindowsTrash(true);
                  MiraOrdena1();
                  console.noteln(
                     "✅ STOP cleanup completed. Original source images were preserved.");
               }
               catch (cleanupError) {
                  console.criticalln(
                     "❌ STOP cleanup could not remove every project window: " +
                     (cleanupError.message || cleanupError));
               }
            }
            InNovaStopRequested = false;
            InNovaStopCleanupRequested = false;
            dialog.setProcessingLock(false);

            if (stoppedByUser) {
               dialog.workingLabel.foregroundColor = 0xd71920;
               dialog.workingStatusText =
                  "⛔ Process stopped. Project workspace cleaned.";
               dialog.elapsedStartTime = Date.now();
               dialog.refreshWorkingLabel();
            }
            else if (!processCompleted)
               dialog.setWorkingStatus("⚠️ Process stopped.");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};


      this.Iconize3.onClick = function() {


               self.projectTypeComboBox.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };


self.Iconize6.onClick = function() {

   let mgcDialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
   mgcDialog.adjustToContents();
   MiraCenterDialog(mgcDialog);
   mgcDialog.execute();
   MiraRefreshConfiguredDataPaths();
};


     this.exitButton = new PushButton(this);
     this.exitButton.text = "Close";

     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.toolTip = "Close InNova Astro Processor";
      this.exitButton.setFixedWidth(102);
      this.exitButton.setScaledFixedHeight(28);


     this.exitButton.onClick = function () {
        if (InNovaRunActive) {
           InNovaRequestStop("the main window");
           return;
        }
        this.dialog.cancel();
    };


      this.consoleButton = new ToolButton(this);

      this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
      this.consoleButton.setScaledFixedSize(28, 28);
      this.consoleButton.toolTip = "Show or hide the PixInsight Process Console";
      this.consoleButton.onClick = function () {
         if (OptionshowConsolRadio === "ON") {
            OptionshowConsolRadio = "OFF";
            this.toolTip = "Show the PixInsight Process Console";
            console.hide();
         }
         else {
            OptionshowConsolRadio = "ON";
            this.toolTip = "Hide the PixInsight Process Console";
            console.show();
         }
      };


    this.actionButtonsSizer = new HorizontalSizer;
    this.actionButtonsSizer.spacing = 10;
    this.progressConsoleBalance = new Control(this);
    this.progressConsoleBalance.setScaledFixedSize(28, 28);
    this.progressConsoleBalance.hide();
    this.actionButtonsSizer.add(this.consoleButton);
    this.openImagesButton = new ToolButton(this);
    this.openImagesButton.icon = this.scaledResource(":/icons/folder-open.png");
    this.openImagesButton.setScaledFixedSize(28, 28);
    this.openImagesButton.toolTip = "Open image files";
    this.openImagesButton.onClick = function() {
       if (InNovaRunActive) return;
       let chooser = new OpenFileDialog;
       chooser.caption = "Open images for InNova Astro Processor";
       chooser.multipleSelections = true;
       chooser.filters = [["Image files", "*.xisf", "*.fit", "*.fits", "*.fts", "*.tif", "*.tiff"], ["All files", "*.*"]];
       if (!chooser.execute()) return;
       try {
          for (let path of chooser.fileNames) {
             let opened = ImageWindow.open(path);
             for (let window of opened) {
                window.show();
                for (let key in self.comboBoxReferences)
                   self.comboBoxReferences[key].addItem(window.mainView.id);
             }
          }
       } catch (error) {
          new MessageBox(String(error), "Open images", StdIcon_Error, StdButton_Ok).execute();
       }
    };
    this.actionButtonsSizer.add(this.openImagesButton);
    this.actionButtonsSizer.add(this.Iconize3);
    this.actionButtonsSizer.add(this.Iconize6);
    this.actionButtonsSizer.addStretch();
    this.actionButtonsSizer.add(this.runButton);
    this.progressButtonSpacer = new Control(this);
    this.progressButtonSpacer.setFixedHeight(1);
    this.progressButtonSpacer.hide();
    this.progressConsoleButton = new ToolButton(this);
    this.progressConsoleButton.icon = this.scaledResource(":/toolbar/view-process-console.png");
    this.progressConsoleButton.setScaledFixedSize(28, 28);
    this.progressConsoleButton.toolTip = "Show or hide the PixInsight Process Console";
    this.progressConsoleButton.onClick = function() {
       self.consoleButton.onClick.call(self.consoleButton);
    };
    this.progressConsoleButton.hide();
    this.actionButtonsSizer.insert(0, this.progressConsoleButton);
    this.actionButtonsSizer.add(this.exitButton);
    this.actionButtonsSizer.add(this.progressButtonSpacer, 100);
    this.actionButtonsSizer.add(this.progressConsoleBalance);


    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;


    this.onClose = function() {
       if (InNovaRunActive) {
          InNovaRequestStop("the progress window");
          return false;
       }
       return true;
    };
    this.progressPanel = InNovaProcessorProgressPanel(this, true);
    this.progressPanel.hide();
    this.sizer.add(this.progressPanel);
    this.sizer.add(this.integrationPage, 100);
    this.sizer.addSpacing(10);
    this.sizer.add(this.actionButtonsSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}
}


let dialog = new IntegratorDialog();
InNovaIntegratorMainDialog = dialog;
InNovaProjectSelectionLoggingEnabled = true;
UpdateInstalledAppsUI(dialog);

function InNovaIntegratorConsumeGetStartedHandoff(targetDialog)
{
   let pending = Settings.read(
      InNovaIntegratorHandoffPendingSetting, DataType_String );
   if (!Settings.lastReadOK || pending !== "1") return false;

   let project = Settings.read(
      InNovaIntegratorHandoffProjectSetting, DataType_String );
   if (!Settings.lastReadOK || typeof project !== "string") project = "SHO";
   let projectIndexes = { LRGB: 0, RGB: 1, SHO: 2, HOO: 3, OSC: 4,
      SEESTAR_S30_PRO: 5, SEESTAR_S50: 6, SEESTAR_S50_PRO: 7,
      SEESTAR: 8, VAONIS_VESPERA: 10 };
   let projectIndex = projectIndexes[project];
   if (projectIndex === undefined) projectIndex = 2;
   targetDialog.projectTypeComboBox.currentItem = projectIndex;
   if (typeof targetDialog.projectTypeComboBox.onItemSelected === "function")
      targetDialog.projectTypeComboBox.onItemSelected(projectIndex);

   let keys = [ "PimageSii", "PimageHa", "PimageOiii",
      "PimageRed", "PimageGreen", "PimageBlue",
      "PimageLuminance", "PimageOsc" ];
   let assigned = 0;
   for (let k = 0; k < keys.length; ++k) {
      let id = Settings.read(
         InNovaIntegratorHandoffImagePrefix + keys[k], DataType_String );
      if (!Settings.lastReadOK || typeof id !== "string" || id.length === 0)
         continue;
      let combo = targetDialog.comboBoxReferences[keys[k]];
      if (!combo) continue;
      InNovaIntegratorHandoffImageIds[id] = true;
      let itemIndex = -1;
      for (let i = 0; i < combo.numberOfItems; ++i)
         if (combo.itemText(i) === id) {
            itemIndex = i;
            break;
         }
      if (itemIndex < 0 && !ImageWindow.windowById(id).isNull) {
         combo.addItem(id);
         itemIndex = combo.numberOfItems - 1;
      }
      if (itemIndex >= 0) {
         combo.currentItem = itemIndex;
         if (typeof combo.onItemSelected === "function")
            combo.onItemSelected(itemIndex);
         ++assigned;
      }
   }

   let objectMode = Settings.read("InNovaHandoffObjectType", DataType_String);
   if (Settings.lastReadOK && objectMode === "MOON_SUN") {
      targetDialog.objectTypeComboBox.currentItem = 1;
      if (typeof targetDialog.objectTypeComboBox.onItemSelected === "function")
         targetDialog.objectTypeComboBox.onItemSelected(1);
   }

   Settings.remove(InNovaIntegratorHandoffPendingSetting);
   console.noteln("🚀 InNova Get Started handoff: " + assigned +
      " prepared channel image(s) assigned automatically.");
   return assigned > 0;
}

function InNovaIntegratorShowGetStartedHandoffNotice()
{


   let notice = new Dialog;
   notice.windowTitle = "InNova Astro Processor";

   let information = new Label(notice);
   information.useRichText = true;
   information.wordWrapping = true;
   information.text =
      "<p align=\"center\"><span style=\"font-size:32pt;color:#2784b9\">ⓘ</span>" +
      "<br/><br/><b>Make sure:</b><br/><br/>" +
      "• Project type<br/>" +
      "• Gradient correction<br/>" +
      "• Object type<br/>" +
      "• Starless image<br/>" +
      "• Any other options<br/><br/>" +
      "<b>Are correct.</b></p>";
   information.setFixedWidth(notice.logicalPixelsToPhysical(460));

   let okButton = new PushButton(notice);
   okButton.text = "OK";
   okButton.icon = notice.scaledResource(":/icons/ok.png");
   okButton.setFixedWidth(notice.logicalPixelsToPhysical(120));
   okButton.defaultButton = true;
   okButton.onClick = function () { notice.ok(); };

   let buttons = new HorizontalSizer;
   buttons.addStretch();
   buttons.add(okButton);
   buttons.addStretch();

   notice.sizer = new VerticalSizer;
   notice.sizer.margin = 16;
   notice.sizer.spacing = 16;
   notice.sizer.add(information);
   notice.sizer.add(buttons);
   notice.adjustToContents();
   MiraCenterDialog(notice);
   notice.execute();
}

let InNovaIntegratorGetStartedHandoffApplied =
   InNovaIntegratorConsumeGetStartedHandoff(dialog);
if (InNovaIntegratorGetStartedHandoffApplied)
   InNovaIntegratorShowGetStartedHandoffNotice();


dialog.initialCenterTimer = new Timer;
dialog.initialCenterTimer.interval = 0.05;
dialog.initialCenterTimer.periodic = false;
dialog.initialCenterTimer.onTimeout = function ()
{
   MiraCenterDialog(dialog);
};
dialog.onShow = function ()
{
   MiraCenterDialog(this);
   dialog.initialCenterTimer.start();
};


dialog.actualizarComboBoxesDesdeGUI = function () {

   var self = dialog;


   let availableImageIds = [];
   let windows = ImageWindow.windows;

   for (let i = 0; i < windows.length; ++i) {
      if (!windows[i] || windows[i].isNull || !windows[i].mainView || windows[i].mainView.isNull)
         continue;

      let id = windows[i].mainView.id;
      if (
         id.indexOf("Final_") === 0 ||
         id.indexOf("Base_") === 0 ||


         id.indexOf("Image_") === 0 ||
         id.indexOf("Gray") === 0 ||
         (id.indexOf("_registered") !== -1 &&
          !InNovaIntegratorHandoffImageIds[id]) ||
         id.indexOf("_ABE") !== -1 ||
         id.indexOf("_stars") !== -1
      )
         continue;

      availableImageIds.push(id);
   }

   function actualizarCombo(comboBox) {
      if (!comboBox)
         return;

      comboBox.clear();
      comboBox.addItem("<Select an Image>");

      for (let i = 0; i < availableImageIds.length; ++i)
         comboBox.addItem(availableImageIds[i]);

      comboBox.currentItem = 0;
   }

   for (let key in self.comboBoxReferences) {
      actualizarCombo(self.comboBoxReferences[key]);
   }

   PimageSii = "EMPTY";
   PimageHa = "EMPTY";
   PimageOiii = "EMPTY";
   PimageRed = "EMPTY";
   PimageGreen = "EMPTY";
   PimageBlue = "EMPTY";
   PimageLuminance = "EMPTY";
   PimageOsc = "EMPTY";
   if (typeof self.updateColorCalibrationAvailability === "function")
      self.updateColorCalibrationAvailability(false);

   CoreApplication.processEvents();
   self.update();
};


if (CanStartApp)
{
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   InNovaStartupSplash.hide();
   dialog.execute();

   if (InNovaEditorPendingLaunch) {
      let editorCompleted = InNovaIntegratorOpenInNovaEditor(
         InNovaEditorPendingSourceId,
         InNovaEditorPendingProjectType);
      console.noteln("\n✅ End of project.");
      if (editorCompleted) console.hide();
   }
}
else
{
   console.criticalln("Application startup blocked.");
}

if (InNovaReturnToStartPath.length > 0) {
   try {
      if (InNovaReturnToBridgeRequest != null) {
         let resultId = "";
         let processed = InNovaBridgeProcessedResultReady;


         if (!processed && InNovaReturnToBridgeRequest.sourceId &&
             !ImageWindow.windowById(InNovaReturnToBridgeRequest.sourceId).isNull)
            resultId = InNovaReturnToBridgeRequest.sourceId;
         if (processed) {
            let preferredIds = [FinalConvertedFocusWindowId, FinalFocusWindowId];
            for (let i = 0; i < preferredIds.length; ++i)
               if (preferredIds[i] && !ImageWindow.windowById(preferredIds[i]).isNull) {
                  resultId = preferredIds[i];
                  break;
               }
            let baseline = {};
            let baselineIds = InNovaReturnToBridgeRequest.baselineIds || [];
            for (let i = 0; i < baselineIds.length; ++i)
               baseline[String(baselineIds[i])] = true;
            if (resultId.length == 0) {
               let active = ImageWindow.activeWindow;
               if (active != null && !active.isNull && !active.mainView.isNull &&
                   !baseline[active.mainView.id])
                  resultId = active.mainView.id;
            }
            if (resultId.length == 0) {
               let current = ImageWindow.windows;
               for (let i = current.length - 1; i >= 0; --i) {
                  if (current[i] == null || current[i].isNull ||
                      current[i].mainView.isNull) continue;
                  let id = current[i].mainView.id;
                  if (!baseline[id] && id.indexOf("_Preview") < 0 &&
                      id.indexOf("mask") < 0) {
                     resultId = id;
                     break;
                  }
               }
            }
         }
         if (resultId.length == 0 && InNovaReturnToBridgeRequest.sourceId &&
             !ImageWindow.windowById(InNovaReturnToBridgeRequest.sourceId).isNull) {
            resultId = InNovaReturnToBridgeRequest.sourceId;
            processed = false;
         }
         Settings.write("InNova/BridgeReturn", DataType_String, JSON.stringify({
            created: Date.now(),
            sourceId: InNovaReturnToBridgeRequest.sourceId || "",
            resultId: resultId,
            processed: processed
         }));
      }
      console.hide();
      MiraLaunchSuiteScript(InNovaReturnToStartPath);
   } catch (error) {
      new MessageBox("InNova Start could not be reopened.\n\n" + error,
         "InNova Astro Processor", StdIcon_Error, StdButton_Ok).execute();
   }
}

} finally {
   InNovaStartupSplash.hide();
}

#endif
