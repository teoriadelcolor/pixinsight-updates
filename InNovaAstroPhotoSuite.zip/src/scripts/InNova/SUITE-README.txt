INNOVA ASTRO PHOTO SUITE — DEVELOPMENT BUILD
==============================================

Current applications
--------------------

1. InNova01.js — InNova Integrator v.1.0.build.0195
   Integration and astrophotography processing workflow.
   The Group 5 option "Open InNova Editor when finished" closes the
   Integrator after a successful run and opens the Editor on a preserved
   copy of the final image.

2. InNova02.js — InNova Editor v.1.0.build.0077
   Independent final-image editor. It preserves the selected source image
   and creates a new result with the suffix "_InNovaEditor".
   When launched from InNova Integrator, the source image and exact project
   type are transferred automatically. In standalone mode, Auto detection
   remains available.

PixInsight menu and installation folder
----------------------------------------

Both applications are registered under:

Script > InNova Astro Photo Suite

Install the suite files together in the InNova script folder so the shared
lib directory and InNovaIcon.svg remain available to both applications.

Shared license and application data
-----------------------------------

InNova Integrator and InNova Editor use the same trial, machine ID and
license.dat. New application data is stored in:

Documents/InNova

This release candidate starts a new 60-day civil trial on 2026.08.01. The
exclusive end date is 2026.09.30.

License activation and renewal remain managed from InNova Integrator.
Existing machine and license data can be migrated by the suite.

Current editor capabilities
---------------------------

- internal cached preview with fit and zoom;
- RGB histogram, logarithmic display and clipping warnings;
- collapsible editing and mask modules;
- independent global, subject and background adjustments;
- luminosity masks and cumulative color-range profiles;
- hue, saturation and luminance editing for selected colors;
- cached Before/After, mask and regional previews;
- debounced nonblocking slider workflow;
- high-quality full-resolution preview;
- independent star-presence and morphological star-size reduction controls;
- independent elapsed-time clock for every processing module;
- custom color-gradient and tonal slider controls;
- visual Color Picker eyedropper control;
- standalone initialization and validation of third-party AI model paths;
- full-resolution processing after Apply and Continue.

Brand assets
------------

- InNovaIcon.svg: PixInsight script icon.
- InNova_Icon.ico: InNova Astro Photo Suite application/package icon.

This is a development build and has not been packaged as a public release.

Website: https://www.teoriadelcolor.es/innovaastrophotosuite
