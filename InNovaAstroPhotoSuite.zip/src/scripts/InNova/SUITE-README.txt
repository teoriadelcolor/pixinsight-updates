INNOVA ASTRO PHOTO SUITE — DEVELOPMENT BUILD
==============================================

Current applications
--------------------

1. InNova01.js — InNova Integrator v.1.0.build.0222
   Integration and astrophotography processing workflow.
   The Group 5 option "Open InNova Editor when finished" closes the
   Integrator after a successful run and opens the Editor on a preserved
   copy of the final image.
   ImageSolver includes automatic recovery for metadata-free SEESTAR and
   Vespera files and extreme wide-field/fisheye images. Catalog identifiers
   found in FITS keywords, window names or source folders are resolved
   automatically; the
   assisted ImageSolver dialog is reserved for the final fallback.
   If any selected image has no astrometric solution, ImageSolver is enabled
   and executed automatically during the same run; no checkbox change or
   second launch is required.
   Targets read from astronomical metadata are trusted automatically. A target
   inferred only from a file or folder name is identified as low confidence
   and must be confirmed before automatic solving. Corrected ImageSolver
   coordinates are reused for other images in the same source folder during
   the current script session.
   Startup diagnostics check local Gaia astrometry and Gaia DR3/SP databases
   independently. ImageSolver can use its online catalog fallback when local
   astrometry is unavailable; MGC remains protected until Gaia DR3/SP is ready.

2. InNova02.js — InNova Editor v.1.0.build.0097
   Independent final-image editor. It preserves the selected source image
   and creates a new result with the suffix "_InNovaEditor".
   When launched from InNova Integrator, the source image and exact project
   type are transferred automatically. In standalone mode, Auto detection
   remains available.

PixInsight menu and installation folder
----------------------------------------

Both applications are registered under:

Script > InNova Astro Photo Suite

Install the suite files together in the InNova script folder so the shared
lib directory and InNovaIcon.svg remain available to both applications.

Shared license and application data
-----------------------------------

InNova Integrator and InNova Editor use the same trial, machine ID and
license.dat. New application data is stored in:

Documents/InNova

This release candidate starts a new 60-day civil trial on 2026.08.05. The
exclusive end date is 2026.10.04.

License activation and renewal remain managed from InNova Integrator.
Existing machine and license data can be migrated by the suite.

Current editor capabilities
---------------------------

- internal cached preview with fit and zoom;
- RGB histogram, logarithmic display and clipping warnings;
- collapsible editing and mask modules;
- active module headers shown in bold blue;
- InNova Neutralization before denoising, luminance enhancement and sharpen;
- independent global, subject and background adjustments;
- luminosity masks and cumulative color-range profiles;
- hue, saturation and luminance editing for selected colors;
- cached Before/After, mask and regional previews;
- adjustable Subject/Background expansion and edge feather;
- debounced nonblocking slider workflow;
- bounded Detailed preview with selective per-stage caches;
- native full-resolution processing reserved for Apply and Continue;
- independent star-presence and morphological star-size reduction controls;
- independent elapsed-time clock for every processing module;
- custom color-gradient and tonal slider controls;
- visual Color Picker eyedropper control;
- standalone initialization and validation of third-party AI model paths;
- full-resolution processing after Apply and Continue.

Brand assets
------------

- InNovaIcon.svg: PixInsight script icon.
- InNova_Icon.ico: InNova Astro Photo Suite application/package icon.

This is a development build and has not been packaged as a public release.

Website: https://www.teoriadelcolor.es/innovaastrophotosuite
