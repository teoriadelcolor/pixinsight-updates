INNOVA ASTRO PHOTO SUITE — 60-DAY RELEASE CANDIDATE
==============================================

Current applications
--------------------

1. InNova01.js — InNova Integrator v.1.0.build.0276
   Integration and astrophotography processing workflow.
   InNova Adaptive Stretch pauses at the linear-to-nonlinear transition and
   previews independent Highlight protection and Shadow protection controls
   before
   the irreversible stretch is accepted. Zero Highlight protection reproduces
   the historical automatic curve, while higher values progressively protect
   bright galaxy and nebula cores before final editing.
   The Group 5 option "Open InNova Editor when finished" closes the
   Integrator after a successful run and opens the Editor on a preserved
   copy of the final image.
   ImageSolver includes automatic recovery for metadata-free SEESTAR and
   Vespera files and extreme wide-field/fisheye images. Catalog identifiers
   found in FITS keywords, window names or source folders are resolved
   automatically; the
   assisted ImageSolver dialog is reserved for the final fallback.
   If any selected image has no astrometric solution, ImageSolver is enabled
   and executed automatically during the same run; no checkbox change or
   second launch is required.
   Targets read from astronomical metadata are trusted automatically. A target
   inferred only from a file or folder name is identified as low confidence
   and must be confirmed before automatic solving. Corrected ImageSolver
   coordinates are reused for other images in the same source folder during
   the current script session.
   Startup diagnostics check local Gaia astrometry and Gaia DR3/SP databases
   independently. ImageSolver can use its online catalog fallback when local
   astrometry is unavailable; MGC remains protected until Gaia DR3/SP is ready.

2. InNova02.js — InNova Editor v.1.0.build.0115
   Independent final-image editor. It preserves the selected source image
   and creates a new result with the suffix "_InNovaEditor".
   When launched from InNova Integrator, the source image and exact project
   type are transferred automatically. In standalone mode, Auto detection
   remains available.

3. InNova03.js — 💫 InNova Adaptive Stretch v.1.0.build.0029
   Independent progressive stretch application for any open color image.
   It offers Advanced Adaptive protection and a Basic mode that reproduces
   the stable STF/HistogramTransformation stretch from the published release,
   plus independent Red, Green and Blue midtones controls for removing color
   casts while the preview histogram updates,
   applies the accepted result in place, and leaves the image unchanged on
   Cancel.

PixInsight menu and installation folder
----------------------------------------

All three applications are registered under:

Script > InNova Astro Photo Suite

Install the suite files together in the InNova script folder so the shared
lib directory and InNovaIcon.svg remain available to all applications.

Shared license and application data
-----------------------------------

InNova Integrator, InNova Editor and InNova Adaptive Stretch use the same
trial, machine ID and license.dat. New application data is stored in:

Documents/InNova

This release candidate starts a new 60-day civil trial on 2026.08.17 and
remains valid through 2026.10.15. The exclusive end date is 2026.10.16.

License activation and renewal remain managed from InNova Integrator.
Existing machine and license data can be migrated by the suite.

Current editor capabilities
---------------------------

- internal cached preview with fit and zoom;
- RGB histogram, logarithmic display and clipping warnings;
- collapsible editing and mask modules;
- active module headers shown in bold blue;
- InNova Background Correction before denoising, luminance enhancement and
  sharpen;
- independent global, subject and background adjustments;
- luminosity masks and cumulative color-range profiles;
- hue, saturation and luminance editing for selected colors;
- cached Before/After, mask and regional previews;
- adjustable Subject/Background expansion and edge feather;
- debounced nonblocking slider workflow;
- bounded Detailed preview with selective per-stage caches;
- native full-resolution processing reserved for Apply;
- independent star-presence and star-brightness reduction controls;
- independent elapsed-time clock for every processing module;
- custom color-gradient and tonal slider controls;
- visual Color Picker eyedropper control;
- standalone initialization and validation of third-party AI model paths;
- full-resolution processing after Apply.

Brand assets
------------

- InNovaIcon.svg: PixInsight script icon.
- InNova_Icon.ico: InNova Astro Photo Suite application/package icon.

This release candidate has been staged for PixInsight CodeSign.

Website: https://www.teoriadelcolor.es/innovaastrophotosuite
