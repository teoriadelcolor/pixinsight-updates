#engine v8

/*
 ****************************************************************************
 * InNova Editor
 *
 * Final image finishing application for InNova Astro Photo Suite.
 * Copyright (C) 2024-2026 Jesús Manuel García Flores
 ****************************************************************************
 */

#feature-id    InNovaEditor : InNova Astro Photo Suite > InNova Editor
#feature-icon  InNovaIcon.svg
#feature-info  Final image editor for InNova Astro Photo Suite. \
Uses the shared InNova Astro Photo Suite trial and license. \
<br/>Copyright &copy; 2024-2026 Jesús M. García Flores.

#define TITLE "InNova Editor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/StdDialogCode.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/BitmapInterpolation.jsh>

/*
 * Suite identity. These values intentionally match InNova Integrator so both
 * applications share the same machine ID, trial interval and license.dat.
 */
var ProjecTname = "🪐 InNova Editor";
var ProjecTver = "v.1.0.build.0097";
var ProjectND = "05ad08xjr";
var ProjectHash =
   "041fbd111663d1eded6f7063c20ac6247b282006b8d83633f49ea171eaf349ea";
var RuntimeToken = "";
var VarLicense = "EMPTY";

/*
 * Compatibility state used by the shared editor engine. InNova Editor only
 * invokes the Image Editor functions; the remaining process functions stay
 * dormant.
 */
var ProjecTypevar = "RGB";
var ProjecTypevarRec = "RGB";
var OptionNarrowbandToRGB = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var Option300 = "OFF";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var StarXPath = "EMPTY";
var StarXPath0 = "StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 = "StarXTerminator.lite.nonoise.11.pb";
var StarBPath = "EMPTY";
var StarBPath0 = "BlurXTerminator.4.mlpackage";
var StarBPath1 = "BlurXTerminator.4.pb";
var StarNPath = "EMPTY";
var StarNPath0 = "NoiseXTerminator.2.mlpackage";
var StarNPath03 = "NoiseXTerminator.3.mlpackage";
var StarNPath1 = "NoiseXTerminator.2.pb";
var StarNPath13 = "NoiseXTerminator.3.pb";
var StarMarsFirst = "MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond = "MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel = "MLDenoise_v5.xmlm";
var originalFilePathMLDenoisefin = "";
var InteractiveProcessStrengths = { NarrowbandToRGB: null };
var InteractiveProcessMaskModes = { NarrowbandToRGB: "none" };
var InteractiveProcessMaskBanks = { NarrowbandToRGB: null };
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};
var InNovaEditorTitle = "🪐 InNova Editor";

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process05.js"

function InNovaEditorInitializeLicense()
{
   if (!IsProjectHashValid()) {
      RuntimeToken = "";
      VarLicense = "EMPTY";
      new MessageBox(
         "Suite validation failed.",
         "InNova Editor",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return false;
   }

   let license = ReadLicenseData();
   let complete = IsLicenseComplete(license);
   let signatureValid = complete && IsLicenseSignatureValid(license);
   let expired = signatureValid && IsLicenseExpired(license.expiry);

   if (signatureValid && !expired) {
      RuntimeToken = license.signature.substr(0, 8);
      VarLicense = "FULL";
      console.noteln("✅ InNova Astro Photo Suite license activated.");
      return true;
   }

   if (IsProjectDateValid()) {
      RuntimeToken = CreateProjectHash().substr(0, 8);
      VarLicense = "PROJECT";
      console.noteln("License mode: TRIAL");
      return true;
   }

   RuntimeToken = "LICENSE_REQUIRED";
   VarLicense = expired ? "EXPIRED" : "EMPTY";
   new MessageBox(
      expired ?
         "Your InNova Astro Photo Suite license has expired.\n\n" +
         "Please renew the license from InNova Integrator." :
         "The InNova Astro Photo Suite trial has expired.\n\n" +
         "Please activate a license from InNova Integrator.",
      "InNova Editor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
   return false;
}

function InNovaEditorResetEditorState()
{
   InteractiveProcessStrengths.NarrowbandToRGB = null;
   InteractiveProcessMaskModes.NarrowbandToRGB = "none";
   InteractiveProcessMaskBanks.NarrowbandToRGB = null;

   for (let name in NarrowbandToRGBCurveSettings)
      NarrowbandToRGBCurveSettings[name] = 0;
}

function InNovaEditorCloneWindow(sourceWindow, outputId)
{
   let image = sourceWindow.mainView.image;
   let bits = sourceWindow.bitsPerSample || 32;
   let floatSamples = sourceWindow.isFloatSample !== undefined ?
      sourceWindow.isFloatSample : true;

   if (floatSamples && bits !== 32 && bits !== 64)
      bits = 32;

   let output = new ImageWindow(
      image.width,
      image.height,
      image.numberOfChannels,
      bits,
      floatSamples,
      sourceWindow.isColor !== undefined ? sourceWindow.isColor : true,
      outputId
   );

   output.mainView.beginProcess(UndoFlag_NoSwapFile);
   output.mainView.image.assign(image);
   output.mainView.endProcess();

   try {
      output.keywords = sourceWindow.keywords;
   }
   catch (e) {
   }

   return output;
}

function InNovaEditorInferProjectType(windowId)
{
   let upperId = windowId.toUpperCase();
   if (upperId.indexOf("SHO") !== -1)
      return "SHO";
   if (upperId.indexOf("HOO") !== -1)
      return "HOO";
   if (upperId.indexOf("LRGB") !== -1)
      return "LRGB";
   if (upperId.indexOf("OSC") !== -1 ||
       upperId.indexOf("VAONIS") !== -1 ||
       upperId.indexOf("SEESTAR") !== -1)
      return "OSC";
   return "RGB";
}

class InNovaEditorDialog extends Dialog
{
   constructor()
   {
      super();
      let dialog = this;
      this.windowTitle = "🪐 InNova Editor";

      this.description = new Label(this);
      this.description.useRichText = true;
      this.description.wordWrapping = true;
      this.description.text =
         "Select an open color image. InNova Editor preserves the original " +
         "and creates a new edited result.";

      this.sourceLabel = new Label(this);
      this.sourceLabel.text = "Image:";
      this.sourceLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
      this.sourceLabel.setFixedWidth(90);

      this.sourceCombo = new ComboBox(this);
      this.sourceCombo.setMinWidth(430);

      this.refreshButton = new PushButton(this);
      this.refreshButton.text = "Refresh";
      this.refreshButton.icon =
         this.scaledResource(":/icons/reload.png");
      this.refreshButton.onClick = function () {
         dialog.populateImages();
      };

      this.runButton = new PushButton(this);
      this.runButton.text = "Run Editor";
      this.runButton.icon =
         this.scaledResource(":/icons/power.png");
      this.runButton.onClick = function () {
         dialog.runEditor();
      };

      this.closeButton = new PushButton(this);
      this.closeButton.text = "Close";
      this.closeButton.icon =
         this.scaledResource(":/icons/close.png");
      this.closeButton.onClick = function () {
         dialog.cancel();
      };

      let imageRow = new HorizontalSizer;
      imageRow.spacing = 8;
      imageRow.add(this.sourceLabel);
      imageRow.add(this.sourceCombo, 100);
      imageRow.add(this.refreshButton);

      let buttons = new HorizontalSizer;
      buttons.spacing = 10;
      buttons.addStretch();
      buttons.add(this.runButton);
      buttons.add(this.closeButton);
      buttons.addStretch();

      this.sizer = new VerticalSizer;
      this.sizer.margin = 12;
      this.sizer.spacing = 10;
      this.sizer.add(this.description);
      this.sizer.add(imageRow);
      this.sizer.addSpacing(4);
      this.sizer.add(buttons);

      this.populateImages();
      this.adjustToContents();
   }

   populateImages()
   {
      let previousId = this.sourceCombo.currentItem > 0 ?
         this.sourceCombo.itemText(this.sourceCombo.currentItem) : "";
      let activeId = ImageWindow.activeWindow &&
                     !ImageWindow.activeWindow.isNull ?
                     ImageWindow.activeWindow.mainView.id : "";

      this.sourceCombo.clear();
      this.sourceCombo.addItem("<Select a color image>");
      let selectedIndex = 0;
      let windows = ImageWindow.windows;

      for (let i = 0; i < windows.length; ++i) {
         let window = windows[i];
         if (!window || window.isNull || !window.mainView ||
             window.mainView.isNull || !window.mainView.image ||
             window.mainView.image.numberOfChannels < 3)
            continue;

         this.sourceCombo.addItem(window.mainView.id);
         let itemIndex = this.sourceCombo.numberOfItems - 1;
         if (window.mainView.id === previousId ||
             (previousId.length === 0 && window.mainView.id === activeId))
            selectedIndex = itemIndex;
      }

      this.sourceCombo.currentItem = selectedIndex;
   }

   runEditor()
   {
      if (this.sourceCombo.currentItem < 1) {
         new MessageBox(
            "Select an open color image.",
            "InNova Editor",
            StdIcon_Warning,
            StdButton_Ok
         ).execute();
         return;
      }

      let sourceId = this.sourceCombo.itemText(this.sourceCombo.currentItem);
      let source = ImageWindow.windowById(sourceId);
      if (!source || source.isNull || !source.mainView ||
          source.mainView.isNull) {
         this.populateImages();
         return;
      }

      let projectType = InNovaEditorInferProjectType(sourceId);
      let outputId = MiraUniqueWindowId(sourceId + "_InNovaEditor");
      let output = InNovaEditorCloneWindow(source, outputId);

      InNovaEditorResetEditorState();
      ProjecTypevar = projectType;
      ProjecTypevarRec = projectType;

      console.noteln("\n🪐 InNova Editor editing: " + sourceId);

      let editorResult;
      try {
         editorResult = InNovaEditorRunProEditor(
            output.mainView, projectType);
      }
      catch (error) {
         output.forceClose();
         new MessageBox(
            "The image editor could not prepare the selected image.\n\n" +
            (error.message || error) + "\n\n" +
            "Review the Process Console for details.",
            "InNova Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

      if (!editorResult.accepted) {
         output.forceClose();
         if (editorResult.openRequested) {
            console.noteln(
               "🪐 InNova Editor returned to the image selector.");
            this.populateImages();
            return;
         }
         if (editorResult.cancelled) {
            console.noteln("🪐 InNova Editor editing cancelled.");
            return;
         }
         new MessageBox(
            "The image editor could not prepare the selected image.\n\n" +
            "Review the Process Console for details.",
            "InNova Editor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

      output.show();
      output.bringToFront();
      console.noteln("✅ 🪐 InNova Editor result created: " + outputId);
      console.noteln("\n✅ Process finished.");
      this.populateImages();
   }
}

console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");

// Standalone startup must initialize the same platform-specific AI model
// paths used by InNova Integrator before provider availability is evaluated.
InitializeInNovaProviderPaths();
originalFilePathMLDenoisefin =
   GetInNovaDataFilePath(StarMLDenoiseModel);
Settings.write("originalFilePathMLDenoisefin", DataType_String,
               originalFilePathMLDenoisefin);

if (InNovaEditorInitializeLicense()) {
   let dialog = new InNovaEditorDialog;
   dialog.onShow = function () {
      MiraCenterDialog(this);
   };
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}
