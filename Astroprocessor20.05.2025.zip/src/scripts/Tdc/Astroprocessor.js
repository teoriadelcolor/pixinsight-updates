/*
 ****************************************************************************
 * AstroProcessor Script
 *
 * AstroProcessor.js
 * Copyright (C) 2024 Jesús Manuel García Flores
 *
 * This script will help you to automate the most common processes in Pixinisight.
 * Upgrade your license for free as Beta tester.
 *
 *
 * If you wish to contact us you can do so by email at info@teoriadelcolor.es
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * This script is protected by copyright and may not be copied,
 * modified, redistributed, or used in any medium without prior written
 * authorization from Teoría del Color.
 *
 *
 * Beta release.
 *
 ****************************************************************************
 */



#feature-id    AstroProcessor : Utilities > AstroProcessor
#feature-icon  AstroprocessorIcon.svg
#feature-info  This script will help you automate the most common processes in Pixinisight. \
Upgrade your license for free. \
<br/>\
Copyright &copy; 2024 Jesús M. García Flores.

#define TITLE "AstroProcessor"

#include <pjsr/Sizer.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/SectionBar.jsh>
#include <pjsr/Color.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdDialogCode.jsh>
#include "lib/process11.js"
#include "lib/process10.js"
#include "lib/process09.js"
#include "lib/process08.js"
#include "lib/process07.js"
#include "lib/process06.js"
#include "lib/process05.js"
#include "lib/process04.js"
#include "lib/process03.js"
#include "lib/process02.js"
#include "lib/process01.js"



// Variables globales
var ProjecTname = "🚀" + " Astro Processor Script";
var ProjecTver  = "v.08.5a";
var ProjecTypevar = "SHO";  // Valor inicial
var AlignmenTypevar = "Ha"; // Valor inicial
var OptionLinkRGB = "false";  // Deshabilitado por defecto
var PimageSii = "EMPTY";        // Valor inicial
var PimageHa = "EMPTY";         // Valor inicial
var PimageOiii = "EMPTY";       // Valor inicial
var PimageRed = "EMPTY";        // Valor inicial
var PimageGreen = "EMPTY";      // Valor inicial
var PimageBlue = "EMPTY";       // Valor inicial
var PimageLuminance = "EMPTY";  // Valor inicial
var PimageOsc = "EMPTY";  // Valor inicial
var Option1var = "OFF";         // Valor inicial para StarsRGB
var VarProcesStar = "OFF";      // Inicializamos la variable para saber cuando se está creando la capa stars
var Option2var = "OFF";          // Valor inicial para 300pppResolution
var Option2var2 = "OFF"         // Valor para Botón OK en 300pppResolution
var OptionABE = "ON";           // Valor inicial
var OptionGraXNoise = "OFF";    // Valor inicial
var OptionGraXpert  = "OFF";      // Valor inicial
var OptionNoiseXterminator  = "OFF";
var OptionStarXterminator = "ON";    // Valor inicial
var OptionstarNet = "OFF";      // Valor inicial
var OptionBlurXterminator = "ON";    // Valor inicial
var OptionHighpass = "OFF";    // Valor inicial
var OptionGradient ="ON";       // Valor inicial
var OptionDBE = "OFF";          // Valor inicial
var OptionEnh = "OFF";          // Valor inicial
var OptionVarStars = "ON";      // Valor inicial
var OptionMgc ="OFF";
var OptionFast = "OFF";
var MiraIconosvar = "SHO_Align";// Valor inicial
var VarPGlobal = "EMPTY";       // Valor inicial
var VarPGlobal2 ="EMPTY";       // Valor inicial
var VarPGlobal3 ="EMPTY";       // Valor inicial
var VarPGlobal4 ="EMPTY";       // Valor inicial
var VarLicense ="EMPTY";        // Valor inicial
var VarPL = "1234-1234-1234-1234";
var NewGreenValue = 0.0;  // Inicializamos NewGreenValue con 0.0
var NewMagentaValue = 1;  // Inicializamos NewMAgenta con 1
var NewStarsValue = 1;  // Inicializamos NewStarsValue
var NewProOptionValue = 100;  // Inicializamos NewStarsValue
var isStarProcess = false; //Valor de paso por MiraGreen2()
var OptionHSOvar = "ON";
var OptionProOne = "HDR";
var OptionMaskvar = "None";        // Inicialización por defecto
var OptionBlurMaskvar = "None";    // Inicialización por defecto
var OptionColorMaskvar = "Red channel"; // Inicialización por defecto
var OptionColorMaskHuevar = 10;     // Inicialización por defecto
var OptionColorMaskSatvar = 10;     // Inicialización por defecto
var OptionColorMaskLumvar = 10;     // Inicialización por defecto
var OptionColorMaskBlackvar = 10;
var OptionColorMaskWhitevar = 10;
var OptionColorMaskContrastvar = 10;
var OptionSigmavar = 5.00;
var OptionSharpenNonstellar = 0.20;
var OptionStarpresence = 10;
var OptionStarRounded = 10;
var OptionStartemperature = 10;
var OptionStarsaturation = 10;
var OptionStarhalo = 0;
var OptionStarblend = 20;
var OptionStarMagenta = 0;
var OptionStarGreen = 0;
var OptionStarBrillance = 10;
var OptionStarSharp = 0;
var OptionMergePro0  = "<Select an Image>";
var OptionMergePro1  = "<Select an Image>";
var OptionMergePro2  = "<Select an Image>";
var OptionMergePro4  = "<Select an Image>";
var OptionMergePro5  = "<Select an Image>";
var OptionAdjvalue = 1;
var OptionAdjvalue2 = 200;
var OptionshowMaskvar = "OFF";
var OptionTypeMaskvar = "None";
var OptionBlurMaskvar = "None";
var OptionRGBMaskvar = "None";
var OptionshowConsolRadio = "ON";
let previousMaskType = null;
let previousBlurOption = null;
var OptionNombVar = null;
var OptionRemaind = null;
var OptionRemaind2 = null;
var OptionReSLider = "OFF";
var OptionSTFvar = "OFF";
var Optiontimevar = null;
var OptionEnabledPreview ="OFF";
var OptionEnabledPreview2 ="OFF";
let lastState = null;      // Estado para Undo
let redoState = null;      // Estado para Redo
var OptionFlag ="0";
var OptionFlag2 = "0";
var OptionCrop  = "OFF";
var OptionGreen = "OFF";
var OptionLower = 0.4;
var OptionUpper = 1;
var OptionFuzziness = 0;
var OptionSmoothness = 0;
var OptionBlur = 0.1;
var OptionInvertMask = "OFF";
var savedImageName = "";
//
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
//ruta del archivo de Trabajo - Working file path
var originalFilePath ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathColor ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathLeyenda ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathMars1 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMars2 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMars3 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin1 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin2 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin3 ="/Applications/PixInsight/src/scripts/Tdc/";
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MarsFound3 ="OFF";
var MarsEdited ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMars1 ="MARS-DR1-1.0.3.xmars";
var StarMars2 ="MARS-DR1-u01-1.0.1.xmars";
var StarMars3 ="MARS-DR1-1.1.1.xmars";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var WindowsOsx3 = 400;
var WindowsOsx4 = 300;
var WindowsOsx5 = 400;
var WindowsOsx6 = 100;
var startTime = Date.now();  // Inicializar startTime al inicio del script


var totalTime = Date.now()
console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("----------------------------------");
console.noteln("Checking third-party software:");
//asigna datos iniciales
defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


//Ruta
// Llamar a la función para obtener la ruta válida
var originalFilePath = getFilePath(originalFilePathMars1, originalFilePathMars2);


// Creación del diálogo principal
function IntegratorDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = ProjecTname;

    let self = this; // Save the `IntegratorDialog` instance context


    // this.setFixedSize();  // Makes the dialog fixed in size if you want no resizing at all.
    this.resizeable = true;
    this.setMaxHeight(1000);      // Ajusta el tamaño máximo en vertical (ajusta según tus necesidades)

    this.scaledMinWidth = 700;
    this.scaledMinHeight = 860;


    // Creación del contenedor de pestañas
    this.tabBox = new TabBox(this);


//-----------------------------------------------------------------------------
//Pestaña Integration----------------------------------------------------------
//-----------------------------------------------------------------------------

    // --- Tab 1: Integration ---
    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;

    // Crear un HorizontalSizer para mantener los dos GroupBoxes en horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Espacio entre los elementos

  // --- GroupBox: Project Type ---
    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "1. Crop:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    // RadioButtons para Project Type
    this.CropprojectLRGBRadioButton = new RadioButton(this);
    this.CropprojectLRGBRadioButton.text = "Multiscale Gradient Correction";
    this.CropprojectLRGBRadioButton.checked = true;
    this.CropprojectLRGBRadioButton.enabled = true;
    OptionCrop = "ON";

    this.CropprojectLRGBRadioButton.onClick = function () {
    if (this.checked) { // Verificar si el RadioButton está activado

        OptionCrop = "ON"; // Cambiar a "ON"
        console.writeln("Multiscale Gradient Correction = 'Enabled'");
        self.MgcCheckBox.enabled = true;
    } else {
        OptionCrop = "OFF"; // Si no está activado, cambiar a "OFF"
        console.writeln("Multiscale Gradient Correction = 'Disabled'");
        self.MgcCheckBox.enabled = false;
    }
    this.dialog.update(); // Actualizar la interfaz si es necesario
   };

    // Crear el Label para seleccionar una imagen
    let CropLabel = new Label(this.integrationPage);
    CropLabel.text = "\n\n\n\n\n\nCropped images you must first run\n'ImageSolver' on each image.";
    CropLabel.textAlignment = TextAlign_Left;


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;

    this.CropprojectTypeGroupBox.sizer.add(this.CropprojectLRGBRadioButton);
    this.CropprojectTypeGroupBox.sizer.add(CropLabel);


    // --- GroupBox: Project Type ---

    function MiraComboProyect() {
    // Disable all ComboBoxes by default
    for (let key in comboBoxReferences) {
        comboBoxReferences[key].enabled = false;
        comboBoxReferences[key].update();
    }

    // Enable specific ComboBoxes based on project type
    switch (ProjecTypevar) {
        case "RGB":
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            break;

        case "LRGB":
            comboBoxReferences["PimageLuminance"].enabled = true;
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            break;

        case "SHO":
            comboBoxReferences["PimageSii"].enabled = true;
            comboBoxReferences["PimageHa"].enabled = true;
            comboBoxReferences["PimageOiii"].enabled = true;
            break;

        case "HOO":
            comboBoxReferences["PimageHa"].enabled = true;
            comboBoxReferences["PimageOiii"].enabled = true;
            break;

        case "OSC":
            comboBoxReferences["PimageOsc"].enabled = true;
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }

    // Update the UI
    for (let key in comboBoxReferences) {
        comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "2. Select Project type:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    // RadioButtons para Project Type
    this.projectLRGBRadioButton = new RadioButton(this);
    this.projectLRGBRadioButton.text = "LRGB";
    this.projectLRGBRadioButton.onClick = function () {
       ProjecTypevar = "LRGB";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectRGBRadioButton = new RadioButton(this);
    this.projectRGBRadioButton.text = "RGB";
    this.projectRGBRadioButton.onClick = function () {
       ProjecTypevar = "RGB";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectSHORadioButton = new RadioButton(this);
    this.projectSHORadioButton.text = "SHO";
    this.projectSHORadioButton.checked = true;
    this.projectSHORadioButton.onClick = function () {
       ProjecTypevar = "SHO";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectHOORadioButton = new RadioButton(this);
    this.projectHOORadioButton.text = "HOO";
    this.projectHOORadioButton.onClick = function () {
       ProjecTypevar = "HOO";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectOSCRadioButton = new RadioButton(this);
    this.projectOSCRadioButton.text = "OSC (RGB Color camera)";
    this.projectOSCRadioButton.onClick = function () {
       ProjecTypevar = "OSC";
       console.noteln("OSC Project selected. Fast Integration mode disabled");
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;

    this.projectTypeGroupBox.sizer.add(this.projectLRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectSHORadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectHOORadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectOSCRadioButton);
    let labeldual = new Label(this);
    labeldual.text = "OSC Dual band. First run DbXtract.\nWhen finished select SHO Project.";
    labeldual.textAlignment = TextAlign_Left;
    this.projectTypeGroupBox.sizer.add(labeldual);


    // --- GroupBox: Alignment Type ---
    this.alignmentGroupBox = new GroupBox(this.integrationPage);
    this.alignmentGroupBox.title = "3. Select Alignment:";
    this.alignmentGroupBox.sizer = new VerticalSizer;

    this.alignmentHaRadioButton = new RadioButton(this);
    this.alignmentHaRadioButton.text = "Project images (default)";
    this.alignmentHaRadioButton.checked = true;
    this.alignmentHaRadioButton.onClick = function () { AlignmenTypevar = "Ha"; };

    this.alignmentAllRadioButton = new RadioButton(this);
    this.alignmentAllRadioButton.text = "All images by Ha";
    this.alignmentAllRadioButton.onClick = function () { AlignmenTypevar = "All by Ha"; };

    this.alignmentGroupBox.sizer.margin = 6;
    this.alignmentGroupBox.sizer.spacing = 6;

    this.alignmentGroupBox.sizer.add(this.alignmentHaRadioButton);
    this.alignmentGroupBox.sizer.add(this.alignmentAllRadioButton);

    // Añadir los dos GroupBoxes al HorizontalSizer para que estén en la misma fila

    horizontalSizer.add(this.projectTypeGroupBox);
     horizontalSizer.add(this.CropprojectTypeGroupBox);
    horizontalSizer.add(this.alignmentGroupBox);


    // --- GroupBox: Tagging ---
    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "4. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    let comboBoxReferences = {};

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer; // Alineación horizontal
       rowSizer.spacing = 6; // Espaciado entre elementos

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(180); // Ajusta el ancho del label para alineación

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];
           let windowTitle = "<Untitled>";

           // Intentar extraer el título desde el filePath (si la imagen proviene de un archivo)
           if (window.filePath && window.filePath.length > 0) {
               let fileName = window.filePath.replace(/^.*[\\\/]/, ''); // Extrae solo el nombre del archivo
               windowTitle = fileName.replace(/\.[^/.]+$/, ""); // Elimina la extensión del archivo
           } else {
               // Si no hay filePath, usa el identificador interno
               windowTitle = window.currentView.fullId;
           }

           comboBox.addItem(windowTitle);
       }

       comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
       };

       // Agregar los elementos al mismo HorizontalSizer
       rowSizer.add(label);
       rowSizer.add(comboBox, 1); // Expande el ComboBox para alineación correcta

       // Agregar el rowSizer al parentSizer
       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;

      // Añadir cada control con el nuevo formato en línea
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC: (.xisf or Raw)", "PimageOsc");

      // Agregar las pestañas al TabBox debajo de los 2 grupos
      this.tabBox.addPage(this.integrationPage, "Integration");




    // --- GroupBox: Project Options ---
    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "5. Select Integration options:";
    this.optionsGroupBox.sizer = new HorizontalSizer;

    // Crear un `VerticalSizer` para la primera columna
    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;

    // Checkboxes para la primera columna
      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;  // Predeterminado deshabilitado
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.ABECheckBox = new CheckBox(this);
   this.ABECheckBox.text = "Automatic mode (Basic)"; // Texto inicial
   this.ABECheckBox.checked = true; // Estado inicial
   this.ABECheckBox.onClick = function () {
       if (this.checked) {
           OptionABE = "ON";
           this.text = "Automatic mode (Basic)"; // Cambiar el texto cuando está activado
           this.styleSheet = "color: black;";
           console.noteln("Automatic mode (Basic)");
           self.FastCheckBox.checked = false;
           self.FastCheckBox.enabled = true;

       } else {
           OptionABE = "OFF";
           this.text = "Manual mode (Advanced)"; // Cambiar el texto cuando está desactivado
           this.styleSheet = "color: blue;";
           console.noteln("Manual mode (Advanced)");
           self.FastCheckBox.styleSheet = "color: black;"; //
           self.FastCheckBox.text = "Fast integration mode 'OFF' "; // Cambiar el texto cuando está desactivado
           self.FastCheckBox.checked = false;
           self.FastCheckBox.enabled = false;
       }
   };


   this.FastCheckBox = new CheckBox(this);
   this.FastCheckBox.text = "Fast integration mode 'OFF' "; // Texto inicial
   this.FastCheckBox.checked = false; // Estado inicial

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' "; // Cambiar el texto cuando está activado
           this.styleSheet = "color: blue;";
           console.noteln("Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionABE = "OFF";
           this.text = "Fast integration mode 'OFF' "; // Cambiar el texto cuando está desactivado
           this.styleSheet = "color: black;";
           console.noteln("Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


   let self = this; // Guardamos referencia a `this` para usarlo dentro de la función

   self.MgcCheckBox = new CheckBox(this);
   self.MgcCheckBox.text = "Multiscale Gradient Correction";
   self.MgcCheckBox.enabled = false;
   self.MgcCheckBox.checked = false;

   this.MgcCheckBox.onClick = function () {

         //Mirar la herramienta:
            try {
           // Intentar crear una instancia de MultiscaleGradientCorrection
           var P = new MultiscaleGradientCorrection();

             console.noteln("> MultiscaleGradientCorrection is available.");

            } catch (error) {
            console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
            throw new Error("Execution stopped due to missing tool.");
            }

        //Fin de comprobar herramienta

       if (this.checked) {
           OptionMgc = "ON";


           if (MarsFound1 === "OFF" || MarsFound2 === "OFF") {
               console.warningln("⚠️ " + "Multiscale Gradient Correction Error.\nMARS database not found.\nPress 'setting' " + "⚙️" +  " button and select Multiscale Gradiente Correction library path.");
               self.MgcCheckBox.checked = false; // Usamos `self` para referenciar correctamente el CheckBox
               self.MgcCheckBox.enabled = false;
               self.CropprojectLRGBRadioButton.checked = false;
           } else {
               console.noteln("Multiscale Gradient Correction : ON");
           }
       } else {
           OptionMgc = "OFF";
           console.noteln("Multiscale Gradient Correction : OFF");
       }
    };

    this.graXpertCheckBox = new CheckBox(this);
    this.graXpertCheckBox.text = "GraXpert Background Extraction (need Internet connection)";
    this.graXpertCheckBox.checked = false;
    this.graXpertCheckBox.onClick = function () {
        OptionGraXpert = this.checked ? "ON" : "OFF";
    };

    this.graXNoiseCheckBox = new CheckBox(this);
    this.graXNoiseCheckBox.text = "Denoising by GraXpert (need Internet connection)";
    this.graXNoiseCheckBox.checked = false;


    this.NoiseXterminatorCheckBox = new CheckBox(this);
    this.NoiseXterminatorCheckBox.text = "Denoising by NoiseXTerminator";
    this.NoiseXterminatorCheckBox.checked = false;

    this.NoiseXterminatorCheckBox.onClick = function () {
    // Actualizar la variable según el estado del CheckBox
    if (this.checked) {
        OptionNoiseXterminator = "ON";
        console.noteln("NoiseXterminator : ON");
        OptionGraXNoise = "OFF";
    } else {
        OptionNoiseXterminator = "OFF";
        console.noteln("NoiseXterminator : OFF");
    }

    // Desmarcar GraXNoiseCheckBox al activar NoiseXterminatorCheckBox
    this.dialog.graXNoiseCheckBox.checked = false;
};


    this.graXNoiseCheckBox.onClick = function () {
    // Actualizar la variable según el estado del CheckBox
    if (this.checked) {
        OptionGraXNoise = "ON";
        console.noteln("GraXpert Denoising : ON");
        OptionNoiseXterminator = "OFF";
    } else {
        OptionGraXNoise = "OFF";
        console.noteln("GraXpert Denoising : OFF");
    }

    // Desmarcar NoiseXterminatorCheckBox al activar GraXNoiseCheckBox
    this.dialog.NoiseXterminatorCheckBox.checked = false;
};

    this.OptionVarStarsCheckBox = new CheckBox(this);
    this.OptionVarStarsCheckBox.text = "Create 'Final_starless' Image";
    this.OptionVarStarsCheckBox.checked = true;
    //pasamos el código LINEA 464 donde se dibuja starXterm y Starnet las opciones del checkbox -



    // Añadir checkboxes a la primera columna
    column1Sizer.add(this.linkRGBChannels);
    column1Sizer.add(this.ABECheckBox);
    column1Sizer.add(this.FastCheckBox);
    column1Sizer.add(this.MgcCheckBox);
    column1Sizer.add(this.graXpertCheckBox);
    column1Sizer.add(this.graXNoiseCheckBox);
    column1Sizer.add(this.NoiseXterminatorCheckBox);
    //column1Sizer.add(this.resolutionCheckBox);

    // Crear un `VerticalSizer` para la segunda columna
    let column2Sizer = new VerticalSizer;
    column2Sizer.spacing = 6;
    column2Sizer.margin = 6;

   // stars
    this.starsHSOCheckBox = new CheckBox(this);
    this.starsHSOCheckBox.text = "Create 'Final_stars' (Project stars)";
    this.starsHSOCheckBox.checked = true;
    let self = this; // Guardar referencia al contexto actual
   this.starsHSOCheckBox.onClick = function () {
    // Cambiar el valor de OptionHSOvar dependiendo de si la opción está activada o desactivada
    OptionHSOvar = this.checked ? "ON" : "OFF";

    // Si la opción HSO está activada (ON)
    if (OptionHSOvar === "ON") {
        Option1var = "OFF";  // Apagar la opción RGB
        self.starsRGBCheckBox.checked = false;  // Desmarcar la opción RGB
    }
    // Si la opción HSO está desactivada (OFF)
    else {
        //Option1var = "ON";  // Encender la opción RGB
        //self.starsRGBCheckBox.checked = true;  // Marcar la opción RGB
    }
};

 // Configuración inicial para el proyecto
    ProjecTypevar = "SHO"; // Establecer el tipo de proyecto por defecto
    MiraComboProyect();    // Configurar los ComboBoxes al iniciar el diálogo

    // Checkboxes para la segunda columna
    this.starsRGBCheckBox = new CheckBox(this);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (only SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    let self = this; // Guardar referencia al contexto actual

    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.criticalln("Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


   Option1var = this.checked ? "ON" : "OFF";
    self.starsHSOCheckBox.checked = false;
    var OptionHSOvar = "OFF";

    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        comboBoxReferences["PimageRed"].enabled = false;
        comboBoxReferences["PimageGreen"].enabled = false;
        comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        self.starsHSOCheckBox.checked = true;
        Option1var = "OFF";
        self.update();
    }
}; // Fin del checkbox




let self = this; // Guardar referencia al contexto principal

// Añadir el nuevo Checkbox para StarXterminator
this.starXterminatorCheckBox = new CheckBox(this);
this.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
this.starXterminatorCheckBox.checked = true;  // Predeterminado activado

// Añadir el nuevo Checkbox para StarNet2
this.starNetCheckBox = new CheckBox(this);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;  // Predeterminado desactivado

//Opciones del checkbox de starless
this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           OptionVarStars = "ON";
           console.noteln("Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = true;
           self.starNetCheckBox.enabled = true;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           console.noteln("Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = true;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "ON";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           OptionstarNet = "OFF";
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           console.noteln("Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };
//


// Variable para almacenar el método seleccionado
let starRemovalMethodLabel = "Star Removal by StarXterminator";  // Predeterminado
OptionStarXterminator = "ON";
OptionstarNet = "OFF";


// Evento onClick para gestionar el cambio entre StarXterminator y StarNet2
this.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarNet2 cuando se selecciona StarXterminator
        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";
        OptionstarNet = "OFF";

        console.writeln("Fast Process !!!");
    } else {
        // Si se desactiva StarXterminator, activar StarNet2 por defecto
        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        OptionstarNet = "ON";

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};

// Evento onClick para gestionar el cambio entre StarNet2 y StarXterminator
this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarXterminator cuando se selecciona StarNet2
        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        OptionstarNet = "ON";

        console.writeln("Slow Process !!!");
    } else {
        // Si se desactiva StarNet2, activar StarXterminator por defecto
        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";
        OptionstarNet = "OFF";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};



   // Añadir el nuevo Checkbox para BlurXterminator
    this.blurXterminatorCheckBox = new CheckBox(this);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;  // Predeterminado activado

    // Añadir el nuevo Checkbox para Highpass
    this.highPassCheckBox = new CheckBox(this);
    this.highPassCheckBox.text = "Sharpen by High pass filter";
    this.highPassCheckBox.checked = false;  // Predeterminado activado


    this.blurXterminatorCheckBox.onClick = function () {
        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {
        // Si StarXterminator está apagado, cambiar el texto para usar StarNet2
        self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
        console.noteln("Sharpen by BlurXTerminator 'OFF'. High pass filter enabled.");

           } else {
        // Si StarXterminator está encendido, usar StarXterminator
         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
        console.noteln("Sharpen by BlurXTerminator 'ON'. High pass filter disabled.");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";


         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("Sharpen by BlurXTerminator 'ON'. High pass filter disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("Sharpen by BlurXTerminator 'OFF'. High pass filter enabled.");
       }
      };




   // Añadir checkboxes a la segunda columna

    column2Sizer.add(this.OptionVarStarsCheckBox);
    column2Sizer.add(this.starXterminatorCheckBox);
    column2Sizer.add(this.starNetCheckBox);
    column2Sizer.add(this.starsHSOCheckBox);
    column2Sizer.add(this.starsRGBCheckBox);
    column2Sizer.add(this.blurXterminatorCheckBox);
    column2Sizer.add(this.highPassCheckBox);


    // Añadir las dos columnas al `HorizontalSizer` del `optionsGroupBox`
    this.optionsGroupBox.sizer.add(column1Sizer);
    this.optionsGroupBox.sizer.addSpacing(20);
    this.optionsGroupBox.sizer.add(column2Sizer);


    // --- Option page ---
    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;


//-----------------------------------------------------------------------------
//Pestaña Tools----------------------------------------------------------------
//-----------------------------------------------------------------------------

// Actualiza el listado de ventanas
        this.optionsPage.onShow = function() {
        updateImageSelector();
}

      // Crear ScrollControl para visualizar la imagen
      function ScrollControl(parent) {
      this.__base__ = ScrollBox;
      this.__base__(parent);

      this.displayImage = null;
      this.viewport.cursor = new Cursor(StdCursor_OpenHand);

          // Función para actualizar la imagen mostrada
         this.doUpdateImage = function(image) {
         this.displayImage = image;
         this.viewport.update();
      };

        this.viewport.onPaint = function(x0, y0, x1, y1) { //Dejar en negro el visor
           var g = new Graphics(this);
           var image = this.parent.displayImage;
           if (image) {
               g.drawBitmap(x0, y0, image.render());
           } else {
               g.fillRect(x0, y0, x1, y1, new Brush(0xff000000)); // Fondo negro si no hay imagen
          }
          g.end();
          };
      }

   ScrollControl.prototype = new ScrollBox;



   // Creamos un espacio para visualizar la imagen usando ScrollControl
   let imageViewerControl = new ScrollControl(this.optionsPage);
   imageViewerControl.setFixedHeight(WindowsOsx3);  // Espacio reservado para la visualización de la imagen
   imageViewerControl.setScaledMinWidth(400);  // Tamaño mínimo escalado

   this.optionsPage.sizer.add(imageViewerControl);  // Añadir el control de imagen al sizer de la página



      // Crear el GroupBox para "Pro Options"
      let ColorGroupBox = new GroupBox(this.optionsPage);
      //ColorGroupBox.title = "Advanced Options II:";
      ColorGroupBox.sizer = new VerticalSizer;
      ColorGroupBox.sizer.margin = 6;
      ColorGroupBox.sizer.spacing = 4;

      // Crear el Label para seleccionar una imagen
      let ColorLabel = new Label(ColorGroupBox);
      ColorLabel.text = "Select a Non Linear image and Apply adjustment:";
      ColorLabel.textAlignment = TextAlign_Left;
      ColorGroupBox.sizer.add(ColorLabel);

      // Visor de imagen principal
      let imageSelector = new ComboBox(ColorGroupBox);
      imageSelector.editEnabled = false;  // Desactivar la edición manual
      imageSelector.setFixedHeight(WindowsOsx2);
      ColorGroupBox.sizer.add(imageSelector);

      ColorGroupBox.sizer.addStretch();

      // Función para cargar las ventanas activas en el ComboBox
      function updateImageSelector() {
          imageSelector.clear();  // Limpiar el ComboBox

          imageSelector.addItem("<Select an Image>");  // Añadir la opción predeterminada

          let windows = ImageWindow.windows;
          for (let i = 0; i < windows.length; i++) {
              imageSelector.addItem(windows[i].mainView.id);  // Añadir las ventanas activas
          }
      }



      // Asignar la función para que se ejecute al hacer clic en el ComboBox
      imageSelector.onMousePress = function() {
          updateImageSelector();  // Actualizar las ventanas activas al hacer clic
      };


      // Función para actualizar OptionMergePro1 cuando se selecciona una ventana
      imageSelector.onItemSelected = function(index) {
          if (index === 0) {
              // Si se selecciona "<Select an Image>", no hacer nada
              console.warningln("Please select a valid image.");
              return;
          }

          if (index > 0) {
              OptionMergePro1 = imageSelector.itemText(index);  // Asignar el nombre de la ventana seleccionada a OptionMergePro1
              console.writeln("Image set to: " + OptionMergePro1);  // Mostrar en consola
              dialog.spaceLabel2.textColor = 0xFF0000; // Set label text color to red
              dialog.spaceLabel2.text = "Loading...";

              // Mostrar la imagen seleccionada en el visor
                MiraPreview(imageViewerControl, imageSelector);

                  // Obtener el ID de la ventana seleccionada y buscar la ventana
                  let selectedImageId = imageSelector.itemText(index);
                  let previewWindow = ImageWindow.windowById(selectedImageId);

        if (previewWindow && !previewWindow.isNull) {
            // Traer la ventana seleccionada al frente
            previewWindow.bringToFront();
            console.writeln("Window '" + selectedImageId + "' brought to front.");

            // Aplicar reducción de saturación a la imagen en el visor
            MiraReduceSaturationInViewer(imageViewerControl, previewWindow);

            dialog.spaceLabel2.textColor = 0x000000; // Set label text color to black
            dialog.spaceLabel2.text = "Image Loaded.";
            console.noteln("Image Loaded.");
        } else {
            console.criticalln("Error: No valid image window found.");
            dialog.spaceLabel2.text = "Failed to load image.";
        }

        // Habilitar el botón de previsualización si las condiciones se cumplen


        if (VarPGlobal2 !== VarPGlobal3) {
            ColorPreviewButton.enabled = true;


            let windowId = previewWindow.mainView.id;  // Assign the window ID
            MiraBringToFrontAndPosition(windowId); // Bring to front and position
        }
    }
};
      // Ejecutar la función para cargar las ventanas activas la primera vez
      updateImageSelector();


      // Añadir el GroupBox a la pestaña
      this.optionsPage.sizer.add(ColorGroupBox);


      // Añadir el GroupBox con RadioButtons para las opciones de capa
      let layerSelectionGroupBox = new GroupBox(ColorGroupBox);
      layerSelectionGroupBox.title = "Select a New Adjustment:";
      layerSelectionGroupBox.sizer = new VerticalSizer;
      layerSelectionGroupBox.sizer.margin = 6;
      layerSelectionGroupBox.sizer.spacing = 4;

      // Create HorizontalSizer to split into two columns
      let adjustmentColumnsSizer = new HorizontalSizer;
      adjustmentColumnsSizer.spacing = 20;  // Space between the two columns

      // Left Column for the first three options
      let leftColumnSizer = new VerticalSizer;
      leftColumnSizer.spacing = 6;

      // Right Column for the other three options
      let rightColumnSizer = new VerticalSizer;
      rightColumnSizer.spacing = 6;

      // Add options to left column

      let HDRLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      HDRLayerRadioButton.text = "HDR - Recover Highlights";
      HDRLayerRadioButton.checked = true;  // No seleccionado por defecto
      leftColumnSizer.add(HDRLayerRadioButton);

      let BlackLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      BlackLayerRadioButton.text = "Image Optimizer";
      BlackLayerRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(BlackLayerRadioButton);

      let textureLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      textureLayerRadioButton.text = "Detail Optimizer";
      textureLayerRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(textureLayerRadioButton);

      let backgroundLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      backgroundLayerRadioButton.text = "Background Optimizer";
      backgroundLayerRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(backgroundLayerRadioButton);

      let GraXXXPertLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      GraXXXPertLayerRadioButton.text = "Background Extraction (GraXpert)";
      GraXXXPertLayerRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(GraXXXPertLayerRadioButton);

      let BlurXXXTRadioButton = new RadioButton(layerSelectionGroupBox);
      BlurXXXTRadioButton.text = "BlurXTerminator";
      BlurXXXTRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(BlurXXXTRadioButton);

      let TresRadioButton = new RadioButton(layerSelectionGroupBox);
      TresRadioButton.text = "300ppi Resolution";
      TresRadioButton.checked = false;  // No seleccionado por defecto
      leftColumnSizer.add(TresRadioButton);

      let GlowLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      GlowLayerRadioButton.text = "Add Glow effect";
      GlowLayerRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(GlowLayerRadioButton);

      let VignetedLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      VignetedLayerRadioButton.text = "Add Vignette";
      VignetedLayerRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(VignetedLayerRadioButton);

      let sharpImageRadioButton = new RadioButton(layerSelectionGroupBox);
      sharpImageRadioButton.text = "Sharpen Image";
      sharpImageRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(sharpImageRadioButton);

      let BlurXXNoiseLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      BlurXXNoiseLayerRadioButton.text = "Remove Noise (NoiseXTerminator)";
      BlurXXNoiseLayerRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(BlurXXNoiseLayerRadioButton);

      let GraXXNoiseLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      GraXXNoiseLayerRadioButton.text = "Remove Noise (GraXpert Denoising)";
      GraXXNoiseLayerRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(GraXXNoiseLayerRadioButton);

      let StarXXXTLayerRadioButton = new RadioButton(layerSelectionGroupBox);
      StarXXXTLayerRadioButton.text = "StarXTerminator";
      StarXXXTLayerRadioButton.checked = false;  // No seleccionado por defecto
      rightColumnSizer.add(StarXXXTLayerRadioButton);

      // Add the two columns to the main sizer
      adjustmentColumnsSizer.add(leftColumnSizer);
      adjustmentColumnsSizer.add(rightColumnSizer);

      // Add the columns to the group box sizer
      layerSelectionGroupBox.sizer.add(adjustmentColumnsSizer);


    OptionSharpenNonstellar = 0.80; //se inicializa para HDR por primera vez


    // Function to detect which RadioButton is selected and update OptionProOne
    function selectedLayer() {
    if (textureLayerRadioButton.checked) {
        OptionProOne = "Detail";  // Update the global variable
          console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.60);       // Valor inicial
          OptionSharpenNonstellar = 0.60;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

    } else if (HDRLayerRadioButton.checked) {
        OptionProOne = "HDR";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.80);       // Valor inicial
          OptionSharpenNonstellar = 0.80;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

    } else if (backgroundLayerRadioButton.checked) {
        OptionProOne = "Background";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.60);       // Valor inicial
          OptionSharpenNonstellar = 0.60;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

   } else if (VignetedLayerRadioButton.checked) {
        OptionProOne = "Vignette";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.40);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (GlowLayerRadioButton.checked) {
        OptionProOne = "Glow Effect";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.10);       // Valor inicial
          OptionSharpenNonstellar = 0.10;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (BlackLayerRadioButton.checked) {
        OptionProOne = "Optimizer Areas";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.20);       // Valor inicial
          OptionSharpenNonstellar = 0.20;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

      } else if (sharpImageRadioButton.checked) {
        OptionProOne = "Sharpen Image";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.30);       // Valor inicial
          OptionSharpenNonstellar = 0.30;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (BlurXXNoiseLayerRadioButton.checked) {
        OptionProOne = "Remove Noise (NoiseXterminator)";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.40);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

     } else if (GraXXNoiseLayerRadioButton.checked) {
        OptionProOne = "Remove Noise (GraXpert)";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(1.00);       // Valor inicial
          OptionSharpenNonstellar = 1.00;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

      } else if (StarXXXTLayerRadioButton.checked) {
        OptionProOne = "StarXTerminator";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(1.00);       // Valor inicial
          OptionSharpenNonstellar = 1.00;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);

      } else if (BlurXXXTRadioButton.checked) {
        OptionProOne = "BlurXTerminator";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.70);       // Valor inicial
          OptionSharpenNonstellar = 0.70;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);


       } else if (TresRadioButton.checked) {
        OptionProOne = "300ppi Resolution";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(1.00);       // Valor inicial
          OptionSharpenNonstellar = 1.00;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);


      } else if (GraXXXPertLayerRadioButton.checked) {
        OptionProOne = "Background Extraction (GraXpert)";  // Update the global variable
        console.writeln("Adjustment Process set to : " + OptionProOne);
          dialog.ProOptionEdit.setValue(0.4);       // Valor inicial
          OptionSharpenNonstellar = 0.40;
          console.writeln("Adjustment presence: " + OptionSharpenNonstellar);
    }
    }

      // Bind radio buttons to update OptionProOne on click
      textureLayerRadioButton.onClick = function() { selectedLayer(); };
      HDRLayerRadioButton.onClick = function() { selectedLayer(); };
      backgroundLayerRadioButton.onClick = function() { selectedLayer(); };
      VignetedLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      GlowLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      BlackLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      sharpImageRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      BlurXXNoiseLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      GraXXNoiseLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      GraXXXPertLayerRadioButton.onClick = function() { selectedLayer(); }; // Añadir el evento onClick
      BlurXXXTRadioButton.onClick = function() { selectedLayer(); };
      TresRadioButton.onClick = function() { selectedLayer(); };
      StarXXXTLayerRadioButton.onClick = function() { selectedLayer(); };

      // Añadir el GroupBox de RadioButtons al GroupBox principal (ColorGroupBox)
      ColorGroupBox.sizer.add(layerSelectionGroupBox);
      ColorGroupBox.sizer.addStretch();



      // Crear el campo numérico StarsValor debajo de los RadioButtons
      let dialog = this;  // Store reference to `this`
      this.ProOptionEdit = new NumericControl(this);
      this.ProOptionEdit.setValue(NewProOptionValue);  // Valor inicial
      this.ProOptionEdit.label.text = "Adjustment value:";
      this.ProOptionEdit.setRange(0, 1);  // Rango
      this.ProOptionEdit.setPrecision(2);  // Unidades
      this.ProOptionEdit.setValue(OptionSharpenNonstellar);       // Valor inicial



      // Evento para manejar la validación del valor y actualizar NewGreenValue
      let OptionAdjvalue = OptionSharpenNonstellar;

      this.ProOptionEdit.onValueUpdated = function (OptionAdjvalue) {
          if (OptionAdjvalue < 0 || OptionAdjvalue > 1) {
              console.criticalln("Error: Adjustment Value must be between 0.0 and 1.0");
          } else {
              OptionSharpenNonstellar = OptionAdjvalue;  // Actualizar la variable global con el nuevo valor
              //console.writeln("Adjustment value set to : " + OptionSharpenNonstellar);
          }
      };

      // Añadir el campo numérico al GroupBox
      ColorGroupBox.sizer.add(this.ProOptionEdit);
      ColorGroupBox.sizer.addStretch();

      // Crear el Label para espacio
      // Asegurarse de que `dialog` esté definido correctamente
      let dialog = this; // Si `this` es tu objeto de diálogo
      //Label para working process...
      dialog.spaceLabel2 = new Label(ColorGroupBox);
      dialog.spaceLabel2.text = "";
      dialog.spaceLabel2.textAlignment = TextAlign_Left;
      ColorGroupBox.sizer.add(dialog.spaceLabel2);

      // Crear un HorizontalSizer para alinear los botones en una misma línea
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones

      // Crear el botón "APPLY" de Texture
      let ColorPreviewButton = new PushButton(ColorGroupBox);
      ColorPreviewButton.text = "Apply";
      ColorPreviewButton.icon = this.scaledResource( ":/icons/play.png" );
      ColorPreviewButton.setFixedWidth(150);
      ColorPreviewButton.enabled = false;
      ColorPreviewButton.toolTip ="Select adjustments and clic Apply";


      ColorPreviewButton.onClick = function() {

        // Verificar si la opción seleccionada es "<Select an Image>" o si MergeLayerRadioButton.checked es true
      if (OptionMergePro1 === "<Select an Image>") {
      let errorMsgBox = new MessageBox("Please select a valid image in Image A or Merge.", "Error", StdIcon_Error, StdButton_Ok);
      errorMsgBox.execute();
      return;  // Salir de la función si no se ha seleccionado una imagen válida o si la condición de MergeLayerRadioButton es true
       }

            // Preguntar al usuario si desea aplicar el proceso
         let msgBox = new MessageBox("Do you want to continue with process??", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
         let response = msgBox.execute();

         if (response === StdButton_Yes) {


                ColorPreviewButton.enabled = false;
                dialog.ToolsXOkButton.enabled = false;

                  if (OptionFlag === "0") {
                     OptionFlag ="1";
                    //Borra Previos
                    MiraBorrarPrev0();
                  }

                 let activeWindow = ImageWindow.activeWindow;
                 let selectedWindow = activeWindow;

                 //actualiza el paso por la función
                 OptionFlag2 = "0";

                 saveCurrentState(selectedWindow);  // Guardar el estado antes de aplicar cualquier proceso


                 MiraProcesosPro(imageViewerControl, imageSelector, OptionSharpenNonstellar, OptionProOne, OptionMergePro1, OptionMergePro2);


                  dialog.spaceLabel2.textColor = 0x0000FF; // Cambiar el color del texto de la etiqueta a negro
                  dialog.spaceLabel2.text = "✅"+ " Apply done !!!";
                  console.noteln("\n✅"+ " Apply done !!!");


                  ColorPreviewButton.enabled = true;
                  dialog.ToolsundoButton.enabled = true;
                  dialog.ToolsXOkButton.enabled = true;




             } else {
        // Si el usuario selecciona "No", cancelar el proceso
        console.noteln("Process canceled by user.");
         }

      };//fin botón Appl



       //Botones Und Redo y OK
        let dialog = this;

        dialog.ToolsundoButton = new PushButton();
        dialog.ToolsundoButton.text = "Undo"; //Undo de Tools
        dialog.ToolsundoButton.toolTip = "Restore the last image state";
        dialog.ToolsundoButton.enabled = false;
        dialog.ToolsundoButton.icon = dialog.scaledResource (":/icons/undo.png");
        dialog.ToolsundoButton.setFixedWidth(100);

        dialog.ToolsundoButton.onClick = function () {
           console.writeln("\nRestore the last image state.");
         let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
         if (selectedWindow && !selectedWindow.isNull) {
              dialog.ToolsundoButton.enabled = false; //Undo de Tools
              let imageViewerControl2 = imageViewerControl; //Undo de Tools
              undoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de undo
              dialog.ToolsXstarredoButton.enabled = true;
              //Undo
              dialog.spaceLabel2.text = "Undo done...";
         } else {
             console.warningln("No active window to undo.");
         }
         };


       dialog.ToolsXstarredoButton = new PushButton(this);
       dialog.ToolsXstarredoButton.text = "Redo";
       dialog.ToolsXstarredoButton.enabled = false;
       dialog.ToolsXstarredoButton.icon = dialog.scaledResource(":/icons/redo.png");
       dialog.ToolsXstarredoButton.setFixedWidth(80);

       dialog.ToolsXstarredoButton.onClick = function () {
          dialog.ToolsundoButton.enabled = true;
          dialog.ToolsXstarredoButton.enabled = false;
          console.writeln("\nRedo the last undone action.");
          let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
          if (selectedWindow && !selectedWindow.isNull) {
              let imageViewerControl2 = imageViewerControl; //Redo de Tools
              redoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de redo
              //Reddo
              dialog.spaceLabel2.text = "Redo done...";
          } else {
              console.warningln("No active window to redo.");
        }
        };


       dialog.ToolsXOkButton = new PushButton(this);
       dialog.ToolsXOkButton.text = "OK";
       dialog.ToolsXOkButton.icon = dialog.scaledResource( ":/icons/ok.png" );
       dialog.ToolsXOkButton.enabled = false;
       dialog.ToolsXOkButton.setFixedWidth(80);



       // Acción del botón OK
       dialog.ToolsXOkButton.onClick = function () {

            //Graba con el nombre.
              // Preguntar si desea aplicar los cambios en una nueva imagen
            let msgBox = new MessageBox("Do you want to apply changes in a new image?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
            let response = msgBox.execute();

            // Si la respuesta es "Sí", ejecutar MiraOk
            if (response === StdButton_Yes) {

             MiraResolFinal();
             MiraOk3(); // Grabar nombre


             //resetea
             OptionFlag ="0";
             OptionFlag2="0";

             imageSelector22.currentItem = 0;
             dialog.ToolsXOkButton.enabled = false;
             dialog.ToolsXstarredoButton.enabled = false;
             dialog.ToolsundoButton.enabled = false;
             ColorPreviewButton.enabled = false;

             updateImageSelector();

             //Borra máscara.
             // Obtener todas las ventanas abiertas
               let allWindows = ImageWindow.windows;

               if (!allWindows || allWindows.length === 0) {
                console.writeln("No active windows found.");
               } else {
                   let deletedCount = 0;

                   // Iterar sobre todas las ventanas
                   for (let i = 0; i < allWindows.length; i++) {
                    let window = allWindows[i];
                       let windowId = window.mainView.id;

                    // Verificar si el nombre termina en "luminosity_detail"
                    if (windowId.endsWith("luminosity_detail")) {
                     console.noteln("Deleting window: " + windowId);
                     window.forceClose();
                     deletedCount++;
                     }

                      // Verificar si el nombre termina en "luminosity_detail"
                     if (windowId.endsWith("luminosity_background")) {
                     console.noteln("Deleting window: " + windowId);
                     window.forceClose();
                     deletedCount++;
                     }


                   }


                  }


            }


       }


      //añadir botones
           buttonSizer.add(ColorPreviewButton);
           buttonSizer.add(dialog.ToolsundoButton);
           buttonSizer.add(dialog.ToolsXstarredoButton);
           buttonSizer.add(dialog.ToolsXOkButton);
           buttonSizer.addStretch();  //  botón a la derecha


    let workingLabel = new Label(ColorGroupBox);
    workingLabel.text = "";
    workingLabel.textAlignment = TextAlign_Right;
    buttonSizer.add(workingLabel);
    // Crear un sizer horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Añadir algo de espacio entre el botón y la etiqueta


    horizontalSizer.add(buttonSizer);
    horizontalSizer.addStretch();
    ColorGroupBox.sizer.add(horizontalSizer);

    this.optionsPage.sizer.add(ColorGroupBox);



// --- NEW Tab Page 2--------------------------COLOR
    this.optionsPage2 = new Control(this);
    this.optionsPage2.sizer = new VerticalSizer;
    this.optionsPage2.sizer.margin = 6;
    this.optionsPage2.sizer.spacing = 9;

// Actualiza el listado de ventanas
        this.optionsPage2.onShow = function() {
        updateImageSelector22();
};



   ScrollControl.prototype = new ScrollBox;

   // Creamos un espacio para visualizar la imagen usando ScrollControl
   let imageViewerControl2 = new ScrollControl(this.optionsPage2);

   imageViewerControl2.setFixedHeight(WindowsOsx3);  // Espacio reservado para la visualización de la imagen
   imageViewerControl2.setScaledMinWidth(400);  // Tamaño mínimo escalado

   this.optionsPage2.sizer.add(imageViewerControl2);  // Añadir el control de imagen al sizer de la página


    let ColorGroupBox2 = new GroupBox(this.optionsPage2);
    //ColorGroupBox2.title = "Advanced Options I:";
    ColorGroupBox2.sizer = new VerticalSizer;
    ColorGroupBox2.sizer.margin = 6;
    ColorGroupBox2.sizer.spacing = 4;

    let ColorLabel2 = new Label(ColorGroupBox2);
    ColorLabel2.text = "Select a Non Linear image and press Refresh to Apply adjustment.";
    ColorLabel2.textAlignment = TextAlign_Left;
    ColorGroupBox2.sizer.add(ColorLabel2);

   //------------------------------------------------------------Visor de HSL
   let imageSelector22 = new ComboBox(ColorGroupBox2);
   imageSelector22.editEnabled = false;
   imageSelector22.visibleItemCount = 10;  // Set the number of visible items to 10
   imageSelector22.setFixedHeight(WindowsOsx2);
   ColorGroupBox2.sizer.add(imageSelector22);

   ColorGroupBox2.sizer.addStretch();

    function updateImageSelector22() {
    imageSelector22.clear();  // Limpiar el ComboBox

    imageSelector22.addItem("<Select an Image>");  // Añadir la opción predeterminada

    let windows = ImageWindow.windows;
    for (let i = 0; i < windows.length; i++) {
        imageSelector22.addItem(windows[i].mainView.id);  // Añadir las ventanas activas
    }
    imageSelector22.visibleItemCount = 10;  // Set the number of visible items to 10
    imageSelector22.update(); // Forzar actualización visual del ComboBox
   }

   // Ejecutar la función para cargar las ventanas activas la primera vez
   updateImageSelector22();


   // Asignar la función para que se ejecute al hacer clic en el ComboBox
      imageSelector22.onMousePress = function() {
          updateImageSelector22();  // Actualizar las ventanas activas al hacer clic
      };

   // Actualizar OptionMergePro0 con el valor seleccionado
   imageSelector22.onItemSelected = function (index) {
    let selectedOption = imageSelector22.itemText(index);

    // Si selecciona "<Select an Image>", OptionMergePro0 debe quedar sin asignar o mostrar un mensaje.
    if (selectedOption === "<Select an Image>") {
        OptionMergePro0 = "<Select an Image>";
        console.warningln("Please select a valid image.");
    } else {
        // Actualizar OptionMergePro0 con la opción seleccionada
        OptionMergePro0 = selectedOption;

        // ejecuta Borra Start_preview

     spaceLabel22.textColor = 0xFF0000; // Set label text color to red
     spaceLabel22.text = "Loading...";

    MiraBorrarPrev0();

    MiraDevelop(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar);

   // Bajar Saturación en el visor
   // Obtener la ventana activa por su nombre

      let previewWindow = ImageWindow.windowById("Start_preview");

      MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);

      let windowId = previewWindow.mainView.id;  // Asignas el ID de la ventana
      MiraBringToFrontAndPosition(windowId);  // Llamada a la función pasando el ID

    // Bajar Saturación en el visor

     spaceLabel22.textColor = 0x000000; // Set label text color to red
     spaceLabel22.text = "Image Loaded.";

    console.writeln("");
    console.noteln("✅" +" Refresh done !!!");

    //activa opciones

    maskOptionsComboBox.enabled = true;
    blurOptionsComboBox.enabled = true;
    RGBOptionsComboBox.enabled = true;


        if  (VarPGlobal2 !== VarPGlobal3){
    ColorRunButton2.enabled = true;
    ColorRunButton222.enabled = true;
    ColorRunButtonGreen222.enabled = true;
        }

    }
};

  // Ejecutar la función para cargar las ventanas nuevas
   updateImageSelector22();


    let buttonSizer2 = new HorizontalSizer;
    buttonSizer2.spacing = 6;

    // Declare maskOptionsComboBox globally if it's part of the UI
    let maskOptionsComboBox;



      // Initialize the ComboBox with values
      maskOptionsComboBox = new ComboBox(this);
      maskOptionsComboBox.addItem("None");
      maskOptionsComboBox.addItem("Light Mask");
      maskOptionsComboBox.addItem("Shadow Mask");
      maskOptionsComboBox.addItem("Red Mask");
      maskOptionsComboBox.addItem("Yellow Mask");
      maskOptionsComboBox.addItem("Green Mask");
      maskOptionsComboBox.addItem("Cyan Mask");
      maskOptionsComboBox.addItem("Blue Mask");
      maskOptionsComboBox.addItem("Magenta Mask");
      maskOptionsComboBox.setFixedHeight(WindowsOsx2);


      // Event handler when a new option is selected
      maskOptionsComboBox.onItemSelected = function (index) {
          let selectedMaskOption = maskOptionsComboBox.itemText(index);

          // If no valid option is selected, assume "None"
          if (selectedMaskOption === "None") {
              OptionTypeMaskvar = selectedMaskOption;
              console.writeln("No mask selected: " + OptionTypeMaskvar);
          } else {
        // Update the selected mask option
        OptionTypeMaskvar = selectedMaskOption;
        console.writeln("Selected mask option: " + OptionTypeMaskvar);

        // Restablecer el valor predeterminado de OptionColorMaskLumvar
        OptionColorMaskLumvar = 0;
        OptionColorMaskSatvar = 0;
        OptionColorMaskHuevar = 0;
        lumSlider.value = 10;  // Colocar el slider en el centro (10 es el valor neutro)
        satSlider.value = 10;
        hueSlider.value = 10;
        }
          };

      let blurOptionsComboBox;

      // Initialize the ComboBox with values
      blurOptionsComboBox = new ComboBox(this);
      blurOptionsComboBox.addItem("None");
      blurOptionsComboBox.addItem("Soft Blur");
      blurOptionsComboBox.addItem("Hard Blur");
      blurOptionsComboBox.setFixedHeight(WindowsOsx2);



      // Event handler when a new option is selected
          blurOptionsComboBox.onItemSelected = function (index) {
          let selectedblurOption = blurOptionsComboBox.itemText(index);

          // If no valid option is selected, assume "None"
          if (selectedblurOption === "None") {
             OptionBlurMaskvar = selectedblurOption;
              console.writeln("No Blurring selected: " + OptionBlurMaskvar);
          } else {
              OptionBlurMaskvar = selectedblurOption;
              console.writeln("Selected Blurring option: " + OptionBlurMaskvar);
              checkLuminosityMask();
              //hacer el check de None en Mask
          }
      };

     // Function to check and enforce the mask option when blur is "Soft" or "Hard"
      function checkLuminosityMask() {
          let selectedMaskOption = maskOptionsComboBox.itemText(maskOptionsComboBox.currentItem);
          if (selectedMaskOption == "None") {
              console.warningln("Error: Luminosity mask cannot be 'None' when blur is 'Soft' or 'Hard'");
          // Automatically select the first mask option (assuming it's index 1)
        maskOptionsComboBox.currentItem = 1;  // Use currentItem instead of setCurrentItem
        OptionTypeMaskvar = maskOptionsComboBox.itemText(1);  // Update the variable
        console.writeln("Selected mask option: " + OptionTypeMaskvar );
          }
         }


let RGBOptionsComboBox;

// Initialize the ComboBox with values
RGBOptionsComboBox = new ComboBox(this);
RGBOptionsComboBox.addItem("None");
RGBOptionsComboBox.addItem("Red Channel");
RGBOptionsComboBox.addItem("Green Channel");
RGBOptionsComboBox.addItem("Blue Channel");
RGBOptionsComboBox.setFixedHeight(WindowsOsx2);
// Establecer la opción predeterminada como "None"
RGBOptionsComboBox.currentItem = 0;  // Establecer el índice inicial en la primera opción ("None")

// Event handler when a new option is selected
RGBOptionsComboBox.onItemSelected = function (index) {
    let selectedRGBOption = RGBOptionsComboBox.itemText(index);

    // If no valid option is selected, assume "None"
    if (selectedRGBOption === "None") {
        OptionRGBMaskvar = selectedRGBOption;
        console.writeln("Selected: " + OptionRGBMaskvar);
        hueSliderLabel.text = "Channel: None";
        hueSliderLabel.textColor = 0x000000; // Set label text color to black (default)
        hueSlider.enabled = false;
    } else {
        OptionRGBMaskvar = selectedRGBOption;
        console.writeln("Selected RGB option: " + OptionRGBMaskvar);
        dialog.XhueSliderLabel.text = "Channel: " + OptionRGBMaskvar;

        // Set the label color based on the selected channel
        switch (OptionRGBMaskvar) {
            case "Red Channel":
                dialog.XhueSliderLabel.textColor = 0xFF0000; // Set label text color to red
                dialog.XhueSliderLabel.text = "Red Channel (Cyan < - 0 - > Red)";
                hueSlider.enabled = true;
                break;
            case "Green Channel":
                dialog.XhueSliderLabel.textColor = 0x008000; // Set label text color to green
                dialog.XhueSliderLabel.text = "Green Channel (Magenta < - 0 - > Green)";
                hueSlider.enabled = true;
                break;
            case "Blue Channel":
                dialog.XhueSliderLabel.textColor = 0x0000FF; // Set label text color to blue
                dialog.XhueSliderLabel.text = "Blue Channel (Yellow < - 0 - > Blue)";
                hueSlider.enabled = true;
                break;
            default:
                dialog.XhueSliderLabel.textColor = 0x000000; // Set to black as fallback
                hueSlider.enabled = false;  // Disable the slider if no valid option is selected
                break;
        }
    }
};


      // Crear el tercer HorizontalSizer (horizontal3Bar)
      let horizontal8Bar = new HorizontalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;


     // Añadir Label1
     let MaskLabel = new Label;
     MaskLabel.text = "Select Masking options:   ";

     // Añadir Label2
     let blurLabel = new Label;
     blurLabel.text = "Select Blurring options:   ";

     // Añadir Label3
     let rgbLabel = new Label;
     rgbLabel.text = "Select RGB Channel:   ";


      // Crear los RadioButtons para Showmask
      let showMaskRadio = new RadioButton;
      showMaskRadio.text = "Show Mask";
      showMaskRadio.checked = false; // Opción por defecto
      showMaskRadio.enabled = false;
      showMaskRadio.visible = false;
      // Handle the onClick event to set the mask visibility option
         showMaskRadio.onClick = function () {

         //

      let windows = ImageWindow.windows;
      let duplicateImageWindow = null;

       // Buscar la ventana duplicada que termina en "_preview"
       for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.endsWith("_preview")) {
            duplicateImageWindow = windows[i];
            break;
        }
      }

    if (!duplicateImageWindow) {
        console.criticalln("Error: No '_preview' window found to apply mask.");
        return;  // Detener si no se encuentra la ventana
    }

    duplicateImageWindow.bringToFront();  // Llevar la ventana al frente

         //


         if (this.checked) {
             OptionshowMaskvar = "ON";
             console.writeln("Show mask: " + OptionshowMaskvar + " " + OptionTypeMaskvar);
             //
             if (OptionTypeMaskvar !== "None") { //Mirar variable de Showmask
             MiraMaskBYN(duplicateImageWindow, imageViewerControl2);  // Llamar a la nueva función
             } else {
               console.warningln("No Mask Selected to show");
               OptionshowMaskvar = "OFF";
            }
         } else {
             OptionshowMaskvar = "OFF";
             console.writeln("Show mask: " + " " + OptionshowMaskvar);
             //
        // Mostrar la ventana Start_preview
        let startPreviewWindow = ImageWindow.windowById("Start_preview");

        if (startPreviewWindow && !startPreviewWindow.mainView.isNull) {
            // Llevar la ventana al frente
            startPreviewWindow.bringToFront();

            // **Limpiar el visor actual antes de actualizar**
            imageViewerControl2.doUpdateImage(null); // Limpia el visor de imágenes

            // Actualizar el visor de imágenes con la imagen seleccionada
            let imageViewerControl = imageViewerControl2;
            fitImageToWindow(imageViewerControl, startPreviewWindow.mainView.image);
             let previewWindow = ImageWindow.windowById("Start_preview"); //Se actualiza NO saturado
             MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);

            // Mostrar la ventana en el visor de imágenes
            imageViewerControl2.show();
        } else {
            console.criticalln("Error: No 'Start_preview' window found.");
        }
             //
         }
         };



      // Añadir el Label y el RadioButton al leftSizer (a la izquierda)
      horizontal8Bar.add(MaskLabel);
      horizontal8Bar.add(showMaskRadio);


      // Añadir el ComboBox a la derecha
      maskOptionsComboBox.minWidth = 200;
      maskOptionsComboBox.maxWidth = 200;
      maskOptionsComboBox.enabled =false;
      horizontal8Bar.add(maskOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal8Bar);

      // añade aquí el código de None, SoftBlur y hard blue
      let horizontal7Bar = new HorizontalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;

      horizontal7Bar.add(blurLabel);

      // Añadir el ComboBox a la derecha
       blurOptionsComboBox.minWidth = 200;
       blurOptionsComboBox.maxWidth = 200;
       blurOptionsComboBox.enabled =false;
      horizontal7Bar.add(blurOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal7Bar);

     // añade aquí el código de RGB
      let horizontal6Bar = new HorizontalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;

      horizontal6Bar.add(rgbLabel);

      //Añadir el ComboBox a la derecha
      RGBOptionsComboBox.minWidth = 200;
      RGBOptionsComboBox.maxWidth = 200;
      RGBOptionsComboBox.enabled =false;
      horizontal6Bar.add(RGBOptionsComboBox);

      // Añadir el horizontal3Bar al GroupBox
      ColorGroupBox2.sizer.add(horizontal6Bar);

      let vertispace = new VerticalSizer;
      ColorGroupBox2.sizer.margin = 6;
      ColorGroupBox2.sizer.spacing = 4;
      let spaceLabel = new Label;
      ColorGroupBox2.sizer.add(spaceLabel);


/////////////////////////// Doble menú

      // Create HorizontalSizer to split into two columns
      let XadjustmentColumnsSizer = new HorizontalSizer;
      XadjustmentColumnsSizer.spacing = 20;  // Space between the two columns

      // Left Column for the first three options
      let XleftColumnSizer = new VerticalSizer;
      XleftColumnSizer.spacing = 6;

      // Right Column for the other three options
      let XrightColumnSizer = new VerticalSizer;
      XrightColumnSizer.spacing = 6;


      dialog = this;
      dialog.XhueSliderLabel = new Label;
      dialog.XhueSliderLabel.text = "Channel: None";
      XleftColumnSizer.add(dialog.XhueSliderLabel);


      let hueSlider = new Slider;
      hueSlider.setRange(0, 20);
      hueSlider.value = OptionColorMaskHuevar;
      hueSlider.onValueUpdated = function(value) {
          OptionColorMaskHuevar = value - 10;
      };
      hueSlider.enabled = false;
      hueSlider.toolTip ="Select one RGB Channel";
      XleftColumnSizer.add(hueSlider);


      let satSliderLabel = new Label;
      satSliderLabel.text = "Saturation:                          - 0 +";
      XleftColumnSizer.add(satSliderLabel);

      let satSlider = new Slider;
      satSlider.setRange(0, 20);
      satSlider.value = OptionColorMaskSatvar;
      satSlider.onValueUpdated = function(value) {
          OptionColorMaskSatvar = value - 10;
      };

      XleftColumnSizer.add(satSlider);



      let lumSliderLabel = new Label;
      lumSliderLabel.text = "Luminance:                         - 0 +";
      XleftColumnSizer.add(lumSliderLabel);


      let lumSlider = new Slider;
      lumSlider.setRange(0, 20);
      lumSlider.value = OptionColorMaskLumvar;
      lumSlider.onValueUpdated = function(value) {
          OptionColorMaskLumvar = value - 10;
      };
      XleftColumnSizer.add(lumSlider);
//

      let BlackSliderLabel = new Label;
      BlackSliderLabel.text = "Black:                                  - 0 +";
      XrightColumnSizer.add(BlackSliderLabel);


      let BlackSlider = new Slider;
      BlackSlider.setRange(0, 20);
      BlackSlider.value = OptionColorMaskBlackvar;
      BlackSlider.onValueUpdated = function(value) {
         OptionColorMaskBlackvar = value -10;
      };
      XrightColumnSizer.add(BlackSlider);


      let WhiteSliderLabel = new Label;
      WhiteSliderLabel.text = "White:                                 - 0 +";
      XrightColumnSizer.add(WhiteSliderLabel);


      let WhiteSlider = new Slider;
      WhiteSlider.setRange(0, 20);
      WhiteSlider.value = OptionColorMaskWhitevar;
      WhiteSlider.onValueUpdated = function(value) {
         OptionColorMaskWhitevar = value -10;
      };
      XrightColumnSizer.add(WhiteSlider);

      let ContrastSliderLabel = new Label;
      ContrastSliderLabel.text = "Contrast:                             - 0 +";
      XrightColumnSizer.add(ContrastSliderLabel);


      let ContrastSlider = new Slider;
      ContrastSlider.setRange(0, 20);
      ContrastSlider.value = OptionColorMaskContrastvar;
      ContrastSlider.onValueUpdated = function(value) {
         OptionColorMaskContrastvar = value - 10;
      };
      XrightColumnSizer.add(ContrastSlider);


      // Add the two columns to the main sizer
      XadjustmentColumnsSizer.add(XleftColumnSizer);
      XadjustmentColumnsSizer.add(XrightColumnSizer);
      // Add the columns to the group box sizer
      ColorGroupBox2.sizer.add(XadjustmentColumnsSizer);
      ColorGroupBox2.sizer.addStretch();

/////////////////////////////

      // Crear el Label para espacio
      let spaceLabel22 = new Label(ColorGroupBox);
      spaceLabel22.text = "";
      spaceLabel22.textAlignment = TextAlign_Left;
      ColorGroupBox2.sizer.add(spaceLabel22);


      // Crear el CheckBox para Show console
      let showConsoleCheckBox = new CheckBox;
      showConsoleCheckBox.text = "Show console";
      showConsoleCheckBox.checked = true; // Opción por defecto

      let ColorRunButton2 = new PushButton(ColorGroupBox2);
      ColorRunButton2.text = "Refresh";
      ColorRunButton2.icon = this.scaledResource( ":/icons/refresh.png" );
      ColorRunButton2.setFixedWidth(100);

      let ColorRunButton222 = new PushButton(ColorGroupBox2);
      ColorRunButton222.text = "Reset";
      ColorRunButton222.icon = this.scaledResource( ":/icons/debug-restart.png" );
      ColorRunButton222.setFixedWidth(100);

      ColorRunButton222.onClick = function() {


        // Reset ComboBoxes
        blurOptionsComboBox.currentItem = 0;
        RGBOptionsComboBox.currentItem = 0;
        maskOptionsComboBox.currentItem = 0;

        // Reset global variables for RGB, Mask, Blur, and Color options
        let selectedblurOption = "None";
        let selectedRGBOption = "None";
        let selectedMaskOption = "None";
        OptionRGBMaskvar = "None";
        OptionTypeMaskvar ="None";
        OptionBlurMaskvar ="None";

        // Reset text and color for hueSlider label
        dialog.XhueSliderLabel.text = "Channel: None";
        dialog.XhueSliderLabel.textColor = 0x000000;  // Default color
        hueSlider.enabled = false;

        // Reset values of sliders and update GlobalState accordingly
        OptionColorMaskLumvar = 10;
        OptionColorMaskSatvar = 10;
        OptionColorMaskHuevar = 10;
        OptionColorMaskBlackvar = 10;
        OptionColorMaskWhitevar = 10;
        OptionColorMaskContrastvar = 10;

        lumSlider.value = 10;  // Neutral value in the middle
        satSlider.value = 10;
        hueSlider.value = 10;
        BlackSlider.value = 10;
        WhiteSlider.value = 10;
        ContrastSlider.value = 10;

        //Borrar máscaras
        // Buscar y eliminar cualquier ventana cuyo nombre termine en "_mask_L"
         let windows = ImageWindow.windows;

         // Iterar sobre las ventanas para encontrar aquellas cuyo ID termine en "_mask_L"
         for (let i = 0; i < windows.length; i++) {
          let windowId = windows[i].mainView.id;

          if (windowId.endsWith("_mask_L")) {  // Verificar si el ID termina en "_mask_L"
              console.writeln("Found and deleting mask window: " + windowId);
              windows[i].forceClose();  // Cerrar la ventana encontrada
          }
         }

        console.writeln("⚙️"+" Reset sliders");

       //

    }

    let ColorRunButtonGreen222 = new PushButton(ColorGroupBox2);
    ColorRunButtonGreen222.text = "Green";
    ColorRunButtonGreen222.icon = this.scaledResource( ":/icons/delete.png" );
    ColorRunButtonGreen222.setFixedWidth(100);

      ColorRunButtonGreen222.onClick = function() {

     spaceLabel22.textColor = 0xFF0000; // Set label text color to red
     spaceLabel22.text = "Loading...";

      let activeWindow = ImageWindow.activeWindow;
      let selectedWindow = activeWindow;
      saveCurrentState(selectedWindow);  // Guardar el estado antes de aplicar cualquier proceso

      NewGreenValue = 1;
      MiraGreen2(NewGreenValue); //si cambiamos el nombre de la función hay que mirar todas las llamadas...

        // Actualizar la imagen en el visor
        let previewWindow = ImageWindow.windowById("Start_preview");
        if (!previewWindow || !previewWindow.mainView || previewWindow.mainView.isNull) {
          console.criticalln("Error: 'Start_preview' window not found or invalid.");
          return;
        }


         let previewWindow = ImageWindow.windowById("Start_preview"); //Se actualiza NO saturado
         MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);

         let windowId = previewWindow.mainView.id;  // Asignas el ID de la ventana
         MiraBringToFrontAndPosition(windowId);  // Llamada a la función pasando el ID

      console.writeln("");
      console.noteln("✅"+ " Refresh done !!!");

      spaceLabel22.textColor = 0x0000FF; // Set label text color to blue
      spaceLabel22.text = "✅"+" Refresh done. Clic OK to save image.";
      self.ColorRunButton3.enabled= true;
      dialog.undoButton.enabled = true;
      }

// Capturar el contexto de `this`
let self = this;

    ColorRunButton2.onClick = function() {

     spaceLabel22.foregroundColor = 0xFF0000;
     spaceLabel22.text = "Loading...";
     OptionshowMaskvar = "OFF";
     showMaskRadio.checked = false;

    // Comprobar si las selecciones de máscara o desenfoque han cambiado
    if (previousMaskType !== OptionTypeMaskvar || previousBlurOption !== OptionBlurMaskvar) {
        console.writeln("New selection detected. Clearing intermediate windows...");
        MiraBorrarPrev();  // Solo borrar ventanas si las selecciones han cambiado
    } else {
        console.writeln("No new selection. Skipping window clearing.");
    }

    ColorRunButton2.enabled= false;
    ColorRunButton222.enabled= false;
    ColorRunButtonGreen222.enabled= false;
    self.ColorRunButton3.enabled = false;


    let windows = ImageWindow.windows;
    let duplicateImageWindow = null;

    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.endsWith("_preview")) {
            duplicateImageWindow = windows[i];
            break;  // Detener el bucle cuando encontramos la ventana
        }
    }

   if (!duplicateImageWindow) {
    console.criticalln("Error: No '_preview' window found to apply mask.");
    return;  // Detener el proceso si no hay una ventana duplicada
   }

   // Llevar la ventana al frente y guardar el estado actual
      duplicateImageWindow.bringToFront();


      let selectedWindow = duplicateImageWindow;
      saveCurrentState(selectedWindow);  // Guardar el estado antes de aplicar cualquier proceso

      console.writeln("DuplicateImageWindow to id: " + duplicateImageWindow.mainView.id);

      // Aplicar el desarrollo de la imagen

      // Definir GlobalState si no está definido
      if (typeof GlobalState === "undefined") {
          var GlobalState = {};
      }

      let OptionRGBMaskvar = GlobalState.OptionRGBMaskvar;


      MiraDevelop2(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar, duplicateImageWindow);

      // Llevar la ventana al frente nuevamente después de aplicar el desarrollo (si es necesario)
      duplicateImageWindow.bringToFront();



         let previewWindow = ImageWindow.windowById("Start_preview"); //Se actualiza NO saturado
         MiraReduceSaturationInViewer(imageViewerControl2, previewWindow);
         //let previewWindow = newImageWindow;  // Obtén el objeto de la ventana
         let windowId = previewWindow.mainView.id;  // Asignas el ID de la ventana
         MiraBringToFrontAndPosition(windowId);  // Llamada a la función pasando el ID

         showMaskRadio.visible = true;
         showMaskRadio.enabled = true;

         console.writeln("");
         console.noteln("✅" +" Refresh done !!!");

         spaceLabel22.textColor = 0x0000FF; // Set label text color to blue
         spaceLabel22.text = "✅"+" Refresh done. Clic OK to save image.";

         ColorRunButton2.enabled= true;

         ColorRunButton222.enabled= true;
         dialog.undoButton.enabled = true;
         ColorRunButtonGreen222.enabled= true;
         self.ColorRunButton3.enabled = true;



   }

    this.ColorRunButton3 = new PushButton(ColorGroupBox2);
    this.ColorRunButton3.text = "OK";
    this.ColorRunButton3.icon = this.scaledResource( ":/icons/ok.png" );
    this.ColorRunButton3.setFixedWidth(100);

    // Acción del botón OK
    this.ColorRunButton3.onClick = function () {
    // Preguntar si desea aplicar los cambios en una nueva imagen
    let msgBox = new MessageBox("Do you want to apply changes in a new image?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
    let response = msgBox.execute();

    // Si la respuesta es "Sí", ejecutar MiraOk
    if (response === StdButton_Yes) {

        MiraResolFinal();
        MiraOk(OptionNombVar, OptionRemaind); //Grabar nombre

        console.writeln("");
        console.noteln("\n✅"+ " Apply done !!!");
        ColorRunButton2.enabled= false;
        ColorRunButton222.enabled= false;
        ColorRunButtonGreen222.enabled= false;
        self.ColorRunButton3.enabled= false;
        dialog.undoButton.enabled = false;
        dialog.XstarredoButton.enabled = false;
        spaceLabel22.textColor = 0x0000; // Set label text color to blue
        imageSelector22.currentItem = 0;
        spaceLabel22.text = "Image saved !!!";


       // Reset slider and ComboBoxes
        blurOptionsComboBox.currentItem = 0;
        RGBOptionsComboBox.currentItem = 0;
        maskOptionsComboBox.currentItem = 0;


        // Reset global variables for RGB, Mask, Blur, and Color options
        let selectedblurOption = "None";
        let selectedRGBOption = "None";
        let selectedMaskOption = "None";
        OptionRGBMaskvar = "None";
        OptionTypeMaskvar ="None";
        OptionBlurMaskvar ="None";

        // Reset text and color for hueSlider label
        dialog.XhueSliderLabel.text = "Channel: None";
        dialog.XhueSliderLabel.textColor = 0x000000;  // Default color
        hueSlider.enabled = false;

        // Reset values of sliders and update GlobalState accordingly
        OptionColorMaskLumvar = 10;
        OptionColorMaskSatvar = 10;
        OptionColorMaskHuevar = 10;
        OptionColorMaskBlackvar = 10;
        OptionColorMaskWhitevar = 10;
        OptionColorMaskContrastvar = 10;

        lumSlider.value = 10;  // Neutral value in the middle
        satSlider.value = 10;
        hueSlider.value = 10;
        BlackSlider.value = 10;
        WhiteSlider.value = 10;
        ContrastSlider.value = 10;



         //Borra máscaras color y luminosidad
        MiraBorrarPrev();

        console.writeln("⚙️"+" Reset sliders");

    } else {
        console.noteln("Process canceled by user.");
        return;  // Salir si la respuesta es "No"
    }
   };

      // Botón para deshacer (Undo)

   let dialog = this;

   dialog.undoButton = new PushButton();
   dialog.undoButton.text = "Undo";
   dialog.undoButton.toolTip = "Restore the last image state";
   dialog.undoButton.icon = dialog.scaledResource (":/icons/undo.png");
   dialog.undoButton.setFixedWidth(100);
   dialog.undoButton.onClick = function () {
        dialog.undoButton.enabled = false; //Undo de Color
        console.writeln("\nRestore the last image state.");
        let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
        if (selectedWindow && !selectedWindow.isNull) {
        //let imageViewerControl2 = imageViewerControl2; //Undo de Color
        undoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de undo
        dialog.XstarredoButton.enabled = true;
        //Undo
        spaceLabel22.text = "Undo done...";

    } else {
        console.warningln("No active window to undo.");
    }
    };


dialog.XstarredoButton = new PushButton(this);
dialog.XstarredoButton.text = "Redo";
dialog.XstarredoButton.icon = dialog.scaledResource(":/icons/redo.png");
dialog.XstarredoButton.setFixedWidth(80);

//buttonSizer.add(dialog.starredoButton);

dialog.XstarredoButton.onClick = function () {
    dialog.undoButton.enabled = true; //Undo de Color
    dialog.XstarredoButton.enabled = false; //Redo de Color
    console.writeln("\nRedo the last undone action.");
    let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
    if (selectedWindow && !selectedWindow.isNull) {
        //imageViewerControl2 = imageViewerControl2; //Redo Color
        redoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de redo
        //Red
        spaceLabel22.text = "Redo done...";

    } else {
        console.warningln("No active window to redo.");
    }
};


    ColorRunButton2.toolTip = "Select an image and clic Load image.";
    ColorRunButton2.enabled = false; // activa con licencia
    ColorRunButton222.enabled= false;
    ColorRunButtonGreen222.enabled= false;
    dialog.undoButton.enabled = false;
    dialog.XstarredoButton.enabled = false;
    this.ColorRunButton3.enabled = false; // activa con licencia
    buttonSizer2.add(ColorRunButton2);
    buttonSizer2.add(ColorRunButton222);
    buttonSizer2.add(ColorRunButtonGreen222);
    buttonSizer2.add(this.undoButton);
    buttonSizer2.add(dialog.XstarredoButton);


    buttonSizer2.add(this.ColorRunButton3);
    buttonSizer2.addStretch();


    ColorGroupBox2.sizer.add(buttonSizer2);

    this.optionsPage2.sizer.add(ColorGroupBox2);

//-----------------------------------------------------------------------------
//Pestaña Stars-------------------------------------------------------------
//-----------------------------------------------------------------------------


// --- Tab Stars ---
this.starPage = new Control(this);
this.starPage.sizer = new VerticalSizer;
this.starPage.sizer.margin = 6;
this.starPage.sizer.spacing = 4;


// Actualiza el listado de ventanas y pon a cero los valores
        this.starPage.onShow = function() {

        starupdateImageSelector(starimageSelector22);
        // Configurar el valor por defecto en starimageSelector22
        if (starimageSelector22.numberOfItems > 0) {
           starimageSelector22.currentItem = 0; // Selecciona el primer elemento
       }

       // Actualizar el listado de imágenes en starimageSelector223
       starupdateImageSelector(starimageSelector223);

       // Configurar el valor por defecto en starimageSelector223
       if (starimageSelector223.numberOfItems > 0) {
           starimageSelector223.currentItem = 0; // Selecciona el primer elemento
       }
}



ScrollControl.prototype = new ScrollBox;

// Crear el visor de imágenes para las estrellas
let imageViewerControlstar = new ScrollControl(this.starPage);
imageViewerControlstar.setFixedHeight(WindowsOsx3);  // Espacio reservado para la visualización de la imagen
imageViewerControlstar.setScaledMinWidth(400);  // Tamaño mínimo escalado
this.starPage.sizer.add(imageViewerControlstar);  // Añadir el control de imagen al sizer de la página

let starGroupBox = new GroupBox(this.starPage);
starGroupBox.sizer = new VerticalSizer;
starGroupBox.sizer.margin = 6;
starGroupBox.sizer.spacing = 4;


// Selector para imagen sin estrellas (Starless)
let starLabel2 = new Label(starGroupBox);
starLabel2.text = "Select starless image:";
starLabel2.textAlignment = TextAlign_Left;
starGroupBox.sizer.add(starLabel2);

let starimageSelector22 = new ComboBox(starGroupBox);
starimageSelector22.editEnabled = false;
starimageSelector22.visibleItemCount = 15;
starimageSelector22.setFixedHeight(WindowsOsx2);
starGroupBox.sizer.add(starimageSelector22);


// Selector para imagen de estrellas (Stars)
let starLabel3 = new Label(starGroupBox);
starLabel3.text = "Select stars image:";
starLabel3.textAlignment = TextAlign_Left;
starGroupBox.sizer.add(starLabel3);

let starimageSelector223 = new ComboBox(starGroupBox);
starimageSelector223.editEnabled = false;
starimageSelector223.enabled = false;
starimageSelector223.visibleItemCount = 15;
starimageSelector223.setFixedHeight(WindowsOsx2);
starGroupBox.sizer.add(starimageSelector223);

starGroupBox.sizer.addStretch();



// Función para actualizar los ComboBox con las ventanas activas
function starupdateImageSelector(comboBox) {
    if (!comboBox) {
        console.writeln("Starting...");
        return;
    }

    comboBox.clear();
    comboBox.addItem("<Select an Image>");
    let windows = ImageWindow.windows;
    for (let i = 0; i < windows.length; i++) {
        comboBox.addItem(windows[i].mainView.id);
    }
    comboBox.visibleItemCount = 15;
}

// Actualizar ambos selectores al iniciar
if (starimageSelector22 && starimageSelector223) {
    starupdateImageSelector(starimageSelector22);
    starupdateImageSelector(starimageSelector223);
} else {
    console.criticalln("Error: starimageSelector22 or starimageSelector223 is undefined");
}

// Asignar funciones onMousePress para actualizar los selectores al hacer clic
starimageSelector22.onMousePress = function() {
   starupdateImageSelector(starimageSelector22);

};

starimageSelector223.onMousePress = function() {
    starupdateImageSelector(starimageSelector223);
};


MiraProcesStar(starimageSelector22, starimageSelector223, imageViewerControlstar);

let spacio = new Label;
      spacio.text = "";
      starGroupBox.sizer.add(spacio);

   // Crear el contenedor horizontal que dividirá los sliders en dos columnas
      let starSliderContainer = new HorizontalSizer;
      starSliderContainer.spacing = 10; // Espacio entre las dos columnas

      // Crear el sizer vertical para los sliders de la columna izquierda
      let starLeftColumn = new VerticalSizer;
      starLeftColumn.spacing = 4; // Espaciado entre elementos en la columna izquierda


//Slider Star presence



      let hueSliderLabel = new Label;
      hueSliderLabel.text = "Stars Presence:";
//
      let starPresenceSlider = new Slider;
      starPresenceSlider.setRange(0, 20);
      starPresenceSlider.value = OptionStarpresence;
      starPresenceSlider.onValueUpdated = function(value) {
          OptionStarpresence = value - 10;
      };
      starPresenceSlider.enabled = true;
      starPresenceSlider.toolTip ="Select star presence";
//
      starLeftColumn.add(hueSliderLabel);
      starLeftColumn.add(starPresenceSlider);
//
//
      let hueSliderLabel1 = new Label;
      hueSliderLabel1.text = "Stars Rounded:";
//
      let starRoundedSlider = new Slider;
      starRoundedSlider.setRange(0, 20);
      starRoundedSlider.value = OptionStarRounded;
      starRoundedSlider.onValueUpdated = function(value) {
          OptionStarRounded = value - 10;
      };
      starRoundedSlider.enabled = true;
      starRoundedSlider.toolTip ="Select star rounded";
//
      starLeftColumn.add(hueSliderLabel1);
      starLeftColumn.add(starRoundedSlider);
//
//
      let hueSliderLabel2 = new Label;
      hueSliderLabel2.text = "Stars Temperature: Cold  < - 0 - > Warm";
//
      let starTempSlider = new Slider;
      starTempSlider.setRange(0, 20);
      starTempSlider.value = OptionStartemperature;
      starTempSlider.onValueUpdated = function(value) {
          OptionStartemperature = value - 10;
      };
      starTempSlider.enabled = true;
      starTempSlider.toolTip ="Select star temperature (Hot and Cool)";
//
      starLeftColumn.add(hueSliderLabel2);
      starLeftColumn.add(starTempSlider);
//
//
      let hueSliderLabel3 = new Label;
      hueSliderLabel3.text = "Stars Saturation:";
//
      let starSaturationSlider = new Slider;
      starSaturationSlider.setRange(0, 20);
      starSaturationSlider.value = OptionStarsaturation;
      starSaturationSlider.onValueUpdated = function(value) {
          OptionStarsaturation = value - 10;
      };
      starSaturationSlider.enabled = true;
      starSaturationSlider.toolTip ="Select star saturation";
//
      starLeftColumn.add(hueSliderLabel3);
      starLeftColumn.add(starSaturationSlider);
//
//
     let hueSliderLabel6 = new Label;
      hueSliderLabel6.text = "Stars Shine:";
//
      let starBrillanceSlider = new Slider;
      starBrillanceSlider.setRange(0, 20);
      starBrillanceSlider.value = OptionStarBrillance;
      starBrillanceSlider.onValueUpdated = function(value) {
          OptionStarBrillance = value -10;
      };
      starBrillanceSlider.enabled = true;
      starBrillanceSlider.toolTip ="Select star brillance";
//
      starLeftColumn.add(hueSliderLabel6);
      starLeftColumn.add(starBrillanceSlider);

// Crear el sizer vertical para los sliders de la columna derecha
let starRightColumn = new VerticalSizer;
starRightColumn.spacing = 4; // Espaciado entre elementos en la columna derecha

      let hueSliderLabel4 = new Label;
      hueSliderLabel4.text = "Stars Halo:";
//

      let starHaloSlider = new Slider;
      starHaloSlider.setRange(0, 20);
      starHaloSlider.value = OptionStarhalo;
      starHaloSlider.onValueUpdated = function(value) {
         OptionStarhalo = value;
      };
      starHaloSlider.enabled = true;
      starHaloSlider.toolTip ="Select star halo";
//
      starRightColumn.add(hueSliderLabel4);
      starRightColumn.add(starHaloSlider);

      let hueSliderLabel5 = new Label;
      hueSliderLabel5.text = "Stars Sharpen:";
//
      let starSharpSlider = new Slider;
      starSharpSlider.setRange(0, 20);
      starSharpSlider.value = OptionStarSharp;
      starSharpSlider.onValueUpdated = function(value) {
          OptionStarSharp = value;
      };
      starSharpSlider.enabled = true;
      starSharpSlider.toolTip ="Select star Sharpen";
//
      starRightColumn.add(hueSliderLabel5);
      starRightColumn.add(starSharpSlider);
//
      let hueSliderLabel7 = new Label;
      hueSliderLabel7.text = "Stars Green:";
//
      let starGreenSlider = new Slider;
      starGreenSlider.setRange(0, 20);
      starGreenSlider.value = OptionStarGreen;
      starGreenSlider.onValueUpdated = function(value) {
          OptionStarGreen = value;
      };
      starGreenSlider.enabled = true;
      starGreenSlider.toolTip ="Select star green reduction";
//
      starRightColumn.add(hueSliderLabel7);
      starRightColumn.add(starGreenSlider);
//
      let hueSliderLabel8 = new Label;
      hueSliderLabel8.text = "Stars Magenta:       ";
//
      let starMagentaSlider = new Slider;
      starMagentaSlider.setRange(0, 20);
      starMagentaSlider.value = OptionStarMagenta;
      starMagentaSlider.onValueUpdated = function(value) {
          OptionStarMagenta = value;
      };
      starMagentaSlider.enabled = true;
      starMagentaSlider.toolTip ="Select star magenta reduction";
//
      starRightColumn.add(hueSliderLabel8);
      starRightColumn.add(starMagentaSlider);
//
      let hueSliderLabel9 = new Label;
      hueSliderLabel9.text = "Stars Blend opacity with starless image:";
//
      let starOpacitySlider = new Slider;
      starOpacitySlider.setRange(0, 20);
      starOpacitySlider.value = OptionStarblend;
      starOpacitySlider.onValueUpdated = function(value) {
          OptionStarblend = value - 10;
          dialog.starfinalImageButton.enabled = true;
      };
      starOpacitySlider.enabled = true;
      starOpacitySlider.toolTip ="Select star opacity";
//
      starRightColumn.add(hueSliderLabel9);
      starRightColumn.add(starOpacitySlider);

// Añadir las dos columnas al contenedor principal
starSliderContainer.add(starLeftColumn);
starSliderContainer.add(starRightColumn);

// Agregar el contenedor de sliders al GroupBox
starGroupBox.sizer.add(starSliderContainer);
starGroupBox.sizer.addStretch();

// Añadir el GroupBox a la pestaña Star
this.starPage.sizer.add(starGroupBox);



// --- Botón Refresh ---
dialog = this;
dialog.starRefreshButton = new PushButton(this.starPage);
dialog.starRefreshButton.text = "Refresh";
dialog.starRefreshButton.icon = dialog.scaledResource (":/icons/refresh.png");
dialog.starRefreshButton.setFixedWidth(80);
dialog.starRefreshButton.enabled = false;
dialog.starRefreshButton.toolTip = "Apply star adjustments and refresh the image preview";



dialog.starRefreshButton.onClick = function () {

    // Obtener las imágenes seleccionadas de los ComboBox
    let starImageName = starimageSelector223.itemText(starimageSelector223.currentItem);
    let starlessImageName = starimageSelector22.itemText(starimageSelector22.currentItem);

    // Si no hay imagen seleccionada, mostrar un mensaje de advertencia
    if (starImageName === "<Select an Image>") {
        (new MessageBox("No star image selected", "Error", StdIcon_Error, StdButton_Ok)).execute();
        console.criticalln("No star image selected.");
        return;
    }


    dialog.starfinalImageButton.enabled = false;
    dialog.starokButton.enabled = false;
    dialog.starResetButton.enabled = false;

    //Borra_blend_0
    MiraBorrarstars();
    // Llamar a la función MiraStarGeneral con los valores de los sliders

    MiraStarGeneral(starimageSelector223, imageViewerControlstar, OptionStarpresence, OptionStarRounded, OptionStartemperature, OptionStarsaturation, OptionStarhalo, OptionStarblend, OptionStarMagenta, OptionStarGreen, OptionStarBrillance, OptionStarSharp)


    // Buscar una ventana que termine en "_blend_0"
    let windows = ImageWindow.windows;
    let previewWindow = null;

    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.endsWith("_blend_0")) {
            previewWindow = windows[i];
            break;
        }
    }

    // Si no se encontró ninguna ventana "_blend_0", buscar "Start_preview"
    if (!previewWindow) {

        previewWindow = ImageWindow.windowById("Start_preview");
    }

    // Verificar si la ventana existe
    if (previewWindow && !previewWindow.mainView.isNull) {
        console.writeln("Front Window " + previewWindow.mainView.id);

        // Reducir la saturación y actualizar la vista
        MiraReduceSaturationInViewer(imageViewerControlstar, previewWindow);

        // Traer la ventana a frente y posicionarla
        MiraBringToFrontAndPosition(previewWindow.mainView.id);
    } else {
        console.criticalln("Error: No valid preview window found.");
    }

    //Activa botón blend
    dialog.starfinalImageButton.enabled = true;
    dialog.starokButton.enabled = false;
    dialog.starResetButton.enabled = true;

    //Resetea valores
    MiraStarResetSliders(starPresenceSlider, starRoundedSlider, starTempSlider, starSaturationSlider, starHaloSlider, starOpacitySlider, starMagentaSlider, starGreenSlider, starBrillanceSlider, starSharpSlider);


console.noteln("✅" +" Refresh done !!!");


};




// Botones para controlar las acciones
let buttonSizer = new HorizontalSizer;
buttonSizer.spacing = 6;
buttonSizer.margen = 4;


//buttonSizer.add(dialog.starRefreshButton);

dialog = this;
dialog.starResetButton = new PushButton(this);
dialog.starResetButton.text = "Reset";
dialog.starResetButton.icon = dialog.scaledResource (":/icons/debug-restart.png");
dialog.starResetButton.setFixedWidth(80);
dialog.starResetButton.enabled = false;
//buttonSizer.add(dialog.starResetButton);

dialog.starResetButton.onClick = function() {

    MiraStarResetSliders(starPresenceSlider, starRoundedSlider, starTempSlider, starSaturationSlider, starHaloSlider, starOpacitySlider, starMagentaSlider, starGreenSlider, starBrillanceSlider, starSharpSlider);

    console.writeln("⚙️"+" Reset sliders");
};



dialog.starfinalImageButton = new PushButton(this);
dialog.starfinalImageButton.text = "Blend";
dialog.starfinalImageButton.icon = dialog.scaledResource (":/icons/favorite-ok.png");
dialog.starfinalImageButton.setFixedWidth(80);
dialog.starfinalImageButton.enabled = false;
//buttonSizer.add(dialog.starfinalImageButton);

dialog.starfinalImageButton.onClick = function () {
   dialog.starfinalImageButton.enabled = false;
   let OptionMergePro1 = starimageSelector22.itemText(starimageSelector22.currentItem);
   let OptionMergePro2 = "Start_preview";
   let OptionSharpenNonstellar = starOpacitySlider.value / 20; // Valor entre 0 y 1 basado en el slider
   let imageViewerControl = imageViewerControlstar;

   MiraBorrarstars();
   let imageViewerControl = imageViewerControlstar;
   MiraMergePro(OptionMergePro1, OptionMergePro2, OptionSharpenNonstellar, imageViewerControl);

   dialog.starokButton.enabled = true;
}

dialog.starundoButton = new PushButton(this);
dialog.starundoButton.text = "Undo"; //Undo Stars
dialog.starundoButton.icon = dialog.scaledResource (":/icons/undo.png");
dialog.starundoButton.setFixedWidth(50);
dialog.starundoButton.enabled = false;
//buttonSizer.add(dialog.starundoButton);

dialog.starundoButton.onClick = function () {
      dialog.starundoButton.enabled = false; //Undo Stars
      console.writeln("\nRestore the last image state.");
      let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
      if (selectedWindow && !selectedWindow.isNull) {
      let imageViewerControl2 = imageViewerControlstar;//Undo Stars
        undoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de undo
        dialog.starredoButton.enabled = true;
      } else {
        console.warningln("No active window to undo.");
      }
     };


dialog.starredoButton = new PushButton(this);
dialog.starredoButton.text = "Redo";
dialog.starredoButton.icon = dialog.scaledResource(":/icons/redo.png");
dialog.starredoButton.setFixedWidth(80);
dialog.starredoButton.enabled = false;  // Desactivado inicialmente, se habilitará cuando haya acciones para rehacer
//buttonSizer.add(dialog.starredoButton);

dialog.starredoButton.onClick = function () {
    dialog.starundoButton.enabled = true; //Undo Stars
    dialog.starredoButton.enabled = false; //Red Stars
    console.writeln("\nRedo the last undone action.");
    let selectedWindow = ImageWindow.activeWindow;  // Obtiene la ventana activa
    if (selectedWindow && !selectedWindow.isNull) {
       let imageViewerControl2 = imageViewerControlstar; //Redo Stars
        redoLastAction(selectedWindow, imageViewerControl2);  // Pasa la ventana activa a la función de redo
    } else {
        console.warningln("No active window to redo.");
    }
};




dialog.starokButton = new PushButton(this);
dialog.starokButton.text = "OK";
dialog.starokButton.icon = dialog.scaledResource (":/icons/ok.png");
dialog.starokButton.setFixedWidth(80);
dialog.starokButton.enabled = false;
//buttonSizer.add(dialog.starokButton);

dialog.starokButton.onClick = function () {
    // Preguntar si desea aplicar los cambios en una nueva imagen
    let msgBox = new MessageBox("Do you want to apply changes in a new image?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
    let response = msgBox.execute();

    // Si la respuesta es "Sí", ejecutar MiraOk
    if (response === StdButton_Yes) {

        MiraOk2(OptionNombVar); //Grabar nombre
        MiraResolFinal(); //Aquí ya tiene el nuevo nombre

        dialog.starRefreshButton.enabled = false;
        dialog.starResetButton.enabled = false;
        dialog.starundoButton.enabled = false;
        dialog.starokButton.enabled = false;
        dialog.starredoButton = false;

        starimageSelector22.currentItem = 0;
        starimageSelector223.currentItem = 0;
        starimageSelector223.enabled = false;

        // Busca y elimina la ventana 'Start_preview'
        let startPreviewWindow = ImageWindow.windowById("Start_preview");
        if (startPreviewWindow && !startPreviewWindow.isNull) {
         startPreviewWindow.forceClose();
         console.writeln("Window 'Start_preview' has been deleted.");
        } else {
         console.writeln("No window named 'Start_preview' found to delete.");
        }



    } else {
        console.noteln("Process canceled by user.");
        return;  // Salir si la respuesta es "No"
    }
    console.noteln("\n✅"+ " Apply done !!!");
   };






//Añade botones
// Crear el HorizontalSizer para los botones
let buttonSizer = new HorizontalSizer;
buttonSizer.spacing = 4;  // Espacio entre los botones
//buttonSizer.margin = 6;   // Margen alrededor de los botones

buttonSizer.add(dialog.starRefreshButton);

buttonSizer.add(dialog.starResetButton);
buttonSizer.add(dialog.starundoButton);
buttonSizer.add(dialog.starredoButton);

buttonSizer.add(dialog.starfinalImageButton);
buttonSizer.add(dialog.starokButton);


//Añade el Sizer
starGroupBox.sizer.add(buttonSizer);

// Fin del código stars



//-----------------------------------------------------------------------------
//Pestaña Licencia-------------------------------------------------------------
//-----------------------------------------------------------------------------

      // --- Tab 3: License ---
      this.licensePage = new Control(this);
      this.licensePage.sizer = new VerticalSizer;
      this.licensePage.sizer.margin = 10;
      this.licensePage.sizer.spacing = 6;

      let licenseGroupBox = new GroupBox(this.licensePage);
      licenseGroupBox.title = "License Information";
      licenseGroupBox.sizer = new VerticalSizer;
      licenseGroupBox.sizer.margin = 6;
      licenseGroupBox.sizer.spacing = 4;

      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(emailLabel);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";  // Inicializar con una cadena vacía o algún valor por defecto
      this.emailEdit.enabled = false;
      licenseGroupBox.sizer.add(this.emailEdit);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(codeLabel);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";  // Inicializar con una cadena vacía
      this.codeEdit.enabled = false;
      licenseGroupBox.sizer.add(this.codeEdit);

      let PathcodeLabel = new Label(this);
      PathcodeLabel.text = "Path: " +  originalFilePath;
      PathcodeLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(PathcodeLabel);

      this.PathcodeEdit = new Edit(this);
      this.PathcodeEdit.minWidth = 300;
      this.PathcodeEdit.text = "";  // Inicializar con una cadena vacía
      this.PathcodeEdit.enabled = false;
      licenseGroupBox.sizer.add(this.PathcodeEdit);

      let NotaLabel = new Label(this);
      NotaLabel.text = "* Windows O.S. users: PixInsight must be running as Administrator.";
      NotaLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(NotaLabel);




      // Llamada a ReadLicenseFile después de que los campos se han creado
      let self = this;
      let filePath = originalFilePath;
      ReadLicenseFile(filePath, self);  // Usamos 'self' para pasar el contexto

      let EspacioLabel = new Label(this);
      EspacioLabel.text = "";
      EspacioLabel.textAlignment = TextAlign_Left ;
      licenseGroupBox.sizer.add(EspacioLabel);

      // Crear una sizer horizontal para los botones "Edit" y "Validate"
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones


      let EditvalidateButton = new PushButton(this);
      EditvalidateButton.text = "Edit";
      EditvalidateButton.icon = this.scaledResource( ":/icons/pencil.png" );
      EditvalidateButton.setFixedWidth(150);
      buttonSizer.add(EditvalidateButton);

          EditvalidateButton.onClick = function () {

             let msgBox = new MessageBox(
             "Editing License Process\nDo you want to continue?",  // Message text
             "Confirmation",  // Title
             StdIcon_Question,  // Question icon
             StdButton_Yes, StdButton_No  // Yes/No buttons
             );

             let result = msgBox.execute();  // Show the MessageBox and capture the result

             // If the user clicks 'Yes', proceed with writing the license file
             if (result === StdButton_Yes) {
                EditvalidateButton.enabled  =false;
               console.noteln("\n💾"+ " Editing License...");
                self.emailEdit.enabled = true;
                self.codeEdit.enabled = true;
                validateButton.enabled = true;


              } else {
                  self.emailEdit.enabled = false;
                  self.codeEdit.enabled = false;
                  self.PathcodeEdit.enabled = false;
              }
              };

              let validateButton = new PushButton(this);
              validateButton.text = "Validate";
              validateButton.icon = this.scaledResource( ":/icons/ok.png" );
              validateButton.setFixedWidth(150);
              validateButton.enabled = false;
              buttonSizer.add(validateButton);
              validateButton.onClick = function () {




             // Usamos 'self' para capturar correctamente los valores de los campos de texto
              let email = self.emailEdit.text ? self.emailEdit.text.trim() : "";
              let code = self.codeEdit.text ? self.codeEdit.text.trim() : "";
              let path = self.PathcodeEdit.text ? self.PathcodeEdit.text.trim() : "";

               // Asegurarse de que los campos no estén vacíos
                if (email === "" || code === "" || path === "") {
               console.criticalln("Error: Both Email and Code fields must be filled.");
               return;
                  }

               // Analizar si es correcto

               if (isValidKeyFromCode(code, OptionAdjvalue2)) {
                   console.noteln("\n✅ " + code);

               } else {
                   console.warningln("⚠️ License validation failed. Please check your license code.");
                   let messageBox = new MessageBox(
                  "License validation failed.\nPlease check your license code.", // Message
                   "Error", // Title
                   StdIcon_Error, // Icon
                   StdButton_Ok // Buttons
                );
                   messageBox.execute(); // Display the message box
                   return;
               }
               //
console.writeln("License File Path: " + originalFilePath);

              // Primero, mostrar el diálogo "Save As" y luego proceder con la escritura del archivo
               let filePath = MiraSaveAs(originalFilePath);  // Mostrar el cuadro de diálogo "Save As"
               if (filePath) {
                // Si el usuario selecciona una ubicación, continuar con el guardado
                console.noteln("\n💾"+" Saving license file...");

                   let originalFilePath = filePath;  // Actualizar la ruta del archivo con la ruta seleccionada
                   let path = filePath;  // Definir 'path' como la ruta seleccionada por el usuario


            // Llamada a la función para escribir el archivo de licencia
                let newPath = WriteLicenseFile(originalFilePath, email, code, originalFilePath);  // Guardar el archivo y devolver la ruta

                if (newPath) {
                 // Actualizar el campo con la ruta
                 self.PathcodeEdit.text = newPath;
                 EditvalidateButton.enabled = true;  // Habilitar el botón de validación
                } else {
                 console.criticalln("\n⚠️"+ " Error saving the license file.");
                }

            } else {
             // Si el usuario cancela la operación
          console.criticalln("\n❌"+ " Save operation aborted.");
          validateButton.enabled = false;
          EditvalidateButton.enabled = true;

         }

     };





//Fin File import

      licenseGroupBox.sizer.add(buttonSizer);
      licenseGroupBox.adjustToContents();  // Ajustamos el grupo al contenido

      //
      // Crear el GroupBox para "License Activation"
      let licenseActivationGroupBox = new GroupBox(this.licensePage);
      licenseActivationGroupBox.title = "License Activation";
      licenseActivationGroupBox.sizer = new VerticalSizer;
      licenseActivationGroupBox.sizer.margin = 6;
         licenseActivationGroupBox.sizer.spacing = 4;


      if (Optiontimevar >= 80){
             //Optiontimevar = "Beta Licensed Script";
      }else{
          if (Optiontimevar <= 30){
             console.writeln("Get your activation license for free");
          }
      }

      // Añadir el texto de información sobre la activación de la licencia
      let activationInfoLabel = new Label(this);
      activationInfoLabel.useRichText = true; // Permitir HTML en el texto
      activationInfoLabel.text =
      "" + ProjecTname + " " + ProjecTver + "<br>" +
      "Remaining days:</b> " + Optiontimevar + "<br>" +
      "Written by Jesús Manuel García Flores<br>" +
      "Get your activation license for free: <a href=\"https://www.teoriadelcolor.es/astroprocessor\">www.teoriadelcolor.es/astroprocessor</a>";
      activationInfoLabel.textAlignment = TextAlign_Center;
      licenseActivationGroupBox.sizer.add(activationInfoLabel);
      // Añadir el GroupBox "License Activation" debajo del "License Information"

      //
      this.licensePage.sizer.add(licenseGroupBox);

      //this.licensePage.sizer.add(licenseImportGroupBox);

      // **Nuevo GroupBox llamado "Information" debajo del "License Information"**
      let informationGroupBox = new GroupBox(this.licensePage);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;  // Espaciado vertical reducido

      // Añadir etiquetas y campos adicionales si es necesario
      let infoLabel = new Label(this);
      infoLabel.text = "Script Information:\nIn order the script work fine, you need to be installed:\n\nRemove Stars:\n- Starnet (free - www.starnetastro.com)\n- StarXTerminator (www.rc-astro.com) - Optional\n* One of them must be installed\n\nNoise Reduction:\n- GraXpert (free - https://graxpert.com)\n- NoiseXTerminator (www.rc-astro.com) - Optional\n* One of them must be installed\n\nSharpen:\n- BlurXTerminator (www.rc-astro.com) - Optional\n- High pass filter - Included in the script\n";
      infoLabel.textAlignment = TextAlign_Left ;
      informationGroupBox.sizer.add(infoLabel);


      // Añadir el nuevo GroupBox "Information" a la página, debajo del de "License"
      this.licensePage.sizer.add(informationGroupBox);

      // Ajustes finales para que el contenido se ajuste
      licenseGroupBox.adjustToContents();
      // Añadir el GroupBox "License Activation" debajo del "License Information"
      this.licensePage.sizer.add(licenseActivationGroupBox);

      this.licensePage.sizer.add(informationGroupBox);
      informationGroupBox.adjustToContents();

      this.licensePage.adjustToContents();



//-----------------------------------------------------------------------------
//Añadir Pestañas--------------------------------------------------------------
//-----------------------------------------------------------------------------

    // Agregar la pestaña License al TabBox

    this.tabBox.addPage(this.integrationPage, "Integration");
    this.tabBox.addPage(this.optionsPage2, "Color");
    this.tabBox.addPage(this.optionsPage, "Tools");
    this.tabBox.addPage(this.starPage, "Stars");
    this.tabBox.addPage(this.licensePage, "License");


//-----------------------------------------------------------------------------
//Botón Run de Integrator------------------------------------------------------
//-----------------------------------------------------------------------------


      // --- Horizontal Sizer to hold Project Type and Alignment GroupBoxes ---
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.spacing = 10; // Espacio entre los dos grupos horizontales


      // Create VerticalSizer for each group to tightly manage layout
      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      CropprojectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);

      // Create VerticalSizer for each group to tightly manage layout
      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      projectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;  // Remove any margin to reduce extra spacing
      alignmentSizer.spacing = 10;  // Set appropriate spacing between elements
      alignmentSizer.add(this.alignmentGroupBox);

      // Create HorizontalSizer to put both projectTypeSizer and alignmentSizer side by side
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;  // Ensure no extra margin is added around the group boxes
      projectAndAlignmentSizer.spacing = 10;  // Space between the two group boxes
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);

      // Agregar el HorizontalSizer al sizer de la integración
      this.integrationPage.sizer.add(projectAndAlignmentSizer);

      // --- Añadir el Tagging GroupBox directamente después del Horizontal Sizer ---
      this.integrationPage.sizer.add(this.taggingGroupBox);

      // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(this.optionsGroupBox);

      // --- RUN Button ---
      this.runButton = new PushButton(this.integrationPage);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select a Project type\nSelect an Alignment\nSelect images\nSelect Integration options\nand click RUN";
      this.runButton.setFixedWidth(102);
      this.runButton.setFixedHeight(WindowsOsx1);





///
      this.integrationPage.sizer.addSpacing(10);

      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";


      // Crear un sizer horizontal
      let horizontalSizer = new HorizontalSizer;
      horizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
      horizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes


      // Añadir el botón y la etiqueta al sizer horizontal
      horizontalSizer.add(this.workingLabel);


     // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(horizontalSizer);

      // Crear un sizer horizontal
      let vhorizontalSizer = new VerticalSizer;
      vhorizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
      vhorizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes

      // Crear el botón "SORT"
      this.SortButton = new PushButton(ColorGroupBox);
      this.SortButton.text = "Arrange";
      this.SortButton.icon = this.scaledResource( ":/icons/queries.png" );
      this.SortButton.setFixedWidth(102);
      this.SortButton.setFixedHeight(WindowsOsx1);

      this.SortButton.toolTip = "Sort all image windows in a cascade order";

      // Evento onClick para ordenar las ventanas en cascada
      this.SortButton.onClick = function() {
          MiraOrdena1();  // Llama a la función para ordenar las ventanas
      };

     // Crear el botón "Iconizar"
      this.Iconize2 = new PushButton(ColorGroupBox);
      this.Iconize2.text = "Minimize";
      this.Iconize2.icon = this.scaledResource( ":/icons/tree.png" );
      this.Iconize2.setFixedWidth(102);
      this.Iconize2.setFixedHeight(WindowsOsx1);
      this.Iconize2.toolTip = "Iconized all image windows";

      // Crear el botón "Reiniciar Projecto"
      this.Iconize3 = new PushButton(ColorGroupBox);
      this.Iconize3.text = "Trash";
      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setFixedWidth(102);
      this.Iconize3.setFixedHeight(WindowsOsx1);
      this.Iconize3.toolTip = "Delete actual project";

      // Crear el botón "Inspector"
      this.Iconize4 = new PushButton(ColorGroupBox);
      this.Iconize4.text = "Manual";
      this.Iconize4.icon = this.scaledResource( ":/icons/properties.png" );
      this.Iconize4.setFixedWidth(102);
      this.Iconize4.setFixedHeight(WindowsOsx1);
      this.Iconize4.toolTip = "Advanced Mode\nManual Image Inspector";

      // Crear el botón "Inspector"
      this.Iconize5 = new PushButton(ColorGroupBox);
      this.Iconize5.text = "Colorizer";
      this.Iconize5.icon = this.scaledResource( ":/icons/color-wheel.png" );
      this.Iconize5.setFixedWidth(102);
      this.Iconize5.setFixedHeight(WindowsOsx1);
      this.Iconize5.toolTip = "Colorize your images";

      // Crear el botón "MGC"
      this.Iconize6 = new PushButton(ColorGroupBox);
      this.Iconize6.text = "";
      this.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      this.Iconize6.setFixedWidth(102);
      this.Iconize6.setFixedHeight(WindowsOsx1);
      this.Iconize6.toolTip = "Multiscale Gradient Correction Preferences";

//
// Capturar el contexto de `this`
      let self = this;
//
      this.runButton.onClick = function () {


     //Mira RGB Stars
     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {
            // Continuar con el proceso si las imágenes RGB están correctamente seleccionadas
            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {
            // Si alguna imagen está vacía, no continúa
            self.starsRGBCheckBox.checked = false;
            Option1var = "OFF";
            self.update();
            return;
        }
     }

      //Mira Crop

      if (OptionCrop === "OFF"){
      let msgBox = new MessageBox("Crop option = 'OFF'\nImages need to be cropped, before run this script.\n\nDo you want to run script without cropped?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_No) {
         return;
      }

      }

      console.noteln("🟢" +" Initializing Script...");

      if (!MiraCheckWindowsABE()) {
        console.noteln("\nReady to work...\n");
        // Detener la ejecución si MiraCheckWindowsABE() falla
        // return;
      }

      let msgBox = new MessageBox("Do you want to Run the Script?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {

        let startTime = Date.now();



        console.noteln("🚀" + "Launching Script...");
        // Cambiar el color del texto a rojo
        dialog.workingLabel.foregroundColor = 0xFF0000;  // Color rojo (en formato RGB hexadecimal)
        dialog.workingLabel.update();

        // Validate the assignments
         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln("\nValidation failed. Please select images.");
          return;
         } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
         }

        dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/12. Please wait... ";
        MiraProyecto();

        //Ejecuta MARS
        if (OptionMgc ==="ON") {
           console.noteln("🚀" + "Launching MARS databases...");
           if (MarsFound1 === "ON" && MarsFound2 === "ON"){
              dialog.workingLabel.text = "🚀" + "Launching Multiscale Gradient Correction process. Please wait... ";
              console.noteln("🚀" + "Launching Multiscale Gradient Correction process...\n");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              let defaultPathMars = originalFilePathMars1;
              let defaultPathMars2 = originalFilePathMars2;
              let defaultPathMars3 = originalFilePathMars3;

              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ MARS-DR1-1.0.3.xmars: \n" + originalFilePathMarsfin1);


              if (MarsFound3 === "ON"){
              console.writeln("⚙️ MARS-DR1-1.1.1.xmars: \n" + originalFilePathMarsfin3);
                 } else {
              console.writeln("⚙️ MARS-DR1-u01-1.0.1.xmars: \n" + originalFilePathMarsfin2);
              }



              MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, originalFilePathMarsfin3 );



           }else{
           console.warningln("Skipping Multiscale Gradient Correction. Not databases founded.");
           //continúa el proceso
          }
        }

        //continúa con el proceso

        dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/12. Please wait... ";

            if (MiraVentana()) {

            //Cuando todo es correcto.
            self.runButton.enabled = false;
            self.SortButton.enabled = false;
            self.Iconize2.enabled = false;
            self.Iconize3.enabled = false;
            self.Iconize4.enabled = false;
            self.Iconize5.enabled = false;
            self.Iconize6.enabled = false;
            self.exitButton.enabled = false;

            dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/9. Please wait... ";
            MiraRenombre();
            dialog.workingLabel.text = "🚀" + "Launching  Process: [1 to 4]/9. Please wait... ";


            // Verificación de tipo de proyecto
            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return; // Detener la ejecución si falla la alineación
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }

            // Continuar con el proceso si la alineación fue exitosa o si el proyecto es OSC
            dialog.workingLabel.text = "Step 5/9. Main process, Please wait... ";
            MiraProcesoGeneral01(OptionABE);
            dialog.workingLabel.text = "Step 6/9. Please wait... ";
            MiraChannelCom();  // Ejecuta MiraChannelCom solo si el proyecto no es OSC
            dialog.workingLabel.text = "Step 7/9. Please wait... ";
            MiraGreen(); // Elimina el verde de la imagen activa
            dialog.workingLabel.text = "Step 8/9. Please wait... ";
 console.show();

            if (OptionVarStars === "ON") {
                console.noteln("Creating Starless Final Image");

                if (OptionHSOvar === "ON") { // ¿Creamos capa de estrellas RGB o SHO/HOO?
                    if (Option1var === "ON") {
                        if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching RGB stars process.");
                              MiraRGBStars(OptionABE, OptionRemaind);
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                    } else {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars2(OptionABE, OptionRemaind);
                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars(OptionABE, OptionRemaind);
                              }
                        }
                    }
                } // fin de OptionHSOvar
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
console.show();
            dialog.workingLabel.text = "Step 9/9. Please wait... ";
            MiraResolFinal(); // Ejecuta la resolución final


              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break; // Salimos del bucle al encontrar la ventana
                         }
                   }
               }


            MirashowTotalTime(startTime);
            Option2var2 = "ON"; // Actualiza para el Botón OK

            MiraBorraVentanas();

            iconizeAndArrangeWindows(); // Iconiza las ventanas y deja Base_Non_Linear activa

            OptionRemaind2 = "null";
            OptionEnabledPreview ==="OFF";
            console.noteln("\n✅" + "End Script...");
            self.runButton.enabled = true;
            self.SortButton.enabled = true;
            self.Iconize2.enabled = true;
            self.Iconize3.enabled = true;
            self.Iconize4.enabled = true;
            self.Iconize5.enabled = true;
            self.Iconize6.enabled = true;
            self.exitButton.enabled = true;
            //


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};
// Fin del botón Run




      this.SortButton.onClick = function() {
          MiraOrdena1();
      };


      this.Iconize2.onClick = function() {
          MiraIconiza2();
      };



      this.Iconize3.onClick = function() {
          MiraCheckWindowsTrash();
          // Update ComboBoxes with current windows

      };


     this.Iconize4.onClick = function() {
    // Obtener la ventana de imagen activa
    let currentImage = ImageWindow.activeWindow;

    // Si no hay una ventana activa, buscar entre las ventanas disponibles
    if (!currentImage || currentImage.isNull) {
        console.noteln("No active image window found. Searching for available windows...");
        let windows = ImageWindow.windows; // Obtener todas las ventanas
        if (windows.length > 0) {
            currentImage = windows[0]; // Seleccionar la primera ventana disponible
            console.writeln("Selected the first available window: " + currentImage.mainView.id);
        } else {
            console.criticalln("Error: No image windows available. Load images to work with.");
            return;
        }
    }

    // Verificar si `deiconize` es una función válida antes de invocarla
    if (typeof currentImage.deiconize === "function") {
        currentImage.deiconize();
        currentImage.bringToFront();
    } else {
        console.criticalln("Error: deiconize is not a function for the active window.");
    }

   // Pasar la ventana activa al inspector
   // Check if all image variables are "EMPTY"
    if (PimageHa === "EMPTY" && PimageSii === "EMPTY" && PimageOiii === "EMPTY" &&
        PimageRed === "EMPTY" && PimageGreen === "EMPTY" && PimageBlue === "EMPTY" &&
        PimageLuminance === "EMPTY" && PimageOsc === "EMPTY") {

        // Show a message box
        let messageBox = new MessageBox(
            "No Images selected.\n\nPlease select Images and choose Project type.", // Message
            "Error", // Title
            StdIcon_Error, // Icon
            StdButton_Ok // Buttons
        );
        messageBox.execute(); // Display the message box

        return; // Exit the function
    } else {
    console.noteln("🚀"+ "Launching Image inspector process...");
    OptionEnabledPreview2 = "ON";
    MiraInspector(currentImage.mainView.id);
    OptionEnabledPreview2 = "OFF";
    }
    };

   this.Iconize5.onClick = function() {

      let dialog = new BlendImagesDialog();
      dialog.execute();
   }

 this.Iconize6.onClick = function() {

      let dialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2);
      dialog.execute();
   }


     // Create a HorizontalSizer to align the buttons on the same row
      let buttonRowSizer = new HorizontalSizer;
      buttonRowSizer.spacing = 2; // Add some spacing between buttons

      // Add Run button and Sort button to the same sizer
      buttonRowSizer.add(this.runButton);
      buttonRowSizer.add(this.SortButton);
      buttonRowSizer.add(this.Iconize2);
      buttonRowSizer.add(this.Iconize3);
      buttonRowSizer.add(this.Iconize4);
      buttonRowSizer.add(this.Iconize5);
      buttonRowSizer.add(this.Iconize6);

      // Add this horizontal sizer to the integration page
      buttonRowSizer.addStretch();
      this.integrationPage.sizer.add(buttonRowSizer);


//-----------------------------------------------------------------------------
//Fondo de Ventana-------------------------------------------------------------
//-----------------------------------------------------------------------------




      // Creating ComboBox for Zoom Options

      dialog.zoomComboBox = new ComboBox(this);
      dialog.zoomComboBox.addItem("No Zoom");  // First option for Zoom to Fit (Ctrl+0 equivalent)
      dialog.zoomComboBox.addItem("Zoom fit");
      dialog.zoomComboBox.addItem("Zoom x1");
      dialog.zoomComboBox.addItem("Zoom in");
      dialog.zoomComboBox.addItem("Zoom out");
      dialog.zoomComboBox.setFixedWidth(WindowsOsx6);  // Set the width of the combo box
      dialog.zoomComboBox.setFixedHeight(WindowsOsx1);
      dialog.zoomComboBox.enabled = true;


      // Handling Zoom based on user selection
      dialog.zoomComboBox.onItemSelected = function (index) {
          let activeWindow = ImageWindow.activeWindow;

          if (!activeWindow || activeWindow.isNull) {
              (new MessageBox("There are no active windows to zoom in.", "Error", StdIcon_Error, StdButton_Ok)).execute();
              return;  // Exit if there's no active window
          }

          switch (index) {
              case 0: // Zoom to Fit (Ctrl+0 equivalent)
                  activeWindow.zoomToOptimalFit();

                  break;
              case 1: // Zoom fit
                  activeWindow.zoomToFit();

                  break;
              case 2: // Zoom x1
                  activeWindow.zoomFactor = 1.0;

                  break;
              case 3: // Zoom in
                  activeWindow.zoomIn();

                  break;
              case 4: // Zoom out
                  activeWindow.zoomOut();

                  break;
              default:
                  console.warningln("Invalid zoom option selected.");
                  break;
          }

             MiraBringToFrontAndPosition(activeWindow.mainView.id);
      };



     // --- EXIT Button ---
     this.exitButton = new PushButton(this);
     this.exitButton.text = "Exit";
     this.exitButton.icon = this.scaledResource( ":/icons/cancel.png" );
     this.exitButton.setFixedWidth(100);  // Set the width of the combo box
     this.exitButton.setFixedHeight(WindowsOsx1);


     this.exitButton.onClick = function () {

        this.dialog.cancel();
    };



      // Crear el CheckBox para Show console
      let showConsoleCheckBox = new CheckBox;
      showConsoleCheckBox.text = "Show console";
      showConsoleCheckBox.checked = true; // Opción por defecto

      // Manejar el evento onCheck para mostrar u ocultar la consola
      showConsoleCheckBox.onCheck = function (checked) {
          if (checked) {
              OptionshowConsolRadio = "ON";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.show(); // Mostrar la consola
          } else {
              OptionshowConsolRadio = "OFF";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.hide(); // Ocultar la consola
          }
      };


    this.exitButton.setFixedWidth(200);

    // Sizer para HELP y EXIT en la misma línea
    this.helpExitSizer = new HorizontalSizer;
    this.helpExitSizer.spacing = 10;
    this.helpExitSizer.add(dialog.zoomComboBox);
    this.helpExitSizer.addStretch();

    this.helpExitSizer.add(showConsoleCheckBox);
    this.helpExitSizer.addStretch();
    this.helpExitSizer.add(this.exitButton);

    // Sizer principal
    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;
    this.sizer.spacing = 10;

    this.sizer.add(this.tabBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.helpExitSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}



IntegratorDialog.prototype = new Dialog;

let dialog = new IntegratorDialog();
// Hacer que la ventana de diálogo sea redimensionable
IntegratorDialog.prototype.resizeable = true;
dialog.execute();


