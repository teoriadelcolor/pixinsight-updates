#engine v8

 /*
 ****************************************************************************
 * AstroProcessor Script
 *
 * AstroProcessor.js
 * Copyright (C) 2024 Jesús Manuel García Flores
 *
 * This script will help you to automate the most common processes in Pixinisight.
 * Upgrade your license for free as Beta tester.
 *
 *
 * If you wish to contact us you can do so by email at info@teoriadelcolor.es
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * This script is protected by copyright and may not be copied,
 * modified, redistributed, or used in any medium without prior written
 * authorization from Teoría del Color.
 *
 *
 *
 ****************************************************************************
 */


#feature-id    AstroProcessor : Utilities > AstroProcessor
#feature-icon  AstroprocessorIcon.svg
#feature-info  This script will help you automate the most common processes in Pixinisight. \
2026. \
<br/>\
Copyright &copy; 2024 Jesús M. García Flores.

#define TITLE "AstroProcessor"

#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdDialogCode.jsh>
#undef TITLE
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "AstroProcessorImageSolver"
#include "lib/ImageSolver/ImageSolver.js"
#undef VERSION
#undef TITLE
#undef SETTINGS_MODULE
#undef SOLVER_SETTINGS_MODULE
#define TITLE "AstroProcessor"

#include "lib/lite01.js"
#include "lib/process04.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process02.js"
#include "lib/process01.js"
#include "lib/process12.js"


// Variables globales
var ProjecTname = "🚀 AstroProcessor";
// Incrementar el bloque de cuatro dígitos en cada modificación de código:
// build.0001, build.0002, build.0003, etc.
var ProjecTver  = "v.1.0.build.0142";
var ProjectND = "23ad07xjr";
var ProjectHash = "d655d1467f58e6da8dcd1989a21c6a75ad53167d67a954bc8af73f41757c57ef";
var CanStartApp = true;
var ProjecTypevar = "SHO";  // Valor inicial
var ProjecTypevar2 = "0"; //Valor inicial
var ProjecTypevarRec = "SHO";  // Valor inicial
var AlignmenTypevar = "Ha"; // Valor inicial
var OptionLinkRGB = "false";  // Deshabilitado por defecto
var PimageSii = "EMPTY";        // Valor inicial
var PimageHa = "EMPTY";         // Valor inicial
var PimageOiii = "EMPTY";       // Valor inicial
var PimageRed = "EMPTY";        // Valor inicial
var PimageGreen = "EMPTY";      // Valor inicial
var PimageBlue = "EMPTY";       // Valor inicial
var PimageLuminance = "EMPTY";  // Valor inicial
var PimageOsc = "EMPTY";  // Valor inicial
var Option1var = "OFF";         // Valor inicial para StarsRGB
var OptionHavar = "OFF";         // Valor inicial para HaMixed
var VarProcesStar = "OFF";      // Inicializamos la variable para saber cuando se está creando la capa stars
var Option2var2 = "OFF";
var Option300 = "OFF"         // Valor para Botón OK en 300pppResolution
var OptionGraXNoise = "OFF";    // Valor inicial
var OptionNarrowbandToRGB = "ON";
var OptionDarkStructureEnhance = "ON";
var OptionFinalStarRefinement = "OFF";
var FinalStarRefinementReady = false;
var OptionNoiseXterminator  = "OFF";
var OptionMLDenoise = "OFF";
var OptionStarXterminator = "OFF";   // Selected from the third-party programs menu
var OptionBlurXterminator = "OFF";   // Selected from the third-party programs menu
var OptionHighpass = "OFF";    // Valor inicial
var OptionGradient ="ON";       // Valor inicial
var OptionImageSolver = "OFF";  // ImageSolver desactivado por defecto
var OptionDBE = "OFF";          // Valor inicial
var OptionVarStars = "OFF";     // No starless process until explicitly selected
var OptionMgc ="OFF";
var OptionVaonisVespera = "OFF";
var OptionFast = "OFF";
var VarPGlobal = "EMPTY";       // Valor inicial
var VarLicense ="EMPTY";        // Valor inicial
var NewGreenValue = 0.0;
var NewMagentaValue = 1;
var NewStarsValue = 1;
var isStarProcess = false; //Valor de paso por MiraGreen2()
var FinalFocusWindowId = "";
var FinalConvertedFocusWindowId = "";
var OptionHSOvar = "OFF";
var OptionSharpenNonstellar = 0.20;

// Verify the window contract between the main processing stages. A failed
// process must stop here instead of allowing a later optional stage to access
// a missing or stale window from another run.
function MiraRequirePipelineWindow(windowId, stageName)
{
   let window = ImageWindow.windowById(windowId);
   if (window && !window.isNull && window.mainView &&
       !window.mainView.isNull)
      return true;

   console.criticalln(
      "❌ " + stageName + " did not create the required window: " +
      windowId + ". Processing has been stopped safely.");
   return false;
}

function MiraValidateFinalWindowContract(requireStars, stageName)
{
   if (!MiraRequirePipelineWindow("Final_starless", stageName))
      return false;

   if (requireStars) {
      if (!MiraRequirePipelineWindow("Final_stars", stageName))
         return false;
      if (!MiraRequirePipelineWindow("Final_Result", stageName))
         return false;
   }

   return true;
}
// Interactive strengths are selected once on the first processed channel and
// reused for the remaining channels of the same Run operation.
var InteractiveProcessStrengths = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var InteractiveProcessMaskModes = {
   DeepSNR: "none",
   MLDenoise: "none",
   NoiseXTerminator: "none",
   BlurXTerminator: "none",
   HighPass: "none",
   NarrowbandToRGB: "none"
};
var InteractiveProcessMaskBanks = {
   DeepSNR: null,
   MLDenoise: null,
   NoiseXTerminator: null,
   BlurXTerminator: null,
   HighPass: null,
   NarrowbandToRGB: null
};
var NarrowbandToRGBCurveSettings = {
   temperature: 0,
   tint: 0,
   exposure: 0,
   contrast: 0,
   highlights: 0,
   shadows: 0,
   whites: 0,
   blacks: 0,
   saturation: 0
};
var RuntimeToken = "";
var OptionMergePro1  = "<Select an Image>";
var OptionshowConsolRadio = "ON";
var OptionRemaind2 = null;
var OptionSTFvar = "OFF";
var OptionEnabledPreview2 ="OFF";
var OptionGreen = "OFF";
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
var defaultProjectPath = GetDefaultLicenseFolder() + "/";
var originalFilePathMars1 = defaultProjectPath;
var originalFilePathMars2 = defaultProjectPath;
var originalFilePathMarsfin1 = defaultProjectPath;
var originalFilePathMarsfin2 = defaultProjectPath;
var originalFilePathMLDenoise = defaultProjectPath;
var originalFilePathMLDenoisefin = defaultProjectPath;
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MLDenoiseFound ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMarsFirst ="MARS-DR1-u01-1.0.1.xmars";
var StarMarsSecond ="MARS-DR2-1.0.3-s08.xmars";
var StarMLDenoiseModel ="MLDenoise_v5.xmlm";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;


console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
console.noteln("Checking third-party software:");
//asigna datos iniciales
defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";

// Restore the preferences saved from the Settings dialog. Invalid
// or missing values leave the built-in defaults unchanged.
let savedMgcSensorName = Settings.read("MgcSensorName", DataType_String);
if (typeof savedMgcSensorName === "string" &&
    savedMgcSensorName.trim().length > 0)
   SensorName = savedMgcSensorName;

let savedMgcNarrowband = Settings.read("MgcNarrowband", DataType_String);
if (savedMgcNarrowband === "ON" || savedMgcNarrowband === "OFF")
   Narrowband = savedMgcNarrowband;

function MiraRestorePositiveMgcNumber(key, fallback)
{
   let savedValue = Settings.read(key, DataType_Double);
   return typeof savedValue === "number" && isFinite(savedValue) &&
          savedValue > 0 ? savedValue : fallback;
}

defaultGrayWavelength = MiraRestorePositiveMgcNumber(
   "MgcGrayWavelength", defaultGrayWavelength);
defaultGrayBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGrayBandwidth", defaultGrayBandwidth);
defaultRedWavelength = MiraRestorePositiveMgcNumber(
   "MgcRedWavelength", defaultRedWavelength);
defaultRedBandwidth = MiraRestorePositiveMgcNumber(
   "MgcRedBandwidth", defaultRedBandwidth);
defaultGreenWavelength = MiraRestorePositiveMgcNumber(
   "MgcGreenWavelength", defaultGreenWavelength);
defaultGreenBandwidth = MiraRestorePositiveMgcNumber(
   "MgcGreenBandwidth", defaultGreenBandwidth);
defaultBlueWavelength = MiraRestorePositiveMgcNumber(
   "MgcBlueWavelength", defaultBlueWavelength);
defaultBlueBandwidth = MiraRestorePositiveMgcNumber(
   "MgcBlueBandwidth", defaultBlueBandwidth);

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}

//Ruta
getFilePath(originalFilePathMars1, originalFilePathMars2);

if (!RuntimeReady())
{
   CanStartApp = false;

   console.criticalln("Initialization cancelled.");

   new MessageBox(
      "Unable to initialize processing engine.",
      "AstroProcessor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();
}
else
{
   CanStartApp = true;
}

// Creación del diálogo principal
class IntegratorDialog extends Dialog {

    constructor() {

        super();

        this.windowTitle = ProjecTname;

    var self = this; // Save the `IntegratorDialog` instance context


    function createIntegrationOptionRadioButton(parent) {
       let container = new Control(parent);
       container.sizer = new HorizontalSizer;
       container.sizer.margin = 0;
       container.sizer.spacing = 0;

       let radioButton = new RadioButton(container);
       container.sizer.add(radioButton);
       radioButton.integrationOptionContainer = container;
       radioButton.checkedBeforeInteraction = false;

       radioButton.onMousePress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       radioButton.onKeyPress = function () {
          this.checkedBeforeInteraction = this.checked;
       };

       return radioButton;
    }

    function preserveIntegrationOptionToggle(radioButton) {
       let originalOnClick = radioButton.onClick;

       radioButton.onClick = function () {

          this.checked = !this.checkedBeforeInteraction;
          this.checkedBeforeInteraction = this.checked;

          if (originalOnClick)
             originalOnClick.call(this);
       };
    }

    function addIntegrationOption(sizer, radioButton) {
       sizer.add(radioButton.integrationOptionContainer);
    }


    // Allow native resizing from every edge and from the lower-right corner.
    // In PJSR the valid Dialog property is userResizable (not resizeable).
    this.userResizable = true;

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 650;


    // Creación del contenedor de pestañas
    this.tabBox = new TabBox(this);


//-----------------------------------------------------------------------------
//Pestaña Integration----------------------------------------------------------
//-----------------------------------------------------------------------------

    // --- Tab 1: Integration ---
    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;

    // Crear un HorizontalSizer para mantener los dos GroupBoxes en horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Espacio entre los elementos

  // --- GroupBox: Project Type ---
    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "2. Gradients:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.ImageSolverCheckBox = new CheckBox(this.integrationPage);
    this.ImageSolverCheckBox.text = "Run ImageSolver";
    this.ImageSolverCheckBox.checked = false;
    this.ImageSolverCheckBox.enabled = true;
    this.ImageSolverCheckBox.toolTip =
       "Run ImageSolver on every selected project image before processing.";

    this.ImageSolverCheckBox.onClick = function () {
       OptionImageSolver = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Run ImageSolver = " + OptionImageSolver);
       this.dialog.update();
    };

    this.gradientCorrectionLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientCorrectionLabel.text = "Select gradient correction:";
    this.gradientCorrectionLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;

    this.gradientCorrectionComboBox = new ComboBox(this.CropprojectTypeGroupBox);
    this.gradientCorrectionComboBox.addItem("Run Gradient Correction");
    this.gradientCorrectionComboBox.addItem("Run Multiscale Gradient Correction");
    this.gradientCorrectionComboBox.currentItem = 0;
    this.gradientCorrectionComboBox.setScaledMinWidth(240);

    this.gradientCorrectionComboBox.onItemSelected = function (itemIndex) {
       if (itemIndex === 0) {
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.noteln("⚙️ Gradient Correction = ON");
          console.noteln("⚙️ Multiscale Gradient Correction : OFF");
          return;
       }

       new MessageBox(
          "Remember to adjust the SFC parameters using the 'Settings' button before running the script.\n\n" +
          "MGC requires SFC calibration, MARS and Gaia DR3/SP databases.",
          "Multiscale Gradient Correction",
          StdIcon_Information,
          StdButton_Ok
       ).execute();

       try {
          new MultiscaleGradientCorrection();
          console.noteln("🟢 MultiscaleGradientCorrection is available.");
       } catch (error) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
          new MessageBox(
             "MultiscaleGradientCorrection is not available in this PixInsight version.",
             "AstroProcessor",
             StdIcon_Error,
             StdButton_Ok
          ).execute();
          return;
       }

       if (!MiraValidateMgcConfiguration(true)) {
          this.currentItem = 0;
          OptionGradient = "ON";
          OptionMgc = "OFF";
          return;
       }

       OptionGradient = "OFF";
       OptionMgc = "ON";
       console.noteln("⚙️ Gradient Correction = OFF");
       console.noteln("⚙️ Multiscale Gradient Correction : ON");
    };


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionLabel);
    this.CropprojectTypeGroupBox.sizer.add(this.gradientCorrectionComboBox);
    this.gradientSettingsLabel = new Label(this.CropprojectTypeGroupBox);
    this.gradientSettingsLabel.text = "Clic on 'Settings' for SFC and MGC options";
    this.gradientSettingsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.CropprojectTypeGroupBox.sizer.add(this.gradientSettingsLabel);
    this.CropprojectTypeGroupBox.adjustToContents();
    this.CropprojectTypeGroupBox.setFixedHeight(
       this.CropprojectTypeGroupBox.height
    );


   // Crea el Checkbox para Ha para poder manejarlo

    this.HalphaCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.HalphaCheckBox.text = "Create 'HAlpha' for blending (RGB/LRGB)";
    this.HalphaCheckBox.checked = false;  // Predeterminado activado

    // --- GroupBox: Project Type ---

    function MiraComboProyect() {
    // Disable all ComboBoxes by default
    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].enabled = false;
        self.comboBoxReferences[key].update();
    }

    // Enable specific ComboBoxes based on project type
    switch (ProjecTypevar) {
        case "RGB":
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            self.comboBoxReferences["PimageLuminance"].enabled = true;
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            self.comboBoxReferences["PimageSii"].enabled = true;
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            self.comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }

    // Update the UI
    for (let key in self.comboBoxReferences) {
        self.comboBoxReferences[key].update();
    }

    if (self.NarrowbandToRGBCheckBox) {
        // The color-adjustment controls are useful for every color project.
        // SHO/HOO additionally receive their dedicated palette conversion.
        self.NarrowbandToRGBCheckBox.enabled = true;
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "1. Project:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    let imageSolverWasEnabledBeforeVaonis = false;
    let imageSolverWasCheckedBeforeVaonis = false;
    let imageSolverForcedByVaonis = false;

    function selectProjectType(projectType, enableFast, vaonisMode) {
       ProjecTypevar = projectType;
       OptionVaonisVespera = vaonisMode ? "ON" : "OFF";

       if (self.oscImageLabel) {
          self.oscImageLabel.text = vaonisMode ? "Vaonis Vespera:" : "OSC Image:";
          self.oscImageLabel.update();
       }

       if (vaonisMode) {
          if (!imageSolverForcedByVaonis) {
             imageSolverWasEnabledBeforeVaonis = self.ImageSolverCheckBox.enabled;
             imageSolverWasCheckedBeforeVaonis = self.ImageSolverCheckBox.checked;
          }

          self.ImageSolverCheckBox.checked = true;
          self.ImageSolverCheckBox.enabled = false;
          OptionImageSolver = "ON";
          imageSolverForcedByVaonis = true;
          console.noteln("⚙️ Vaonis Vespera mode: interactive ImageSolver enabled.");
       }
       else if (imageSolverForcedByVaonis) {
          self.ImageSolverCheckBox.enabled = imageSolverWasEnabledBeforeVaonis;
          self.ImageSolverCheckBox.checked = imageSolverWasCheckedBeforeVaonis;
          OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
          imageSolverForcedByVaonis = false;
       }

       self.FastCheckBox.enabled = enableFast;
       if (!enableFast) {
          self.FastCheckBox.checked = false;
          self.FastCheckBox.text = "Fast integration mode 'OFF' ";
          self.FastCheckBox.styleSheet = "color: black;";
          OptionFast = "OFF";
       }

       let narrowbandProject = projectType === "SHO" || projectType === "HOO";
       let rgbProject = projectType === "RGB" || projectType === "LRGB";

       if (self.finalStarsComboBox && !narrowbandProject &&
           self.finalStarsComboBox.currentItem === 2) {
          self.finalStarsComboBox.currentItem = 0;
          Option1var = "OFF";
          OptionHSOvar = "OFF";
       }

       if (self.HalphaCheckBox) {
          self.HalphaCheckBox.enabled = rgbProject;
          if (!rgbProject) {
             self.HalphaCheckBox.checked = false;
             OptionHavar = "OFF";
          }
       }

       MiraComboProyect();
       self.update();
    }

    this.projectTypeComboBox = new ComboBox(this.projectTypeGroupBox);
    this.projectTypeComboBox.addItem("LRGB");
    this.projectTypeComboBox.addItem("RGB");
    this.projectTypeComboBox.addItem("SHO");
    this.projectTypeComboBox.addItem("HOO");
    this.projectTypeComboBox.addItem("OSC (RGB Color camera .xisf or Raw)");
    this.projectTypeComboBox.addItem("VAONIS VESPERA (.tiff)");
    this.projectTypeComboBox.currentItem = 2;
    this.projectTypeComboBox.setScaledMinWidth(240);
    this.projectTypeComboBox.toolTip =
       "Select the project type. VAONIS VESPERA TIFF mode automatically " +
       "opens ImageSolver when an astrometric solution is required.";

    this.projectTypeComboBox.onItemSelected = function (itemIndex) {
       let projectTypes = ["LRGB", "RGB", "SHO", "HOO", "OSC", "OSC"];
       let enableFast = itemIndex !== 4 && itemIndex !== 5;
       selectProjectType(projectTypes[itemIndex], enableFast, itemIndex === 5);
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;
    this.projectTypeLabel = new Label(this.projectTypeGroupBox);
    this.projectTypeLabel.text = "Select project type:";
    this.projectTypeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
    this.projectTypeGroupBox.sizer.add(this.projectTypeLabel);
    this.projectTypeGroupBox.sizer.add(this.projectTypeComboBox);
    this.projectTypeGroupBox.sizer.add(this.ImageSolverCheckBox);
    this.projectTypeGroupBox.adjustToContents();
    this.projectTypeGroupBox.setFixedHeight(this.projectTypeGroupBox.height);


    // --- GroupBox: Alignment Type ---


    // Añadir los dos GroupBoxes al HorizontalSizer para que estén en la misma fila

    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);



    // --- GroupBox: Tagging ---
    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "3. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    self.comboBoxReferences = {};

    // Platform-independent label column width. Using the current PJSR font
    // metrics keeps the gap compact on macOS, Windows and Linux while leaving
    // enough room for the longest label.
    let taggingLabelWidth = this.font.width("Luminance Image:M");

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer; // Alineación horizontal
       rowSizer.spacing = 6; // Espaciado entre elementos

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(taggingLabelWidth);

       if (variableKey === "PimageOsc")
          self.oscImageLabel = label;

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];

           if (!window || window.isNull || !window.mainView || window.mainView.isNull)
               continue;

           // Los procesos posteriores buscan ventanas por su identificador de vista.
           // Usar el nombre de archivo aquí puede ser ambiguo y no tiene por qué
           // coincidir con mainView.id.
           comboBox.addItem(window.mainView.id);
       }

       self.comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = index === 0 ? "EMPTY" : comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
       };

       // Agregar los elementos al mismo HorizontalSizer
       rowSizer.add(label);
       rowSizer.add(comboBox, 1); // Expande el ComboBox para alineación correcta

       // Agregar el rowSizer al parentSizer
       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;

      // Añadir cada control con el nuevo formato en línea
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC Image:", "PimageOsc");
      this.taggingGroupBox.sizer.addSpacing(6);

      // Agregar las pestañas al TabBox debajo de los 2 grupos
      //this.tabBox.addPage(this.integrationPage, "Integration");


    // --- GroupBox: Project Options ---
    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "4. Third-party software:";
    this.optionsGroupBox.sizer = new VerticalSizer;

    // Crear un `VerticalSizer` para la primera columna
    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;

    // Checkboxes para la primera columna
      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;  // Predeterminado deshabilitado
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.FastCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
   this.FastCheckBox.text = "Fast integration mode 'OFF' "; // Texto inicial
   this.FastCheckBox.checked = false; // Estado inicial

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' "; // Cambiar el texto cuando está activado
           this.styleSheet = "color: blue;";
           console.writeln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = "Fast integration mode 'OFF' "; // Cambiar el texto cuando está desactivado
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


    this.NarrowbandToRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.NarrowbandToRGBCheckBox.text = "Image Editor";
    this.NarrowbandToRGBCheckBox.checked = true;
    this.NarrowbandToRGBCheckBox.enabled = true;
    this.NarrowbandToRGBCheckBox.onClick = function () {
        OptionNarrowbandToRGB = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ Image Editor: " + OptionNarrowbandToRGB);
    };

    this.darkStructureEnhanceCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.darkStructureEnhanceCheckBox.text = "Enhance Dark structures";
    this.darkStructureEnhanceCheckBox.checked = true;
    this.darkStructureEnhanceCheckBox.onClick = function () {
        OptionDarkStructureEnhance = this.checked ? "ON" : "OFF";
        console.noteln("⚙️ Enhance Dark structures: " +
                       OptionDarkStructureEnhance);
    };

    this.finalStarRefinementCheckBox =
       createIntegrationOptionRadioButton(this.integrationPage);
    this.finalStarRefinementCheckBox.text = "Star Refinement";
    this.finalStarRefinementCheckBox.checked = false;
    this.finalStarRefinementCheckBox.enabled = false;
    this.finalStarRefinementCheckBox.onClick = function () {
       if (this.checked && OptionVarStars !== "ON") {
          this.checked = false;
          OptionFinalStarRefinement = "OFF";
          console.warningln(
             "⚠️ Star Refinement requires a Final_starless method.");
          return;
       }
       OptionFinalStarRefinement = this.checked ? "ON" : "OFF";
       console.noteln("⚙️ Star Refinement: " +
                      OptionFinalStarRefinement);
    };

    this.resolutionCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.resolutionCheckBox.text = "300ppi Print Resolution";
    this.resolutionCheckBox.checked = false;
    this.resolutionCheckBox.onClick = function () {
          // Actualizar la variable según el estado del CheckBox
          if (this.checked) {
              Option300 = "ON";
              console.noteln("⚙️ 300ppi Print Resolution: ON");
          } else {
              Option300 = "OFF";
              console.noteln("⚙️ 300ppi Print Resolution: OFF");
          }

      };

 // Configuración inicial para el proyecto
    ProjecTypevar = "SHO"; // Establecer el tipo de proyecto por defecto
    MiraComboProyect();    // Configurar los ComboBoxes al iniciar el diálogo

    // Legacy state proxy kept outside every sizer while the processing code
    // is migrated to the new menu-driven interface.
    this.OptionVarStarsCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.OptionVarStarsCheckBox.integrationOptionContainer.visible = false;
    this.starsHSOCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsHSOCheckBox.integrationOptionContainer.visible = false;

    // Checkboxes para la segunda columna
    this.starsRGBCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    var self = this; // Guardar referencia al contexto actual



    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.warningln("\n⚠️ Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


    if (!this.checked) {
        Option1var = "OFF";
        console.noteln("⚙️ Create RGB 'Final_stars' : OFF");
        return;
    }

    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
            self.comboBoxReferences["PimageRed"].enabled = true;
            self.comboBoxReferences["PimageGreen"].enabled = true;
            self.comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            OptionHSOvar = "OFF";
            self.starsHSOCheckBox.checked = false;
            //recuerda el proyecto anterior.
            ProjecTypevar2 = "1";
            self.starsRGBCheckBox.checked = true;

    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        self.comboBoxReferences["PimageRed"].enabled = false;
        self.comboBoxReferences["PimageGreen"].enabled = false;
        self.comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        Option1var = "OFF";
        self.update();
    }
}; // Fin del checkbox




var self = this; // Guardar referencia al contexto principal

// Añadir el nuevo Checkbox para StarXterminator
self.starXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
self.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
self.starXterminatorCheckBox.checked = true;  // Predeterminado activado



// Añadir el nuevo Checkbox para StarNet2
this.starNetCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;  // Predeterminado desactivado

//Opciones del checkbox de starless
this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           if (starXterminatorInstalled) {
              self.starXterminatorCheckBox.checked = true;
              self.starNetCheckBox.checked = false;
              OptionStarXterminator = "ON";
           } else if (starNet2Installed) {
              self.starXterminatorCheckBox.checked = false;
              self.starNetCheckBox.checked = true;
              OptionStarXterminator = "OFF";
           } else {
              this.checked = false;
              OptionVarStars = "OFF";
              OptionStarXterminator = "OFF";
              console.warningln("⚠️ StarXTerminator or StarNet2 must be installed to create a starless image.");
              return;
           }

           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = starXterminatorInstalled;
           self.starNetCheckBox.enabled = starNet2Installed;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           OptionHSOvar = "ON";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = false;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "OFF";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           OptionHSOvar = "OFF";
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           Option1var = "OFF";
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };
//


// Variable para almacenar el método seleccionado
let starRemovalMethodLabel = "Star Removal by StarXterminator";  // Predeterminado
OptionStarXterminator = "ON";


// Evento onClick para gestionar el cambio entre StarXterminator y StarNet2
self.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        if (!starXterminatorInstalled) {
            this.checked = false;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarNet2 cuando se selecciona StarXterminator
        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";

        console.writeln("Fast Process !!!");
    } else {
        if (!starNet2Installed) {
            this.checked = true;
            OptionStarXterminator = "ON";
            console.warningln("⚠️ StarNet2 is not installed. StarXTerminator remains selected.");
            return;
        }

        // Si se desactiva StarXterminator, activar StarNet2.
        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};

// Evento onClick para gestionar el cambio entre StarNet2 y StarXterminator
this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        if (!starNet2Installed) {
            this.checked = false;
            console.warningln("⚠️ StarNet2 is not installed.");
            return;
        }

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarXterminator cuando se selecciona StarNet2
        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");

        console.writeln("Slow Process !!!");
    } else {
        if (!starXterminatorInstalled) {
            this.checked = true;
            OptionStarXterminator = "OFF";
            console.warningln("⚠️ StarXTerminator is not installed. StarNet2 remains selected.");
            return;
        }

        // Si se desactiva StarNet2, activar StarXterminator.
        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};



   // Añadir el nuevo Checkbox para BlurXterminator
    this.blurXterminatorCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;  // Predeterminado activado

    // Añadir el nuevo Checkbox para Highpass
    this.highPassCheckBox = createIntegrationOptionRadioButton(this.integrationPage);
    this.highPassCheckBox.text = "Sharpen by High pass filter";
    this.highPassCheckBox.checked = false;  // Predeterminado activado




    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.warningln("⚠️ Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;
    //var OptionHSOvar = "OFF";

    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("Enable Ha Image for blending?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
            self.comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        self.comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
}; // Fin del checkbox

    this.blurXterminatorCheckBox.onClick = function () {
        if (this.checked && !blurXterminatorInstalled) {
           this.checked = false;
           self.highPassCheckBox.checked = true;
           OptionBlurXterminator = "OFF";
           OptionHighpass = "ON";
           console.warningln("⚠️ BlurXTerminator is not installed. Sharpen by High pass filter remains enabled.");
           return;
        }

        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {
        // Si StarXterminator está apagado, cambiar el texto para usar StarNet2
         self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
         OptionHighpass = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator : OFF. High pass filter enabled.");

           } else {
        // Si StarXterminator está encendido, usar StarXterminator
         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
         OptionHighpass = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator : ON");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";

         if (!this.checked && !blurXterminatorInstalled) {
            this.checked = true;
            self.blurXterminatorCheckBox.checked = false;
            OptionHighpass = "ON";
            OptionBlurXterminator = "OFF";
            console.warningln("⚠️ BlurXTerminator is not installed. Sharpen by High pass filter is required.");
            return;
         }

         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'ON'. High pass filter disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'OFF'. High pass filter enabled.");
       }
      };

    // These controls are not part of the interface. They only preserve a few
    // legacy callback references until the underlying processing modules are
    // fully independent from UI control objects.
    let legacyHiddenControls = [
       this.OptionVarStarsCheckBox,
       this.starsHSOCheckBox,
       this.starsRGBCheckBox,
       self.starXterminatorCheckBox,
       this.starNetCheckBox,
       this.blurXterminatorCheckBox,
       this.highPassCheckBox
    ];
    for (let i = 0; i < legacyHiddenControls.length; ++i)
       legacyHiddenControls[i].integrationOptionContainer.visible = false;

    let integrationOptionRadioButtons = [
       this.FastCheckBox,
       this.NarrowbandToRGBCheckBox,
       this.HalphaCheckBox,
       this.darkStructureEnhanceCheckBox,
       this.resolutionCheckBox
    ];

    for (let i = 0; i < integrationOptionRadioButtons.length; ++i)
       preserveIntegrationOptionToggle(integrationOptionRadioButtons[i]);




    // Group 4: mutually exclusive third-party processing menus. Index zero
    // disables the corresponding category completely.
    this.optionsGroupBox.sizer.margin = 6;
    this.optionsGroupBox.sizer.spacing = 10;

    function addThirdPartyCombo(combo, items) {
       combo.setScaledMinWidth(240);
       for (let i = 0; i < items.length; ++i)
          combo.addItem(items[i]);
       combo.currentItem = 0;
       self.optionsGroupBox.sizer.add(combo);
    }

    function warnMissingThirdPartyPlugin(pluginName) {
       console.warningln("⚠️ " + pluginName +
          " plugin is not installed. Choose another option.");
    }

    this.noiseReductionComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.noiseReductionComboBox, [
       "<Select noise reduction>",
       "DeepSNR",
       "MLDenoise",
       "NoiseXTerminator"
    ]);

    this.noiseReductionComboBox.onItemSelected = function (itemIndex) {
       OptionGraXNoise = "OFF";
       OptionMLDenoise = "OFF";
       OptionNoiseXterminator = "OFF";

       if (itemIndex === 1) {
          if (!deepSNRInstalled) {
             this.currentItem = 0;
             warnMissingThirdPartyPlugin("DeepSNR");
             return;
          }
          OptionGraXNoise = "ON";
          console.noteln("⚙️ Noise reduction: DeepSNR");
       }
       else if (itemIndex === 2) {
          if (!mlDenoiseInstalled) {
             this.currentItem = 0;
             warnMissingThirdPartyPlugin("MLDenoise");
             return;
          }
          if (!IsUsableMLDenoisePath(originalFilePathMLDenoisefin)) {
             this.currentItem = 0;
             console.warningln(
                "⚠️ MLDenoise model is not configured. Choose another option.");
             return;
          }
          OptionMLDenoise = "ON";
          console.noteln("⚙️ Noise reduction: MLDenoise");
       }
       else if (itemIndex === 3) {
          if (!noiseXterminatorInstalled) {
             this.currentItem = 0;
             warnMissingThirdPartyPlugin("NoiseXTerminator");
             return;
          }
          OptionNoiseXterminator = "ON";
          console.noteln("⚙️ Noise reduction: NoiseXTerminator");
       }
       else {
          console.noteln("⚙️ Noise reduction: OFF");
       }
    };

    this.sharpenComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.sharpenComboBox, [
       "<Select Sharpen>",
       "BlurXTerminator",
       "High pass filter"
    ]);

    this.sharpenComboBox.onItemSelected = function (itemIndex) {
       OptionBlurXterminator = "OFF";
       OptionHighpass = "OFF";

       if (itemIndex === 1) {
          if (!blurXterminatorInstalled) {
             this.currentItem = 0;
             warnMissingThirdPartyPlugin("BlurXTerminator");
             return;
          }
          OptionBlurXterminator = "ON";
          console.noteln("⚙️ Sharpen: BlurXTerminator");
       }
       else if (itemIndex === 2) {
          OptionHighpass = "ON";
          console.noteln("⚙️ Sharpen: High pass filter");
       }
       else {
          console.noteln("⚙️ Sharpen: OFF");
       }
    };

    this.starlessMethodComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.starlessMethodComboBox, [
       "No create 'Final_starless'",
       "Create 'Final_starless' by StarXTerminator",
       "Create 'Final_starless' by StarXNet2"
    ]);

    this.finalStarsComboBox = new ComboBox(this.optionsGroupBox);
    addThirdPartyCombo(this.finalStarsComboBox, [
       "<Create 'Final_stars' image (Project stars)>",
       "Create 'Final_stars' image (Project stars)",
       "Create RGB 'Final_stars' (SHO/HOO)"
    ]);
    this.finalStarsComboBox.enabled = false;

    function resetFinalStarsSelection() {
       self.finalStarsComboBox.currentItem = 0;
       OptionHSOvar = "OFF";
       Option1var = "OFF";
       self.finalStarRefinementCheckBox.checked = false;
       self.finalStarRefinementCheckBox.enabled = false;
       OptionFinalStarRefinement = "OFF";
       FinalStarRefinementReady = false;
       MiraComboProyect();
    }

    function enableFinalStarRefinement() {
       self.finalStarRefinementCheckBox.enabled = true;
       self.finalStarRefinementCheckBox.checked = true;
       OptionFinalStarRefinement = "ON";
       FinalStarRefinementReady = false;
    }

    this.starlessMethodComboBox.onItemSelected = function (itemIndex) {
       OptionVarStars = "OFF";
       OptionStarXterminator = "OFF";

       if (itemIndex === 1 && !starXterminatorInstalled) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarXTerminator");
          return;
       }

       if (itemIndex === 2 && !starNet2Installed) {
          this.currentItem = 0;
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          warnMissingThirdPartyPlugin("StarNet2");
          return;
       }

       if (itemIndex === 0) {
          self.finalStarsComboBox.enabled = false;
          resetFinalStarsSelection();
          console.noteln("⚙️ Final_starless creation: OFF");
          return;
       }

       OptionVarStars = "ON";
       OptionStarXterminator = itemIndex === 1 ? "ON" : "OFF";
       self.finalStarsComboBox.enabled = true;
       // Project stars are the real default whenever a starless method is
       // selected. A programmatic ComboBox selection does not emit
       // onItemSelected, so update both the interface and processing flags.
       self.finalStarsComboBox.currentItem = 1;
       OptionHSOvar = "ON";
       Option1var = "OFF";
       enableFinalStarRefinement();
       MiraComboProyect();
       console.noteln("⚙️ Final_starless method: " +
          (itemIndex === 1 ? "StarXTerminator" : "StarNet2"));
       console.noteln("⚙️ Final_stars: Project stars (default)");
    };

    this.finalStarsComboBox.onItemSelected = function (itemIndex) {
       OptionHSOvar = "OFF";
       Option1var = "OFF";

       if (itemIndex === 0) {
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
          console.noteln("⚙️ Final_stars creation: OFF");
          return;
       }

       if (OptionVarStars !== "ON") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ Select a Final_starless method first.");
          return;
       }

       if (itemIndex === 1) {
          OptionHSOvar = "ON";
          enableFinalStarRefinement();
          MiraComboProyect();
          console.noteln("⚙️ Final_stars: Project stars");
          return;
       }

       if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          console.warningln("⚠️ RGB Final_stars is only available for SHO and HOO projects.");
          return;
       }

       let msgBox = new MessageBox(
          "Enable RGB Images for stars?",
          "Confirmation",
          StdIcon_Question,
          StdButton_Yes,
          StdButton_No
       );

       if (msgBox.execute() === StdButton_Yes) {
          self.comboBoxReferences["PimageRed"].enabled = true;
          self.comboBoxReferences["PimageGreen"].enabled = true;
          self.comboBoxReferences["PimageBlue"].enabled = true;
          Option1var = "ON";
          ProjecTypevar2 = "1";
          enableFinalStarRefinement();
          console.noteln("⚙️ Final_stars: RGB stars");
       }
       else {
          this.currentItem = 0;
          self.finalStarRefinementCheckBox.checked = false;
          self.finalStarRefinementCheckBox.enabled = false;
          OptionFinalStarRefinement = "OFF";
          FinalStarRefinementReady = false;
          MiraComboProyect();
       }
    };

    // Group 5: independent final output options.
    this.finalOptionsGroupBox = new GroupBox(this.integrationPage);
    this.finalOptionsGroupBox.title = "5. Final options:";
    this.finalOptionsGroupBox.sizer = new VerticalSizer;
    this.finalOptionsGroupBox.sizer.margin = 6;
    this.finalOptionsGroupBox.sizer.spacing = 6;
    this.finalOptionsGroupBox.sizer.add(this.linkRGBChannels);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.FastCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.HalphaCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.finalStarRefinementCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.darkStructureEnhanceCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.NarrowbandToRGBCheckBox);
    addIntegrationOption(this.finalOptionsGroupBox.sizer, this.resolutionCheckBox);

    this.optionsGroupsSizer = new HorizontalSizer;
    this.optionsGroupsSizer.spacing = 10;
    this.optionsGroupsSizer.add(this.optionsGroupBox);
    this.optionsGroupsSizer.add(this.finalOptionsGroupBox);


    // --- Option page ---
    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;






//-----------------------------------------------------------------------------
//Pestaña Licencia-------------------------------------------------------------
//-----------------------------------------------------------------------------

      // --- Tab 3: License ---
      this.licensePage = new Control(this);
      this.licensePage.sizer = new VerticalSizer;
      this.licensePage.sizer.margin = 10;
      this.licensePage.sizer.spacing = 6;

      let licenseGroupBox = new GroupBox(this.licensePage);
      licenseGroupBox.title = "License Information";
      licenseGroupBox.sizer = new VerticalSizer;
      licenseGroupBox.sizer.margin = 6;
      licenseGroupBox.sizer.spacing = 4;

      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      emailLabel.setFixedWidth(105);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";  // Inicializar con una cadena vacía o algún valor por defecto
      this.emailEdit.enabled = false;

      let emailSizer = new HorizontalSizer;
      emailSizer.spacing = 8;
      emailSizer.add(emailLabel);
      emailSizer.add(this.emailEdit, 1);
      licenseGroupBox.sizer.add(emailSizer);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      codeLabel.setFixedWidth(105);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";  // Inicializar con una cadena vacía
      this.codeEdit.enabled = false;

      let codeSizer = new HorizontalSizer;
      codeSizer.spacing = 8;
      codeSizer.add(codeLabel);
      codeSizer.add(this.codeEdit, 1);
      licenseGroupBox.sizer.add(codeSizer);

      let expiryLabel = new Label(this);
      expiryLabel.text = "Expiry:";
      expiryLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      expiryLabel.setFixedWidth(105);

      this.expiryEdit = new Edit(this);
      this.expiryEdit.minWidth = 300;
      this.expiryEdit.text = "2027-01-01";
      this.expiryEdit.enabled = false;

      let expirySizer = new HorizontalSizer;
      expirySizer.spacing = 8;
      expirySizer.add(expiryLabel);
      expirySizer.add(this.expiryEdit, 1);
      licenseGroupBox.sizer.add(expirySizer);

      let machineIdLabel = new Label(this);
      machineIdLabel.text = "Machine ID:";
      machineIdLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      machineIdLabel.setFixedWidth(105);

      this.machineIdEdit = new Edit(this);
      this.machineIdEdit.minWidth = 300;
      this.machineIdEdit.text = GetOrCreateMachineId();
      this.machineIdEdit.enabled = true;
      this.machineIdEdit.readOnly = true;

      let machineIdSizer = new HorizontalSizer;
      machineIdSizer.spacing = 8;
      machineIdSizer.add(machineIdLabel);
      machineIdSizer.add(this.machineIdEdit, 1);
      licenseGroupBox.sizer.add(machineIdSizer);

      let signatureLabel = new Label(this);
      signatureLabel.text = "Signature:";
      signatureLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      signatureLabel.setFixedWidth(105);

      this.signatureEdit = new Edit(this);
      this.signatureEdit.minWidth = 300;
      this.signatureEdit.text = "";
      this.signatureEdit.enabled = false;
      this.signatureEdit.toolTip = "Paste the complete 512-character signature.";

      let signatureSizer = new HorizontalSizer;
      signatureSizer.spacing = 8;
      signatureSizer.add(signatureLabel);
      signatureSizer.add(this.signatureEdit, 1);
      licenseGroupBox.sizer.add(signatureSizer);

      let PathcodeLabel = new Label(this);
      PathcodeLabel.text = "Path: ";
      PathcodeLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
      PathcodeLabel.setFixedWidth(105);

      this.PathcodeEdit = new Edit(this);
      this.PathcodeEdit.minWidth = 300;
      this.PathcodeEdit.text = "";  // Inicializar con una cadena vacía
      this.PathcodeEdit.enabled = false;
      this.PathcodeEdit.readOnly = true;

      let pathSizer = new HorizontalSizer;
      pathSizer.spacing = 8;
      pathSizer.add(PathcodeLabel);
      pathSizer.add(this.PathcodeEdit, 1);
      licenseGroupBox.sizer.add(pathSizer);

      let NotaLabel = new Label(this);
      NotaLabel.text = "* Send this Machine ID when requesting or renewing a license.";
      NotaLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(NotaLabel);




      // Llamada a ReadLicenseFile después de que los campos se han creado
      // Llamada a ReadLicenseFile después de que los campos se han creado
      var self = this;

      let filePath = LoadLicensePath();

      if (File.exists(filePath))
      {
        let license = ReadLicenseDataSilent();

            if (IsLicenseComplete(license))
            {
               self.emailEdit.text = license.email;
               self.codeEdit.text = license.code;
               self.expiryEdit.text = license.expiry;
               self.signatureEdit.text = license.signature;
               self.PathcodeEdit.text = filePath;
            }
            else
            {
               console.warningln("Running in trial mode.");

               self.emailEdit.text = "";
               self.codeEdit.text = "";
               self.expiryEdit.text = "2027-01-01";
               self.PathcodeEdit.text = filePath;
            }
      }
      else
      {
         self.PathcodeEdit.text = filePath;
         self.emailEdit.text = "";
         self.codeEdit.text = "";
      }


      // Separación compacta antes de los botones. Una Label vacía ocupaba
      // demasiada altura y dejaba la fila pegada al borde inferior del marco.
      licenseGroupBox.sizer.addSpacing(6);

      // Crear una sizer horizontal para los botones "Edit" y "Validate"
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones


      let EditvalidateButton = new PushButton(this);
      EditvalidateButton.text = "Edit";
      EditvalidateButton.icon = this.scaledResource( ":/icons/pencil.png" );
      EditvalidateButton.setFixedWidth(150);
      EditvalidateButton.setFixedHeight(WindowsOsx1 + 5);
      buttonSizer.add(EditvalidateButton);

          EditvalidateButton.onClick = function () {

             let msgBox = new MessageBox(
             "Editing License Process\nDo you want to continue?",  // Message text
             "Confirmation",  // Title
             StdIcon_Question,  // Question icon
             StdButton_Yes, StdButton_No  // Yes/No buttons
             );

             let result = msgBox.execute();  // Show the MessageBox and capture the result

             // If the user clicks 'Yes', proceed with writing the license file
             if (result === StdButton_Yes) {
                EditvalidateButton.enabled  =false;
               console.noteln("\n💾"+ " Editing License...");
                self.signatureEdit.enabled = true;
                self.emailEdit.enabled = true;
                self.codeEdit.enabled = true;
                self.expiryEdit.enabled = true;
                self.PathcodeEdit.enabled = false;
                validateButton.enabled = true;


              } else {
                 self.signatureEdit.enabled = false;
                  self.emailEdit.enabled = false;
                  self.codeEdit.enabled = false;
                  self.PathcodeEdit.enabled = false;
              }
              };

              let validateButton = new PushButton(this);
              validateButton.text = "Validate";
              validateButton.icon = this.scaledResource( ":/icons/ok.png" );
              validateButton.setFixedWidth(150);
              validateButton.setFixedHeight(WindowsOsx1 + 5);
              validateButton.enabled = false;
              buttonSizer.add(validateButton);
              validateButton.onClick = function () {
               //

              let email = self.emailEdit.text ? self.emailEdit.text.trim() : "";
let code = self.codeEdit.text ? self.codeEdit.text.trim() : "";
let expiry = self.expiryEdit.text ? self.expiryEdit.text.trim() : "";
let machineId = self.machineIdEdit.text ? self.machineIdEdit.text.trim() : "";
let signature = self.signatureEdit.text ?
   self.signatureEdit.text.replace(/\s/g, "") : "";
let path = self.PathcodeEdit.text ? self.PathcodeEdit.text.trim() : "";

if (path === "")
   path = GetDefaultLicenseFile();

if (email === "" || code === "" || expiry === "" ||
    machineId === "" || signature === "")
{
   new MessageBox(
      "Email, Code, Expiry, Machine ID and Signature are required.",
      "AstroProcessor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();

   return;
}

let licenseCandidate = {
   scheme: LICENSE_SCHEME,
   email: email,
   code: code,
   expiry: expiry,
   machineId: machineId,
   signature: signature
};

if (!IsLicenseSignatureValid(licenseCandidate))
{
   new MessageBox(
      "License could not be activated.\n\nInvalid license data.",
      "AstroProcessor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();

   return;
}

if (IsLicenseExpired(expiry))
{
   new MessageBox(
      "Your license has expired.\n\nPlease renew your AstroProcessor license.",
      "AstroProcessor",
      StdIcon_Error,
      StdButton_Ok
   ).execute();

   return;
}

WriteLicenseDat(path, email, code, expiry, machineId, signature);

RuntimeToken = signature.substr(0, 8);
VarLicense = "FULL";
self.runButton.enabled = true;
UpdateLicenseActivationStatus();

self.signatureEdit.enabled = false;
self.emailEdit.enabled = false;
self.codeEdit.enabled = false;
self.expiryEdit.enabled = false;
validateButton.enabled = false;
EditvalidateButton.enabled = true;

new MessageBox(
   "License activated successfully.",
   "AstroProcessor",
   StdIcon_Information,
   StdButton_Ok
).execute();

console.noteln("✅ License activated:");
console.writeln(path);

              }
               //







//Fin File import

      licenseGroupBox.sizer.add(buttonSizer);
      licenseGroupBox.sizer.addSpacing(14);
      licenseGroupBox.adjustToContents();  // Ajustamos el grupo al contenido

      //
      // Crear el GroupBox para "License Activation"
      let licenseActivationGroupBox = new GroupBox(this.licensePage);
      licenseActivationGroupBox.title = "License Activation";
      licenseActivationGroupBox.sizer = new VerticalSizer;
      licenseActivationGroupBox.sizer.margin = 6;
         licenseActivationGroupBox.sizer.spacing = 4;

      // Añadir el texto de información sobre la activación de la licencia
      let activationInfoLabel = new Label(this);
      activationInfoLabel.useRichText = true; // Permitir HTML en el texto

      function UpdateLicenseActivationStatus()
      {
         let licenseStatusText = "NOT ACTIVATED";
         let remainingTimeText = "";

         if (VarLicense === "PROJECT")
         {
            licenseStatusText = "TRIAL";
            remainingTimeText =
               "Trial days left: " + GetTrialDaysLeft() + "<br>";
         }
         else if (VarLicense === "FULL")
         {
            licenseStatusText = "LICENSED";

            let activeLicense = ReadLicenseDataSilent();
            if (IsLicenseComplete(activeLicense))
            {
               remainingTimeText =
                  "Days until renewal: " +
                  GetLicenseDaysLeft(activeLicense.expiry) + "<br>" +
                  "Renewal date: " + activeLicense.expiry + "<br>";
            }
         }

         activationInfoLabel.text =
            "" + ProjecTname + " " + ProjecTver + "<br>" +
            "<b>License mode:</b> " + licenseStatusText + "<br>" +
            remainingTimeText +
            "Written by Jesús Manuel García Flores<br>" +
            "Get your license: <a href=\"https://www.teoriadelcolor.es/astroprocessor\">www.teoriadelcolor.es/astroprocessor</a>";
      }

      UpdateLicenseActivationStatus();
      activationInfoLabel.textAlignment = TextAlign_Center;
      licenseActivationGroupBox.sizer.add(activationInfoLabel);
      // Añadir el GroupBox "License Activation" debajo del "License Information"

      //
      this.licensePage.sizer.add(licenseGroupBox);

      //this.licensePage.sizer.add(licenseImportGroupBox);

      // **Nuevo GroupBox llamado "Information" debajo del "License Information"**
      let informationGroupBox = new GroupBox(this.licensePage);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;  // Espaciado vertical reducido

      // Añadir etiquetas y campos adicionales si es necesario
      let infoLabel = new Label(this);

      infoLabel.text =
    "Third-party software required for the script to work:\n" +
    "\n" +
    "Remove Stars:\n" +
    "- StarNet free - Repository: https://pixinsight.starnetastro.com/\n" +
    "- StarXTerminator - www.rc-astro.com - Optional\n" +
    "* One of them must be installed\n\n" +
    "Noise Reduction:\n" +
    "- DeepSNR free - Repository: https://pixinsight.deepsnrastro.com/\n" +
    "- MLDenoise free with MLDenoise_v5.xmlm\n" +
    "- NoiseXTerminator - www.rc-astro.com - Optional\n" +
    "* One of them must be installed\n\n" +
    "Gradient Correction:\n" +
    "- Multiscale Gradient Correction requires MARS and Gaia DR3/SP databases.\n" +
    "- Store MARS and MLDenoise_v5.xmlm in Documents/AstroProcessor/data.";

      infoLabel.textAlignment = TextAlign_Left ;
      informationGroupBox.sizer.add(infoLabel);


      // Añadir el nuevo GroupBox "Information" a la página, debajo del de "License"
      this.licensePage.sizer.add(informationGroupBox);

      // Ajustes finales para que el contenido se ajuste
      licenseGroupBox.adjustToContents();
      // Añadir el GroupBox "License Activation" debajo del "License Information"
      this.licensePage.sizer.add(licenseActivationGroupBox);

      //this.licensePage.sizer.add(informationGroupBox);
      informationGroupBox.adjustToContents();

      this.licensePage.adjustToContents();



//-----------------------------------------------------------------------------
//Añadir Pestañas--------------------------------------------------------------
//-----------------------------------------------------------------------------
// Agregar la pestaña License al TabBox

this.tabBox.addPage(this.integrationPage, "Integration");
this.tabBox.addPage(this.licensePage, "License");




      // --- Horizontal Sizer to hold Project Type and Alignment GroupBoxes ---
      //let projectAndAlignmentSizer = new HorizontalSizer;
      //projectAndAlignmentSizer.spacing = 10; // Espacio entre los dos grupos horizontales


      // Create VerticalSizer for each group to tightly manage layout
      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      CropprojectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);

      // Create VerticalSizer for each group to tightly manage layout
      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      projectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;  // Remove any margin to reduce extra spacing
      alignmentSizer.spacing = 10;  // Set appropriate spacing between elements
      //alignmentSizer.add(this.alignmentGroupBox);

      // Create HorizontalSizer to put both projectTypeSizer and alignmentSizer side by side
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;  // Ensure no extra margin is added around the group boxes
      projectAndAlignmentSizer.spacing = 10;  // Space between the two group boxes
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);

      // Agregar el HorizontalSizer al sizer de la integración
      this.integrationPage.sizer.add(projectAndAlignmentSizer);

      // --- Añadir el Tagging GroupBox directamente después del Horizontal Sizer ---
      this.integrationPage.sizer.add(this.taggingGroupBox);

      // Add the two processing/final-option groups on the same row.
      this.integrationPage.sizer.add(this.optionsGroupsSizer);



      // --- RUN Button ---
      this.runButton = new PushButton(this);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select Project type\nSelect Gradient Correction\nSelect images\nSelect Integration options\nand click on Run";
      this.runButton.setFixedWidth(102);
      this.runButton.setFixedHeight(WindowsOsx1);





      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";
      this.workingLabel.textAlignment =
         TextAlign_Center | TextAlign_VertCenter;
      this.workingLabel.setFixedHeight(WindowsOsx1);

      this.workingStatusText = "";
      this.elapsedStartTime = 0;
      this.elapsedTimer = new Timer(1, true, this);

      this.formatElapsedTime = function (elapsedMilliseconds) {
         let totalSeconds = Math.max(0, Math.floor(elapsedMilliseconds/1000));
         let hours = Math.floor(totalSeconds/3600);
         let minutes = Math.floor((totalSeconds % 3600)/60);
         let seconds = totalSeconds % 60;

         function twoDigits(value) {
            return value < 10 ? "0" + value : "" + value;
         }

         return twoDigits(hours) + ":" + twoDigits(minutes) + ":" +
            twoDigits(seconds);
      };

      this.refreshWorkingLabel = function () {
         if (this.elapsedStartTime <= 0)
            return;

         this.workingLabel.text = this.workingStatusText +
            "  ⏱ Elapsed: " +
            this.formatElapsedTime(Date.now() - this.elapsedStartTime);
         this.workingLabel.update();
      };

      this.setWorkingStatus = function (statusText) {
         this.workingStatusText = statusText;
         this.refreshWorkingLabel();
      };

      this.startElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.elapsedStartTime = Date.now();
         this.refreshWorkingLabel();
         this.elapsedTimer.start();
      };

      this.stopElapsedTimer = function () {
         this.elapsedTimer.stop();
         this.refreshWorkingLabel();
      };

      this.elapsedTimer.onTimeout = function () {
         self.refreshWorkingLabel();
      };

      this.setProcessingLock = function (locked) {
         let configurationEnabled = !locked;

         // Deshabilitar los contenedores conserva el estado enabled individual
         // de cada control y permite restaurarlo exactamente al finalizar.
         this.projectTypeGroupBox.enabled = configurationEnabled;
         this.CropprojectTypeGroupBox.enabled = configurationEnabled;
         this.taggingGroupBox.enabled = configurationEnabled;
         this.optionsGroupBox.enabled = configurationEnabled;
         this.finalOptionsGroupBox.enabled = configurationEnabled;
         this.licensePage.enabled = configurationEnabled;

         if (locked) {
            this.runButton.enabled = false;
            this.Iconize3.enabled = false;
            this.Iconize6.enabled = false;
            this.exitButton.enabled = false;
         } else {
            this.runButton.enabled = CanProcess();
            this.Iconize3.enabled = true;
            this.Iconize6.enabled = true;
            this.exitButton.enabled = true;
         }

         this.update();
      };


      // Crear un sizer horizontal
      let horizontalSizer2 = new HorizontalSizer;
      horizontalSizer2.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
      horizontalSizer2.margin = 0;  // Ensure no extra margin is added around the group boxes


      // Añadir el botón y la etiqueta al sizer horizontal
      horizontalSizer2.add(this.workingLabel, 100);


     // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(horizontalSizer2);

      // Crear el botón "Reiniciar Projecto"
      this.Iconize3 = new PushButton(this);
      this.Iconize3.text = "Trash";
      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setFixedWidth(102);
      this.Iconize3.setFixedHeight(WindowsOsx1);
      this.Iconize3.toolTip = "Delete actual project";
      if (!CanProcess())
      {
         self.runButton.enabled = false;
      }
      else
      {
         self.runButton.enabled = true;
      }

      // Settings button
      self.Iconize6 = new PushButton(this);
      self.Iconize6.text = "Settings";
      self.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      self.Iconize6.setFixedWidth(102);
      self.Iconize6.setFixedHeight(WindowsOsx1);
      self.Iconize6.toolTip = "Options and Settings";
      self.Iconize6.enabled = true;


      var self = this;
      //
      this.runButton.onClick = function () {
      if (!CanProcess())
      {
         new MessageBox(
            "Your trial or license has expired.\n\nPlease activate a valid license in the License tab.",
            "AstroProcessor",
            StdIcon_Error,
            StdButton_Ok
         ).execute();
         return;
      }

     // Rebuild the run context from the current interface state. The dialog
     // remains alive after a completed run, so transient globals from a prior
     // run must never be reused by the next one.
     let selectedProjectTypes = ["LRGB", "RGB", "SHO", "HOO", "OSC", "OSC"];
     let selectedProjectType = selectedProjectTypes[self.projectTypeComboBox.currentItem];
     OptionVaonisVespera = self.projectTypeComboBox.currentItem === 5 ? "ON" : "OFF";

     if (OptionVaonisVespera === "ON") {
        self.ImageSolverCheckBox.checked = true;
        self.ImageSolverCheckBox.enabled = false;
        OptionImageSolver = "ON";
     }

     ProjecTypevar = selectedProjectType;
     ProjecTypevarRec = selectedProjectType;

     // Re-read every directly selectable option. Click handlers keep the UI
     // responsive, but they are not a reliable source of truth after a
     // completed/aborted run or after programmatic control updates.
     OptionImageSolver = self.ImageSolverCheckBox.checked ? "ON" : "OFF";
     OptionFast = self.FastCheckBox.enabled && self.FastCheckBox.checked ?
        "ON" : "OFF";
     OptionLinkRGB = self.linkRGBChannels.checked ? "true" : "false";
     OptionNarrowbandToRGB = self.NarrowbandToRGBCheckBox.checked ?
        "ON" : "OFF";
     OptionDarkStructureEnhance =
        self.darkStructureEnhanceCheckBox.checked ? "ON" : "OFF";
     OptionHavar = self.HalphaCheckBox.enabled &&
        self.HalphaCheckBox.checked ? "ON" : "OFF";
     Option300 = self.resolutionCheckBox.checked ? "ON" : "OFF";
     OptionGradient = self.gradientCorrectionComboBox.currentItem === 0 ?
        "ON" : "OFF";
     OptionMgc = self.gradientCorrectionComboBox.currentItem === 1 ?
        "ON" : "OFF";

     if (OptionVaonisVespera === "ON")
        OptionImageSolver = "ON";

     // Rebuild all menu-driven options on every Run. Some processing
     // functions temporarily change these globals, so no previous execution
     // can leak state into the next one.
     OptionGraXNoise = self.noiseReductionComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionMLDenoise = self.noiseReductionComboBox.currentItem === 2 ? "ON" : "OFF";
     OptionNoiseXterminator = self.noiseReductionComboBox.currentItem === 3 ? "ON" : "OFF";
     OptionBlurXterminator = self.sharpenComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionHighpass = self.sharpenComboBox.currentItem === 2 ? "ON" : "OFF";
     OptionVarStars = self.starlessMethodComboBox.currentItem > 0 ? "ON" : "OFF";
     OptionStarXterminator = self.starlessMethodComboBox.currentItem === 1 ? "ON" : "OFF";
     OptionFinalStarRefinement = self.finalStarRefinementCheckBox.checked &&
        OptionVarStars === "ON" ? "ON" : "OFF";
     FinalStarRefinementReady = false;
     // Also enforce the default at Run time. This covers projects selected
     // before this interface revision and any programmatic UI restoration.
     if (OptionVarStars === "ON" && self.finalStarsComboBox.currentItem === 0)
        self.finalStarsComboBox.currentItem = 1;
     OptionHSOvar = self.finalStarsComboBox.currentItem === 1 ? "ON" : "OFF";
     Option1var = self.finalStarsComboBox.currentItem === 2 ? "ON" : "OFF";
     ProjecTypevar2 = Option1var === "ON" ? "1" : "0";

     // FAST creates the project star layer during the main channel workflow.
     // The separate RGB-star integration is intentionally unavailable in
     // FAST mode, so never leave the interface in a state that silently
     // promises an output that will be skipped.
     if (OptionFast === "ON" && Option1var === "ON") {
        console.warningln(
           "⚠️ FAST mode does not run the separate RGB star integration. " +
           "Using project stars for this run.");
        self.finalStarsComboBox.currentItem = 1;
        Option1var = "OFF";
        OptionHSOvar = "ON";
        ProjecTypevar2 = "0";
     }
     VarProcesStar = "OFF";
     VarPGlobal = "EMPTY";
     isStarProcess = false;
     OptionRemaind2 = null;
     OptionEnabledPreview2 = "OFF";
     InteractiveProcessStrengths.DeepSNR = null;
     InteractiveProcessStrengths.MLDenoise = null;
     InteractiveProcessStrengths.NoiseXTerminator = null;
     InteractiveProcessStrengths.BlurXTerminator = null;
     InteractiveProcessStrengths.HighPass = null;
     InteractiveProcessStrengths.NarrowbandToRGB = null;
     InteractiveProcessMaskModes.DeepSNR = "none";
     InteractiveProcessMaskModes.MLDenoise = "none";
     InteractiveProcessMaskModes.NoiseXTerminator = "none";
     InteractiveProcessMaskModes.BlurXTerminator = "none";
     InteractiveProcessMaskModes.HighPass = "none";
     InteractiveProcessMaskModes.NarrowbandToRGB = "none";
     InteractiveProcessMaskBanks.DeepSNR = null;
     InteractiveProcessMaskBanks.MLDenoise = null;
     InteractiveProcessMaskBanks.NoiseXTerminator = null;
     InteractiveProcessMaskBanks.BlurXTerminator = null;
     InteractiveProcessMaskBanks.HighPass = null;
     InteractiveProcessMaskBanks.NarrowbandToRGB = null;
     NarrowbandToRGBCurveSettings.temperature = 0;
     NarrowbandToRGBCurveSettings.tint = 0;
     NarrowbandToRGBCurveSettings.exposure = 0;
     NarrowbandToRGBCurveSettings.contrast = 0;
     NarrowbandToRGBCurveSettings.highlights = 0;
     NarrowbandToRGBCurveSettings.shadows = 0;
     NarrowbandToRGBCurveSettings.whites = 0;
     NarrowbandToRGBCurveSettings.blacks = 0;
     NarrowbandToRGBCurveSettings.saturation = 0;

     //Mira RGB Stars
     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {
            // Continuar con el proceso si las imágenes RGB están correctamente seleccionadas
            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {
            // Si alguna imagen está vacía, no continúa
            self.finalStarsComboBox.currentItem = 0;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");

      // Recover source IDs left by an interrupted execution (or by an older
      // build) before the reusable-intermediate cleanup scans the windows.
      if (!MiraRestoreSelectedSourceIds()) {
         console.criticalln(
            "❌ Source-window identifiers are ambiguous. Close or rename the duplicate window reported above, then run the script again.");
         return;
      }

      // A repeated run must not reuse registered/ABE helper windows created by
      // the previous run. The user can remove them and continue, or cancel.
      if (!MiraCheckWindowsABE()) {
         console.warningln("\n⚠️ Run cancelled because previous intermediate windows are still open.");
         return;
      }

      let msgBox = new MessageBox("Do you want to Run the Script?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {

        // Only clear the workspace after the user has explicitly confirmed
        // the run. Cancelling the confirmation must not move any image.
        MiraPrepareWorkspaceForRun();

        FinalFocusWindowId = "";
        FinalConvertedFocusWindowId = "";
        let startTime = Date.now();
        dialog.workingStatusText = "🚀 Starting process. Please wait...";
        dialog.startElapsedTimer();
        let processCompleted = false;
        dialog.setProcessingLock(true);

        try {

        console.noteln("🚀" + "Launching Script...");
        // Mostrar el paso actual y el tiempo transcurrido en azul.
        dialog.workingLabel.foregroundColor = 0x0000FF;
        dialog.workingLabel.update();

        // Validate the assignments
         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln("\n❌ Validation failed. Please select images.");
          return;
        } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
        }

        // Cropping removes the astrometric solution. When ImageSolver is not
        // enabled, stop before processing and explain how to correct either a
        // fully cropped set or a mixed cropped/uncropped set.
        if (OptionImageSolver !== "ON" &&
            !MiraValidateSelectedImageAstrometry(ProjecTypevar)) {
           return;
        }

        // ImageSolver must run before any existing AstroProcessor operation.
        if (OptionImageSolver === "ON") {
           dialog.setWorkingStatus("🚀 Running ImageSolver on selected images. Please wait...");
           if (!MiraRunImageSolverForSelectedImages(ProjecTypevar)) {
              console.criticalln("\n❌ ImageSolver failed. AstroProcessor has been cancelled before processing.");
              return;
           }
        }

        dialog.setWorkingStatus("🚀Launching Process: [1 to 4]/12. Please wait...");
        if (!MiraProyecto())
            {
               console.criticalln("Process cancelled.");
               return;
            }

        //Ejecuta MARS
        if (OptionMgc ==="ON") {
           // Revalidate immediately before execution in case a configured
           // database was moved or deleted after the option was enabled.
           if (!MiraValidateMgcConfiguration(true)) {
              OptionMgc = "OFF";
              OptionGradient = "ON";
              dialog.gradientCorrectionComboBox.currentItem = 0;
           }
           else {
              console.noteln("🚀" + "Launching MARS databases...");
              dialog.setWorkingStatus("🚀Launching Multiscale Gradient Correction process. Please wait...");
              console.noteln("🚀" + "Launching Multiscale Gradient Correction process...\n");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin1) + ": \n" + originalFilePathMarsfin1);
              console.writeln("⚙️ " + GetMarsFileName(originalFilePathMarsfin2) + ": \n" + originalFilePathMarsfin2);



              if (!MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, MiraImageSolverSelectedIds(ProjecTypevar))) {
                 console.criticalln(
                    "❌ Multiscale Gradient Correction did not complete on every selected image. Processing has been stopped to avoid mixing corrected and uncorrected channels.");
                 return;
              }
           }
        }

        //continúa con el proceso

        dialog.setWorkingStatus("🚀Launching Process: [1 to 4]/12. Please wait...");

            if (MiraVentana()) {

            //Starting Process
            dialog.setWorkingStatus("🚀Launching Process: [1 to 4]/9. Please wait...");
            MiraRenombre();
            dialog.setWorkingStatus("🚀Launching Process: [1 to 4]/9. Please wait...");


            // Verificación de tipo de proyecto
            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return; // Detener la ejecución si falla la alineación
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }

            // Continuar con el proceso si la alineación fue exitosa o si el proyecto es OSC
            dialog.setWorkingStatus("🚀 Step 5/9. Main process, Please wait...");
            MiraProcesoGeneral01();
            dialog.setWorkingStatus("🚀 Step 6/9. Please wait...");
            if (!MiraChannelCom()) {
               console.criticalln(
                  "❌ Channel combination or final-window creation failed. Processing has been stopped safely.");
               return;
            }

            if (!MiraValidateFinalWindowContract(
                   OptionFast === "ON" && OptionVarStars === "ON",
                   "Channel combination"))
               return;

            dialog.setWorkingStatus("🚀 Step 7/9. Please wait...");

            //MiraChannelCom();

               let finalColorTarget = ImageWindow.windowById("Final_starless");
               if (finalColorTarget && !finalColorTarget.isNull)
                  finalColorTarget.bringToFront();
               MiraGreen();

            // Denoise and sharpen are intentionally deferred until the
            // stretched Final_starless image exists. This makes every
            // interactive preview visually meaningful.
            if (OptionGraXNoise === "ON" ||
                OptionMLDenoise === "ON" ||
                OptionNoiseXterminator === "ON" ||
                OptionBlurXterminator === "ON" ||
                OptionHighpass === "ON") {
               dialog.setWorkingStatus(
                  "🚀 Adjusting denoise and sharpen on the visible final image...");
               if (!MiraApplyVisibleFinalProcesses())
                  return;
            }

            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (Option1var === "ON") {
                        if (OptionFast === "OFF"){
                              console.noteln("\n🚀" + "Launching RGB stars process.");
                              try {
                                 MiraRGBStars();
                              } finally {
                                 // MiraRGBStars temporarily switches the project
                                 // to RGB and sets VarProcesStar to ON.
                                 VarProcesStar = "OFF";
                                 ProjecTypevar = ProjecTypevarRec;
                              }
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                } else if (OptionHSOvar === "ON") {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars2();

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars();

                              }
                        }
                }
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            if (!MiraValidateFinalWindowContract(
                   OptionVarStars === "ON", "Final star creation"))
               return;

            //Mira HAlpha
            if (OptionHavar ==="ON"){
               let imageWindow = "Filter_Ha_registered_ABE";
               let BlendwindowOption = "Final_starless";
               if (!MiraHaBlend2(imageWindow, BlendwindowOption))
                  return;
            }

            // This common stage runs after both the normal and FAST star
            // creation paths. The interactive preview always composites the
            // adjusted star layer over the real Final_starless image.
            if (OptionFinalStarRefinement === "ON") {
               dialog.setWorkingStatus(
                  "🚀 Refining the final star layer. Please wait...");
               MiraRunFinalStarRefinement();
            }

            dialog.setWorkingStatus("🚀 Step 9/9. Please wait...");

            // Dark Structures uses its original independent interactive
            // workflow. It prepares the maximum enhancement once, then the
            // user slider only blends the prepared images.
            if (OptionDarkStructureEnhance === "ON") {
               dialog.setWorkingStatus("🚀 Enhance Dark structures. Please wait...");
               MiraEnhanceFinalDarkStructures();
            }

              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break; // Salimos del bucle al encontrar la ventana
                         }
                   }
              }

            if (OptionNarrowbandToRGB === "ON") {
               // Use the recorded project type because RGB star generation can
               // temporarily change ProjecTypevar to RGB.
               if (!MiraCreateNarrowbandRGBOutputs(ProjecTypevarRec)) {
                  console.warningln(
                     "⚠️ Image Editor produced no output; the unedited final image will be retained.");
               }
            }


            MiraRenProyectos(); //renombra con el proyecto

            MiraResolFinal(); // Ejecuta la resolución final
            MirashowTotalTime(startTime);
            Option2var2 = "ON"; // Actualiza para el Botón OK

            // Processing has finished. Freeze the elapsed time before asking
            // whether intermediate windows should be deleted.
            dialog.stopElapsedTimer();
            MiraBorraVentanas();

            MiraOrdena1();
            MiraFocusFinalOutput();


            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            console.noteln("\n✅" + " End Script...");
            dialog.setWorkingStatus("✅ Process completed.");
            processCompleted = true;
            //


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
        } catch (processingError) {
            console.show();
            let processingMessage = processingError && processingError.message ?
               processingError.message : processingError;
            console.criticalln(
               "\n❌ AstroProcessor stopped after an unexpected processing error: " +
               processingMessage);
            if (processingError && processingError.stack)
               console.criticalln(processingError.stack);
            new MessageBox(
               "AstroProcessor stopped safely.\n\n" + processingMessage +
               "\n\nReview the Process Console for the stage and missing window details.",
               "AstroProcessor processing error",
               StdIcon_Error,
               StdButton_Ok
            ).execute();
        } finally {
            // Always leave a clean transient context for another click on Run,
            // including executions stopped early by an error or cancellation.
            try {
               MiraRestoreSelectedSourceIds();
            } catch (restoreError) {
               console.warningln(
                  "⚠️ Source-window names could not be fully restored: " +
                  restoreError.message);
            }
            VarProcesStar = "OFF";
            VarPGlobal = "EMPTY";
            isStarProcess = false;
            ProjecTypevar = ProjecTypevarRec;
            OptionRemaind2 = null;
            OptionEnabledPreview2 = "OFF";
            dialog.stopElapsedTimer();
            dialog.setProcessingLock(false);

            if (!processCompleted)
               dialog.setWorkingStatus("⚠️ Process stopped.");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};
// Fin del botón Run


      this.Iconize3.onClick = function() {
               //Activa los proyectos

               self.projectTypeComboBox.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };





self.Iconize6.onClick = function() {

   let mgcDialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
   mgcDialog.adjustToContents();
   MiraCenterDialog(mgcDialog);
   mgcDialog.execute();
};






//-----------------------------------------------------------------------------
//Fondo de Ventana-------------------------------------------------------------
//-----------------------------------------------------------------------------




     // --- EXIT Button ---
     this.exitButton = new PushButton(this);
     this.exitButton.text = "Exit";
     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.setFixedWidth(102);  // Set the width of the combo box
     this.exitButton.setFixedHeight(WindowsOsx1);


     this.exitButton.onClick = function () {

        this.dialog.cancel();
    };



      // Console toggle button. Its text describes the action performed by the
      // next click.
      this.consoleButton = new PushButton(this);
      this.consoleButton.text = "Hide";
      this.consoleButton.icon = this.scaledResource( ":/toolbar/view-process-console.png" );
      this.consoleButton.setFixedWidth(102);
      this.consoleButton.setFixedHeight(WindowsOsx1);
      this.consoleButton.toolTip = "Show or hide the PixInsight Process Console";
      this.consoleButton.onClick = function () {
         if (OptionshowConsolRadio === "ON") {
            OptionshowConsolRadio = "OFF";
            this.text = "Show";
            console.hide();
         }
         else {
            OptionshowConsolRadio = "ON";
            this.text = "Hide";
            console.show();
         }
      };

    // Main action row: keep the execution controls in their workflow order.
    this.actionButtonsSizer = new HorizontalSizer;
    this.actionButtonsSizer.spacing = 10;
    this.actionButtonsSizer.addStretch();
    this.actionButtonsSizer.add(this.runButton);
    this.actionButtonsSizer.add(this.consoleButton);
    this.actionButtonsSizer.add(this.Iconize3);
    this.actionButtonsSizer.add(this.Iconize6);
    this.actionButtonsSizer.add(this.exitButton);
    this.actionButtonsSizer.addStretch();

    // Sizer principal
    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;
    //this.sizer.spacing = 10;

    // The TabBox consumes additional vertical space while the bottom action
    // row remains anchored to the bottom of the dialog.
    this.sizer.add(this.tabBox, 100);
    this.sizer.addSpacing(10);
    this.sizer.add(this.actionButtonsSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}
}


//IntegratorDialog.prototype = new Dialog;

let dialog = new IntegratorDialog();
UpdateInstalledAppsUI(dialog);
//

dialog.actualizarComboBoxesDesdeGUI = function () {

   var self = dialog;

   // Build the list once. Previously ImageWindow.windows was fetched and
   // filtered again for every ComboBox in comboBoxReferences.
   let availableImageIds = [];
   let windows = ImageWindow.windows;

   for (let i = 0; i < windows.length; ++i) {
      if (!windows[i] || windows[i].isNull || !windows[i].mainView || windows[i].mainView.isNull)
         continue;

      let id = windows[i].mainView.id;
      if (
         id.indexOf("Final_") === 0 ||
         id.indexOf("Base_") === 0 ||
         // Keep imported TIFF views with normal PixInsight identifiers such
         // as Image01. Only generated Image_* helper windows are hidden.
         id.indexOf("Image_") === 0 ||
         id.indexOf("Gray") === 0 ||
         id.indexOf("_registered") !== -1 ||
         id.indexOf("_ABE") !== -1 ||
         id.indexOf("_stars") !== -1
      )
         continue;

      availableImageIds.push(id);
   }

   function actualizarCombo(comboBox) {
      if (!comboBox)
         return;

      comboBox.clear();
      comboBox.addItem("<Select an Image>");

      for (let i = 0; i < availableImageIds.length; ++i)
         comboBox.addItem(availableImageIds[i]);

      comboBox.currentItem = 0;
   }

   for (let key in self.comboBoxReferences) {
      actualizarCombo(self.comboBoxReferences[key]);
   }

   PimageSii = "EMPTY";
   PimageHa = "EMPTY";
   PimageOiii = "EMPTY";
   PimageRed = "EMPTY";
   PimageGreen = "EMPTY";
   PimageBlue = "EMPTY";
   PimageLuminance = "EMPTY";
   PimageOsc = "EMPTY";

   CoreApplication.processEvents();
   self.update();
};


//
if (CanStartApp)
{
   dialog.adjustToContents();
   MiraCenterDialog(dialog);
   dialog.execute();
}
else
{
   console.criticalln("Application startup blocked.");
}
