const license = {
    email: "automator@script.es",
    code: "1234-1234-1234-1234"
};
