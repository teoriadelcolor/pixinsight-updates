

function MiraResolFinal() {
    // Verificar si la opción de resolución final está activada
    if (Option2var !== "ON") {
        console.noteln("Final resolution adjustment is OFF. Skipping process...");
        return;
    }

    let finalResultWindow;  // Declarar la variable fuera del if para que tenga un alcance global dentro de la función

        if (OptionHSOvar === "ON") {
            finalResultWindow = ImageWindow.windowById("Final_Result");  // Asignar si OptionHSOvar está en OFF
        } else {
            let activeWindow = ImageWindow.activeWindow;
            finalResultWindow = activeWindow;  // Asignar si OptionHSOvar está en ON
        }


    // Buscar la ventana "Final_Result" u otra según opción
    if (finalResultWindow && !finalResultWindow.isNull) {
        finalResultWindow.bringToFront();
        console.noteln("Final_Result window found and brought to front.");
    } else {
        console.criticalln("Final_Result window not found. Exiting process...");
        return;
    }

    // Ejecutar MiraResol2 en lugar de MiraIconos

    MiraResol2();  // Llamada a la función para ajustar la resolución final a 300 ppi

}




function MiraEnh() {
    if (OptionEnh === "ON") {

        let finalResultWindow;  // Declarar la variable fuera del if para que tenga un alcance global dentro de la función

        if (OptionHSOvar === "ON") {
            finalResultWindow = ImageWindow.windowById("Final_Result");  // Asignar si OptionHSOvar está en ON
        } else {
            let activeWindow = ImageWindow.activeWindow;
            finalResultWindow = activeWindow;  // Asignar si OptionHSOvar está en OFF
        }

        // Comprobar si finalResultWindow es válido
        if (finalResultWindow && !finalResultWindow.isNull) {
            console.writeln("Window found. Applying Enhanced process on Final_Result or active window...");
            MiraEnh2();  // Se ejecuta el proceso MiraEnh2 sobre la ventana final o activa
            console.noteln("Enhanced process applied successfully.");
        } else {
            console.criticalln("Final_Result window not found. Exiting MiraEnh process...");
        }

if (OptionHSOvar === "ON"){
            // Ahora aplicar el proceso sobre la ventana "Final_starless" después de procesar "Final_Result" o la ventana activa
            let finalStarlessWindow = ImageWindow.windowById("Final_starless");

           // Comprobar si la ventana "Final_starless" es válida
           if (finalStarlessWindow && !finalStarlessWindow.isNull) {
             console.writeln("Bringing Final_starless window to the front...");
             finalStarlessWindow.bringToFront();  // Traer la ventana al frente

             console.writeln("Applying Enhanced process on Final_starless...");
             MiraEnh2();  // Ejecutar el proceso sobre "Final_starless"
             console.noteln("Enhanced process applied successfully on Final_starless.");
           } else {
             console.criticalln("Final_starless window not found. Skipping Enhanced process on it.");
          }
}

    } else {
        console.writeln("Enhanced process is OFF. Skipping Enhanced process...");
    }
}






function MiraABE(targetWindow) {
    var P = new AutomaticBackgroundExtractor;
    P.tolerance = 1.000;
    P.deviation = 0.800;
    P.unbalance = 1.800;
    P.minBoxFraction = 0.050;
    P.maxBackground = 1.0000;
    P.minBackground = 0.0000;
    P.useBrightnessLimits = false;
    P.polyDegree = 1;
    P.boxSize = 5;
    P.boxSeparation = 5;
    P.modelImageSampleFormat = AutomaticBackgroundExtractor.prototype.f32;
    P.abeDownsample = 2.00;
    P.writeSampleBoxes = false;
    P.justTrySamples = false;
    P.targetCorrection = AutomaticBackgroundExtractor.prototype.Divide;
    P.normalize = false;
    P.discardModel = true;
    P.replaceTarget = false;
    P.correctedImageId = "";
    P.correctedImageSampleFormat = AutomaticBackgroundExtractor.prototype.SameAsTarget;
    P.verboseCoefficients = false;
    P.compareModel = false;
    P.compareFactor = 10.00;

    // Ejecutar ABE en la ventana objetivo
    console.writeln();
    console.noteln("Running ABE on: " + targetWindow.mainView.id);
    P.executeOn(targetWindow.mainView);
}


// Función MiraGraXpert
function MiraGraXpert(currentImage) {


    // Generar el nombre de la ventana basada en ProjecTypevar
    let windowName = currentImage + "_ABE";

    console.noteln("Running GraXpert process...on: " + windowName);

    // Imprimir todas las ventanas activas para facilitar la depuración
    console.writeln("Active windows:");
    let windows = ImageWindow.windows;
    for (let i = 0; i < windows.length; i++) {
        //console.writeln(" - " + windows[i].mainView.id);
    }

    // Buscar la ventana por el nombre generado
    let targetWindow = ImageWindow.windowById(windowName);

    // Verificar si la ventana con el nombre existe
    if (targetWindow.isNull) {
        console.criticalln("Error: Image with name '" + windowName + "' does not exist.");
        return;
    }

    // Inicialización del proceso GraXpert
    var P = new GraXpert;
    P.backgroundExtraction = true;
    P.smoothing = 0.000;
    P.correction = "Division";
    P.createBackground = false;
    P.backgroundExtractionAIModel = "1.0.1";
    P.denoising = false;
    P.strength = 1.000;
    P.batchSize = 4;
    P.denoiseAIModel = "2.0.0";
    P.disableGPU = false;
    P.replaceImage = true;
    P.showLogs = false;
    P.appPath = "";  // Si GraXpert no está en la ruta del sistema, puedes definir la ruta aquí.

    // Ejecutar el proceso GraXpert sobre la ventana encontrada
    if (P.executeOn(targetWindow.mainView)) {
        console.writeln("GraXpert process completed successfully on: " + windowName);
    } else {
        console.criticalln("GraXpert process failed on: " + windowName);
    }
}



function MiraGraXNoise(image) {
    console.noteln("Starting GraXNoise process...");

    // Crear instancia de GraXpert con los parámetros dados
    var P = new GraXpert;
    P.backgroundExtraction = false;
    P.smoothing = 0.000;
    P.correction = "Division";
    P.createBackground = false;
    P.backgroundExtractionAIModel = "1.0.1";
    P.denoising = true;
    P.strength = 1.000;
    P.batchSize = 4;
    P.denoiseAIModel = "2.0.0";
    P.disableGPU = false;
    P.replaceImage = true;
    P.showLogs = false;
    P.appPath = "";  // Si es necesario, proporciona la ruta de la aplicación

    // Ejecutar el proceso GraXpert
    try {
        if (P.executeOn(ImageWindow.activeWindow.mainView)) {
            console.writeln("GraXNoise process completed successfully.");
        } else {
            console.criticalln("GraXNoise process failed to execute.");
        }
    } catch (error) {
        console.criticalln("Error during GraXNoise process execution: " + error.message);
    }
}


function MiraStarXterminator(image) {
    if (typeof StarXTerminator === 'undefined') {
        console.criticalln("StarXTerminator is not available.");
        return false;
    }

    // Verificar si imageView es una vista válida
    if (!image || !(image instanceof View)) {
        console.criticalln("Invalid image view provided.");
        return false;
    }

    // Crear y configurar la instancia de StarXTerminator
    var P = new StarXTerminator;
    P.ai_file = "StarXTerminator.lite.nonoise.11.mlpackage";
    P.stars = true;     // Extraer estrellas
    P.unscreen = true;  // Quitar estrellas
    P.overlap = 0.20;   // Porcentaje de superposición de áreas procesadas

    // Ejecutar el proceso StarXTerminator en la vista de imagen proporcionada
    try {
        if (image && image instanceof View) {
            P.executeOn(image);  // Ejecutar en la vista de imagen proporcionada
            console.writeln("StarXTerminator process completed successfully on image: " + image.id);
            return true;
        } else {
            console.criticalln("Invalid image view provided.");
            return false;
        }
    } catch (e) {
        console.criticalln("Error executing StarXTerminator: " + e.message);
        return false;
    }
}

function MiraBlurXterminator(image) {
    if (typeof BlurXTerminator === 'undefined') {
        console.criticalln("BlurXTerminator is not available.");
        return false;
    }

    // Verificar si imageView es una vista válida
    if (!image || !(image instanceof View)) {
        console.criticalln("Invalid image view provided.");
        return false;
    }

    // Configurar los parámetros específicos para BlurXTerminator
    var P = new BlurXTerminator;
    P.ai_file = "BlurXTerminator.4.mlpackage";
    P.correct_only = false;
    P.correct_first = false;
    P.nonstellar_then_stellar = false;
    P.lum_only = false;
    P.sharpen_stars = 0.54;
    P.adjust_halos = 0.50;
    P.nonstellar_psf_diameter = 4.08;
    P.auto_nonstellar_psf = true;
    P.sharpen_nonstellar = 0.37;


    // Ejecutar el proceso StarXTerminator en la vista de imagen proporcionada
    try {
        if (image && image instanceof View) {
            P.executeOn(image);  // Ejecutar en la vista de imagen proporcionada
            console.writeln("BlurXTerminator process completed successfully on image: " + image.id);
            return true;
        } else {
            console.criticalln("Invalid image view provided.");
            return false;
        }
    } catch (e) {
        console.criticalln("Error executing BlurXTerminator: " + e.message);
        return false;
    }
}


function MiraChannel2(iconName) {
    let P = new LRGBCombination;

    // Adaptar los valores de los canales según ProjecTypevar
    if (iconName === "RGB_stars") {
        P.channels = [
            [true, "Filter_Red_registered_ABE", 1.00000],
            [true, "Filter_Green_registered_ABE", 1.00000],
            [true, "Filter_Blue_registered_ABE", 1.00000],
            [false, "Ha_registered_ABE", 1.00000]
        ];
    }else if (iconName === "RGB") {
        P.channels = [
            [true, "Filter_Red_registered_ABE", 1.00000],
            [true, "Filter_Green_registered_ABE", 1.00000],
            [true, "Filter_Blue_registered_ABE", 1.00000],
            [false, "Ha_registered_ABE", 1.00000]
        ];
    } else if (iconName === "LRGB") {
        P.channels = [
            [true, "Filter_Red_registered_ABE", 1.00000],
            [true, "Filter_Green_registered_ABE", 1.00000],
            [true, "Filter_Blue_registered_ABE", 1.00000],
            [true, "Filter_Luminance_registered_ABE", 1.00000]
        ];
    } else if (iconName === "SHO") {
        P.channels = [
            [true, "Filter_Sii_registered_ABE", 1.00000],
            [true, "Filter_Ha_registered_ABE", 1.00000],
            [true, "Filter_Oiii_registered_ABE", 1.00000],
            [false, "Ha_registered_ABE", 1.00000]
        ];
    } else if (iconName === "HOO") {
        P.channels = [
            [true, "Filter_Ha_registered_ABE", 1.00000],
            [true, "Filter_Oiii_registered_ABE", 1.00000],
            [true, "Filter_Oiii_registered_ABE", 1.00000],
            [false, "Ha_registered_ABE", 1.00000]
        ];
    } else {
        console.criticalln("Error: Unrecognized ProjecTypevar value: " + ProjecTypevar);
        return;
    }
console.writeln(iconName);
    // Propiedades adicionales de LRGBCombination
    P.mL = 0.500;
    P.mc = 0.500;
    P.clipHighlights = true;
    P.noiseReduction = false;
    P.layersRemoved = 4;
    P.layersProtected = 2;
    P.inheritAstrometricSolution = true;



    // Ejecutar el proceso

    if (P.executeGlobal()) {
        console.noteln("Channels Combination process completed successfully." + ProjecTypevar + "...");
    } else {

        console.criticalln("Channels Combination process failed." + ProjecTypevar );
    }
}



function MiraGreen2(NewGreenValue) {

    var P = new SCNR;

     // Si estamos en el proceso de estrellas, forzamos el valor a 1, de lo contrario usamos NewGreenValue
    if (isStarProcess) {
        P.amount = 1.0;
        console.noteln("Stars Green Reduction process completed");
    } else {
        P.amount = NewGreenValue;
        console.noteln("Image Green Reduction process executed. Value: " +  NewGreenValue);
    }


    P.protectionMethod = SCNR.prototype.AverageNeutral;
    P.colorToRemove = SCNR.prototype.Green;
    P.preserveLightness = true;

    // Aplicar el proceso a la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        P.executeOn(activeWindow.mainView);

    } else {
        console.criticalln("No active window found to apply the Green Reduction process.");
    }
}

function MiraMagenta2(NewMagentaValue) {

    var P = new SCNR;
    P.amount = NewMagentaValue;  // Asignar el valor numérico a P.amount
    P.protectionMethod = SCNR.prototype.AverageNeutral;
    P.colorToRemove = SCNR.prototype.Green;
    P.preserveLightness = true;

    // Aplicar el proceso a la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        P.executeOn(activeWindow.mainView);
        console.noteln("Magenta Stars process executed on active window: " + activeWindow.mainView.id + " . Value: " +  NewMagentaValue);
    } else {
        console.criticalln("No active window found to apply the Magenta Stars process.");
    }
}


function MiraChannelStars(iconName) {
    let P = new LRGBCombination;

    // Adaptar los valores de los canales según ProjecTypevar
    if (iconName === "RGB") {
        P.channels = [
            [true, "Filter_Red_registered", 1.00000],
            [true, "Filter_Green_registered", 1.00000],
            [true, "Filter_Blue_registered", 1.00000],
            [false, "Ha_registered", 1.00000]
        ];
    } else if (iconName === "LRGB") {
        P.channels = [
            [true, "Filter_Red_registered", 1.00000],
            [true, "Filter_Green_registered", 1.00000],
            [true, "Filter_Blue_registered", 1.00000],
            [true, "Filter_Luminance_registered", 1.00000]
        ];
    } else if (iconName === "SHO") {
        P.channels = [
            [true, "Filter_Sii_registered", 1.00000],
            [true, "Filter_Ha_registered", 1.00000],
            [true, "Filter_Oiii_registered", 1.00000],
            [false, "Ha_registered", 1.00000]
        ];
    } else if (iconName === "HOO") {
        P.channels = [
            [true, "Filter_Ha_registered", 1.00000],
            [true, "Filter_Oiii_registered", 1.00000],
            [true, "Filter_Oiii_registered", 1.00000],
            [false, "Ha_registered", 1.00000]
        ];
    } else {
        console.criticalln("Error: Unrecognized ProjecTypevar value: " + ProjecTypevar);
        return;
    }
console.writeln(iconName);
    // Propiedades adicionales de LRGBCombination
    P.mL = 0.500;
    P.mc = 0.500;
    P.clipHighlights = true;
    P.noiseReduction = false;
    P.layersRemoved = 4;
    P.layersProtected = 2;
    P.inheritAstrometricSolution = true;



    // Ejecutar el proceso
    console.noteln("Executing LRGBCombination Stars for " + ProjecTypevar + "...");
    if (P.executeGlobal()) {
        console.noteln("LRGBCombination process completed successfully.");
    } else {

        console.criticalln("LRGBCombination process failed.");
    }
}


function MiraFinalStars() {
    console.noteln("Executing FinalStars process...");

    try {
        var P = new PixelMath;
        P.expression = "~((~Final_starless)*(~Final_stars))";
        P.expression1 = "";
        P.expression2 = "";
        P.expression3 = "";
        P.useSingleExpression = true;
        P.symbols = "";
        P.clearImageCacheAndExit = false;
        P.cacheGeneratedImages = false;
        P.generateOutput = true;
        P.singleThreaded = false;
        P.optimization = true;
        P.use64BitWorkingImage = false;
        P.rescale = false;
        P.rescaleLower = 0;
        P.rescaleUpper = 1;
        P.truncate = true;
        P.truncateLower = 0;
        P.truncateUpper = 1;
        P.createNewImage = true;
        P.showNewImage = true;
        P.newImageId = "Final_Result";  // ID de la nueva imagen
        P.newImageWidth = 0;
        P.newImageHeight = 0;
        P.newImageAlpha = false;
        P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        // Buscar la ventana de imagen activa donde se aplicará PixelMath
        let starlessWindow = ImageWindow.windowById("Final_starless");  // Asegúrate de usar una ventana válida
        if (starlessWindow && !starlessWindow.isNull) {
            let targetView = starlessWindow.mainView;  // Definir correctamente targetView

            // Ejecutar PixelMath en la ventana de destino
            if (P.executeOn(targetView)) {
                console.noteln("FinalStars process completed successfully.");
            } else {
                console.criticalln("FinalStars process failed.");
            }
        } else {
            console.criticalln("Target window 'Final_starless' not found.");
        }

    } catch (e) {
        console.criticalln("Error executing FinalStars: " + e.message);
    }
}


// Calcular el valor escalado basado en NewStarsValue
function calculateStarBrightness(NewStarsValue) {
    const minBrightness = 0.00100000;  // Valor mínimo de brillo permitido
    const midBrightness = 0.00594937;  // Valor de brillo cuando NewStarsValue es 0.5
    const maxBrightness = 0.01073571;  // Valor máximo de brillo cuando NewStarsValue es 3

    // Interpolamos linealmente para que cuando NewStarsValue aumente, el brillo también aumente
    if (NewStarsValue <= 0.5) {
        // Si NewStarsValue está entre 0 y 0.5, interpolamos para reducir el brillo
        return (NewStarsValue / 0.5) * (midBrightness - minBrightness) + minBrightness;
    } else {
        // Si NewStarsValue está entre 0.5 y 3, interpolamos para aumentar el brillo
        return midBrightness + ((NewStarsValue - 0.5) / 2.5) * (maxBrightness - midBrightness);
    }
}

function MiraHistogram(NewStarsValue) {
    let scaledValue = calculateStarBrightness(NewStarsValue);


    // Si el valor es menor que el mínimo permitido, ajustarlo al mínimo
    if (scaledValue < 0.00100000) {
        scaledValue = 0.00100000;
    }

    console.noteln("Histogram Transformation adjusted: " + scaledValue);

    var P = new HistogramTransformation;
    P.H = [
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, scaledValue, 1.00000000, 0.00000000, 1.00000000],  // Usar scaledValue aquí
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000]
    ];

    // Buscar la ventana activa para aplicar el HistogramTransformation
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        if (P.executeOn(activeWindow.mainView)) {
            console.noteln("HistogramTransformation applied successfully.");
        } else {
            console.criticalln("Failed to apply HistogramTransformation.");
        }
    } else {
        console.criticalln("No active window found to apply HistogramTransformation.");
    }
}





function MiraEnh2() {
    console.noteln("Running Enhaced Process...");

   var P = new CurvesTransformation;
P.R = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.Rt = CurvesTransformation.prototype.AkimaSubsplines;
P.G = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.Gt = CurvesTransformation.prototype.AkimaSubsplines;
P.B = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.Bt = CurvesTransformation.prototype.AkimaSubsplines;
P.K = [ // x, y
   [0.00000, 0.00000],
   [0.09211, 0.08947],
   [0.14737, 0.15526],
   [0.24474, 0.28684],
   [1.00000, 1.00000]
];
P.Kt = CurvesTransformation.prototype.AkimaSubsplines;
P.A = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.At = CurvesTransformation.prototype.AkimaSubsplines;
P.L = [ // x, y
   [0.00000, 0.00000],
   [0.17105, 0.15263],
   [0.28421, 0.26579],
   [0.45000, 0.47368],
   [0.71842, 0.76579],
   [1.00000, 1.00000]
];
P.Lt = CurvesTransformation.prototype.AkimaSubsplines;
P.a = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.at = CurvesTransformation.prototype.AkimaSubsplines;
P.b = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.bt = CurvesTransformation.prototype.AkimaSubsplines;
P.c = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.ct = CurvesTransformation.prototype.AkimaSubsplines;
P.H = [ // x, y
   [0.00000, 0.00000],
   [1.00000, 1.00000]
];
P.Ht = CurvesTransformation.prototype.AkimaSubsplines;
P.S = [ // x, y
   [0.00000, 0.00000],
   [0.47632, 0.54474],
   [1.00000, 1.00000]
];
P.St = CurvesTransformation.prototype.AkimaSubsplines;


    // Ejecutar el proceso en la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        if (P.executeOn(activeWindow.mainView)) {
            console.noteln("CurvesTransformation applied successfully.");
        } else {
            console.criticalln("CurvesTransformation failed.");
        }
    } else {
        console.criticalln("No active window found to apply CurvesTransformation.");
    }
}


function MiraResol2() {
    var P = new Crop;
    P.leftMargin = 0;
    P.topMargin = 0;
    P.rightMargin = 0;
    P.bottomMargin = 0;
    P.mode = Crop.prototype.AbsolutePixels;
    P.xResolution = 300.000;
    P.yResolution = 300.000;
    P.metric = false;
    P.forceResolution = true;
    P.red = 0.000000;
    P.green = 0.000000;
    P.blue = 0.000000;
    P.alpha = 1.000000;
    P.noGUIMessages = false;

    // Aplicar el proceso en la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        if (P.executeOn(activeWindow.mainView)) {
            console.noteln("Final Resolution adjustment applied successfully.");
        } else {
            console.criticalln("Failed to apply Final Resolution adjustment.");
        }
    } else {
        console.criticalln("No active window found to apply Final Resolution adjustment.");
    }
}  // <-- Asegúrate de que esta llave esté presente


function MiraSaTstars() {


var P = new ColorSaturation;
P.HS = [ // x, y
   [0.00000, 0.52727],
   [0.21842, 0.79091],
   [0.37632, -0.13636],
   [0.63947, 0.81818],
   [0.84474, 0.05455],
   [1.00000, 0.52727]
];
P.HSt = ColorSaturation.prototype.AkimaSubsplines;
P.hueShift = 0.000;



    // Ejecutar el proceso en la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        if (P.executeOn(activeWindow.mainView)) {
            console.noteln("Stars saturation process applied successfully.");
        } else {
            console.criticalln("Stars saturation process failed.");
        }
    } else {
        console.criticalln("No active window found to apply Stars saturation process.");
    }
}


function MiraGradient() {
    var P = new GradientCorrection;
    P.reference = 0.50;
    P.lowThreshold = 0.20;
    P.lowTolerance = 0.50;
    P.highThreshold = 0.05;
    P.highTolerance = 0.00;
    P.iterations = 15;
    P.scale = 5.00;
    P.smoothness = 0.40;
    P.downsamplingFactor = 16;
    P.protection = true;
    P.protectionThreshold = 0.10;
    P.protectionAmount = 0.50;
    P.protectionSmoothingFactor = 16;
    P.lowClippingLevel = 0.000076;
    P.automaticConvergence = false;
    P.convergenceLimit = 0.00001000;
    P.maxIterations = 10;
    P.useSimplification = true;
    P.simplificationDegree = 1;
    P.simplificationScale = 1024;
    P.generateSimpleModel = false;
    P.generateGradientModel = false;
    P.generateProtectionMasks = false;
    P.gridSamplingDelta = 16;

      // Ejecutar el proceso en la ventana activa
    let activeWindow = ImageWindow.activeWindow;
    if (activeWindow && !activeWindow.isNull) {
        if (P.executeOn(activeWindow.mainView)) {
            console.noteln("Gradient Reduction process applied successfully.");
        } else {
            console.criticalln("Gradient Reduction process failed.");
        }
    } else {
        console.criticalln("No active window found to apply Gradient Reduction process.");
    }
}





function WriteLicenseFile(filePath, email, code) {
    try {
        // Obtener el directorio de salida y asegurarse de que tiene una barra al final
        let outputDir;
        if (!this.outputDir || this.outputDir.length === 0) {
            outputDir = File.extractDrive(filePath) + File.extractDirectory(filePath);
        } else {
            outputDir = this.outputDir;
        }

        if (!outputDir.endsWith('/')) {
            outputDir += '/';
        }

        // Crear la ruta final para el archivo license.js
        let newPath = outputDir + "license.js";

        // Si no se permite sobrescribir y el archivo ya existe
        if (!this.overwrite && File.exists(newPath)) {
            let messageBox = new MessageBox(
                "<p>The file '" + newPath + "' already exists.</p>" +
                "<p><b>Do you want to overwrite it?</b></p>",
                "Warning", StdIcon_Error, StdButton_No, StdButton_Yes
            );

            // Si el usuario selecciona "No", salir sin hacer nada
            if (messageBox.execute() != StdButton_Yes) {
                console.writeln("Operation cancelled. The file '" + newPath + "' was not overwritten.");

                return;  // Salir de la función si no desea sobrescribir
            }
        }

        // Crear el archivo y escribir los datos
        let file = new File;
        file.createForWriting(newPath);

        // Formatear el contenido del archivo con los datos del formulario
        let content = "const license = {\n" +
                      '    email: "' + email + '",\n' +
                      '    code: "' + code + '"\n' +
                      "};\n";

        let data = new ByteArray(content);
        file.write(data);
        file.close();

        console.writeln("License file written correctly at: " + newPath);
        // Añadimos un cuadro de mensaje con el botón OK
        (new MessageBox("Exit the script for the changes to take effect", "Information", StdIcon_Information, StdButton_Ok)).execute();



    } catch (e) {
        console.criticalln("Error writing to file: " + e.message);
    }
}


function MiraVacioRGB() {
    // Verificar si las variables de imagen RGB están vacías
    if (PimageRed === "EMPTY" || PimageGreen === "EMPTY" || PimageBlue === "EMPTY") {
        // Mostrar un mensaje de error si alguna de las imágenes está vacía
        let msgBox = new MessageBox(
            "One or more RGB images are not selected!\nPlease ensure Red, Green, and Blue images are selected before proceeding.",
            "Error",
            StdIcon_Error,
            StdButton_Ok
        );

        msgBox.execute();
        console.criticalln("Error: One or more RGB images are not selected.");
        return false;  // Devolver false para indicar que las imágenes no están seleccionadas
    }

    // Si las imágenes están correctamente seleccionadas
    console.noteln("Star Layer option. All RGB images are selected.");
    return true;  // Devolver true para indicar que todo está bien
}
