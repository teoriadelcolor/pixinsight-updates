function MiraStarnet2() {
    // Verificar si hay una imagen activa
    let activeWindow = ImageWindow.activeWindow;
    if (!activeWindow || !activeWindow.mainView || activeWindow.mainView.isNull) {
        console.criticalln("No active image found to apply StarNet2.");
        return;
    }


    // Crear una nueva instancia de StarNet2
    var P = new StarNet2;
    P.stride = StarNet2.prototype.defStride;
    P.mask = false;
    P.linear = true;
    P.upsample = false;
    P.shadows_clipping = -2.80;
    P.target_background = 0.25;

    // Ejecutar StarNet2 en la imagen activa
    if (!P.executeOn(activeWindow.mainView)) {
        console.criticalln("Failed to apply StarNet2.");
        return;
    }

    console.writeln("StarNet2 process completed on the active image.");
}


function MiraBorrarPrev0() {
    console.writeln("Deleting all preview, preview_lightMask, and preview_shadow_mask windows...");

    let windows = ImageWindow.windows;
    let windowsToDelete = [];

    // Recorrer todas las ventanas abiertas
    for (let i = 0; i < windows.length; i++) {
        let windowName = windows[i].mainView.id;  // Obtener el ID de la ventana

        // Convertir windowName a string si es necesario
        if (typeof windowName !== 'string') {
            windowName = String(windowName);
        }


         // Borrar todas las ventanas que contengan "_preview_shadow_mask"
        if (windowName.indexOf("Start_preview") !== -1) {
            console.writeln("Marking window for deletion: " + windowName);
            windowsToDelete.push(windows[i]);
        }

    }

    // Cerrar todas las ventanas marcadas
    for (let i = 0; i < windowsToDelete.length; i++) {
        windowsToDelete[i].forceClose();
        console.writeln("Deleted window: " + windowsToDelete[i].mainView.id);
    }

    console.writeln("All marked Start_Preview Windows deleted.");
}




function MiraBorrarPrev() {


    let windows = ImageWindow.windows;
    let windowsToDelete = [];

    // Recorrer todas las ventanas abiertas
    for (let i = 0; i < windows.length; i++) {
        let windowName = windows[i].mainView.id;  // Obtener el ID de la ventana

        // Convertir windowName a string si es necesario
        if (typeof windowName !== 'string') {
            windowName = String(windowName);
        }


        // Borrar todas las ventanas que contengan "_preview_lightMask"
        if (windowName.indexOf("Final_starless_preview_light_mask_light_mask_Preview") !== -1) {
            console.writeln("Marking window for deletion: " + windowName);
            windowsToDelete.push(windows[i]);
        }

       // Borrar todas las ventanas que contengan "_preview_lightMask"
        if (windowName.indexOf("Final_starless_preview_light_mask_L") !== -1) {
            console.writeln("Marking window for deletion: " + windowName);
            windowsToDelete.push(windows[i]);
        }

        // Borrar todas las ventanas que contengan "_preview_shadow_mask"
        if (windowName.indexOf("Final_starless_preview_shadow_mask_L") !== -1) {
            console.writeln("Marking window for deletion: " + windowName);
            windowsToDelete.push(windows[i]);
        }

         // Borrar todas las ventanas que contengan "_preview_shadow_mask"
        if (windowName.indexOf("Final_starless_preview_shadow_mask_shadow_mask_Preview") !== -1) {
            console.writeln("Marking window for deletion: " + windowName);
            windowsToDelete.push(windows[i]);
        }

    }

    // Cerrar todas las ventanas marcadas
    for (let i = 0; i < windowsToDelete.length; i++) {
        windowsToDelete[i].forceClose();
        console.writeln("Deleted window: " + windowsToDelete[i].mainView.id);
    }

    console.writeln("All marked windows deleted.");
}



function MiraDevelop(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar) {
    // Step 1: Preview the selected image in MiraPreview
    MiraPreview(imageViewerControl2, imageSelector22);

    // Read the type of mask from the variable
    let selectedMaskOption = OptionTypeMaskvar;

    // Step 2: Duplicate the selected image
    let selectedImageIndex = imageSelector22.currentItem; // Get the selected index
    let selectedImageName = imageSelector22.itemText(selectedImageIndex); // Get the selected image name

    if (selectedImageIndex < 0 || !selectedImageName) {
        console.criticalln("No image selected.");
        return;
    }

    // Guardar el nombre de la imagen seleccionada en la variable pública
    OptionNombVar = selectedImageName;
    console.writeln("\nImage saved: " + OptionNombVar);

    let selectedWindow = ImageWindow.windowById(selectedImageName); // Get the selected image window

    if (!selectedWindow || !selectedWindow.mainView || selectedWindow.mainView.isNull) {
        console.criticalln("Selected image window is invalid or not found.");
        return;
    }

    // Create a manual duplicate of the selected image
    let duplicateImageWindow = new ImageWindow(
        selectedWindow.mainView.image.width,
        selectedWindow.mainView.image.height,
        selectedWindow.mainView.image.numberOfChannels,
        selectedWindow.mainView.image.bitsPerSample,
        selectedWindow.mainView.image.sampleType != SampleType_Real,
        selectedWindow.mainView.image.isColor
    );

    // Copy data from the original image to the new window
    duplicateImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    duplicateImageWindow.mainView.image.assign(selectedWindow.mainView.image);
    duplicateImageWindow.mainView.endProcess();

    // Rename the duplicated window with the original name + "_preview"
    let newDuplicateName = "Start_preview";
    duplicateImageWindow.mainView.id = newDuplicateName;
    duplicateImageWindow.show();

    console.writeln("Duplicated image created with name: " + newDuplicateName);

}





function MiraDevelop2(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionBlurMaskvar, duplicateImageWindow) {
    console.writeln("Options: " + duplicateImageWindow.mainView.id);

    let shouldApplyHSL = false;  // Flag to control HSL application

    // Paso 1: Verificar si los valores de máscara y blur han cambiado
    if (previousMaskType !== OptionTypeMaskvar || previousBlurOption !== OptionBlurMaskvar) {
        console.writeln("Mask or blur options have changed. Re-creating masks and applying blur.");
        shouldApplyHSL = true;  // HSL se debe aplicar después de la máscara o desenfoque

        // Paso 2: Aplicar la máscara si se seleccionó alguna
        if (OptionTypeMaskvar !== "None") {
            console.writeln("Applying Mask: " + OptionTypeMaskvar);
            switch (OptionTypeMaskvar) {
                case "Light Mask":
                    applyMask(duplicateImageWindow, "Light", OptionshowMaskvar);  // Aplicar la máscara de luz
                    break;
                case "Shadow Mask":
                    applyMask(duplicateImageWindow, "Shadow", OptionshowMaskvar);  // Aplicar la máscara de sombra
                    break;
                case "Red Mask":
                case "Yellow Mask":
                case "Green Mask":
                case "Cyan Mask":
                case "Blue Mask":
                case "Magenta Mask":
                    applyColorMask(duplicateImageWindow, OptionTypeMaskvar);  // Aplicar la máscara de color
                    break;
                default:
                    console.criticalln("Unknown mask type.");
                    return;
            }
        }

        // Paso 3: Aplicar desenfoque si se selecciona una opción
        if (!applyBlur(duplicateImageWindow, OptionBlurMaskvar)) {
            console.criticalln("Error: Failed to apply blur.");
            return;
        }

        // Guardar los valores seleccionados para evitar aplicar de nuevo
        previousMaskType = OptionTypeMaskvar;
        previousBlurOption = OptionBlurMaskvar;
    } else {
        console.writeln("Mask and blur options have not changed. Skipping mask creation and blur application.");
        shouldApplyHSL = true;  // Aún necesitamos aplicar HSL si los valores no han cambiado
    }

    // **Paso 4: Buscar la ventana que termine en "_preview", pero no en "_preview_mask"**
    let windows = ImageWindow.windows;
    let mainImageWindow = null;

    // Buscar entre todas las ventanas
    for (let i = 0; i < windows.length; i++) {
        let windowName = windows[i].mainView.id;

        // Verificar si la ventana termina en "_preview" pero no en "_preview_mask"
        if (windowName.endsWith("_preview") && !windowName.endsWith("_preview_mask")) {
            mainImageWindow = windows[i];
            break;  // Romper el ciclo cuando se encuentra la ventana correcta
        }
    }

    if (mainImageWindow && !mainImageWindow.mainView.isNull) {
        mainImageWindow.bringToFront();  // Asegurar que la ventana principal esté al frente
        console.writeln("Bringing " + mainImageWindow.mainView.id + " to the front for HSL adjustments.");

        // Aplicar ajustes HSL solo a la ventana principal
        if (shouldApplyHSL) {
            console.writeln("HSL options: " + OptionColorMaskLumvar + ", OptionColorMaskSatvar: " + OptionColorMaskSatvar + ", OptionRGBMaskvar: " + OptionRGBMaskvar);

            // Aplicar ajustes HSL a la imagen principal
            MiraDeveLight(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionColorMaskLumvar, OptionColorMaskSatvar, OptionColorMaskHuevar, OptionRGBMaskvar);
        }
    } else {
        console.criticalln("Error: Main image window (ending in '_preview') not found or invalid.");
    }
}





function applyMask(imageWindow, maskType, OptionshowMaskvar) {
    console.writeln("Creating " + maskType + " Mask");

    // Obtener el nombre de la ventana de imagen original
    let selectedImageName = imageWindow.mainView.id;

    let selectedWindow = ImageWindow.windowById(selectedImageName); // Obtener la ventana seleccionada
    let selectedImage = selectedWindow.mainView.image;

    // Verificar si la imagen es RGB
    if (!selectedWindow.mainView.image.isColor) {
        let messageBox = new MessageBox(
            "Error: ChannelExtraction can only be executed on RGB color images.\nPlease, use Non linear images.",
            "Invalid Image Type",
            StdIcon_Error,
            StdButton_Ok
        );
        messageBox.execute();
        console.criticalln("Error: ChannelExtraction can only be executed on RGB color images.");
        return;
    }

    // Crear una copia de la imagen seleccionada para aplicar la máscara
    let maskImageWindow = new ImageWindow(selectedImage.width, selectedImage.height,
        selectedImage.numberOfChannels, selectedImage.bitsPerSample,
        selectedImage.sampleType != SampleType_Real, selectedImage.isColor);
    maskImageWindow.mainView.id = selectedImageName + "_" + maskType.toLowerCase() + "_mask";

    // Copiar los datos de la imagen a la nueva ventana
    maskImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    maskImageWindow.mainView.image.assign(selectedImage);
    maskImageWindow.mainView.endProcess();

    // Crear la máscara usando ChannelExtraction
    let P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.prototype.CIELab;
    P.channels = [[true, ""], [false, ""], [false, ""]];
    P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
    P.inheritAstrometricSolution = true;

    if (P.executeOn(maskImageWindow.mainView)) {
        console.writeln(maskType + " mask extracted successfully from: " + maskImageWindow.mainView.id);
    } else {
        console.criticalln("Failed to extract the " + maskType + " mask.");
        return;
    }

    // Si estamos aplicando una máscara de sombras, invertimos la máscara de luminosidad creada
    if (maskType === "Shadow") {

        // Buscar la ventana de la máscara de sombras que termine en "_preview_shadow_mask_L"
    let windows = ImageWindow.windows;
    let luminosityMaskWindow = null;

    for (let i = 0; i < windows.length; i++) {
        let windowName = windows[i].mainView.id;

        // Verificar si el nombre termina en "_preview_shadow_mask_L"
        if (windowName.endsWith("_preview_shadow_mask_L")) {
            luminosityMaskWindow = windows[i];
            break; // Salir del ciclo al encontrar la ventana
        }
    }

        if (luminosityMaskWindow && !luminosityMaskWindow.mainView.isNull) {
        // Invertir la máscara de sombras
        luminosityMaskWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
        luminosityMaskWindow.mainView.image.invert();
        luminosityMaskWindow.mainView.endProcess();
        console.writeln("Inverted the luminosity mask: " + luminosityMaskWindow.mainView.id);
    } else {
        console.criticalln("Failed to find the luminosity mask window for inversion.");
        return;
    }
}

    // Refrescar la imagen para que se vea la inversión
    maskImageWindow.show();

    // Obtener la ventana activa generada por ChannelExtraction
    let maskWindow = ImageWindow.activeWindow;

    if (!maskWindow || maskWindow.mainView.isNull) {
        console.criticalln("Failed to find the " + maskType + " mask window.");
        return;
    }

    // Poner la ventana de máscara como la ventana activa
    maskWindow.bringToFront();


    // Renombrar la ventana de la máscara
    let newMaskWindowName = maskWindow.mainView.id + "_" + maskType.toLowerCase() + "_mask_Preview";
    maskWindow.mainView.id = newMaskWindowName;
    console.writeln("Renamed " + maskType + " mask to: " + newMaskWindowName);

    // Asignar la máscara a la imagen original
    imageWindow.mask = maskWindow;
    imageWindow.maskInverted = false;

      // Poner la ventana principal de imagen como la activa en lugar de la de máscara
      let previewWindowName = imageWindow.mainView.id + "_preview";
      let previewWindow = ImageWindow.windowById(previewWindowName);

      if (previewWindow && !previewWindow.mainView.isNull) {
          // Hacer que la ventana _preview sea la activa
          previewWindow.bringToFront();
          console.writeln("Brought window " + previewWindowName + " to the front.");
      } else {
          console.warningln("Warning: Preview window not found or invalid.");
      }

       // Controlar la visibilidad de la máscara basándose en OptionshowMaskvar
    if (OptionshowMaskvar === "ON") {
        imageWindow.maskVisible = true;  // Mostrar la máscara
        console.writeln("Mask is visible.");
    } else {
        imageWindow.maskVisible = false;  // Ocultar la máscara
        console.writeln("Mask is not visible.");
    }

    console.writeln("");
    console.noteln(maskType + " mask applied to: " + imageWindow.mainView.id);
}



function applySoftBlur(window) {
    console.writeln("Applying Soft Blur");
    var P = new PixelMath;
    P.expression = "gconv($T, 7, 1, 0)";  // Example of soft blur with sigma 7
    P.useSingleExpression = true;
    P.executeOn(window.mainView);
}

function applyHardBlur(window) {
    console.writeln("Applying Hard Blur");
    var P = new PixelMath;
    P.expression = "gconv($T, 27, 1, 0)";  // Example of hard blur with sigma 27
    P.useSingleExpression = true;
    P.executeOn(window.mainView);
}





function MiraDeveLight(imageViewerControl2, imageSelector22, OptionTypeMaskvar, OptionshowMaskvar, OptionColorMaskLumvar, OptionColorMaskSatvar, OptionColorMaskHuevar, OptionRGBMaskvar) {
    console.writeln("");
    console.noteln("HSL options: " + OptionColorMaskLumvar + ", OptionColorMaskSatvar: " + OptionColorMaskSatvar + ", OptionRGBMaskvar: " + OptionRGBMaskvar);

    // Obtener la ventana de la imagen activa
    let activeWindow = ImageWindow.activeWindow;
    if (!activeWindow || activeWindow.mainView.isNull) {
        console.criticalln("Error: No active image window found.");
        return;
    }

    // Crear la transformación de curvas
    let P = new CurvesTransformation;

    // Aplicar el ajuste de luminancia si es diferente de 10
    if (OptionColorMaskLumvar !== 10) {
        let midPointAdjustmentLum = 0.5 + (OptionColorMaskLumvar / 100);  // Rango muy fino para mayor precisión
        P.K = [
            [0.00000, 0.00000],
            [0.50000, midPointAdjustmentLum],
            [1.00000, 1.00000]
        ];
        P.Kt = CurvesTransformation.prototype.AkimaSubsplines;
    }

    // Aplicar el ajuste de saturación si es diferente de 10
    if (OptionColorMaskSatvar !== 10) {
        let midPointAdjustmentSat = 0.5 + (OptionColorMaskSatvar / 100);  // Rango muy fino para mayor precisión
        P.S = [
            [0.00000, 0.00000],
            [0.50000, midPointAdjustmentSat],
            [1.00000, 1.00000]
        ];
        P.St = CurvesTransformation.prototype.AkimaSubsplines;
    }

    // Ajustar el canal de color seleccionado
    switch (OptionRGBMaskvar) {
        case "Red Channel":
            if (OptionColorMaskHuevar !== 10) {
                let midPointAdjustmentRed = 0.5 + (OptionColorMaskHuevar / 50);  // Ajuste más fino para el canal rojo
                P.R = [
                    [0.00000, 0.00000],
                    [0.50000, midPointAdjustmentRed],
                    [1.00000, 1.00000]
                ];
                P.Rt = CurvesTransformation.prototype.AkimaSubsplines;
                console.writeln("Adjustment applied to Red Channel.");
            }
            break;

        case "Green Channel":
            if (OptionColorMaskHuevar !== 10) {
                let midPointAdjustmentGreen = 0.5 + (OptionColorMaskHuevar / 50);  // Ajuste más fino para el canal verde
                P.G = [
                    [0.00000, 0.00000],
                    [0.50000, midPointAdjustmentGreen],
                    [1.00000, 1.00000]
                ];
                P.Gt = CurvesTransformation.prototype.AkimaSubsplines;
                console.writeln("Adjustment applied to Green Channel.");
            }
            break;

        case "Blue Channel":
            if (OptionColorMaskHuevar !== 10) {
                let midPointAdjustmentBlue = 0.5 + (OptionColorMaskHuevar / 50);  // Ajuste más fino para el canal azul
                P.B = [
                    [0.00000, 0.00000],
                    [0.50000, midPointAdjustmentBlue],
                    [1.00000, 1.00000]
                ];
                P.Bt = CurvesTransformation.prototype.AkimaSubsplines;
                console.writeln("Adjustment applied to Blue Channel.");
            }
            break;

        case "None":
        default:
            console.writeln("No color adjustment applied (No channel selected).");
            break;
    }

 // Buscar la ventana que termina en "_preview", pero no en "_preview_mask"
let windows = ImageWindow.windows;
let previewWindow = null;

for (let i = 0; i < windows.length; i++) {
    let windowName = windows[i].mainView.id;

    // Verificar si el nombre termina en "_preview" pero no en "_preview_mask"
    if (windowName.endsWith("_preview") && !windowName.endsWith("_preview_mask")) {
        previewWindow = windows[i];
        break; // Salir del bucle una vez que se encuentra la ventana correcta
    }
}

if (previewWindow && !previewWindow.mainView.isNull) {
    // Aplicar la transformación de curvas a la ventana correcta
    if (P.executeOn(previewWindow.mainView)) {
        console.writeln("Color adjustment applied successfully to " + previewWindow.mainView.id);

        // Actualizar la imagen en el visor
        fitImageToWindow(imageViewerControl2, previewWindow.mainView.image, false);
        imageViewerControl2.show();
    } else {
        console.criticalln("Error: Failed to apply the curves transformation.");
    }
} else {
    console.criticalln("Error: No valid preview window found for applying the curves transformation.");
}
}





function applyColorMask(duplicateImageWindow, maskType) {
    console.writeln("Applying " + maskType + " Mask");

    // Verificar si la imagen es de tipo RGB (tres canales)
    if (duplicateImageWindow.mainView.image.numberOfChannels !== 3) {
        console.criticalln("Error: The image must be an RGB color image with three channels to apply a color mask.");
        return;  // Detener el proceso si no es una imagen RGB
    }

    let imageId = duplicateImageWindow.mainView.id;
    let minHue, maxHue;
    switch (maskType) {
        case "Red Mask":
            minHue = 300;
            maxHue = 60;
            break;
        case "Yellow Mask":
            minHue = 30;
            maxHue = 90;
            break;
        case "Green Mask":
            minHue = 90;
            maxHue = 150;
            break;
        case "Cyan Mask":
            minHue = 150;
            maxHue = 210;
            break;
        case "Blue Mask":
            minHue = 210;
            maxHue = 270;
            break;
        case "Magenta Mask":
            minHue = 270;
            maxHue = 330;
            break;
        default:
            console.criticalln("Error: Invalid mask type selected.");
            return;
    }

    // Verificar que la imagen sea válida antes de proceder
    if (!duplicateImageWindow || duplicateImageWindow.mainView.image.isNull || duplicateImageWindow.mainView.image.isEmpty) {
        console.criticalln("Error: Invalid image provided for ColorMask.");
        return;
    }

    // Llamar a la función ColorMask para generar la máscara
    if (!ColorMask(duplicateImageWindow.mainView.image, imageId, minHue, maxHue)) {
        console.criticalln("Error: Failed to apply the " + maskType);
    } else {
        console.writeln(maskType + " applied successfully.");
    }
}






function ColorMask(image, name, minHue, maxHue) {
    console.writeln("Creating Color Mask: " + name);

    // Verificar si la imagen es válida
    if (!image || image.isNull || image.isEmpty) {
        console.criticalln("Error: Invalid image provided for ColorMask.");
        return false;
    }

    // Verificar si la imagen es de tipo RGB (3 canales)
    if (image.numberOfChannels !== 3) {
        console.criticalln("Error: The image must be an RGB image with 3 channels to create a color mask.");
        return false;
    }

    // Verificar que el nombre no esté vacío
    if (!name || name.trim() === "") {
        console.criticalln("Error: Mask name is empty.");
        return false;
    }

    // Definir la expresión de PixelMath para crear la máscara de color
    let PM = new PixelMath;
    let min = minHue / 360;
    let max = maxHue / 360;
    let mid = (min + max) / 2;
    let maskMod = "*CIEc($T)";  // Máscara de crominancia

    // Construir la expresión utilizando concatenación de cadenas
    let expression = "iif(CIEh($T)<" + min +
        ",0, iif(CIEh($T)<=" + mid +
        ",~mtf((CIEh($T)-" + min + ")/(" + mid + "-" + min + "),1)" + maskMod +
        ", iif(CIEh($T)<=" + max +
        ",~mtf((" + max + "-CIEh($T))/(" + max + "-" + mid + "),1)" + maskMod +
        ",0)))";

    // Configurar PixelMath
    PM.expression = expression;
    PM.useSingleExpression = true;
    PM.rescale = true;
    PM.rescaleLower = 0;
    PM.rescaleUpper = 1;
    PM.createNewImage = true;
    PM.newImageId = name + "_color_mask";
    PM.newImageColorSpace = PixelMath.prototype.Gray;  // Creamos la máscara en escala de grises
    PM.newImageSampleFormat = PixelMath.prototype.f32;  // 32 bits flotante

    // Verificar si la imagen es válida antes de ejecutar PixelMath
    if (image.isNull || image.isEmpty) {
        console.criticalln("Error: Image is invalid for PixelMath process.");
        return false;
    }

    // Ejecutar PixelMath para crear la máscara de color
    if (!PM.executeOn(image)) {
        console.criticalln("Error: Failed to create the color mask.");
        return false;
    }

    console.writeln("Color Mask created successfully.");
    return true;
}






function ensure32BitFloatingPoint(duplicateImageWindow) {
    let image = duplicateImageWindow.mainView.image;

    if (image.isNull || image.isEmpty) {
        console.criticalln("Error: Image is null or empty. Cannot apply PixelMath.");
        return false;  // Devuelve false si la imagen no es válida
    }

    // Verificar si la imagen es de tipo RGB (tres canales)
    if (image.numberOfChannels !== 3) {
        console.criticalln("Error: The image must be an RGB color image with three channels.");
        return false;  // Detener el proceso si no es una imagen RGB
    }

    // Verificar si la imagen ya es de 32 bits en coma flotante
    if (image.bitsPerSample !== 32 || image.sampleType !== SampleType_Real) {
        console.writeln("Image is not in 32-bit floating point format. Creating a new 32-bit floating point image.");

        // Crear una nueva imagen en formato de 32 bits flotante
        let newImageWindow = new ImageWindow(
            image.width,
            image.height,
            image.numberOfChannels,
            32,   // Forzar a 32 bits
            true, // Tipo de muestra flotante
            image.isColor
        );

        // Copiar los datos de la imagen original a la nueva imagen
        newImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
        newImageWindow.mainView.image.assign(image);  // Asignar los datos de la imagen original
        newImageWindow.mainView.endProcess();

        // Mostrar la nueva imagen en la ventana activa
        newImageWindow.show();

        // Ahora trabajamos con la nueva ventana
        duplicateImageWindow = newImageWindow;
    }

    // Verificar si la conversión fue exitosa
    if (duplicateImageWindow.mainView.image.bitsPerSample !== 32 || duplicateImageWindow.mainView.image.sampleType !== SampleType_Real) {
        console.criticalln("Error: Image is still not in 32-bit floating point format after creating a new image.");
        return false;
    }

    console.writeln("Image successfully converted to 32-bit floating point format.");
    return true;  // La imagen está en el formato correcto
}






function MiraMaskBYN(duplicateImageWindow, imageViewerControl) {
    console.writeln("MiraMaskBYN called with duplicateImageWindow: " + duplicateImageWindow.mainView.id);

    // Buscar cualquier ventana cuyo nombre contenga "_mask_L"
    let windows = ImageWindow.windows;
    let maskWindow = null;

    // Iterar sobre las ventanas para encontrar una cuyo ID contenga "_mask_L"
    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.indexOf("_mask_L") !== -1) {  // Usar indexOf para buscar "_mask_L"
            maskWindow = windows[i];
            console.writeln("Found mask window: " + maskWindow.mainView.id);
            break;
        }
    }

    // Verificar si la máscara ya existe
    if (!maskWindow || maskWindow.mainView.isNull) {
        console.warningln("Masking Option = None.\nOr no existing mask window found containing '_mask_L'.");
        return;
    }

    // Mostrar la máscara en el visor
    maskWindow.bringToFront();  // Hacer la ventana de la máscara la activa
    maskWindow.show();  // Mostrar la máscara en el visor
    console.writeln("Mask window: " + maskWindow.mainView.id + " is now active and visible.");

    // Actualizar el visor de la imagen si es necesario (dependiendo de tu interfaz de usuario)
    fitImageToWindow(imageViewerControl, maskWindow.mainView.image, false);
    imageViewerControl.show();
}






function applyBlur(duplicateImageWindow, OptionBlurMaskvar) {
    console.noteln("Blur option: " + OptionBlurMaskvar);

    // Determinar el valor de sigma según la opción seleccionada
    let sigma = 0;
    switch (OptionBlurMaskvar) {
        case "Soft Blur":
            sigma = 7;  // Sigma bajo para desenfoque suave
            break;
        case "Hard Blur":
            sigma = 27;  // Sigma alto para desenfoque fuerte
            break;
        case "None":
        default:
            console.writeln("No blur applied.");
            return true;  // Si no hay desenfoque seleccionado, no hay error y salimos
    }

    console.writeln("Applying " + OptionBlurMaskvar + " with sigma: " + sigma);

    // Buscar la máscara activa con el sufijo "_mask_L"
    let maskWindow = null;
    let maskIdSuffix = "_mask_L";

    // Recorrer todas las ventanas abiertas para encontrar la máscara activa
    let windows = ImageWindow.windows;
    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id.indexOf(maskIdSuffix) !== -1) {
            maskWindow = windows[i];
            break;
        }
    }

    // Verificar si se ha encontrado la máscara
    if (!maskWindow || maskWindow.mainView.image.isNull || maskWindow.mainView.image.isEmpty) {
        console.criticalln("Error: No valid mask window found to apply the blur.");
        return false;
    }

    console.writeln("Applying blur to mask: " + maskWindow.mainView.id);

    // Crear la expresión de PixelMath para desenfoque
    let P = new PixelMath;
    P.expression = "gconv($T, " + sigma + ", 1, 0)";  // Desenfoque Gaussiano con el sigma apropiado
    P.useSingleExpression = true;
    P.generateOutput = true;
    P.createNewImage = false;  // No crear una nueva imagen
    P.showNewImage = true;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    // Ejecutar PixelMath sobre la máscara activa
    if (!P.executeOn(maskWindow.mainView)) {
        console.criticalln("Error: Failed to apply the blur on mask.");
        return false;
    }

    console.writeln(OptionBlurMaskvar + " applied successfully to mask: " + maskWindow.mainView.id);
    return true;
}




function MiraOk() {
    let windows = ImageWindow.windows;
    let targetWindow = null;

    // Search for the image named "Start_preview"
    for (let i = 0; i < windows.length; i++) {
        if (windows[i].mainView.id === "Start_preview") {
            targetWindow = windows[i];
            break;
        }
    }

    if (!targetWindow) {
        console.criticalln("Error: No 'Start_preview' window found.");
        return;
    }

    // Rename the found window to OptionNombVar + "_end_HSL"
    if (OptionNombVar) {
        targetWindow.mainView.id = OptionNombVar + "_end_HSL";
        console.writeln("Renamed image to: " + OptionNombVar + "_end_HSL");
        // Deactivate the mask after renaming the window
         targetWindow.removeMask();  // Eliminar la máscara activa
        targetWindow.maskVisible = false;  // Asegurarse de que la máscara no esté visible


    } else {
        console.criticalln("Error: OptionNombVar is null or undefined.");
    }

    // Reset OptionNombVar
    OptionNombVar = null;
}

function gC() {
    var caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return caracteres.charAt(Math.floor(Math.random() * caracteres.length));
}


function sLEl(email) {
    var suma = 0;

    for (var i = 0; i < email.length; i++) {
        var caracter = email.charAt(i);
        if (/^[a-zA-Z]+$/.test(caracter)) {
            suma += caracter.charCodeAt(0);
        }
    }
    return suma;
}


function gCo(sLs) {

    var sumaStr = sLs.toString();
    var codigo = "";
    var numBloques = sumaStr.length;

    for (var i = 0; i < numBloques; i++) {

        codigo += sumaStr.charAt(i);
        codigo += generarCaracterAleatorio();
        codigo += generarCaracterAleatorio();

        if (i < numBloques - 1) {
            codigo += "-";
        }
    }
    return codigo;
}


function vCo(ctdc, ntdc) {

    var partesC = ctdc.split('-');
    var sumaC = "";

    for (var i = 0; i < partesC.length; i++) {
        sumaC += partesC[i].charAt(0);
    }

    var sumaCInt = parseInt(sumaC);
    var sumaLetl = sLEl(ntdc);
    return sumaCInt === sumaLetl;

}



function MiraFgCo(email, code) {

var ntdc = email;
var sLs = sLEl(ntdc);
var ctdc = gCo(sLs);

ctdc = code;
var esC = vCo(ctdc, ntdc);

if (esC) {
     VarPGlobal2 = code;
     console.noteln("Licensed to:");
     console.writeln(email);
     console.writeln(code);
     console.writeln("")
} else {
     VarPGlobal3 = code;
     console.writeln("Licensed to:");
     console.writeln(email);
     console.writeln(code);
     console.writeln("")
}
}




