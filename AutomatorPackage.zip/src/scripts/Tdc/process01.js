


function MiraProyecto() {
    console.writeln("Automator Script");
    console.writeln("");
    console.noteln("Project Type:");
    console.writeln(ProjecTypevar);
    console.noteln("Alignment Channel:");
    if (AlignmenTypevar === "Ha") {
        console.write("Project images");
    } else {
        console.write(AlignmenTypevar);
    }

    console.writeln("");
    console.noteln("Selected Images:");
    console.writeln("  Ha: " + PimageHa);
    console.writeln("  Sii: " + PimageSii);
    console.writeln("  Oiii: " + PimageOiii);
    console.writeln("  Red: " + PimageRed);
    console.writeln("  Green: " + PimageGreen);
    console.writeln("  Blue: " + PimageBlue);
    console.writeln("  Luminance: " + PimageLuminance);
    console.noteln("Options:");
    console.writeln("  Link RGB Channels: " + OptionLinkRGB);
    console.writeln("  Run StarXterminator: " + OptionStarXterminator);
    console.writeln("  Run BlurXterminator: " + OptionBlurXterminator);
    console.writeln("  Run GraXNoise: " + OptionGraXNoise);
    console.writeln("  Run Green Reduction. Value: " + NewGreenValue);
    console.writeln("  Run Enhanced Process: " + OptionEnh);
    console.writeln("  Create a Project Stars layer: " + OptionHSOvar);
    console.writeln("  Create a RGB Stars layer: " + Option1var);
    console.writeln("  Adjust 300ppp Resolution: " + Option2var);
    console.writeln("");
}

function MiraVentana() {
    let proceed = true;

    if (ProjecTypevar === "RGB" && (PimageRed === "EMPTY" || PimageGreen === "EMPTY" || PimageBlue === "EMPTY")) {
        new MessageBox("Image not found. Please check selected images", "Error", StdIcon_Error, StdButton_Ok).execute();
        console.writeln("Cancel Process...");
        proceed = false;
    } else if (ProjecTypevar === "LRGB" && (PimageLuminance === "EMPTY" || PimageRed === "EMPTY" || PimageGreen === "EMPTY" || PimageBlue === "EMPTY")) {
        new MessageBox("Image not found. Please check selected images", "Error", StdIcon_Error, StdButton_Ok).execute();
        console.writeln("Cancel Process...");
        proceed = false;
    } else if (ProjecTypevar === "SHO" && (PimageSii === "EMPTY" || PimageHa === "EMPTY" || PimageOiii === "EMPTY")) {
        new MessageBox("Image not found. Please check selected images or Project Type", "Error", StdIcon_Error, StdButton_Ok).execute();
        console.writeln("Cancel Process...");
        proceed = false;
    } else if (ProjecTypevar === "HOO" && (PimageHa === "EMPTY" || PimageOiii === "EMPTY")) {
        new MessageBox("Image not found. Please check selected images or Project Type", "Error", StdIcon_Error, StdButton_Ok).execute();
        console.writeln("Cancel Process...");
        proceed = false;
    } else {
        console.writeln("");
        console.noteln("Running Process...");
    }

    return proceed;
}

function MiraRenombre() {
    let windows = ImageWindow.windows;
    console.writeln("");
    console.noteln("Renaming Process...");

    function renameWindow(imageName, newName) {
        for (let i = 0; i < windows.length; i++) {
            if (windows[i].mainView.id === imageName) {
                windows[i].mainView.id = newName;
                console.writeln("Renamed " + imageName + " to " + newName);
                return true;
            }
        }
        console.criticalln("Window not found for image: " + imageName);
        return false;
    }

   if (AlignmenTypevar === "All by Ha") {
        renameWindow(PimageHa, "Filter_Ha");
        renameWindow(PimageRed, "Filter_Red");
        renameWindow(PimageGreen, "Filter_Green");
        renameWindow(PimageBlue, "Filter_Blue");
        renameWindow(PimageLuminance, "Filter_Luminance");
        renameWindow(PimageSii, "Filter_Sii");
        renameWindow(PimageOiii, "Filter_Oiii");
    } else if (ProjecTypevar === "RGB") {
        renameWindow(PimageRed, "Filter_Red");
        renameWindow(PimageGreen, "Filter_Green");
        renameWindow(PimageBlue, "Filter_Blue");
    } else if (ProjecTypevar === "LRGB") {
        renameWindow(PimageLuminance, "Filter_Luminance");
        renameWindow(PimageRed, "Filter_Red");
        renameWindow(PimageGreen, "Filter_Green");
        renameWindow(PimageBlue, "Filter_Blue");
    } else if (ProjecTypevar === "SHO") {
        renameWindow(PimageSii, "Filter_Sii");
        renameWindow(PimageHa, "Filter_Ha");
        renameWindow(PimageOiii, "Filter_Oiii");
    } else if (ProjecTypevar === "HOO") {
        renameWindow(PimageHa, "Filter_Ha");
        renameWindow(PimageOiii, "Filter_Oiii");
    }
}

function MiraIconos() {
    var Iconoabuscar = ProcessInstance.fromIcon(MiraIconosvar);

    if (Iconoabuscar === null || Iconoabuscar.isNull) {
        new MessageBox("¡¡¡ Error !!! " + MiraIconosvar + " Icon not found.", "Error", StdIcon_Error, StdButton_Ok).execute();
        console.criticalln("¡¡¡ Error !!! " + MiraIconosvar + " Icon not found.");
        return false;
    } else {
        console.noteln("Icon " + MiraIconosvar + " found. Starting Process...");
        return true;
    }
}



function MiraAlignTotal() {
    let referenceImage = "";
    let targets = [];

    // Configuración de referencia y objetivos según el ProjecTypevar y AlignmenTypevar
    if (AlignmenTypevar === "All by Ha") {
        referenceImage = "Filter_Ha";
        targets = [
            [true, false, "Filter_Red"],
            [true, false, "Filter_Green"],
            [true, false, "Filter_Blue"],
            [true, false, "Filter_Luminance"],
            [true, false, "Filter_Sii"],
            [true, false, "Filter_Oiii"]
        ];
    } else if (ProjecTypevar === "RGB") {
        referenceImage = "Filter_Red";
        targets = [
            [true, false, "Filter_Green"],
            [true, false, "Filter_Blue"]
        ];
    } else if (ProjecTypevar === "LRGB") {
        referenceImage = "Filter_Luminance";
        targets = [
            [true, false, "Filter_Red"],
            [true, false, "Filter_Green"],
            [true, false, "Filter_Blue"]
        ];

    } else if (ProjecTypevar === "SHO") {
        referenceImage = "Filter_Ha";
        targets = [
            [true, false, "Filter_Sii"],
            [true, false, "Filter_Oiii"]
        ];
    } else if (ProjecTypevar === "HOO") {
        referenceImage = "Filter_Ha";
        targets = [
            [true, false, "Filter_Oiii"]
        ];

    } else {
        console.criticalln("Unrecognized ProjecTypevar: " + ProjecTypevar);
        return false;
    }

    // Configuración del StarAlignment con los valores obtenidos
    var P = new StarAlignment;
    P.structureLayers = 5;
    P.noiseLayers = 0;
    P.referenceImage = referenceImage;
    P.targets = targets;
    P.inputHints = "";
    P.outputHints = "";
    P.mode = StarAlignment.prototype.RegisterMatch;
    P.outputPrefix = "";
    P.outputPostfix = "_registered";
    P.outputExtension = ".xisf";

    // Ejecutar StarAlignment
    console.noteln("Running StarAlignment with reference: " + referenceImage);
    let result = P.executeGlobal();

    if (result) {
        console.noteln("StarAlignment completed successfully.");

        // Duplicar y renombrar la ventana de referencia
        let referenceWindow = ImageWindow.windowById(referenceImage);
        if (referenceWindow && referenceWindow instanceof ImageWindow) {
            console.noteln("Reference image found: " + referenceImage);

            let width = referenceWindow.mainView.image.width;
            let height = referenceWindow.mainView.image.height;
            let numberOfChannels = referenceWindow.mainView.image.numberOfChannels;
            let bitsPerSample = referenceWindow.bitsPerSample || 32;
            let isFloatSample = referenceWindow.isFloatSample || true;
            let isColor = typeof referenceWindow.isColor === 'boolean' ? referenceWindow.isColor : false;

            let registeredWindow = new ImageWindow(
                width,
                height,
                numberOfChannels,
                bitsPerSample,
                isFloatSample,
                isColor
            );

            registeredWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
            registeredWindow.mainView.image.assign(referenceWindow.mainView.image);
            registeredWindow.mainView.endProcess();

            registeredWindow.mainView.id = referenceImage + "_registered";
            registeredWindow.show();
            console.noteln("Duplicated and renamed: " + referenceImage + " to " + registeredWindow.mainView.id);

            return true;  // Salida exitosa
        } else {
            console.criticalln("Reference image not found or is not a valid ImageWindow: " + referenceImage);
            throw new Error("Exiting script due to alignment failure...");
        }
    } else {
        console.criticalln("StarAlignment process failed.");
        throw new Error("Exiting script due to alignment failure...");
    }
}




function MiraRenomGraXpert() {
    let windows = ImageWindow.windows;

    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;

        // Verificar si el nombre de la ventana contiene "_registered"
        if (windowId.indexOf("_registered") !== -1) {
            // Crear la duplicación de la ventana
            let width = windows[i].mainView.image.width || 1000;
            let height = windows[i].mainView.image.height || 1000;
            let numberOfChannels = windows[i].mainView.image.numberOfChannels || 1;
            let bitsPerSample = windows[i].bitsPerSample || 16;
            let isFloatSample = windows[i].isFloatSample !== undefined ? windows[i].isFloatSample : true;
            let isColor = windows[i].isColor !== undefined ? windows[i].isColor : false;

            let duplicateWindow = new ImageWindow(
                width,
                height,
                numberOfChannels,
                bitsPerSample,
                isFloatSample,
                isColor
            );

            duplicateWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
            duplicateWindow.mainView.image.assign(windows[i].mainView.image);
            duplicateWindow.mainView.endProcess();

            // Renombrar la ventana duplicada con "_GraXpert"
            let newWindowId = windowId + "_GraXpert";
            duplicateWindow.mainView.id = newWindowId;
            duplicateWindow.show();

            console.noteln("Duplicated and renamed: " + windowId + " to " + newWindowId);
        }
    }

    console.writeln("");
    console.noteln("Completed renaming for GraXpert process.");
}




function iconizeAndArrangeWindows() {
    console.writeln("");
    console.noteln("Running Iconized Process...");

    // Obtener todas las ventanas abiertas
    let windows = ImageWindow.windows;
    let baseWindow = null;
    let finalWindow = null;

    // Iterar sobre todas las ventanas para encontrar las que tienen "Base" o "Final" en su nombre
    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;
        if (windowId.indexOf("Base") !== -1) {
            baseWindow = windows[i];
        } else if (windowId.indexOf("Final") !== -1) {
            finalWindow = windows[i];
        }
    }

    // Iconizar todas las ventanas excepto las que tienen "Base" o "Final" en su nombre
    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;
        if (windowId.indexOf("Base") === -1 && windowId.indexOf("Final") === -1) {
            windows[i].iconize();
        }
    }

    // Asegurarse de que "Base" y "Final" estén al frente y activas
    if (baseWindow) {
        baseWindow.bringToFront();
        baseWindow.show();
    }
    if (finalWindow) {
        finalWindow.bringToFront();
        finalWindow.show();
    }

}




