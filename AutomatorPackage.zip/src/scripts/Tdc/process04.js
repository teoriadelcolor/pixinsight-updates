

function ExitWithLuminosityMaskCheck2() {
    // Obtener todas las ventanas abiertas
    let windows = ImageWindow.windows;
    let luminosityWindows = [];

    // Iterar a través de todas las ventanas y buscar las que tengan "luminosity" en su ID
    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;
        if (windowId.indexOf("luminosity") !== -1) {
            luminosityWindows.push(windows[i]);
        }
    }

    // Si hay ventanas de luminosidad, las elimina
    if (luminosityWindows.length > 0) {

            // Eliminar todas las ventanas de luminosidad
            for (let i = 0; i < luminosityWindows.length; i++) {
                luminosityWindows[i].forceClose();
                console.writeln("Deleted luminosity mask window: " + luminosityWindows[i].mainView.id);
            }
    }

}



function ExitWithLuminosityMaskCheck() {
    // Obtener todas las ventanas abiertas
    let windows = ImageWindow.windows;
    let luminosityWindows = [];

    // Iterar a través de todas las ventanas y buscar las que tengan "luminosity" en su ID
    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;
        if (windowId.indexOf("luminosity") !== -1) {
            luminosityWindows.push(windows[i]);
        }
    }

    // Si hay ventanas de luminosidad, preguntar si se desean borrar antes de salir
    if (luminosityWindows.length > 0) {
        let msgBox = new MessageBox(
            "Luminosity Masks founded\nDo you want to delete them?",
            "Confirmation",
            StdIcon_Question,
            StdButton_Yes,
            StdButton_No
        );

        let response = msgBox.execute();

        if (response === StdButton_Yes) {
            // Eliminar todas las ventanas de luminosidad
            for (let i = 0; i < luminosityWindows.length; i++) {
                luminosityWindows[i].forceClose();
                console.writeln("Deleted luminosity mask window: " + luminosityWindows[i].mainView.id);
            }
            console.noteln("Luminosity mask windows deleted.");
        } else if (response === StdButton_No) {
            console.noteln("Exiting without deleting luminosity mask windows.");
        }
    } else {
        //console.writeln("No luminosity mask windows found.");
    }

    // Salir de la aplicación
    console.writeln("Exiting Automator Script...");

}




function fitImageToWindow(imageViewerControl, selectedImage, oneToOne = false) {
    if (!selectedImage) {
        console.criticalln("Error: No image selected for fitting.");
        return;
    }



    let imageWidth = selectedImage.width;
    let imageHeight = selectedImage.height;


    // Verificar si queremos mostrar la imagen en 1:1
    if (oneToOne) {
        imageViewerControl.doUpdateImage(selectedImage); // Mostrar la imagen en su tamaño original
         enableDragging(imageViewerControl, selectedImage);  // Habilitar el arrastre
        return;
    }

  // Si no es 1:1, realizar el ajuste normal
   let viewportWidth = 600;
   let viewportHeight = 400;


    // Calculamos el factor de escala para ajustar la imagen al viewport
    let widthScale = viewportWidth / imageWidth;
    let heightScale = viewportHeight / imageHeight;
    let scaleFactor = Math.min(widthScale, heightScale);


    // Utilizamos el menor factor de escala para mantener las proporciones de la imagen
    //let scaleFactor = Math.min(widthScale, heightScale);

    // Verificar si la imagen necesita reducción
    if (scaleFactor < 1) {
        // Invertir el zoomFactor para hacer una reducción (Zoom negativo)
        let zoomFactor = -Math.round(1 / scaleFactor);  // Zoom negativo para reducir

        // Creamos una ventana temporal para redimensionar la imagen
        let tempWindow = new ImageWindow(
            imageWidth, imageHeight, selectedImage.numberOfChannels,
            selectedImage.bitsPerSample, selectedImage.isReal, selectedImage.isColor
        );

        tempWindow.mainView.beginProcess();
        tempWindow.mainView.image.assign(selectedImage);
        tempWindow.mainView.endProcess();

        // Aplicar el factor de reducción usando zoom negativo
        let resample = new IntegerResample;
        resample.zoomFactor = zoomFactor;  // Zoom negativo para reducción
        resample.executeOn(tempWindow.mainView);

        // Actualizamos la imagen redimensionada en el control de visualización
        let resizedImage = new Image(tempWindow.mainView.image);
        imageViewerControl.doUpdateImage(resizedImage);

        // Cerramos la ventana temporal
        tempWindow.forceClose();
    } else {
        // Si la imagen ya es más pequeña que el viewport, mostrarla en su tamaño original
        imageViewerControl.doUpdateImage(selectedImage);
    }
}


function MiraPreview(imageViewerControl, imageSelector) {

    let selectedImageId = imageSelector.currentItem;
    if (selectedImageId >= 0) {
        let selectedImageName = imageSelector.itemText(selectedImageId);
        let selectedWindow = ImageWindow.windowById(selectedImageName);

        if (selectedWindow && selectedWindow.mainView) {
            let selectedImage = selectedWindow.mainView.image;
            fitImageToWindow(imageViewerControl, selectedImage, false);  // Ajustamos la imagen a la ventana
            imageViewerControl.show();
        } else {
            console.criticalln("Error: Selected image window or mainView not found.");
        }
    } else {
        console.criticalln("No image selected.");
    }
}


function MiraTextureOrBackgroundPro(imageViewerControl, imageSelector, OptionSharpenNonstellar, processType) {
    let selectedImageIndex = imageSelector.currentItem;
    let selectedImageName = imageSelector.itemText(selectedImageIndex);

    if (selectedImageIndex < 0 || !selectedImageName) {
        console.criticalln("No image selected. Please select an image to apply the process.");
        return;
    }

    let selectedWindow = ImageWindow.windowById(selectedImageName);

    if (!selectedWindow || !selectedWindow.mainView || selectedWindow.mainView.isNull) {
        console.criticalln("Selected image window is invalid or not found.");
        return;
    }

    if (!selectedWindow.mainView.image.isColor) {
        let messageBox = new MessageBox(
            "Error: ChannelExtraction can only be executed on RGB color images.\nPlease, use Non-linear images.",
            "Invalid Image Type",
            StdIcon_Error,
            StdButton_Ok
        );
        messageBox.execute();
        return;
    }

    // Create luminosity masks (for both texture and adjustment)
    let P = new ChannelExtraction;
    P.colorSpace = ChannelExtraction.prototype.CIELab;
    P.channels = [[true, ""], [false, ""], [false, ""]];
    P.sampleFormat = ChannelExtraction.prototype.SameAsSource;
    P.inheritAstrometricSolution = true;

    if (!P.executeOn(selectedWindow.mainView)) {
        console.criticalln("Failed to apply the luminosity mask.");
        return;
    }

    let maskWindowName = selectedImageName + "_L";
    let maskWindow = ImageWindow.windowById(maskWindowName);

    if (!maskWindow || !maskWindow.mainView || maskWindow.mainView.isNull) {
        console.criticalln("Failed to find the luminosity mask window.");
        return;
    }

    maskWindow.bringToFront();
    let newMaskWindowName = selectedImageName + "_luminosity_" + processType;
    maskWindow.mainView.id = newMaskWindowName;

    P.executeOn(selectedWindow.mainView);
    maskWindowName = selectedImageName + "_L";
    maskWindow = ImageWindow.windowById(maskWindowName);

    if (!maskWindow || !maskWindow.mainView || maskWindow.mainView.isNull) {
        console.criticalln("Failed to find the second luminosity mask.");
        return;
    }

    maskWindow.bringToFront();
    newMaskWindowName = selectedImageName + "_luminosity_adjustment";
    maskWindow.mainView.id = newMaskWindowName;

    let adjustmentsImageWindow = maskWindow;
    let OptionSigmavar = 5.00;
    MiraHT50(adjustmentsImageWindow);
    MiraCom(adjustmentsImageWindow, OptionSigmavar);

    let textureImageWindow = ImageWindow.windowById(selectedImageName + "_luminosity_" + processType);

    if (!textureImageWindow || !textureImageWindow.mainView || textureImageWindow.mainView.isNull) {
        console.criticalln("Failed to find the texture image window.");
        return;
    }

    if (!adjustmentsImageWindow || !adjustmentsImageWindow.mainView || adjustmentsImageWindow.mainView.isNull) {
        console.criticalln("Failed to find the adjustments image window.");
        return;
    }

    textureImageWindow.bringToFront();
    if (textureImageWindow.mainView.mask) {
        textureImageWindow.mainView.mask = null;
    }

    try {
        textureImageWindow.mask = adjustmentsImageWindow;
        textureImageWindow.maskInverted = false;
        textureImageWindow.maskVisible = true;
    } catch (error) {
        console.criticalln("Failed to apply the adjustments mask to the texture image. Error: " + error.message);
        return;
    }

    textureImageWindow.invertMask = true;
    MiraFondo(textureImageWindow);
    textureImageWindow.invertMask = false;

    if (typeof OptionBlurXterminator !== "undefined" && OptionBlurXterminator === "ON") {
        MiraTextureFin(textureImageWindow, OptionSharpenNonstellar);
    }

    let originalImageWindow = ImageWindow.windowById(selectedImageName);
    if (!originalImageWindow || !originalImageWindow.mainView || originalImageWindow.mainView.isNull) {
        console.criticalln("Failed to find the original image window.");
        return;
    }

    originalImageWindow.bringToFront();
    let duplicateImageWindow = new ImageWindow(
        originalImageWindow.mainView.image.width,
        originalImageWindow.mainView.image.height,
        originalImageWindow.mainView.image.numberOfChannels,
        originalImageWindow.mainView.image.bitsPerSample,
        originalImageWindow.mainView.image.sampleType != SampleType_Real,
        originalImageWindow.mainView.image.isColor
    );

    duplicateImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    duplicateImageWindow.mainView.image.assign(originalImageWindow.mainView.image);
    duplicateImageWindow.mainView.endProcess();

    let newDuplicateWindow = duplicateImageWindow;
    newDuplicateWindow.mainView.id = selectedImageName + "_" + processType + "Pro";

    duplicateImageWindow.bringToFront();
    OptionSigmavar = 10.00;
    MiraCom(duplicateImageWindow, OptionSigmavar);

    let textureProWindow = ImageWindow.windowById(newDuplicateWindow.mainView.id);
    MiraPasaTexturaPro(textureProWindow, textureImageWindow);

    let finalWindowName = selectedImageName + "_" + processType + "Pro_session0";
    newDuplicateWindow.mainView.id = finalWindowName;
    duplicateImageWindow.show();

    console.writeln("Process completed for image: " + selectedImageName);
}







// Función para aplicar HistogramTransformation (MiraHT50)
function MiraHT50(window) {
    var P = new HistogramTransformation;
    P.H = [
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.26329114, 1.00000000, 0.00000000, 1.00000000],
        [0.00000000, 0.50000000, 1.00000000, 0.00000000, 1.00000000]
    ];
    P.executeOn(window.mainView);
}

// Función para aplicar Convolution (MiraCom)
function MiraCom(window, OptionSigmavar) {
    var P = new Convolution;
    P.mode = Convolution.prototype.Parametric;
    P.sigma = OptionSigmavar;
    P.shape = 2.00;
    P.aspectRatio = 1.00;
    P.rotationAngle = 0.00;
    P.rescaleHighPass = false;
    P.executeOn(window.mainView);
}

// Función para aplicar ACDNR (MiraFondo)
function MiraFondo(window) {
    var P = new ACDNR;
    P.applyToLightness = true;
    P.applyToChrominance = true;
    P.useMaskL = true;
    P.useMaskC = true;
    P.sigmaL = 2.0;
    P.sigmaC = 2.0;
    P.shapeL = 0.50;
    P.shapeC = 0.50;
    P.amountL = 0.90;
    P.amountC = 1.00;
    P.iterationsL = 3;
    P.iterationsC = 3;
    P.executeOn(window.mainView);
}

// Función para aplicar BlurXTerminator (MiraTextureFin)
function MiraTextureFin(window, OptionSharpenNonstellar) {
    console.writeln("TexturePro Sharpen value = " + OptionSharpenNonstellar);
    var P = new BlurXTerminator;
    P.ai_file = "BlurXTerminator.4.mlpackage";
    P.lum_only = true;
    P.sharpen_stars = 0.70;
    P.adjust_halos = -0.08;
    P.sharpen_nonstellar = OptionSharpenNonstellar;
    P.executeOn(window.mainView);
}

// Definición de la función MiraPasaTexturaPro()
function MiraPasaTexturaPro(newDuplicateWindow, luminosityTextureWindow) {
    var P = new LRGBCombination;
    P.channels = [
        [false, "Filter_Red_registered_DBE", 1.00000],
        [false, "Filter_Green_registered_DBE", 1.00000],
        [false, "Filter_Blue_registered_DBE", 1.00000],
        [true, luminosityTextureWindow.mainView.id, 1.00000] // Usar el nombre de la ventana "xxx_texturePro"
    ];
    P.mL = 0.500;
    P.mc = 0.500;
    P.clipHighlights = true;
    P.noiseReduction = true;
    P.layersRemoved = 4;
    P.layersProtected = 2;
    P.inheritAstrometricSolution = true;

    // Ejecutar el proceso en la ventana proporcionada

    P.executeOn(newDuplicateWindow.mainView);
}



function MiraProcesosPro (imageViewerControl, imageSelector, OptionSharpenNonstellar, OptionProOne, OptionMergePro1, OptionMergePro2) {

   console.noteln("Adjustment value: " + OptionSharpenNonstellar);

            dialog.spaceLabel2.foregroundColor = 0xFF0000;  // Color rojo (en formato RGB hexadecimal)
            // Actualizar el label para que el cambio sea visible
            dialog.spaceLabel2.update();

            dialog.spaceLabel2.text = "Running Process. Please wait... ";

            //MiraPreview(imageViewerControl, imageSelector);
            ExitWithLuminosityMaskCheck2(); //Mira si hay ML creadas anteriores

            console.noteln("Option selected: " + OptionProOne);
            console.noteln("Adjustmente value: " + OptionSharpenNonstellar);

            if (OptionProOne === "Detail") {
                //Ejecuta Proceso 01
                console.noteln("Running Enhanced Detail Process...");
                 MiraTextureOrBackgroundPro(imageViewerControl, imageSelector, OptionSharpenNonstellar, "texture");
            } else if (OptionProOne === "Background") {
               //Ejecuta Proceso 02
               console.noteln("Running Enhanced Background Process...");
               MiraTextureOrBackgroundPro(imageViewerControl, imageSelector, OptionSharpenNonstellar, "background");
            } else if (OptionProOne === "Merge") {
               //Ejecuta Proceso 03
               console.noteln("Running Merge Images Process...");
               MiraMergePro(OptionMergePro1, OptionMergePro2, OptionSharpenNonstellar)
            }

            dialog.spaceLabel2.foregroundColor = 0x0000FF;  // Color azul (en formato RGB hexadecimal)
            dialog.spaceLabel2.text = "Done !!!";


            // Mostrar la nueva imagen en el visor con zoom 1:1
            console.noteln("Loading Image...");

            MiraPreview(imageViewerControl, imageSelector); // Llamar a la función MiraPreview

            console.noteln("Process End...");


}







function MiraMergePro(OptionMergePro1, OptionMergePro2, OptionSharpenNonstellar) {
    console.noteln("Merge Process: " + OptionMergePro1 + " , " + OptionMergePro2);

    dialog.spaceLabel2.text = "Running Process: 1 to 3. Please wait... ";

    // Validar que las variables de imagen no sean "None"
    if (OptionMergePro1 === "None" || OptionMergePro2 === "None") {
        console.criticalln("No valid images selected for merging.");
        return;
    }

    // Obtener la ventana de la imagen A (OptionMergePro1)
    let selectedWindow1 = ImageWindow.windowById(OptionMergePro1);

    if (!selectedWindow1 || !selectedWindow1.mainView || selectedWindow1.mainView.isNull) {
        console.criticalln("Image window for OptionMergePro1 is invalid or not found.");
        return;
    }

    dialog.spaceLabel2.text = "Running Process: 2 to 3. Please wait... ";

    // Obtener la ventana de la imagen B (OptionMergePro2)
    let selectedWindow2 = ImageWindow.windowById(OptionMergePro2);

    if (!selectedWindow2 || !selectedWindow2.mainView || selectedWindow2.mainView.isNull) {
        console.criticalln("Image window for OptionMergePro2 is invalid or not found.");
        return;
    }

    // Crear una nueva ventana para fusionar las dos imágenes
    let newImageWindow = new ImageWindow(
        selectedWindow1.mainView.image.width,
        selectedWindow1.mainView.image.height,
        selectedWindow1.mainView.image.numberOfChannels,
        selectedWindow1.mainView.image.bitsPerSample,
        selectedWindow1.mainView.image.sampleType != SampleType_Real,
        selectedWindow1.mainView.image.isColor
    );

    // Copiar los datos de la imagen A a la nueva ventana
    newImageWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
    newImageWindow.mainView.image.assign(selectedWindow1.mainView.image);
    newImageWindow.mainView.endProcess();

 dialog.spaceLabel2.text = "Running Process: 3 to 3. Please wait... ";

    // Usar PixelMath para combinar las imágenes A y B con la opacidad de OptionSharpenNonstellar
    var P = new PixelMath;
    // Ajustar la expresión para multiplicar por 2 la contribución de la segunda imagen
      // Combina las imágenes con una mayor presencia para la segunda imagen
      //P.expression = "~((~" + OptionMergePro1 + ") * (~" + OptionMergePro2 + "))";

      // Ajustar la expresión para multiplicar por 2 la contribución de la segunda imagen
       //  P.expression = "~((~" + OptionMergePro1 + ") * (~" + OptionMergePro2 + ") * " + OptionSharpenNonstellar + ")";
       //P.expression = "(" + OptionMergePro1 + ") * (1 - " + OptionSharpenNonstellar + ") + (" + OptionMergePro2 + ") * " + OptionSharpenNonstellar;
P.expression = "1 - ((1 - " + OptionMergePro1 + ") * (1 - (" + OptionMergePro2 + " * " + OptionSharpenNonstellar + ")))";


         // Aplicar la expresión a todos los canales
         P.expression1 = P.expression;
         P.expression2 = "";
         P.expression3 = "";
         P.useSingleExpression = true;



    // Ejecutar PixelMath sobre la nueva ventana
    if (!P.executeOn(newImageWindow.mainView)) {
        console.criticalln("PixelMath merge process failed.");
        return;
    }

    // Renombrar la ventana fusionada
    let newImageName = OptionMergePro1 + "_mergePro_session0";
    newImageWindow.mainView.id = newImageName;

    // Mostrar la nueva ventana
    newImageWindow.show();

    console.writeln("New Merged image created with name: " + newImageName);
}
