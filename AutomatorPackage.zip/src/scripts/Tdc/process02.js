

function MiraProcesoGeneral01() {
    if (typeof ProjecTypevar === "undefined") {
        console.criticalln("Error: ProjecTypevar is not defined. Exiting process.");
        return;
    }

    let projectType = ProjecTypevar;
    let processes = ["ABE", "GraXpert", "GraXNoise", "StarXterminator", "DBE", "END"];
    let imageSequence = [];

    // Construir la secuencia de imágenes a partir de las variables correspondientes
    if (projectType === "RGB") {
        imageSequence = ["Filter_Red_registered", "Filter_Green_registered", "Filter_Blue_registered"];
    } else if (projectType === "LRGB") {
        imageSequence = ["Filter_Luminance_registered", "Filter_Red_registered", "Filter_Green_registered", "Filter_Blue_registered"];
    } else if (projectType === "SHO") {
        imageSequence = ["Filter_Sii_registered", "Filter_Ha_registered", "Filter_Oiii_registered"];
    } else if (projectType === "HOO") {
        imageSequence = ["Filter_Ha_registered", "Filter_Oiii_registered"];
    } else {
        console.criticalln("Error: Unrecognized ProjecTypevar value: " + projectType);
        return;
    }

    for (let i = 0; i < imageSequence.length; i++) {
        let currentImage = imageSequence[i];

        let window = ImageWindow.windowById(currentImage);
        if (window && !window.isNull) {
            window.bringToFront();
        } else {
            console.criticalln("Could not find or activate window for " + currentImage);
            continue;
        }

        for (let j = 0; j < processes.length; j++) {
            VarPGlobal = processes[j];

            if (VarPGlobal === "END") {
                console.noteln("Completed all processes for image: " + currentImage);
                break;
            }

            // Skip StarXterminator if the option is OFF
            if (VarPGlobal === "StarXterminator" && OptionStarXterminator === "OFF") {
                console.writeln("Skipping StarXterminator process for " + currentImage);
                console.writeln("Executing StarNet2 instead for " + currentImage);

                try {
                    // Ejecutar MiraStarnet2() en lugar de StarXterminator
                    console.show();
                    let targetWindow = ImageWindow.windowById(currentImage);
                    if (targetWindow && !targetWindow.isNull) {
                        MiraStarnet2(targetWindow.mainView); // Ejecutar StarNet2 en la ventana principal
                    } else {
                        console.criticalln("StarNet2 - Window not found or is invalid: " + currentImage);
                    }
                } catch (e) {
                    console.warningln("An error occurred while executing StarNet2: " + e.message);
                    console.warningln("Continuing with the next process...");
                }

                continue;
            }

            try {
                if (VarPGlobal === "ABE") {
                    // Llamar a la función MiraABE en lugar de MiraIconos
                    let targetWindow = window;
                    MiraABE(targetWindow);
                } else if (VarPGlobal === "GraXNoise" && OptionGraXNoise === "ON") {
                    console.show();
                    MiraGraXNoise(currentImage);
                } else if (VarPGlobal === "DBE" && OptionDBE === "ON") {
                    // Ejecutar DBE
                    // Aquí iría la función para DBE
                } else if (VarPGlobal === "GraXpert") {
                    console.show();
                    MiraGraXpert(currentImage);
                } else if (VarPGlobal === "StarXterminator") {
                    console.show();
                    let targetWindow = ImageWindow.windowById(currentImage);
                    if (targetWindow && !targetWindow.isNull) {
                        // Modificar el nombre de la imagen para que tenga el sufijo "_ABE"
                        let originalName = targetWindow.mainView.id;
                        let newName = originalName;

                        // Si no tiene el sufijo "_ABE", lo añadimos
                        if (!originalName.endsWith("_ABE")) {
                            newName = originalName + "_ABE";
                        }
                        // Buscar la ventana con el nuevo nombre si existe
                        let newTargetWindow = ImageWindow.windowById(newName);
                        MiraStarXterminator(newTargetWindow.mainView); // Pasa el mainView correctamente
                    } else {
                        console.criticalln("StarXterminator - Window not found or is invalid: " + currentImage);
                    }
                }
            } catch (e) {
                console.warningln("An error occurred while executing " + VarPGlobal + ": " + e.message);
                console.warningln("Continuing with the next process...");
            }
        }

        // Aplicar STF y HistogramTransformation en la ventana que contiene "_registered_ABE"
        let abeRegisteredWindow = null;
        let windows = ImageWindow.windows;
        for (let k = 0; k < windows.length; k++) {
            let windowId = windows[k].mainView.id;
            if (typeof windowId === "string" && windowId.indexOf("_registered_ABE") !== -1) {
                abeRegisteredWindow = windows[k];
                break;
            }
        }

        if (abeRegisteredWindow && !abeRegisteredWindow.isNull) {
            // Ejecución de STF
            MiraSTFProcess(abeRegisteredWindow.mainView);
        } else {
            console.criticalln("Could not find or activate ABE window for " + currentImage);
        }
    }

    console.writeln("");
    console.noteln("All processes have been completed for all images.");
}


///////////////////////////////////////////////////////////////////////////////////

function MiraSTFProcess(view) {
    console.noteln("Applying STF and HistogramTransformation to: " + view.id);

    // Determinar si RGB Channels están vinculados
    let rgbLinked = (OptionLinkRGB === "ON");

    // Paso 1: Ejecución de STF
    let shadowsClipping = -2.8;
    let targetBackground = 0.25;

    console.writeln("Link RGB Channels: " + rgbLinked);

    var stf = new ScreenTransferFunction;

    var n = view.image.isColor ? 3 : 1;

    var median = view.computeOrFetchProperty("Median");
    var mad = view.computeOrFetchProperty("MAD");
    mad.mul(1.4826);

    var A = [
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1]
    ];

    if (rgbLinked) {
        var invertedChannels = 0;
        for (var c = 0; c < n; ++c) {
            if (median.at(c) > 0.5) ++invertedChannels;
        }

        if (invertedChannels < n) {
            var c0 = 0, m = 0;
            for (var c = 0; c < n; ++c) {
                if (1 + mad.at(c) != 1) c0 += median.at(c) + shadowsClipping * mad.at(c);
                m += median.at(c);
            }
            c0 = Math.range(c0 / n, 0.0, 1.0);
            m = Math.mtf(targetBackground, m / n - c0);

            A = [
                [c0, 1, m, 0, 1],
                [c0, 1, m, 0, 1],
                [c0, 1, m, 0, 1],
                [0, 1, 0.5, 0, 1]
            ];
        } else {
            var c1 = 0, m = 0;
            for (var c = 0; c < n; ++c) {
                m += median.at(c);
                if (1 + mad.at(c) != 1) c1 += median.at(c) - shadowsClipping * mad.at(c);
                else c1 += 1;
            }
            c1 = Math.range(c1 / n, 0.0, 1.0);
            m = Math.mtf(c1 - m / n, targetBackground);

            A = [
                [0, c1, m, 0, 1],
                [0, c1, m, 0, 1],
                [0, c1, m, 0, 1],
                [0, 1, 0.5, 0, 1]
            ];
        }
    } else {
        for (var c = 0; c < n; ++c) {
            if (median.at(c) < 0.5) {
                var c0 = (1 + mad.at(c) != 1) ? Math.range(median.at(c) + shadowsClipping * mad.at(c), 0.0, 1.0) : 0.0;
                var m = Math.mtf(targetBackground, median.at(c) - c0);
                A[c] = [c0, 1, m, 0, 1];
            } else {
                var c1 = (1 + mad.at(c) != 1) ? Math.range(median.at(c) - shadowsClipping * mad.at(c), 0.0, 1.0) : 1.0;
                var m = Math.mtf(c1 - median.at(c), targetBackground);
                A[c] = [0, c1, m, 0, 1];
            }
        }
    }

    stf.STF = A;
    stf.executeOn(view);

    // Paso 2: Convertir STF a parámetros de HistogramTransformation
    var HT = new HistogramTransformation;
    HT.H = stf.STF.map((stfChannel) => {
        return [stfChannel[0], stfChannel[2], stfChannel[1], stfChannel[3], stfChannel[4]];
    });

    HT.executeOn(view);

    // Paso 3: Resetear STF
    var stfReset = new ScreenTransferFunction;
    stfReset.STF = [
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1],
        [0, 1, 0.5, 0, 1]
    ];
    stfReset.executeOn(view);

    console.noteln("STF and HistogramTransformation applied successfully. Link RGB Channels option = " + rgbLinked);


}



///////////////////////////////////////////////////////////////////////////////////


function MiraRenombraBases() {
    let windows = ImageWindow.windows;

    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;

        // Buscar la imagen generada por MiraChannelComb que empieza con "Image"
        if (windowId.startsWith("Image")) {
            let baseWindowName = "Base_Non_Linear" + "_" + ProjecTypevar;

            // Renombrar la imagen existente
            windows[i].mainView.id = baseWindowName

            console.noteln("Renamed: " + windowId + " to " + baseWindowName);


                //Si StarLayer =on no hagas el STF.

                   if (VarProcesStar === "OFF"){

                       // Aplicar STF después de renombrar
                         MiraSTFProcess(windows[i].mainView);
                       // Salir del bucle después de renombrar y aplicar STF a la ventana correspondiente

                          // Crear la duplicación de la ventana
                          let width = windows[i].mainView.image.width || 1000;
                          let height = windows[i].mainView.image.height || 1000;
                          let numberOfChannels = windows[i].mainView.image.numberOfChannels || 1;
                           let bitsPerSample = windows[i].bitsPerSample || 16;
                           let isFloatSample = windows[i].isFloatSample !== undefined ? windows[i].isFloatSample : true;
                           let isColor = windows[i].isColor !== undefined ? windows[i].isColor : false;

                           let duplicateWindow = new ImageWindow(
                               width,
                              height,
                             numberOfChannels,
                             bitsPerSample,
                          isFloatSample,
                          isColor
                      );

                      duplicateWindow.mainView.beginProcess(UndoFlag_NoSwapFile);
                      duplicateWindow.mainView.image.assign(windows[i].mainView.image);
                      duplicateWindow.mainView.endProcess();

                      // Renombrar la ventana duplicada con "_GraXpert"
                      let newWindowId = "Final_starless";
                      duplicateWindow.mainView.id = newWindowId;
                      duplicateWindow.show();

                console.noteln("Duplicated and renamed STF window to 'Final_starless'");

                   break;
                  }

        }
      }

    console.writeln("");
    console.noteln("Completed renaming for final image and STF application.");
}



function MiraChannelCom() {
    if (typeof ProjecTypevar === "undefined") {
        console.criticalln("Error: ProjecTypevar is not defined. Exiting process.");
        return;
    }

    let iconName = "";

    // Determinar el nombre del icono basado en el tipo de proyecto
    if (ProjecTypevar === "RGB") {
        if (Option1var === "OFF") {
            iconName = "RGB";
        } else {
            iconName = "RGB_stars";
        }
    } else if (ProjecTypevar === "LRGB") {
        iconName = "LRGB";
    } else if (ProjecTypevar === "SHO") {
        iconName = "SHO";
    } else if (ProjecTypevar === "HOO") {
        iconName = "HOO";
    } else {
        console.criticalln("Error: Unrecognized ProjecTypevar value: " + ProjecTypevar);
        return;
    }

    console.writeln("");
    console.noteln("Channel Combination process completed.");

    // Ejecutar MiraChannel2 con el tipo de proyecto
    console.noteln("Executing MiraChannel2 for " + ProjecTypevar + "...");
    MiraChannel2(iconName);

    MiraRenombraBases(); // Renombra y aplica STF

    // Comprobar si OptionGradient está activado
    if (OptionGradient === "ON") {

    MiraGradient();  // Ejecutar MiraGradient

}
}




function MirashowTotalTime(startTime) {

    let totalTime = Date.now() - startTime;
    let seconds = Math.floor((totalTime / 1000) % 60);
    let minutes = Math.floor((totalTime / (1000 * 60)) % 60);
    let hours = Math.floor((totalTime / (1000 * 60 * 60)) % 24);

   // Función para añadir ceros delante si el número es menor a 10
    function pad(number) {
        return number < 10 ? '0' + number : number;
    }

    // Formatear el tiempo total utilizando la función pad
    let formattedTime = pad(hours) + ':' + pad(minutes) + ':' + pad(seconds);


    console.writeln("");
    console.warningln("Total Process Time: " + formattedTime);
    dialog.workingLabel.foregroundColor = 0x000000;  // Color negro (en formato RGB hexadecimal)
    // Actualizar el label para que el cambio sea visible

    dialog.workingLabel.text = "Total elapsed time: " + formattedTime;
    dialog.workingLabel.update();


}

function MiraCheckWindowsABE() {
    let windows = ImageWindow.windows;

    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;

        if (windowId.indexOf("_registered_") !== -1 || windowId.indexOf("_ABE") !== -1) {
            let msgBox = new MessageBox(
                "Previous processes are found!\nPlease rename or close 'registered' and 'ABE' windows before starting a new process.",
                "Critical Error",
                StdIcon_Error,
                StdButton_Ok
            );

            msgBox.execute();
            console.criticalln("Previous processes are found, Please rename or close 'registered' and 'ABE' windows before starting a new process.");
            return false;
        }
    }

    return true;  // Continuar si no se encontraron ventanas con "_registered_" o "_ABE"
}




function MiraRGBStars() {
    console.writeln("");
    console.noteln("* * * * * * Stars Process RGB * * * * * * ");



    // Ejecutar el renaming y alineamiento de RGB
    VarProcesStar = "ON"; // ahora estamos en el proceso de crear la capa de estrellas
    ProjecTypevar = "RGB";
    console.noteln("Creating Stars Layer..." + ProjecTypevar);
    console.writeln("Creating Stars layer Step 1...");

    MiraVentana();
    MiraRenombre();
    MiraAlignTotal();

    // Busca ventana "Image"
    let windows = ImageWindow.windows;

    for (let i = 0; i < windows.length; i++) {
        let windowId = windows[i].mainView.id;

        // Buscar la imagen que empieza con "Filter"
        if (windowId.startsWith("Filter_Red_registered")) {
            windows[i].bringToFront(); // Trae la ventana al frente
            break; // Termina el bucle una vez que encuentres la ventana
        }
    }

    console.writeln("Creating Stars layer Step 2. ABE process...");

    let filters = ["Filter_Red_registered", "Filter_Blue_registered", "Filter_Green_registered"];

    // Recorrer las ventanas correspondientes a los filtros rojo, azul y verde
    for (let filter of filters) {
        for (let i = 0; i < windows.length; i++) {
            let windowId = windows[i].mainView.id;

            // Buscar la imagen que coincide con el filtro actual
            if (windowId.startsWith(filter)) {
                windows[i].bringToFront(); // Trae la ventana al frente
                let targetWindow = windows[i];
                MiraABE(targetWindow);
            }
        }
    }

    console.writeln("Completed ABE process on all filter windows.");
    console.writeln("Creating Stars layer Step 3...Channel combination.");

    // Ejecutar ChannelsCombination
    MiraChannelCom();

    // Buscar la ventana "Base_Non_Linear_RGB"
    let currentImage = "Base_Non_Linear_RGB";
    let window = ImageWindow.windowById(currentImage);
    if (window && !window.isNull) {
        window.bringToFront();
    } else {
        console.criticalln("Could not find or activate window for " + currentImage);
        return;
    }

    console.writeln("Creating Stars layer Step 4... Removal Stars");

    // Comprobación de si ejecutar StarXterminator o StarNet2
    if (VarPGlobal === "StarXterminator" && OptionStarXterminator === "OFF") {
        console.writeln("Skipping StarXterminator process for " + currentImage);
        console.writeln("Executing StarNet2 instead for " + currentImage);

        try {
            // Ejecutar MiraStarnet2() en lugar de StarXterminator
            console.show();
            let targetWindow = ImageWindow.windowById(currentImage);
            if (targetWindow && !targetWindow.isNull) {
                MiraStarnet2(targetWindow.mainView); // Ejecutar StarNet2 en la ventana principal
            } else {
                console.criticalln("StarNet2 - Window not found or is invalid: " + currentImage);
            }
        } catch (e) {
            console.warningln("An error occurred while executing StarNet2: " + e.message);
            console.warningln("Continuing with the next process...");
        }

        // En lugar de continuar, simplemente seguimos con el proceso sin hacer uso de "continue"
    } else {
        // Paso 3: Ejecutar StarXterminator
        VarPGlobal = "StarXterminator";
        OptionStarXterminator = "ON";
        let window2 = ImageWindow.windowById(currentImage);
        if (window2 && !window2.isNull) {
            MiraStarXterminator(window2.mainView);  // Pasa el mainView en lugar del ImageWindow completo
        } else {
            console.criticalln("StarXterminator - Window not found or is invalid: " + currentImage);
        }
    }

    // Buscar ventana generada por StarXterminator o StarNet2
    let starWindow = ImageWindow.windowById("Base_Non_Linear_RGB_stars");

    // Ejecutar proceso Magenta Stars
    MiraMagenta(); // Ejecuta MagentaStars

    // Ejecutar procesos adicionales si los iconos existen
    let processes = ["HT_stars", "Green", "BlurXterminator", "Sat_stars"];
    for (let i = 0; i < processes.length; i++) {
        VarPGlobal = processes[i];

        if (VarPGlobal === "BlurXterminator" && OptionBlurXterminator === "OFF") {
            console.writeln("Skipping BlurXterminator process as it is OFF");
            continue; // Saltar al siguiente proceso
        }

        if (VarPGlobal === "HT_stars") {
            console.writeln("Executing HT_stars on " + starWindow.mainView.id);
            MiraHistogram(NewStarsValue);
        } else if (VarPGlobal === "Green") {
            console.writeln("Executing Green process on " + starWindow.mainView.id);
            isStarProcess = true; // Activar el flag indicando que estamos en el proceso de estrellas
            MiraGreen();  // Llama a MiraGreen
            isStarProcess = false; // Desactivar el flag después del proceso
        } else if (VarPGlobal === "BlurXterminator") {
            console.writeln("Executing BlurXterminator process on " + starWindow.mainView.id);
            MiraBlurXterminator(starWindow.mainView);
        } else if (VarPGlobal === "Sat_stars") {
            console.writeln("Executing Sat_stars process on " + starWindow.mainView.id);
            MiraSaTstars();
        } else {
            console.warningln("Unknown process: " + VarPGlobal + ". Skipping...");
        }
    }

    // Renombrar la ventana activa como "stars"
    if (starWindow && !starWindow.isNull) {
        starWindow.mainView.id = "Final_stars";
        console.writeln("Window renamed to 'Final_stars'");
    } else {
        console.criticalln("Failed to rename window. 'starWindow' is not valid.");
    }

    // Buscar la ventana "starless" y ejecutar FinalStars
    let starlessWindow = ImageWindow.windowById("Final_starless");
    if (starlessWindow && !starlessWindow.isNull) {
        console.writeln("Executing MiraFinalStars on starless window...");
        MiraFinalStars();
    } else {
        console.criticalln("Failed to find 'Final_starless' window for Final_stars process.");
    }

    console.noteln("Stars RGB layer completed successfully and Final Merge done.");
} // fin del proceso MiraStarRGB









function MiraBorraVentanas() {
    let msgBox = new MessageBox("Delete intermediate Process windows?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
    console.writeln("");
    let response = msgBox.execute();

    if (response === StdButton_Yes) {
        let windows = ImageWindow.windows;
        let deletedCount = 0;

        // PRIMERO: Renombrar ventanas RGB si Option1var === "ON"
        for (let i = 0; i < windows.length; i++) {
            let windowId = windows[i].mainView.id;

            // Si Option1var está en "ON", renombrar ventanas de RGB
            if (Option1var === "ON" &&
                (windowId === "Filter_Red_registered_ABE" ||
                 windowId === "Filter_Green_registered_ABE" ||
                 windowId === "Filter_Blue_registered_ABE")) {

                // Renombrar estas ventanas a "Filter_XXX_registered_ABE_stars"
                windows[i].mainView.id = windowId.replace("_ABE", "_ABE_stars");
                //console.writeln("Renamed to: " + windows[i].mainView.id);
                continue;
            }
        }

        // SEGUNDO: Comenzar a borrar las ventanas
        for (let i = 0; i < windows.length; i++) {
            let windowId = windows[i].mainView.id;

            // Verificar si la ventana comienza con "Base_"
            if (windowId.startsWith("Base_")) {
                // Si Option1Var está en "ON" y el nombre es "Base_Non_Linear_RGB_stars", no la borres
                if (Option1var === "ON" && windowId === "Base_Non_Linear_RGB_stars") {
                    //console.writeln("Keeping window: " + windowId);  // No borrar esta ventana
                    continue;
                }

                // Borrar cualquier otra ventana que comience con "Base_"
                windows[i].forceClose();
                //console.writeln("Deleted window: " + windowId);
                deletedCount++;
                continue;  // Continuar al siguiente ciclo
            }

            // Verificar si la ventana comienza con "Create_"
            else if (windowId.startsWith("Create_")) {
                // Borrar las ventanas que comienzan con "Create_"
                windows[i].forceClose();
                //console.writeln("Deleted window: " + windowId);
                deletedCount++;
                continue;  // Continuar al siguiente ciclo
            }

            // Verificar si la ventana contiene "registered_"
            if (windowId.indexOf("registered") !== -1) {
                // Evitar borrar ventanas que terminan en "_ABE"
                if (windowId.endsWith("_ABE")) {
                    //console.writeln("Keeping window: " + windowId);  // No borrar las ventanas con ABE Final.
                    continue;  // No borrar estas ventanas
                }

                // Verificar ventanas que terminan en "_ABE_stars" con condiciones
                if (windowId.endsWith("_ABE_stars")) {
                    if (OptionHSOvar === "OFF" && Option1var === "OFF") {
                        // Si OptionHSOvar es "OFF" y Option1var es "OFF", borrar todas las ventanas "_ABE_stars"
                        windows[i].forceClose();
                        //console.writeln("Deleted window: " + windowId);
                        deletedCount++;
                    } else if (OptionHSOvar === "ON" && Option1var === "OFF") {
                        // Si OptionHSOvar es "ON" y Option1var es "OFF", borrar todas excepto las del ProjecTypevar
                        if (ProjecTypevar === "SHO" &&
                            (windowId === "Filter_Ha_registered_ABE_stars" ||
                             windowId === "Filter_Sii_registered_ABE_stars" ||
                             windowId === "Filter_Oiii_registered_ABE_stars")) {
                            //console.writeln("Keeping window: " + windowId);  // No borrar las ventanas de SHO
                            continue;
                        } else if (ProjecTypevar === "HOO" &&
                            (windowId === "Filter_Ha_registered_ABE_stars" ||
                             windowId === "Filter_Oiii_registered_ABE_stars")) {
                            //console.writeln("Keeping window: " + windowId);  // No borrar las ventanas de HOO
                            continue;
                        } else if (ProjecTypevar === "RGB" &&
                            (windowId === "Filter_Red_registered_ABE_stars" ||
                             windowId === "Filter_Green_registered_ABE_stars" ||
                             windowId === "Filter_Blue_registered_ABE_stars")) {
                            //console.writeln("Keeping window: " + windowId);  // No borrar las ventanas de RGB
                            continue;
                        } else if (ProjecTypevar === "LRGB" &&
                            (windowId === "Filter_Luminance_registered_ABE_stars" ||
                             windowId === "Filter_Red_registered_ABE_stars" ||
                             windowId === "Filter_Green_registered_ABE_stars" ||
                             windowId === "Filter_Blue_registered_ABE_stars")) {
                            //console.writeln("Keeping window: " + windowId);  // No borrar las ventanas de LRGB
                            continue;
                        }
                        // Borrar cualquier otra ventana "_ABE_stars"
                        windows[i].forceClose();
                        //console.writeln("Deleted window: " + windowId);
                        deletedCount++;
                    }
                } else if (windowId.startsWith("Filter_")) { //Opción NO estrellas SHO/HOO y SÍ estrellas RGB
                    // Borrar las ventanas que empiezan con "Filter_" excepto las del ProjecTypevar
                    if (ProjecTypevar === "SHO" &&
                        (windowId === "Filter_Ha" || windowId === "Filter_Sii" || windowId === "Filter_Oiii")) {
                        //console.writeln("Keeping window: " + windowId);  // No borrar estas ventanas
                        continue;
                    } else if (ProjecTypevar === "HOO" &&
                        (windowId === "Filter_Ha" || windowId === "Filter_Oiii")) {
                        //console.writeln("Keeping window: " + windowId);  // No borrar estas ventanas
                        continue;
                    }
                    // Borrar cualquier otra ventana "Filter_"
                    windows[i].forceClose();
                    //console.writeln("Deleted window: " + windowId);
                    deletedCount++;
                }
            }
        }



// Últimas ventanas borradas en proceso Star Layer RGB




    // Comprobar que Option1var esté en "ON"
    if (Option1var === "ON") {
        // Ventanas a eliminar
        let ventanasAEliminar = ["Filter_Sii_registered_ABE_stars", "Filter_Ha_registered_ABE_stars", "Filter_Oiii_registered_ABE_stars"];

        // Iterar por las ventanas disponibles
        for (let i = 0; i < windows.length; i++) {
            let windowId = windows[i].mainView.id;

            // Verificar si el ID de la ventana actual está en la lista de ventanas a eliminar
            if (ventanasAEliminar.indexOf(windowId) !== -1) {
                windows[i].forceClose();
                //console.writeln("Deleted window: " + windowId);
            }
        }
    } else {
        //console.noteln("RGB Star Layer is OFF, no windows will be deleted.");
    }





        // Acabamos. Verificar si se han eliminado ventanas
        if (deletedCount === 0) {
            console.noteln("No eligible windows found to delete.");
        } else {
            console.writeln("Total windows deleted: " + deletedCount);
        }
    } else if (response === StdButton_No) {
        console.noteln("Deletion of intermediate windows canceled.");
    }
}







function MiraGreen() {

        console.noteln("Green Reduction process is ON. Value " + NewGreenValue);

        // Ejecutar la nueva función MiraGreen2 en lugar de MiraIconos
        MiraGreen2(NewGreenValue); //si cambiamos el nombre de la función hay que mirar todas las llamadas...

}



function MiraMagenta() {
    console.noteln("Running Magenta Stars correction...");



    try {
        let activeWindow = ImageWindow.activeWindow;

        if (!activeWindow.isNull) {
            // Habilitar la edición de la imagen
            activeWindow.mainView.beginProcess(UndoFlag_NoSwapFile);

            // Invertir la imagen
            activeWindow.mainView.image.invert();
            console.noteln("Image inverted for Green correction.");

            //cambiamos el valor para Magenta???
            MiraMagenta2(NewMagentaValue);

            // Volver a invertir la imagen
            activeWindow.mainView.image.invert();

            // Finalizar el proceso de edición
            activeWindow.mainView.endProcess();
        } else {
            console.criticalln("No active window found to apply Magenta correction.");
        }

    } catch (e) {
        console.criticalln("Error executing Magenta Stars correction: " + e.message);
    }
}


function MiraSHOStars() {
    console.writeln("");
    console.noteln("* * * * * * Stars Process * * * * * * ");




    if (Option1var === "OFF") {
        iconName = ProjecTypevar;
        MiraChannelStars(iconName);

        // Buscar la ventana creada con el nombre "Imagexxx"
        let windows = ImageWindow.windows;
        let imageWindow = null;
        for (let i = 0; i < windows.length; i++) {
            if (windows[i].mainView.id.startsWith("Image")) {
                imageWindow = windows[i];
                break;
            }
        }

        if (imageWindow && !imageWindow.isNull) {
            let newWindowName = "Create_stars_" + ProjecTypevar;
            imageWindow.mainView.id = newWindowName;
            console.noteln("Renamed image window to: " + newWindowName);
        } else {
            console.criticalln("No window starting with 'Image' found after executing.");
            return;
        }

        // Buscar la ventana que contiene la Create_stars y ejecutar StarXterminator
        let currentImage = "Create_stars_" + ProjecTypevar;
        let window = ImageWindow.windowById(currentImage);
        if (window && !window.isNull) {
            window.bringToFront();
        } else {
            console.criticalln("Could not find or activate window for " + currentImage);
            return;
        }

       //
          console.writeln("Creating Stars layer Step 4... StarXterminator");

    // Comprobación de si ejecutar StarXterminator o StarNet2
    if (VarPGlobal === "StarXterminator" && OptionStarXterminator === "OFF") {
        console.writeln("Skipping StarXterminator process for " + currentImage);
        console.writeln("Executing StarNet2 instead for " + currentImage);

        try {
            // Ejecutar MiraStarnet2() en lugar de StarXterminator
            console.show();
            let targetWindow = ImageWindow.windowById(currentImage);
            if (targetWindow && !targetWindow.isNull) {
                MiraStarnet2(targetWindow.mainView); // Ejecutar StarNet2 en la ventana principal
            } else {
                console.criticalln("StarNet2 - Window not found or is invalid: " + currentImage);
            }
        } catch (e) {
            console.warningln("An error occurred while executing StarNet2: " + e.message);
            console.warningln("Continuing with the next process...");
        }

        // En lugar de continuar, simplemente seguimos con el proceso sin hacer uso de "continue"
    } else {
        // Paso 3: Ejecutar StarXterminator
        VarPGlobal = "StarXterminator";
        OptionStarXterminator = "ON";
        let window2 = ImageWindow.windowById(currentImage);
        if (window2 && !window2.isNull) {
            MiraStarXterminator(window2.mainView);  // Pasa el mainView en lugar del ImageWindow completo
        } else {
            console.criticalln("StarXterminator - Window not found or is invalid: " + currentImage);
        }
    }
       //

       // Buscar la ventana con el nombre que comienza con "Create_stars_" + ProjecTypevar + "_stars"
        let starWindow = null;
        windows = ImageWindow.windows; // No redeclarar, solo reasignar
        for (let i = 0; i < windows.length; i++) {
            let windowId = windows[i].mainView.id;
            if (windowId === "Create_stars_" + ProjecTypevar + "_stars") {
                starWindow = windows[i];
                break;
            }
        }



        if (starWindow && !starWindow.isNull) {
            console.noteln("*************** Running stars process ***************");

            // Ejecutar procesos adicionales si los iconos existen
            let processes = ["HT_stars", "Green", "BlurXterminator", "Sat_stars"];
            for (let i = 0; i < processes.length; i++) {
                VarPGlobal = processes[i];

                if (VarPGlobal === "BlurXterminator" && OptionBlurXterminator === "OFF") {
                    console.writeln("Skipping BlurXterminator process as it is OFF");
                    continue; // Saltar al siguiente proceso
                }

                if (VarPGlobal === "HT_stars") {
                    console.writeln("Executing HT_stars on " + starWindow.mainView.id);
                    MiraHistogram(NewStarsValue);
                } else if (VarPGlobal === "Green") {
                    console.writeln("Executing Green process on " + starWindow.mainView.id);
                    // Activar el flag indicando que estamos en el proceso de estrellas
                    isStarProcess = true;

                   // Ejecutar el proceso Green
                     MiraGreen();  // Llama a MiraGreen, pero isStarProcess indicará que estamos en el proceso de estrellas

                     // Desactivar el flag después del proceso
                     isStarProcess = false;

                } else if (VarPGlobal === "BlurXterminator") {
                    console.writeln("Executing BlurXterminator process on " + starWindow.mainView.id);
                    MiraBlurXterminator(starWindow.mainView);
                } else if (VarPGlobal === "Sat_stars") {
                    console.writeln("Executing Sat_stars process on " + starWindow.mainView.id);
                    MiraSaTstars();
                } else {
                    console.warningln("Unknown process: " + VarPGlobal + ". Skipping...");
                }
            }


            MiraMagenta(); //ejecuta MiraMagenta()

            console.writeln("Renaming " + starWindow.mainView.id);
            starWindow.mainView.id = "Final_stars";
            console.writeln("Window renamed to 'Final_stars'");

            // Buscar la ventana "Final_starless" y ejecutar MiraFinalStars
            let starlessWindow = ImageWindow.windowById("Final_starless");
            if (starlessWindow && !starlessWindow.isNull) {
                console.writeln("Executing MiraFinalStars on starless window...");
                MiraFinalStars();
            } else {
                console.criticalln("Failed to find 'Final_starless' window for Final_stars process.");
            }

            console.noteln("Stars " + ProjecTypevar + " layer completed successfully and Final Merge done.");
        } else {
            console.criticalln("Failed to rename window. 'starWindow' is not valid.");
            return;
        }
    } else {
        console.noteln("Option1var is ON, skipping star creation process for " + ProjecTypevar + ".");
    }
}



