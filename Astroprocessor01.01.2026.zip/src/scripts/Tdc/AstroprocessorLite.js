/*
 ****************************************************************************
 * AstroProcessor Script
 *
 * AstroProcessor.js
 * Copyright (C) 2024 Jesús Manuel García Flores
 *
 * This script will help you to automate the most common processes in Pixinisight.
 * Upgrade your license for free as Beta tester.
 *
 *
 * If you wish to contact us you can do so by email at info@teoriadelcolor.es
 *
 * This product is based on software from the PixInsight project, developed
 * by Pleiades Astrophoto and its contributors (https://pixinsight.com/).
 *
 * This script is protected by copyright and may not be copied,
 * modified, redistributed, or used in any medium without prior written
 * authorization from Teoría del Color.
 *
 *
 * Beta release.
 *
 ****************************************************************************
 */


#feature-id    AstroProcessor : Utilities > AstroProcessorLite
#feature-icon  AstroprocessorIcon.svg
#feature-info  This script will help you automate the most common processes in Pixinisight. \
Upgrade your license for free. \
<br/>\
Copyright &copy; 2024 Jesús M. García Flores.

#define TITLE "Astro Processor Script Lite"

#include <pjsr/Sizer.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/SectionBar.jsh>
#include <pjsr/Color.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/StdDialogCode.jsh>
#include "lib/lite01.js"
#include "lib/process11.js"
#include "lib/process03.js"
#include "lib/process02.js"
#include "lib/process01.js"



// Variables globales
var ProjecTname = "🚀" + " Astro Processor Script Lite";
var ProjecTver  = "v.0.1a";
var ProjecTypevar = "SHO";  // Valor inicial
var ProjecTypevar2 = "0"; //Valor inicial
var ProjecTypevarRec = "SHO";  // Valor inicial
var AlignmenTypevar = "Ha"; // Valor inicial
var OptionLinkRGB = "false";  // Deshabilitado por defecto
var PimageSii = "EMPTY";        // Valor inicial
var PimageHa = "EMPTY";         // Valor inicial
var PimageOiii = "EMPTY";       // Valor inicial
var PimageRed = "EMPTY";        // Valor inicial
var PimageGreen = "EMPTY";      // Valor inicial
var PimageBlue = "EMPTY";       // Valor inicial
var PimageLuminance = "EMPTY";  // Valor inicial
var PimageOsc = "EMPTY";  // Valor inicial
var Option1var = "OFF";         // Valor inicial para StarsRGB
var OptionHavar = "OFF";         // Valor inicial para HaMixed
var VarProcesStar = "OFF";      // Inicializamos la variable para saber cuando se está creando la capa stars
var Option2var = "OFF";          // Valor inicial para 300pppResolution
var Option2var2 = "OFF";
var Option300 = "OFF"         // Valor para Botón OK en 300pppResolution
var OptionABE = "ON";           // Valor inicial
var OptionGraXNoise = "OFF";    // Valor inicial
var OptionGraXpert  = "OFF";      // Valor inicial
var OptionNoiseXterminator  = "OFF";
var OptionStarXterminator = "ON";    // Valor inicial
var OptionstarNet = "OFF";      // Valor inicial
var OptionBlurXterminator = "ON";    // Valor inicial
var OptionHighpass = "OFF";    // Valor inicial
var OptionGradient ="ON";       // Valor inicial
var OptionDBE = "OFF";          // Valor inicial
var OptionEnh = "OFF";          // Valor inicial
var OptionVarStars = "ON";      // Valor inicial
var OptionMgc ="OFF";
var OptionFast = "OFF";
var MiraIconosvar = "SHO_Align";// Valor inicial
var VarPGlobal = "EMPTY";       // Valor inicial
var VarPGlobal2 ="EMPTY";       // Valor inicial
var VarPGlobal3 ="EMPTY";       // Valor inicial
var VarPGlobal4 ="EMPTY";       // Valor inicial
var VarLicense ="EMPTY";        // Valor inicial
var VarPL = "1234-1234-1234-1234";
var NewGreenValue = 0.0;  // Inicializamos NewGreenValue con 0.0
var NewMagentaValue = 1;  // Inicializamos NewMAgenta con 1
var NewStarsValue = 1;  // Inicializamos NewStarsValue
var NewProOptionValue = 100;  // Inicializamos NewStarsValue
var isStarProcess = false; //Valor de paso por MiraGreen2()
var OptionHSOvar = "ON";
var OptionProOne = "HDR";
var OptionMaskvar = "None";        // Inicialización por defecto
var OptionBlurMaskvar = "None";    // Inicialización por defecto
var OptionColorMaskvar = "Red channel"; // Inicialización por defecto
var OptionColorMaskHuevar = 10;     // Inicialización por defecto
var OptionColorMaskSatvar = 10;     // Inicialización por defecto
var OptionColorMaskLumvar = 10;     // Inicialización por defecto
var OptionColorMaskBlackvar = 10;
var OptionColorMaskWhitevar = 10;
var OptionColorMaskContrastvar = 10;
var OptionSigmavar = 5.00;
var OptionSharpenNonstellar = 0.20;
var OptionStarpresence = 10;
var OptionStarRounded = 10;
var OptionStartemperature = 10;
var OptionStarsaturation = 10;
var OptionStarhalo = 0;
var OptionStarblend = 20;
var OptionStarMagenta = 0;
var OptionStarGreen = 0;
var OptionStarBrillance = 10;
var OptionStarSharp = 0;
var OptionMergePro0  = "<Select an Image>";
var OptionMergePro1  = "<Select an Image>";
var OptionMergePro2  = "<Select an Image>";
var OptionMergePro4  = "<Select an Image>";
var OptionMergePro5  = "<Select an Image>";
var OptionAdjvalue = 1;
var OptionAdjvalue2 = 200;
var OptionshowMaskvar = "OFF";
var OptionTypeMaskvar = "None";
var OptionBlurMaskvar = "None";
var OptionRGBMaskvar = "None";
var OptionshowConsolRadio = "ON";
let previousMaskType = null;
let previousBlurOption = null;
var OptionNombVar = null;
var OptionRemaind = null;
var OptionRemaind2 = null;
var OptionReSLider = "OFF";
var OptionSTFvar = "OFF";
var Optiontimevar = null;
var OptionEnabledPreview ="OFF";
var OptionEnabledPreview2 ="OFF";
let lastState = null;      // Estado para Undo
let redoState = null;      // Estado para Redo
var OptionFlag ="0";
var OptionFlag2 = "0";
var OptionCrop  = "OFF";
var OptionGreen = "OFF";
var OptionLower = 0.4;
var OptionUpper = 1;
var OptionFuzziness = 0;
var OptionSmoothness = 0;
var OptionBlur = 0.1;
var OptionInvertMask = "OFF";
var savedImageName = "";
//
var defaultGrayWavelength = 656.30;
var defaultGrayBandwidth = 3.00;
var defaultRedWavelength = 656.30;
var defaultRedBandwidth = 3.00;
var defaultGreenWavelength = 500.70;
var defaultGreenBandwidth = 3.00;
var defaultBlueWavelength = 500.70;
var defaultBlueBandwidth = 3.00;
var Narrowband = "OFF";
var SensorName = "Ideal QE curve";
//ruta del archivo de Trabajo - Working file path
var originalFilePath ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathColor ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathLeyenda ="/Applications/PixInsight/src/scripts/Tdc/lib/";
var originalFilePathMars1 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMars2 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMars3 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin1 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin2 ="/Applications/PixInsight/src/scripts/Tdc/";
var originalFilePathMarsfin3 ="/Applications/PixInsight/src/scripts/Tdc/";
var MarsFound1 ="OFF";
var MarsFound2 ="OFF";
var MarsFound3 ="OFF";
var MarsEdited ="OFF";
var StarXPath ="EMPTY";
var StarXPath0 ="StarXTerminator.lite.nonoise.11.mlpackage";
var StarXPath1 ="StarXTerminator.lite.nonoise.11.pb";
var StarBPath ="EMPTY";
var StarBPath0 ="BlurXTerminator.4.mlpackage";
var StarBPath1 ="BlurXTerminator.4.pb";
var StarNPath ="EMPTY";
var StarNPath0 ="NoiseXTerminator.2.mlpackage";
var StarNPath03 ="NoiseXTerminator.3.mlpackage";
var StarNPath1 ="NoiseXTerminator.2.pb";
var StarNPath13 ="NoiseXTerminator.3.pb";
var StarMars1 ="MARS-DR1-1.0.3.xmars";
var StarMars2 ="MARS-DR1-u01-1.0.1.xmars";
var StarMars3 ="MARS-DR1-1.1.1.xmars";
var WindowsOsx1 = 27;
var WindowsOsx2 = 20;
var WindowsOsx3 = 400;
var WindowsOsx4 = 300;
var WindowsOsx5 = 400;
var WindowsOsx6 = 100;
var startTime = Date.now();  // Inicializar startTime al inicio del script


var totalTime = Date.now()
console.clear();
console.writeln(ProjecTname + " " + ProjecTver);
console.writeln("-------------------------------------");
console.noteln("Checking third-party software:");
//asigna datos iniciales
defaultGrayWavelength = 656.30;
defaultGrayBandwidth = 3.00;
defaultRedWavelength = 656.30;
defaultRedBandwidth = 3.00;
defaultGreenWavelength = 500.70;
defaultGreenBandwidth = 3.00;
defaultBlueWavelength = 500.70;
defaultBlueBandwidth = 3.00;
Narrowband = "OFF";
SensorName = "Ideal QE curve";

if (checkStarRemovalTools()) {
    console.noteln("Getting paths:");
} else {
    console.criticalln("⚠️ "+"Script cannot create starless image without StarXterminator or StarNet2.");
    console.criticalln("---------------------------------------------------------------------------");
}


//Ruta
// Llamar a la función para obtener la ruta válida
var originalFilePath = getFilePath(originalFilePathMars1, originalFilePathMars2);


// Creación del diálogo principal
function IntegratorDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = ProjecTname;

    let self = this; // Save the `IntegratorDialog` instance context


    // this.setFixedSize();  // Makes the dialog fixed in size if you want no resizing at all.
    this.resizeable = true;
    this.setMaxHeight(900);      // Ajusta el tamaño máximo en vertical (ajusta según tus necesidades)

    this.scaledMinWidth = 620;
    this.scaledMinHeight = 770;//750
    this.scaledMaxHeight = 900;
    this.scaledMaxWidth = 620;


    // Creación del contenedor de pestañas
    this.tabBox = new TabBox(this);


//-----------------------------------------------------------------------------
//Pestaña Integration----------------------------------------------------------
//-----------------------------------------------------------------------------

    // --- Tab 1: Integration ---
    this.integrationPage = new Control(this);
    this.integrationPage.sizer = new VerticalSizer;
    this.integrationPage.sizer.margin = 5;
    this.integrationPage.sizer.spacing = 6;

    // Crear un HorizontalSizer para mantener los dos GroupBoxes en horizontal
    let horizontalSizer = new HorizontalSizer;
    horizontalSizer.spacing = 10;  // Espacio entre los elementos

  // --- GroupBox: Project Type ---
    this.CropprojectTypeGroupBox = new GroupBox(this.integrationPage);
    this.CropprojectTypeGroupBox.title = "2. Select Gradient Correction:";
    this.CropprojectTypeGroupBox.sizer = new VerticalSizer;

    this.GRadientRadioButton = new CheckBox(this);
    this.GRadientRadioButton.text = "Gradient Correction";
    this.GRadientRadioButton.checked = true;
    this.GRadientRadioButton.enabled = true;

   this.GRadientRadioButton.onClick = function () {
    OptionCrop = (OptionCrop === "ON") ? "OFF" : "ON";

    if (OptionCrop === "ON") {
        console.noteln("⚙️ Gradient Correction = 'Enabled'");
        OptionGradient = "ON"
        self.GRadientRadioButton.checked = true;
    } else {
       OptionGradient = "OFF"
        console.noteln("⚙️ Gradient Correction = 'Disabled'");
        self.GRadientRadioButton.checked = false;
    }

    this.dialog.update();
    };


    // RadioButtons para Project Type
    this.CropprojectLRGBRadioButton = new CheckBox(this);
    this.CropprojectLRGBRadioButton.text = "Multiscale Gradient Correction";
    this.CropprojectLRGBRadioButton.checked = false;
    this.CropprojectLRGBRadioButton.enabled = true;
    OptionCrop = "ON";


   // Crear el Label
    let MGCLabel = new Label(this.integrationPage);
    MGCLabel.text = "Clic on '⚙️' to select SFC options and MGC path.";
    MGCLabel.textAlignment = TextAlign_Left;



    this.CropprojectLRGBRadioButton.onClick = function () {
    if (this.checked) { // Verificar si el RadioButton está activado

        OptionCrop = "ON"; // Cambiar a "ON"
        console.noteln("⚙️Multiscale Gradient Correction = 'Enabled'");
        self.MgcCheckBox.enabled = true;
    } else {
        OptionCrop = "OFF"; // Si no está activado, cambiar a "OFF"
        console.noteln("⚙️ Multiscale Gradient Correction = 'Disabled'");
        self.MgcCheckBox.enabled = false;
    }
    this.dialog.update(); // Actualizar la interfaz si es necesario
   };

    // Crear el Label para seleccionar una imagen
    let CropLabel = new Label(this.integrationPage);
    CropLabel.text = "\nCropped images and SFC.\nFirst, run 'ImageSolver' on each image.\nGaia DR3SP must be installed.";
    CropLabel.textAlignment = TextAlign_Left;


    this.CropprojectTypeGroupBox.sizer.margin = 6;
    this.CropprojectTypeGroupBox.sizer.spacing = 6;
    this.CropprojectTypeGroupBox.sizer.add(this.GRadientRadioButton);
    this.CropprojectTypeGroupBox.sizer.add(this.CropprojectLRGBRadioButton);
    this.CropprojectTypeGroupBox.sizer.add(MGCLabel);
    this.CropprojectTypeGroupBox.sizer.add(CropLabel);


   // Crea el Checkbox para Ha para poder manejarlo

    this.HalphaCheckBox = new CheckBox(this);
    this.HalphaCheckBox.text = "Create 'HAlpha' for blending (RGB/LRGB)";
    this.HalphaCheckBox.checked = false;  // Predeterminado activado

    // --- GroupBox: Project Type ---

    function MiraComboProyect() {
    // Disable all ComboBoxes by default
    for (let key in comboBoxReferences) {
        comboBoxReferences[key].enabled = false;
        comboBoxReferences[key].update();
    }

    // Enable specific ComboBoxes based on project type
    switch (ProjecTypevar) {
        case "RGB":
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "LRGB":
            comboBoxReferences["PimageLuminance"].enabled = true;
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        case "SHO":
            comboBoxReferences["PimageSii"].enabled = true;
            comboBoxReferences["PimageHa"].enabled = true;
            comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "HOO":
            comboBoxReferences["PimageHa"].enabled = true;
            comboBoxReferences["PimageOiii"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            self.HalphaCheckBox.checked = false;
            break;

        case "OSC":
            comboBoxReferences["PimageOsc"].enabled = true;
            ProjecTypevarRec = ProjecTypevar;
            console.writeln("⚙️ Current Project: " + ProjecTypevarRec);
            break;

        default:
            console.warningln("Unknown project type: " + ProjecTypevar);
            break;
    }

    // Update the UI
    for (let key in comboBoxReferences) {
        comboBoxReferences[key].update();
    }

}


    this.projectTypeGroupBox = new GroupBox(this.integrationPage);
    this.projectTypeGroupBox.title = "1. Select Project type:";
    this.projectTypeGroupBox.sizer = new VerticalSizer;

    // RadioButtons para Project Type
    this.projectLRGBRadioButton = new RadioButton(this);
    this.projectLRGBRadioButton.text = "LRGB";
    this.projectLRGBRadioButton.onClick = function () {
       ProjecTypevar = "LRGB";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectRGBRadioButton = new RadioButton(this);
    this.projectRGBRadioButton.text = "RGB";
    this.projectRGBRadioButton.onClick = function () {
       ProjecTypevar = "RGB";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectSHORadioButton = new RadioButton(this);
    this.projectSHORadioButton.text = "SHO";
    this.projectSHORadioButton.checked = true;
    this.projectSHORadioButton.onClick = function () {
       ProjecTypevar = "SHO";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectHOORadioButton = new RadioButton(this);
    this.projectHOORadioButton.text = "HOO";
    this.projectHOORadioButton.onClick = function () {
       ProjecTypevar = "HOO";
       self.FastCheckBox.enabled = true;
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectOSCRadioButton = new RadioButton(this);
    this.projectOSCRadioButton.text = "OSC (RGB Color camera .xisf or Raw)";
    this.projectOSCRadioButton.onClick = function () {
       ProjecTypevar = "OSC";
       MiraComboProyect();
       this.dialog.update();
    };

    this.projectTypeGroupBox.sizer.margin = 6;
    this.projectTypeGroupBox.sizer.spacing = 6;

    this.projectTypeGroupBox.sizer.add(this.projectLRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectRGBRadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectSHORadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectHOORadioButton);
    this.projectTypeGroupBox.sizer.add(this.projectOSCRadioButton);
    let labeldual = new Label(this);
    labeldual.text = "OSC Dual band. Run 'DbXtract' and SHO Project.";
    labeldual.textAlignment = TextAlign_Left;
    this.projectTypeGroupBox.sizer.add(labeldual);


    // --- GroupBox: Alignment Type ---


    // Añadir los dos GroupBoxes al HorizontalSizer para que estén en la misma fila

    horizontalSizer.add(this.projectTypeGroupBox);
    horizontalSizer.add(this.CropprojectTypeGroupBox);
    //horizontalSizer.add(this.alignmentGroupBox);


    // --- GroupBox: Tagging ---
    this.taggingGroupBox = new GroupBox(this.integrationPage);
    this.taggingGroupBox.title = "3. Select Images:";
    this.taggingGroupBox.sizer = new VerticalSizer;

    let comboBoxReferences = {};

    function addTaggingControl(parentSizer, labelText, variableKey) {
       let rowSizer = new HorizontalSizer; // Alineación horizontal
       rowSizer.spacing = 6; // Espaciado entre elementos

       let label = new Label(this);
       label.text = labelText;
       label.textAlignment = TextAlign_Left | TextAlign_VertCenter;
       label.setFixedWidth(140); // Ajusta el ancho del label para alineación

       let comboBox = new ComboBox(this);
       comboBox.editEnabled = false;
       comboBox.setFixedHeight(WindowsOsx2);
       comboBox.addItem("<Select an Image>");

       let windowList = ImageWindow.windows;

       for (let i = 0; i < windowList.length; i++) {
           let window = windowList[i];
           let windowTitle = "<Untitled>";

           // Intentar extraer el título desde el filePath (si la imagen proviene de un archivo)
           if (window.filePath && window.filePath.length > 0) {
               let fileName = window.filePath.replace(/^.*[\\\/]/, ''); // Extrae solo el nombre del archivo
               windowTitle = fileName.replace(/\.[^/.]+$/, ""); // Elimina la extensión del archivo
           } else {
               // Si no hay filePath, usa el identificador interno
               windowTitle = window.currentView.fullId;
           }

           comboBox.addItem(windowTitle);
       }

       comboBoxReferences[variableKey] = comboBox;

       comboBox.onItemSelected = function (index) {
           let selectedText = comboBox.itemText(index);
           if (variableKey === "PimageSii") PimageSii = selectedText;
           if (variableKey === "PimageHa") PimageHa = selectedText;
           if (variableKey === "PimageOiii") PimageOiii = selectedText;
           if (variableKey === "PimageRed") PimageRed = selectedText;
           if (variableKey === "PimageGreen") PimageGreen = selectedText;
           if (variableKey === "PimageBlue") PimageBlue = selectedText;
           if (variableKey === "PimageLuminance") PimageLuminance = selectedText;
           if (variableKey === "PimageOsc") PimageOsc = selectedText;
       };

       // Agregar los elementos al mismo HorizontalSizer
       rowSizer.add(label);
       rowSizer.add(comboBox, 1); // Expande el ComboBox para alineación correcta

       // Agregar el rowSizer al parentSizer
       parentSizer.add(rowSizer);
   }

      this.taggingGroupBox.sizer.margin = 6;
      this.taggingGroupBox.sizer.spacing = 6;

      // Añadir cada control con el nuevo formato en línea
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Sii Image:", "PimageSii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Ha Image:", "PimageHa");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Oiii Image:", "PimageOiii");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Red Image:", "PimageRed");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Green Image:", "PimageGreen");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Blue Image:", "PimageBlue");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "Luminance Image:", "PimageLuminance");
      addTaggingControl.call(this, this.taggingGroupBox.sizer, "OSC Image:", "PimageOsc");

      // Agregar las pestañas al TabBox debajo de los 2 grupos
      this.tabBox.addPage(this.integrationPage, "Integration");


    // --- GroupBox: Project Options ---
    this.optionsGroupBox = new GroupBox(this.integrationPage);
    this.optionsGroupBox.title = "4. Select Integration options:";
    this.optionsGroupBox.sizer = new HorizontalSizer;

    // Crear un `VerticalSizer` para la primera columna
    let column1Sizer = new VerticalSizer;
    column1Sizer.spacing = 6;
    column1Sizer.margin = 6;

    // Checkboxes para la primera columna
      this.linkRGBChannels = new RadioButton(this);
      this.linkRGBChannels.text = "Link RGB Channels";
      this.linkRGBChannels.checked = false;  // Predeterminado deshabilitado
      this.linkRGBChannels.onCheck = function(checked) {
          if (checked) {
              OptionLinkRGB = "true";
          } else {
          OptionLinkRGB = "false";
         }
      };


   this.ABECheckBox = new CheckBox(this);
   this.ABECheckBox.text = "Automatic mode (Basic)"; // Texto inicial
   this.ABECheckBox.checked = true; // Estado inicial
   this.ABECheckBox.onClick = function () {
       if (this.checked) {
           OptionABE = "ON";
           this.text = "Automatic mode (Basic)"; // Cambiar el texto cuando está activado
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Automatic mode (Basic)");
           self.FastCheckBox.checked = false;
           self.FastCheckBox.enabled = true;

       } else {
           OptionABE = "OFF";
           this.text = "Manual mode (Advanced)"; // Cambiar el texto cuando está desactivado
           this.styleSheet = "color: blue;";
           console.noteln("⚙️ Manual mode (Advanced)");
           self.FastCheckBox.styleSheet = "color: black;"; //
           self.FastCheckBox.text = "Fast integration mode 'OFF' "; // Cambiar el texto cuando está desactivado
           self.FastCheckBox.checked = false;
           self.FastCheckBox.enabled = false;
       }
   };


   this.FastCheckBox = new CheckBox(this);
   this.FastCheckBox.text = "Fast integration mode 'OFF' "; // Texto inicial
   this.FastCheckBox.checked = false; // Estado inicial

    this.FastCheckBox.onClick = function () {
       if (this.checked) {
           OptionFast = "ON";
           this.text = "Fast integration mode 'ON' "; // Cambiar el texto cuando está activado
           this.styleSheet = "color: blue;";
           console.noteln("⚙️ Fast integration mode 'ON' - (Developed for Low performance computers)");
       } else {
           OptionFast = "OFF";
           this.text = "Fast integration mode 'OFF' "; // Cambiar el texto cuando está desactivado
           this.styleSheet = "color: black;";
           console.noteln("⚙️ Fast integration mode 'OFF' - (Developed for High performance computers)");

       }
   };


   let self = this; // Guardamos referencia a `this` para usarlo dentro de la función

   self.MgcCheckBox = new CheckBox(this);
   self.MgcCheckBox.text = "Multiscale Gradient Correction";
   self.MgcCheckBox.enabled = false;
   self.MgcCheckBox.checked = false;

   this.MgcCheckBox.onClick = function () {

         //Mirar la herramienta:
            try {
           // Intentar crear una instancia de MultiscaleGradientCorrection
           var P = new MultiscaleGradientCorrection();

             console.noteln("🟢 MultiscaleGradientCorrection is available.");

            } catch (error) {
            console.criticalln("Error: MultiscaleGradientCorrection is not available in this PixInsight version.");
            throw new Error("Execution stopped due to missing tool.");
            }

        //Fin de comprobar herramienta

       if (this.checked) {
           OptionMgc = "ON";


           if (MarsFound1 === "OFF" || MarsFound2 === "OFF") {
               console.warningln("⚠️ " + "Multiscale Gradient Correction Error.\nMARS database not found.\nPress 'setting' " + "⚙️" +  " button and select Multiscale Gradiente Correction library path.");
               self.MgcCheckBox.checked = false; // Usamos `self` para referenciar correctamente el CheckBox
               self.MgcCheckBox.enabled = false;
               self.CropprojectLRGBRadioButton.checked = false;
           } else {
               console.noteln("⚙️ Multiscale Gradient Correction : ON");
           }
       } else {
           OptionMgc = "OFF";
           console.noteln("⚙️ Multiscale Gradient Correction : OFF");
       }
    };

    this.graXpertCheckBox = new CheckBox(this);
    this.graXpertCheckBox.text = "GraXpert Background Extraction (Internet)";
    this.graXpertCheckBox.checked = false;
    this.graXpertCheckBox.onClick = function () {
        //OptionGraXpert = this.checked ? "ON" : "OFF";
        if (this.checked) {
        OptionGraXpert = "ON";
        console.noteln("⚙️ GraXpert background Extraction : ON");
         } else {
        OptionGraXpert = "OFF";
        console.noteln("⚙️ GraXpert background Extraction : OFF");
         }

    };

    this.graXNoiseCheckBox = new CheckBox(this);
    this.graXNoiseCheckBox.text = "Denoising by GraXpert (Internet)";
    this.graXNoiseCheckBox.checked = false;


    this.NoiseXterminatorCheckBox = new CheckBox(this);
    this.NoiseXterminatorCheckBox.text = "Denoising by NoiseXTerminator";
    this.NoiseXterminatorCheckBox.checked = false;

    this.NoiseXterminatorCheckBox.onClick = function () {
    // Actualizar la variable según el estado del CheckBox
    if (this.checked) {
        OptionNoiseXterminator = "ON";
        console.noteln("⚙️ NoiseXterminator : ON");
        OptionGraXNoise = "OFF";
    } else {
        OptionNoiseXterminator = "OFF";
        console.noteln("⚙️ NoiseXterminator : OFF");
    }

    // Desmarcar GraXNoiseCheckBox al activar NoiseXterminatorCheckBox
    this.dialog.graXNoiseCheckBox.checked = false;
};


    this.graXNoiseCheckBox.onClick = function () {
    // Actualizar la variable según el estado del CheckBox
    if (this.checked) {
        OptionGraXNoise = "ON";
        console.noteln("⚙️ GraXpert Denoising : ON");
        OptionNoiseXterminator = "OFF";
    } else {
        OptionGraXNoise = "OFF";
        console.noteln("⚙️ GraXpert Denoising : OFF");
    }

    // Desmarcar NoiseXterminatorCheckBox al activar GraXNoiseCheckBox
    this.dialog.NoiseXterminatorCheckBox.checked = false;
};

    this.OptionVarStarsCheckBox = new CheckBox(this);
    this.OptionVarStarsCheckBox.text = "Create 'Final_starless' Image";
    this.OptionVarStarsCheckBox.checked = true;
    //pasamos el código LINEA 464 donde se dibuja starXterm y Starnet las opciones del checkbox -

    this.resolutionCheckBox = new CheckBox(this);
    this.resolutionCheckBox.text = "300ppi Print Resolution";
    this.resolutionCheckBox.checked = false;
    this.resolutionCheckBox.onClick = function () {
          // Actualizar la variable según el estado del CheckBox
          if (this.checked) {
              Option300 = "ON";
              console.noteln("⚙️ 300ppi Print Resolution : ON");
              OptionNoiseXterminator = "OFF";
          } else {
              Option300 = "OFF";
              console.noteln("⚙️ 300ppi Print Resolution : OFF");
          }

      };

    // Añadir checkboxes a la primera columna
    column1Sizer.add(this.linkRGBChannels);
    column1Sizer.add(this.ABECheckBox);
    column1Sizer.add(this.FastCheckBox);
    column1Sizer.add(this.MgcCheckBox);
    column1Sizer.add(this.graXpertCheckBox);
    column1Sizer.add(this.graXNoiseCheckBox);
    column1Sizer.add(this.NoiseXterminatorCheckBox);
    column1Sizer.add(this.resolutionCheckBox);

    // Crear un `VerticalSizer` para la segunda columna
    let column2Sizer = new VerticalSizer;
    column2Sizer.spacing = 6;
    column2Sizer.margin = 6;

   // stars
    this.starsHSOCheckBox = new CheckBox(this);
    this.starsHSOCheckBox.text = "Create 'Final_stars' (Project stars)";
    this.starsHSOCheckBox.checked = true;
    let self = this; // Guardar referencia al contexto actual
   this.starsHSOCheckBox.onClick = function () {
    // Cambiar el valor de OptionHSOvar dependiendo de si la opción está activada o desactivada
    OptionHSOvar = this.checked ? "ON" : "OFF";

    // Si la opción HSO está activada (ON)
    if (OptionHSOvar === "ON") {
        Option1var = "OFF";  // Apagar la opción RGB
        self.starsRGBCheckBox.checked = false;  // Desmarcar la opción RGB
    }
    // Si la opción HSO está desactivada (OFF)
    else {
        //Option1var = "ON";  // Encender la opción RGB
        //self.starsRGBCheckBox.checked = true;  // Marcar la opción RGB
    }
};

 // Configuración inicial para el proyecto
    ProjecTypevar = "SHO"; // Establecer el tipo de proyecto por defecto
    MiraComboProyect();    // Configurar los ComboBoxes al iniciar el diálogo

    // Checkboxes para la segunda columna
    this.starsRGBCheckBox = new CheckBox(this);
    this.starsRGBCheckBox.text = "Create RGB 'Final_stars' (SHO/HOO)";
    this.starsRGBCheckBox.checked = false;
    let self = this; // Guardar referencia al contexto actual



    this.starsRGBCheckBox.onClick = function () {

    if (ProjecTypevar !== "SHO" && ProjecTypevar !== "HOO") {
      console.criticalln("Invalid Project type selected. SHO or HOO type project, not selected.");
      self.starsRGBCheckBox.checked = false;
    return;
    }


   Option1var = this.checked ? "ON" : "OFF";
    self.starsHSOCheckBox.checked = false;
    var OptionHSOvar = "OFF";

    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("Enable RGB Images for stars?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
            comboBoxReferences["PimageRed"].enabled = true;
            comboBoxReferences["PimageGreen"].enabled = true;
            comboBoxReferences["PimageBlue"].enabled = true;
            Option1var = "ON";
            //recuerda el proyecto anterior.
            ProjecTypevar2 = "1";

    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        comboBoxReferences["PimageRed"].enabled = false;
        comboBoxReferences["PimageGreen"].enabled = false;
        comboBoxReferences["PimageBlue"].enabled = false;
        self.starsRGBCheckBox.checked = false;
        self.starsHSOCheckBox.checked = true;
        Option1var = "OFF";
        self.update();
    }
}; // Fin del checkbox




let self = this; // Guardar referencia al contexto principal

// Añadir el nuevo Checkbox para StarXterminator
this.starXterminatorCheckBox = new CheckBox(this);
this.starXterminatorCheckBox.text = "Create Starless by StarXTerminator";
this.starXterminatorCheckBox.checked = true;  // Predeterminado activado

// Añadir el nuevo Checkbox para StarNet2
this.starNetCheckBox = new CheckBox(this);
this.starNetCheckBox.text = "Create Starless by StarNet2";
this.starNetCheckBox.checked = false;  // Predeterminado desactivado

//Opciones del checkbox de starless
this.OptionVarStarsCheckBox.onClick = function () {
        OptionVarStars = this.checked ? "ON" : "OFF";
        if (OptionVarStars === "ON"){
           OptionVarStars = "ON";
           console.noteln("⚙️ Create 'Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.enabled = true;
           self.starNetCheckBox.enabled = true;
           self.starsHSOCheckBox.checked = true;
           self.starsHSOCheckBox.enabled = true;
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = true;
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is enabled");
        } else{
           OptionVarStars = "OFF";
           console.noteln("⚙️ Create a Starless Final Image: " + OptionVarStars);
           self.starXterminatorCheckBox.checked = true;
           self.starXterminatorCheckBox.enabled = false;
           OptionStarXterminator = "ON";

           self.starNetCheckBox.checked = false;
           self.starNetCheckBox.enabled = false;
           OptionstarNet = "OFF";
           self.starsHSOCheckBox.checked = false;
           self.starsHSOCheckBox.enabled = false;
           self.starsRGBCheckBox.checked = false;
           self.starsRGBCheckBox.enabled = false;
           console.noteln("⚙️ Create a 'Final_stars'(Project stars and RGB stars), is disabled");
        }
    };
//


// Variable para almacenar el método seleccionado
let starRemovalMethodLabel = "Star Removal by StarXterminator";  // Predeterminado
OptionStarXterminator = "ON";
OptionstarNet = "OFF";


// Evento onClick para gestionar el cambio entre StarXterminator y StarNet2
this.starXterminatorCheckBox.onClick = function () {
    if (this.checked) {
        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarNet2 cuando se selecciona StarXterminator
        dialog.starNetCheckBox.checked = false;
        OptionStarXterminator = "ON";
        OptionstarNet = "OFF";

        console.writeln("Fast Process !!!");
    } else {
        // Si se desactiva StarXterminator, activar StarNet2 por defecto
        dialog.starNetCheckBox.checked = true;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");
        OptionstarNet = "ON";

        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Slow Process !!!");
    }
};

// Evento onClick para gestionar el cambio entre StarNet2 y StarXterminator
this.starNetCheckBox.onClick = function () {
    if (this.checked) {
        starRemovalMethodLabel = "Star Removal by StarNet2";
        console.noteln(starRemovalMethodLabel + " method selected.");

        // Desactivar StarXterminator cuando se selecciona StarNet2
        dialog.starXterminatorCheckBox.checked = false;
        OptionStarXterminator = "OFF";
        console.writeln("⚙️ StarXTerminator disabled.");
        OptionstarNet = "ON";

        console.writeln("Slow Process !!!");
    } else {
        // Si se desactiva StarNet2, activar StarXterminator por defecto
        dialog.starXterminatorCheckBox.checked = true;
        OptionStarXterminator = "ON";
        OptionstarNet = "OFF";

        starRemovalMethodLabel = "Star Removal by StarXterminator";
        console.noteln(starRemovalMethodLabel + " method selected.");

        console.writeln("Fast Process !!!");
    }
};



   // Añadir el nuevo Checkbox para BlurXterminator
    this.blurXterminatorCheckBox = new CheckBox(this);
    this.blurXterminatorCheckBox.text = "Sharpen by BlurXTerminator";
    this.blurXterminatorCheckBox.checked = true;  // Predeterminado activado

    // Añadir el nuevo Checkbox para Highpass
    this.highPassCheckBox = new CheckBox(this);
    this.highPassCheckBox.text = "Sharpen by High pass filter";
    this.highPassCheckBox.checked = false;  // Predeterminado activado




    this.HalphaCheckBox.onClick = function () {

    if (ProjecTypevar !== "RGB" && ProjecTypevar !== "LRGB") {
      console.criticalln("Invalid Project type selected. 'RGB' or 'LRGB' type project, not selected.");
      self.HalphaCheckBox.checked = false;
    return;
    }


    OptionHavar = this.checked ? "ON" : "OFF";
    self.HalphaCheckBox.checked = false;
    //var OptionHSOvar = "OFF";

    // Preguntar si las imágenes RGB están seleccionadas
    let msgBox = new MessageBox("Enable Ha Image for blending?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);

    if (msgBox.execute() === StdButton_Yes) {
        // Llamar a MiraVacioRGB para verificar que no estén vacías
            comboBoxReferences["PimageHa"].enabled = true;
            self.HalphaCheckBox.checked = true;
            OptionHavar = "ON";


    } else {
        // Si el usuario selecciona "No", desmarca el checkbox y actualiza
        comboBoxReferences["PimageHa"].enabled = false;
        self.HalphaCheckBox.checked = false;
        OptionHavar = "OFF";
        self.update();
    }
}; // Fin del checkbox

    this.blurXterminatorCheckBox.onClick = function () {
        OptionBlurXterminator = this.checked ? "ON" : "OFF";


         if (OptionBlurXterminator === "OFF") {
        // Si StarXterminator está apagado, cambiar el texto para usar StarNet2
        self.highPassCheckBox.checked = true;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'OFF'. High pass filter enabled.");

           } else {
        // Si StarXterminator está encendido, usar StarXterminator
         self.highPassCheckBox.checked = false;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'ON'. High pass filter disabled.");
       }
      };


       this.highPassCheckBox.onClick = function () {
        OptionHighpass = this.checked ? "ON" : "OFF";


         if (OptionHighpass === "OFF") {

        self.blurXterminatorCheckBox.checked = true;
         OptionBlurXterminator = "ON";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'ON'. High pass filter disabled.");

           } else {

          self.blurXterminatorCheckBox.checked = false;
         OptionBlurXterminator = "OFF";
        console.noteln("⚙️ Sharpen by BlurXTerminator 'OFF'. High pass filter enabled.");
       }
      };




   // Añadir checkboxes a la segunda columna

    column2Sizer.add(this.OptionVarStarsCheckBox);
    column2Sizer.add(this.starXterminatorCheckBox);
    column2Sizer.add(this.starNetCheckBox);
    column2Sizer.add(this.starsHSOCheckBox);
    column2Sizer.add(this.starsRGBCheckBox);
    column2Sizer.add(this.HalphaCheckBox);
    column2Sizer.add(this.blurXterminatorCheckBox);
    column2Sizer.add(this.highPassCheckBox);



    // Añadir las dos columnas al `HorizontalSizer` del `optionsGroupBox`
    this.optionsGroupBox.sizer.add(column1Sizer);
    this.optionsGroupBox.sizer.addSpacing(20);
    this.optionsGroupBox.sizer.add(column2Sizer);


    // --- Option page ---
    this.optionsPage = new Control(this);
    this.optionsPage.sizer = new VerticalSizer;
    this.optionsPage.sizer.margin = 6;
    this.optionsPage.sizer.spacing = 4;






//-----------------------------------------------------------------------------
//Pestaña Licencia-------------------------------------------------------------
//-----------------------------------------------------------------------------

      // --- Tab 3: License ---
      this.licensePage = new Control(this);
      this.licensePage.sizer = new VerticalSizer;
      this.licensePage.sizer.margin = 10;
      this.licensePage.sizer.spacing = 6;

      let licenseGroupBox = new GroupBox(this.licensePage);
      licenseGroupBox.title = "License Information";
      licenseGroupBox.sizer = new VerticalSizer;
      licenseGroupBox.sizer.margin = 6;
      licenseGroupBox.sizer.spacing = 4;

      let emailLabel = new Label(this);
      emailLabel.text = "Email:";
      emailLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(emailLabel);

      this.emailEdit = new Edit(this);
      this.emailEdit.minWidth = 300;
      this.emailEdit.text = "";  // Inicializar con una cadena vacía o algún valor por defecto
      this.emailEdit.enabled = false;
      licenseGroupBox.sizer.add(this.emailEdit);

      let codeLabel = new Label(this);
      codeLabel.text = "Code:";
      codeLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(codeLabel);

      this.codeEdit = new Edit(this);
      this.codeEdit.minWidth = 300;
      this.codeEdit.text = "";  // Inicializar con una cadena vacía
      this.codeEdit.enabled = false;
      licenseGroupBox.sizer.add(this.codeEdit);

      let PathcodeLabel = new Label(this);
      PathcodeLabel.text = "Path: " +  originalFilePath;
      PathcodeLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(PathcodeLabel);

      this.PathcodeEdit = new Edit(this);
      this.PathcodeEdit.minWidth = 300;
      this.PathcodeEdit.text = "";  // Inicializar con una cadena vacía
      this.PathcodeEdit.enabled = false;
      licenseGroupBox.sizer.add(this.PathcodeEdit);

      let NotaLabel = new Label(this);
      NotaLabel.text = "* Windows O.S. users: PixInsight must be running as Administrator.";
      NotaLabel.textAlignment = TextAlign_Left;
      licenseGroupBox.sizer.add(NotaLabel);




      // Llamada a ReadLicenseFile después de que los campos se han creado
      let self = this;
      let filePath = originalFilePath;

      VarPGlobal2 = ReadLicenseFile(filePath, self, null, null, null, VarPGlobal2, VarPGlobal3, VarPGlobal4);



      let EspacioLabel = new Label(this);
      EspacioLabel.text = "";
      EspacioLabel.textAlignment = TextAlign_Left ;
      licenseGroupBox.sizer.add(EspacioLabel);

      // Crear una sizer horizontal para los botones "Edit" y "Validate"
      let buttonSizer = new HorizontalSizer;
      buttonSizer.spacing = 6;  // Espaciado entre los botones


      let EditvalidateButton = new PushButton(this);
      EditvalidateButton.text = "Edit";
      EditvalidateButton.icon = this.scaledResource( ":/icons/pencil.png" );
      EditvalidateButton.setFixedWidth(150);
      buttonSizer.add(EditvalidateButton);

          EditvalidateButton.onClick = function () {

             let msgBox = new MessageBox(
             "Editing License Process\nDo you want to continue?",  // Message text
             "Confirmation",  // Title
             StdIcon_Question,  // Question icon
             StdButton_Yes, StdButton_No  // Yes/No buttons
             );

             let result = msgBox.execute();  // Show the MessageBox and capture the result

             // If the user clicks 'Yes', proceed with writing the license file
             if (result === StdButton_Yes) {
                EditvalidateButton.enabled  =false;
               console.noteln("\n💾"+ " Editing License...");
                self.emailEdit.enabled = true;
                self.codeEdit.enabled = true;
                validateButton.enabled = true;


              } else {
                  self.emailEdit.enabled = false;
                  self.codeEdit.enabled = false;
                  self.PathcodeEdit.enabled = false;
              }
              };

              let validateButton = new PushButton(this);
              validateButton.text = "Validate";
              validateButton.icon = this.scaledResource( ":/icons/ok.png" );
              validateButton.setFixedWidth(150);
              validateButton.enabled = false;
              buttonSizer.add(validateButton);
              validateButton.onClick = function () {




             // Usamos 'self' para capturar correctamente los valores de los campos de texto
              let email = self.emailEdit.text ? self.emailEdit.text.trim() : "";
              let code = self.codeEdit.text ? self.codeEdit.text.trim() : "";
              let path = self.PathcodeEdit.text ? self.PathcodeEdit.text.trim() : "";

               // Asegurarse de que los campos no estén vacíos
                if (email === "" || code === "" || path === "") {
               console.criticalln("Error: Both Email and Code fields must be filled.");
               return;
                  }


               if (isValidKeyFromCode(code, OptionAdjvalue2)) {
                   console.noteln("\n✅ " + code);

               } else {
                   console.warningln("⚠️ License validation failed. Please check your license code.");
                   let messageBox = new MessageBox(
                  "License validation failed.\nPlease check your license code.", // Message
                   "Error", // Title
                   StdIcon_Error, // Icon
                   StdButton_Ok // Buttons
                );
                   messageBox.execute(); // Display the message box
                   return;
               }
               //
               console.writeln("License File Path: " + originalFilePath);

              // Primero, mostrar el diálogo "Save As" y luego proceder con la escritura del archivo
               let filePath = MiraSaveAs(originalFilePath);  // Mostrar el cuadro de diálogo "Save As"
               if (filePath) {
                // Si el usuario selecciona una ubicación, continuar con el guardado
                console.noteln("\n💾"+" Saving license file...");

                   let originalFilePath = filePath;  // Actualizar la ruta del archivo con la ruta seleccionada
                   let path = filePath;  // Definir 'path' como la ruta seleccionada por el usuario


            // Llamada a la función para escribir el archivo de licencia
                let newPath = WriteLicenseFile(originalFilePath, email, code, originalFilePath);  // Guardar el archivo y devolver la ruta

                if (newPath) {
                 // Actualizar el campo con la ruta
                 self.PathcodeEdit.text = newPath;
                 EditvalidateButton.enabled = true;  // Habilitar el botón de validación
                } else {
                 console.criticalln("\n⚠️"+ " Error saving the license file.");
                }

            } else {
             // Si el usuario cancela la operación
          console.criticalln("\n❌"+ " Save operation aborted.");
          validateButton.enabled = false;
          EditvalidateButton.enabled = true;

         }

     };





//Fin File import

      licenseGroupBox.sizer.add(buttonSizer);
      licenseGroupBox.adjustToContents();  // Ajustamos el grupo al contenido

      //
      // Crear el GroupBox para "License Activation"
      let licenseActivationGroupBox = new GroupBox(this.licensePage);
      licenseActivationGroupBox.title = "License Activation";
      licenseActivationGroupBox.sizer = new VerticalSizer;
      licenseActivationGroupBox.sizer.margin = 6;
         licenseActivationGroupBox.sizer.spacing = 4;


      if (Optiontimevar >= 80){

             //Optiontimevar = "Beta Licensed Script";
      }else{
          if (Optiontimevar <= 30){
             console.writeln("Get your activation license for free");
          }
      }

      // Añadir el texto de información sobre la activación de la licencia
      let activationInfoLabel = new Label(this);
      activationInfoLabel.useRichText = true; // Permitir HTML en el texto
      activationInfoLabel.text =
      "" + ProjecTname + " " + ProjecTver + "<br>" +
      "Remaining days:</b> " + Optiontimevar + "<br>" +
      "Written by Jesús Manuel García Flores<br>" +
      "Get your activation license for free: <a href=\"https://www.teoriadelcolor.es/astroprocessor\">www.teoriadelcolor.es/astroprocessor</a>";
      activationInfoLabel.textAlignment = TextAlign_Center;
      licenseActivationGroupBox.sizer.add(activationInfoLabel);
      // Añadir el GroupBox "License Activation" debajo del "License Information"

      //
      this.licensePage.sizer.add(licenseGroupBox);

      //this.licensePage.sizer.add(licenseImportGroupBox);

      // **Nuevo GroupBox llamado "Information" debajo del "License Information"**
      let informationGroupBox = new GroupBox(this.licensePage);
      informationGroupBox.title = "Information";
      informationGroupBox.sizer = new VerticalSizer;
      informationGroupBox.sizer.margin = 6;
      informationGroupBox.sizer.spacing = 4;  // Espaciado vertical reducido

      // Añadir etiquetas y campos adicionales si es necesario
      let infoLabel = new Label(this);
      infoLabel.text = "Script Information:\nIn order the script work fine, you need to be installed:\n\nRemove Stars:\n- Starnet (free - www.starnetastro.com)\n- StarXTerminator (www.rc-astro.com) - Optional\n* One of them must be installed\n\nNoise Reduction:\n- GraXpert (free - https://graxpert.com)\n- NoiseXTerminator (www.rc-astro.com) - Optional\n* One of them must be installed\n\nSharpen:\n- BlurXTerminator (www.rc-astro.com) - Optional\n- High pass filter - Included in the script\n";
      infoLabel.textAlignment = TextAlign_Left ;
      informationGroupBox.sizer.add(infoLabel);


      // Añadir el nuevo GroupBox "Information" a la página, debajo del de "License"
      this.licensePage.sizer.add(informationGroupBox);

      // Ajustes finales para que el contenido se ajuste
      licenseGroupBox.adjustToContents();
      // Añadir el GroupBox "License Activation" debajo del "License Information"
      this.licensePage.sizer.add(licenseActivationGroupBox);

      this.licensePage.sizer.add(informationGroupBox);
      informationGroupBox.adjustToContents();

      this.licensePage.adjustToContents();



//-----------------------------------------------------------------------------
//Añadir Pestañas--------------------------------------------------------------
//-----------------------------------------------------------------------------

    // Agregar la pestaña License al TabBox

    this.tabBox.addPage(this.integrationPage, "Integration");
    //this.tabBox.addPage(this.optionsPage2, "Color");
    //this.tabBox.addPage(this.optionsPage, "Tools");
    //this.tabBox.addPage(this.starPage, "Stars");
    this.tabBox.addPage(this.licensePage, "License");



      // --- Horizontal Sizer to hold Project Type and Alignment GroupBoxes ---
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.spacing = 10; // Espacio entre los dos grupos horizontales


      // Create VerticalSizer for each group to tightly manage layout
      let CropprojectTypeSizer = new VerticalSizer;
      CropprojectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      CropprojectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      CropprojectTypeSizer.add(this.CropprojectTypeGroupBox);

      // Create VerticalSizer for each group to tightly manage layout
      let projectTypeSizer = new VerticalSizer;
      projectTypeSizer.margin = 0;  // Remove any margin to reduce extra spacing
      projectTypeSizer.spacing = 10;  // Set appropriate spacing between elements
      projectTypeSizer.add(this.projectTypeGroupBox);

      let alignmentSizer = new VerticalSizer;
      alignmentSizer.margin = 0;  // Remove any margin to reduce extra spacing
      alignmentSizer.spacing = 10;  // Set appropriate spacing between elements
      //alignmentSizer.add(this.alignmentGroupBox);

      // Create HorizontalSizer to put both projectTypeSizer and alignmentSizer side by side
      let projectAndAlignmentSizer = new HorizontalSizer;
      projectAndAlignmentSizer.margin = 0;  // Ensure no extra margin is added around the group boxes
      projectAndAlignmentSizer.spacing = 10;  // Space between the two group boxes
      projectAndAlignmentSizer.add(projectTypeSizer);
      projectAndAlignmentSizer.add(CropprojectTypeSizer);
      projectAndAlignmentSizer.add(alignmentSizer);

      // Agregar el HorizontalSizer al sizer de la integración
      this.integrationPage.sizer.add(projectAndAlignmentSizer);

      // --- Añadir el Tagging GroupBox directamente después del Horizontal Sizer ---
      this.integrationPage.sizer.add(this.taggingGroupBox);

      // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(this.optionsGroupBox);



      // --- RUN Button ---
      this.runButton = new PushButton(this.integrationPage);
      this.runButton.text = "Run";
      this.runButton.icon = this.scaledResource(":/icons/play.png");
      this.runButton.toolTip = "Select a Project type\nSelect an Alignment\nSelect images\nSelect Integration options\nand click RUN";
      this.runButton.setFixedWidth(102);
      this.runButton.setFixedHeight(WindowsOsx1);





      this.workingLabel = new Label(this.integrationPage);
      this.workingLabel.text = "";


      // Crear un sizer horizontal
      let horizontalSizer = new HorizontalSizer;
      horizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
      horizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes


      // Añadir el botón y la etiqueta al sizer horizontal
      horizontalSizer.add(this.workingLabel);


     // Añadir el sizer horizontal a la página de integración
      this.integrationPage.sizer.add(horizontalSizer);

      // Crear un sizer horizontal
      let vhorizontalSizer = new VerticalSizer;
      vhorizontalSizer.spacing = 5;  // Añadir algo de espacio entre el botón y la etiqueta
      vhorizontalSizer.margin = 0;  // Ensure no extra margin is added around the group boxes

      // Crear el GroupBox para "Pro Options"
      let ColorGroupBox = new GroupBox();


      // Crear el botón "SORT"
      this.SortButton = new PushButton(ColorGroupBox);
      this.SortButton.text = "Arrange";
      this.SortButton.icon = this.scaledResource( ":/icons/queries.png" );
      this.SortButton.setFixedWidth(102);
      this.SortButton.setFixedHeight(WindowsOsx1);
      this.SortButton.enabled = true;


      this.SortButton.toolTip = "Sort all image windows in a cascade order";

      // Evento onClick para ordenar las ventanas en cascada
      this.SortButton.onClick = function() {
          MiraOrdena1();  // Llama a la función para ordenar las ventanas
      };

     // Crear el botón "Iconizar"
      this.Iconize2 = new PushButton(ColorGroupBox);
      this.Iconize2.text = "Minimize";
      this.Iconize2.icon = this.scaledResource( ":/icons/tree.png" );
      this.Iconize2.setFixedWidth(102);
      this.Iconize2.setFixedHeight(WindowsOsx1);
      this.Iconize2.toolTip = "Iconized all image windows";

      // Crear el botón "Reiniciar Projecto"
      this.Iconize3 = new PushButton(ColorGroupBox);
      this.Iconize3.text = "Trash";
      this.Iconize3.icon = this.scaledResource( ":/icons/trash.png" );
      this.Iconize3.setFixedWidth(102);
      this.Iconize3.setFixedHeight(WindowsOsx1);
      this.Iconize3.toolTip = "Delete actual project";
      if (VarPGlobal2 === VarPGlobal3){self.runButton.enabled = false;}

      // Crear el botón "MGC"
      this.Iconize6 = new PushButton(ColorGroupBox);
      this.Iconize6.text = "";
      this.Iconize6.icon = this.scaledResource( ":/icons/process.png" );
      this.Iconize6.setFixedWidth(102);
      this.Iconize6.setFixedHeight(WindowsOsx1);
      this.Iconize6.toolTip = "Multiscale Gradient Correction Preferences";

      // Capturar el contexto de `this`
      let self = this;
      //
      this.runButton.onClick = function () {


     //Mira RGB Stars
     if (Option1var !== "OFF"){
      if (MiraVacioRGB()) {
            // Continuar con el proceso si las imágenes RGB están correctamente seleccionadas
            console.writeln("RGB images are found and selected.");
             Option1var = "ON";
        } else {
            // Si alguna imagen está vacía, no continúa
            self.starsRGBCheckBox.checked = false;
            Option1var = "OFF";
            self.update();
            return;
        }
     }


      console.noteln("🟢" +" Initializing Script...");

      //if (!MiraCheckWindowsABE()) {
      //  console.noteln("\nReady to work...\n");
        // Detener la ejecución si MiraCheckWindowsABE() falla
        // return;
      //}

      let msgBox = new MessageBox("Do you want to Run the Script?", "Confirmation", StdIcon_Question, StdButton_Yes, StdButton_No);
      if (msgBox.execute() === StdButton_Yes) {

        let startTime = Date.now();

        console.noteln("🚀" + "Launching Script...");
        // Cambiar el color del texto a rojo
        dialog.workingLabel.foregroundColor = 0xFF0000;  // Color rojo (en formato RGB hexadecimal)
        dialog.workingLabel.update();

        // Validate the assignments
         if (!validateProjectImageAssignments(ProjecTypevar)) {
          console.criticalln("\n❌ Validation failed. Please select images.");
          return;
         } else {
          console.writeln("\nValidation passed. Proceeding with the project.");
         }

        dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/12. Please wait... ";
        MiraProyecto();

        //Ejecuta MARS
        if (OptionMgc ==="ON") {
           console.noteln("🚀" + "Launching MARS databases...");
           if (MarsFound1 === "ON" && MarsFound2 === "ON"){
              dialog.workingLabel.text = "🚀" + "Launching Multiscale Gradient Correction process. Please wait... ";
              console.noteln("🚀" + "Launching Multiscale Gradient Correction process...\n");
              let  selectedSensorIndex = SensorName;
              let narrowbandEnabled = Narrowband;
              let defaultPathMars = originalFilePathMars1;
              let defaultPathMars2 = originalFilePathMars2;
              let defaultPathMars3 = originalFilePathMars3;

              console.writeln("⚙️ Sensor name: " + SensorName);
              console.writeln("⚙️ Narrowband option: " + narrowbandEnabled);
              console.writeln("⚙️ MARS-DR1-1.0.3.xmars: \n" + originalFilePathMarsfin1);


              if (MarsFound3 === "ON"){
              console.writeln("⚙️ MARS-DR1-1.1.1.xmars: \n" + originalFilePathMarsfin3);
                 } else {
              console.writeln("⚙️ MARS-DR1-u01-1.0.1.xmars: \n" + originalFilePathMarsfin2);
              }



              MiraMgcProcesos(narrowbandEnabled, selectedSensorIndex, defaultGrayWavelength, defaultGrayBandwidth, defaultRedWavelength, defaultRedBandwidth, defaultGreenWavelength, defaultGreenBandwidth, defaultBlueWavelength, defaultBlueBandwidth, originalFilePathMarsfin1, originalFilePathMarsfin2, originalFilePathMarsfin3 );



           }else{
           console.warningln("Skipping Multiscale Gradient Correction. Not databases founded.");
           //continúa el proceso
          }
        }

        //continúa con el proceso

        dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/12. Please wait... ";

            if (MiraVentana()) {

            //Cuando todo es correcto.
            self.runButton.enabled = false;
            self.SortButton.enabled = false;
            self.Iconize2.enabled = false;
            self.Iconize3.enabled = false;
            self.Iconize6.enabled = false;
            self.exitButton.enabled = false;


            //Desactiva el proyecto actual.
            if (ProjecTypevar === "LRGB"){
               self.projectLRGBRadioButton.enabled = false;
            } else if (ProjecTypevar === "RGB"){
               self.projectRGBRadioButton.enabled = false;
            } else if (ProjecTypevar === "SHO"){
               self.projectSHORadioButton.enabled = false;
               } else if (ProjecTypevar === "HOO"){
               self.projectHOORadioButton.enabled = false;
               } else if (ProjecTypevar === "OSC"){
               self.projectOSCRadioButton.enabled = false;
            }

           if (self.starsRGBCheckBox.checked === true){
              self.projectLRGBRadioButton.enabled = false;
              self.projectRGBRadioButton.enabled = false;
              }


            //Starting Process
            dialog.workingLabel.text = "🚀" + "Launching Process: [1 to 4]/9. Please wait... ";
            MiraRenombre();
            dialog.workingLabel.text = "🚀" + "Launching  Process: [1 to 4]/9. Please wait... ";


            // Verificación de tipo de proyecto
            if (ProjecTypevar !== "OSC") {
                if (MiraAlignTotal()) {
                    console.writeln("Alignment process completed successfully.");
                } else {
                    console.criticalln("Exiting script due to alignment failure...");
                    return; // Detener la ejecución si falla la alineación
                }
            } else {
                console.noteln("OSC Project - No Alignment process needed.");
            }

            // Continuar con el proceso si la alineación fue exitosa o si el proyecto es OSC
            dialog.workingLabel.text = "🚀 Step 5/9. Main process, Please wait... ";
            MiraProcesoGeneral01(OptionABE);
            dialog.workingLabel.text = "🚀 Step 6/9. Please wait... ";
            MiraChannelCom();  // Ejecuta MiraChannelCom solo si el proyecto no es OSC
            dialog.workingLabel.text = "🚀 Step 7/9. Please wait... ";
            MiraGreen(); // Elimina el verde de la imagen activa
            dialog.workingLabel.text = "🚀 Step 8/9. Please wait... ";
            console.show();


            if (OptionVarStars === "ON") {
                console.noteln("\n✅ Creating Starless Final Image");

                if (OptionHSOvar === "ON") { // ¿Creamos capa de estrellas RGB o SHO/HOO?
                    if (Option1var === "ON") {
                        if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching RGB stars process.");
                              MiraRGBStars(OptionABE, OptionRemaind);
                              } else {
                              console.noteln("\n🟢" + "Fast Integration process 'ON'. Skipping RGB stars process.");
                              }
                    } else {
                        if (ProjecTypevar ==="OSC"  && OptionStarXterminator === "OFF"){
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars2(OptionABE, OptionRemaind);

                              }
                        }else{
                              if (OptionFast ==="OFF"){
                              console.noteln("\n🚀" + "Launching project stars process.");
                              MiraSHOStars(OptionABE, OptionRemaind);

                              }
                        }
                    }
                } // fin de OptionHSOvar
            } else {
                console.noteln("Skipping Create Starless Final Image");
            }
            console.show();

            //Mira HAlpha
            if (OptionHavar ==="ON"){
               let imageWindow = "Filter_Ha_registered_ABE";
               let BlendwindowOption = "Final_starless";
               let OptionSharpenNonstellar = 3;
               MiraHaBlend2(imageWindow, BlendwindowOption, OptionSharpenNonstellar);
            }

            dialog.workingLabel.text = "🚀 Step 9/9. Please wait... ";


              if (OptionVarStars === "OFF"){
                                let windows = ImageWindow.windows;
                                for (let i = 0; i < windows.length; i++) {
                                let targetWindow = windows[i];

                           if (targetWindow.mainView.id === "Final_starless") {
                           targetWindow.mainView.id = "Final_image";
                           console.writeln("✅ Window renamed successfully.");

                            break; // Salimos del bucle al encontrar la ventana
                         }
                   }
               }


            MiraRenProyectos(); //renombra con el proyecto
            MiraResolFinal(); // Ejecuta la resolución final
            MirashowTotalTime(startTime);
            Option2var2 = "ON"; // Actualiza para el Botón OK

            MiraBorraVentanas();

            MiraOrdena1();


            OptionRemaind2 = "null";
            OptionEnabledPreview ==="OFF";
            console.noteln("\n✅" + " End Script...");
            self.runButton.enabled = true;
            self.SortButton.enabled = true;
            self.Iconize2.enabled = true;
            self.Iconize3.enabled = true;
            self.Iconize6.enabled = true;
            self.exitButton.enabled = true;
            //


        } else {
            console.criticalln("Exiting script due to wrong window selection or project type...");
        }
    } else {
        console.warningln("\nFinished script...");
    }
};
// Fin del botón Run


      this.SortButton.onClick = function() {
          MiraOrdena1();
      };


      this.Iconize2.onClick = function() {
          MiraIconiza2();
      };



      this.Iconize3.onClick = function() {
               //Activa los proyectos

               self.projectLRGBRadioButton.enabled = true;
               self.projectRGBRadioButton.enabled = true;
               self.projectSHORadioButton.enabled = true;
               self.projectHOORadioButton.enabled = true;
               self.projectOSCRadioButton.enabled = true;

          MiraCheckWindowsTrash();
          MiraOrdena1();


      };





 this.Iconize6.onClick = function() {

      let dialog = new MgcImagesDialog(originalFilePathMarsfin1, originalFilePathMarsfin2, SensorName);
      dialog.execute();
   }






// Primera fila con Run, Arrange, Minimize, Trash centrados
let topButtonRow = new HorizontalSizer;
topButtonRow.spacing = 10; // espacio entre botones
topButtonRow.add(this.runButton);
topButtonRow.add(this.SortButton);
topButtonRow.add(this.Iconize2);
topButtonRow.add(this.Iconize3);
topButtonRow.alignment = 0.5; // centra los botones horizontalmente


// Añadir las dos filas al sizer principal de la pestaña con espacio vertical
this.integrationPage.sizer.add(topButtonRow);


//-----------------------------------------------------------------------------
//Fondo de Ventana-------------------------------------------------------------
//-----------------------------------------------------------------------------




     // --- EXIT Button ---
     this.exitButton = new PushButton(this);
     this.exitButton.text = "Exit";
     this.exitButton.icon = this.scaledResource( ":/icons/close.png" );
     this.exitButton.setFixedWidth(100);  // Set the width of the combo box
     this.exitButton.setFixedHeight(WindowsOsx1);


     this.exitButton.onClick = function () {

        this.dialog.cancel();
    };



      // Crear el CheckBox para Show console
      let showConsoleCheckBox = new CheckBox;
      showConsoleCheckBox.text = "Show console";
      showConsoleCheckBox.checked = true; // Opción por defecto

      // Manejar el evento onCheck para mostrar u ocultar la consola
      showConsoleCheckBox.onCheck = function (checked) {
          if (checked) {
              OptionshowConsolRadio = "ON";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.show(); // Mostrar la consola
          } else {
              OptionshowConsolRadio = "OFF";
           console.writeln("Show console: " + OptionshowConsolRadio);
           console.hide(); // Ocultar la consola
          }
      };


    this.exitButton.setFixedWidth(200);

    // Sizer para HELP y EXIT en la misma línea
    this.helpExitSizer = new HorizontalSizer;
    this.helpExitSizer.spacing = 10;
    this.helpExitSizer.add(this.Iconize6);
    this.helpExitSizer.addStretch();

    this.helpExitSizer.add(showConsoleCheckBox);
    this.helpExitSizer.addStretch();
    this.helpExitSizer.add(this.exitButton);

    // Sizer principal
    this.sizer = new VerticalSizer;
    this.sizer.margin = 10;
    //this.sizer.spacing = 10;

    this.sizer.add(this.tabBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.helpExitSizer);
    this.sizer.addSpacing(10);

    this.windowTitle = ProjecTname;


}



IntegratorDialog.prototype = new Dialog;

let dialog = new IntegratorDialog();
// Hacer que la ventana de diálogo sea redimensionable
IntegratorDialog.prototype.resizeable = true;

//

this.actualizarComboBoxesDesdeGUI = function () {
    let self = this; // Asegura referencia correcta al contexto del diálogo

    let windows = ImageWindow.windows;

    function actualizarCombo(comboBox) {
        if (!comboBox)
            return;

        comboBox.clear();
        comboBox.addItem("<Select an Image>");

        for (let i = 0; i < windows.length; ++i) {
            let id = windows[i].mainView.id;
            comboBox.addItem(id);
        }

        comboBox.currentItem = 0; // Resetea la selección
    }

    actualizarCombo(self.imageSelector1);
    actualizarCombo(self.imageSelector2);
    actualizarCombo(self.imageSelector3);
    actualizarCombo(self.comboHa);
    actualizarCombo(self.comboOiii);
    actualizarCombo(self.comboSii);
    actualizarCombo(self.comboRed);
    actualizarCombo(self.comboGreen);
    actualizarCombo(self.comboBlue);
    actualizarCombo(self.comboLuminance);
    actualizarCombo(self.comboOSC);

    processEvents(); // Refresca interfaz
    gc(true);
};
//
dialog.execute();


